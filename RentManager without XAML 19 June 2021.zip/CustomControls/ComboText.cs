﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;

namespace RentManager.CustomControls
{
    class ComboText : FrameworkElement
    {
        EditText box;
        TextBlock block;
        Run text;
        VisualCollection children;
        
        public string Hint { get; set; }
        public string Icon { get; set; }
        public string Editable { get; set; }
        public string NonEditable { get; set; }
        public string StringFormat { get; set; }
        public string Error { get; set; }
        public bool IsRequired { get; set; }
        public bool IsMultiline { get; set; }

        public ComboText() { 
            text = new Run() { FontSize = 12 };
            block = new TextBlock();
            box = new EditText() { Visibility = Visibility.Hidden };
            children = new VisualCollection(this) { box, block };
            Loaded += onLoaded;
            Unloaded += onUnloaded;
        }

        void onUnloaded(object sender, RoutedEventArgs e) {
            Loaded -= onLoaded;
            Unloaded -= onUnloaded;
        }
        void onLoaded(object sender, RoutedEventArgs e) {
            
            if(StringFormat != null) 
                text.SetBinding(Run.TextProperty, new Binding(NonEditable) { StringFormat = StringFormat});
            
            else text.SetBinding(Run.TextProperty, new Binding(NonEditable));
            block.Inlines.Add(new Run() {
                Foreground = Brushes.Gray,
                FontStyle = FontStyles.Italic,
                FontSize = 11,
                Text = Hint
            });
            block.Inlines.Add(new LineBreak());
            block.Inlines.Add(text);

            box.Hint = Hint;
            box.Icon = Icon;
            if (IsRequired) {
                box.IsRequired = true;
                box.SetBinding(EditText.ErrorProperty, new Binding(Error));
            }
            if (IsMultiline) box.IsMultiline = true;
            box.SetBinding(EditText.TextProperty, new Binding(Editable));
        }
        protected override Size MeasureOverride(Size availableSize) {
            foreach (FrameworkElement item in children) 
                item.Measure(availableSize);
            return box.DesiredSize;
        }
        protected override Size ArrangeOverride(Size finalSize) {
            foreach (FrameworkElement item in children) 
                item.Arrange(new Rect(item.DesiredSize));
            return finalSize;
        }
        protected override Visual GetVisualChild(int index) => children[index];
        protected override int VisualChildrenCount => children.Count;

        public bool IsOnEdit {
            get { return (bool)GetValue(IsOnEditProperty); }
            set { SetValue(IsOnEditProperty, value); }
        }
        public static readonly DependencyProperty IsOnEditProperty =
            DependencyProperty.Register("IsOnEdit", typeof(bool), typeof(ComboText), new PropertyMetadata() { 
                DefaultValue = false,
                PropertyChangedCallback = (s,e) => {
                    var o = (ComboText)s;
                    if((bool)e.NewValue) {
                        o.box.Visibility = Visibility.Visible;
                        o.block.Visibility = Visibility.Hidden;
                    }
                    else {
                        o.box.Visibility = Visibility.Hidden;
                        o.block.Visibility = Visibility.Visible;
                    }
                }
            });
    }
}
