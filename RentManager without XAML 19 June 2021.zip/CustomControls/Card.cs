﻿using RentManager.Helpers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Effects;

namespace RentManager.CustomControls
{
    class Card : FrameworkElement
    {
        Grid container;
        TextBlock headerBlock;
        Separator divider;
        Border border;
        FrameworkElement content;
        public FrameworkElement Content {
            get { return content; }
            set {
                content = value;
                Grid.SetRow(value, 2);
                container.Children.Add(value);
            }
        }
        string header;
        public string Header {
            get { return header; }
            set {
                header = value;
                headerBlock.Text = value;
                headerBlock.Visibility = Visibility.Visible;
                divider.Visibility = Visibility.Visible;
            }
        }

        public Card() {
            Margin = Constants.CardMargin;
            headerBlock = new TextBlock() {
                FontSize = 24,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.LightGray,
                Visibility = Visibility.Collapsed
            };
            divider = new Separator() {
                Margin = new Thickness(0, 0, 0, 5),
                Background = Brushes.LightGray,
                Visibility = Visibility.Collapsed
            };
            Grid.SetRow(divider, 1);
            container = new Grid() {
                RowDefinitions = {
                    new RowDefinition(){Height = GridLength.Auto},
                    new RowDefinition(){Height = GridLength.Auto},
                    new RowDefinition()
                },
                Children = { headerBlock, divider }
            };
            border = new Border() {
                Padding = new Thickness(5),
                CornerRadius = new CornerRadius(5),
                Background = Brushes.White,
                Effect = new DropShadowEffect() { BlurRadius = 10, ShadowDepth = 0 },
                Child = container
            };
            AddVisualChild(border);
        }
        protected override Size MeasureOverride(Size availableSize) {
            border.Width = availableSize.Width;
            border.Height = availableSize.Height;
            border.Measure(availableSize);
            return border.DesiredSize;
        }
        protected override Size ArrangeOverride(Size finalSize) {
            border.Arrange(new Rect(border.DesiredSize));
            return finalSize;
        }
        protected override Visual GetVisualChild(int index) => border;
        protected override int VisualChildrenCount => 1;
    }
}
