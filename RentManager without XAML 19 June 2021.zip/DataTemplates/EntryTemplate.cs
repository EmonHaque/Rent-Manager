﻿using RentManager.CustomControls;
using RentManager.Helpers;
using RentManager.Models;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;

namespace RentManager.DataTemplates
{
    class EntryTemplate : DataTemplate
    {
        public EntryTemplate(Binding command) {
            var grid = new FrameworkElementFactory(typeof(Grid));
            var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var col4 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var col5 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var date = new FrameworkElementFactory(typeof(TextBlock));
            var particulars = new FrameworkElementFactory(typeof(TextBlock));
            var amount = new FrameworkElementFactory(typeof(TextBlock));
            var isCash = new FrameworkElementFactory(typeof(BiState));
            var button = new FrameworkElementFactory(typeof(DependencyButton<Transaction>));

            var control = new FrameworkElementFactory(typeof(Run));
            var plot = new FrameworkElementFactory(typeof(Run));
            var space = new FrameworkElementFactory(typeof(Run));
            var tenant = new FrameworkElementFactory(typeof(Run));
            var colon1 = new FrameworkElementFactory(typeof(Run));
            var colon2 = new FrameworkElementFactory(typeof(Run));
            var colon3 = new FrameworkElementFactory(typeof(Run));

            col1.SetValue(ColumnDefinition.WidthProperty, new GridLength(1, GridUnitType.Auto));
            col3.SetValue(ColumnDefinition.WidthProperty, new GridLength(100));
            col4.SetValue(ColumnDefinition.WidthProperty, new GridLength(1, GridUnitType.Auto));
            col5.SetValue(ColumnDefinition.WidthProperty, new GridLength(1, GridUnitType.Auto));
            particulars.SetValue(Grid.ColumnProperty, 1);
            amount.SetValue(Grid.ColumnProperty, 2);
            isCash.SetValue(Grid.ColumnProperty, 3);
            button.SetValue(Grid.ColumnProperty, 4);
            control.SetValue(Run.FontWeightProperty, FontWeights.Bold);
            plot.SetValue(Run.FontWeightProperty, FontWeights.Bold);
            colon1.SetValue(Run.TextProperty, " : ");
            colon2.SetValue(Run.TextProperty, " : ");
            colon3.SetValue(Run.TextProperty, " : ");

            date.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
            particulars.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
            particulars.SetValue(TextBlock.MarginProperty, new Thickness(5, 0, 0, 0));
            particulars.SetValue(TextBlock.TextWrappingProperty, TextWrapping.Wrap);
            amount.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
            amount.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
            isCash.SetValue(BiState.VerticalAlignmentProperty, VerticalAlignment.Center);
            isCash.SetValue(BiState.IsEnabledProperty, false);

            date.SetBinding(TextBlock.TextProperty, new Binding(nameof(Transaction.Date)) { StringFormat = "dd MMM yyyy" });
            amount.SetBinding(TextBlock.TextProperty, new Binding(nameof(Transaction.Amount)) { StringFormat = "N0" });
            isCash.SetBinding(BiState.IsTrueProperty, new Binding(nameof(Transaction.IsCash)));

            button.SetValue(DependencyButton<Transaction>.WidthProperty, 16d);
            button.SetValue(DependencyButton<Transaction>.HeightProperty, 16d);
            button.SetValue(DependencyButton<Transaction>.MarginProperty, new Thickness(10, 2, 0, 2));
            button.SetValue(DependencyButton<Transaction>.IconProperty, Icons.Minus);
            button.SetBinding(DependencyButton<Transaction>.CommandProperty, command);
            button.SetBinding(DependencyButton<Transaction>.ParameterProperty, new Binding("."));

            control.SetBinding(Run.TextProperty, new Binding(nameof(Transaction.ControlId)) { Converter = Converters.controlId2ControlName });
            plot.SetBinding(Run.TextProperty, new Binding(nameof(Transaction.PlotId)) { Converter = Converters.plotId2plotName });
            space.SetBinding(Run.TextProperty, new Binding(nameof(Transaction.SpaceId)) { Converter = Converters.spaceId2spaceName });
            tenant.SetBinding(Run.TextProperty, new Binding(nameof(Transaction.TenantId)) { Converter = Converters.tenantId2TenantName });

            particulars.AppendChild(control);
            particulars.AppendChild(colon1);
            particulars.AppendChild(plot);
            particulars.AppendChild(colon2);
            particulars.AppendChild(space);
            particulars.AppendChild(colon3);
            particulars.AppendChild(tenant);

            grid.AppendChild(col1);
            grid.AppendChild(col2);
            grid.AppendChild(col3);
            grid.AppendChild(col4);
            grid.AppendChild(col5);
            grid.AppendChild(date);
            grid.AppendChild(particulars);
            grid.AppendChild(amount);
            grid.AppendChild(isCash);
            grid.AppendChild(button);

            grid.SetBinding(Grid.ToolTipProperty, new Binding(nameof(Transaction.Narration)));

            VisualTree = grid;
        }
    }
}
