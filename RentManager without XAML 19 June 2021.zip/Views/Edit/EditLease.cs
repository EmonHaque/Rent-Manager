﻿using RentManager.Abstracts;
using RentManager.CustomControls;
using RentManager.DataTemplates;
using RentManager.Enums;
using RentManager.Helpers;
using RentManager.Models;
using RentManager.ViewModel.Edit;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;

namespace RentManager.Views.Edit
{
    class EditLease : CardView
    {
        public override string Icon => Icons.Lease;
        public override string Header => "Lease";

        SelectItem nonEditablePlots, receivableHeads;
        ListBox leaseList;
        ComboSelect plot, space, tenant;
        ComboText business;
        ComboBiState isExpired;
        ComboDate startDate, endDate;
        Grid expireGrid;
        ComboButton buttons;
        ItemsControl receivables, editableReceivables;
        EditText receivableAmount;
        CommandButton addReceivable;
        Separator divider;
        TextBlock chargesBlock;
        Grid receivableGrid;
        Run errorCharges;
        EditText search;
        TriState filter;
        CountBlock counter;
        EditLeaseVM viewModel;
       
        public EditLease() {
            viewModel = new EditLeaseVM();
            DataContext = viewModel;
            initializeUI();
            bind();
        }
        
        void initializeUI() {
            nonEditablePlots = new SelectItem() {
                Hint = "Plot",
                IsRequired = true,
                Icon = Icons.Plot,
                SelectedValuePath = nameof(Plot.Id),
                DisplayPath = nameof(Plot.Name),
                FilterParameter = SelectQuery.NonEditable,
                FilterCommand = viewModel.FilterCommand
            };
            search = new EditText() {
                Icon = Icons.Search,
                Hint = "Search",
                IsTrimBottomRequested = true
            };
            filter = new TriState() {
                CheckedTip = "Active",
                UncheckedTip = "Expired",
                UndefinedTip = "All",
                VerticalAlignment = VerticalAlignment.Center
            };
            counter = new CountBlock() {
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(5, 0, 0, 0)
            };
            Grid.SetColumn(filter, 1);
            Grid.SetColumn(counter, 2);
            var searchGrid = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto }
                },
                Children = { search, filter, counter }
            };
            Grid.SetRow(searchGrid, 1);

            leaseList = new ListBox() {
                BorderBrush = Brushes.LightGray,
                BorderThickness = new Thickness(0, 0, 1, 0),
                ItemTemplate = new LeaseTemplate(nameof(viewModel.EditableQuery), viewModel, hasTrigger: true)
            };
            Grid.SetRow(leaseList, 2);
            
            initializeEditables();
            var editableGrid = new Grid() {
                Margin = new Thickness(10,0,0,0),
                RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(),
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto }
                },
                Children = { plot, space, tenant, business, startDate, chargesBlock, divider, receivableGrid, receivables, expireGrid, buttons }
            };
            Grid.SetRow(editableGrid, 2);
            Grid.SetColumn(editableGrid, 1);

            var grid = new Grid() {
                RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition()
                },
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition()
                },
                Children = { searchGrid, nonEditablePlots, leaseList, editableGrid }
            };

            setContent(grid);
        }
       
        void initializeEditables() {
            plot = new ComboSelect() {
                Hint = "Plot",
                Icon = Icons.Plot,
                IsRequired = true,
                SelectedValuePath = nameof(Plot.Id),
                DisplayPath = nameof(Plot.Name),
                ItemsSource = nameof(viewModel.Plots),
                Error = nameof(viewModel.ErrorPlotId),
                Query = nameof(viewModel.PlotQuery),
                FilterParameter = SelectQuery.Plot,
                FilterCommand = viewModel.FilterCommand,
                SelectedValue = $"{nameof(viewModel.Edited)}.{nameof(Lease.PlotId)}",
                NonEditable = new Binding($"{nameof(viewModel.Selected)}.{nameof(Lease.PlotId)}") { Converter = Converters.plotId2plotName }
            };
            space = new ComboSelect() {
                Hint = "Space",
                Icon = Icons.Space,
                IsRequired = true,
                SelectedValuePath = nameof(Space.Id),
                DisplayPath = nameof(Space.Name),
                ItemsSource = nameof(viewModel.Spaces),
                Error = nameof(viewModel.ErrorSpaceId),
                Query = nameof(viewModel.SpaceQuery),
                FilterParameter = SelectQuery.Space,
                FilterCommand = viewModel.FilterCommand,
                SelectedValue = $"{nameof(viewModel.Edited)}.{nameof(Lease.SpaceId)}",
                NonEditable = new Binding($"{nameof(viewModel.Selected)}.{nameof(Lease.SpaceId)}") { Converter = Converters.spaceId2spaceName }
            };
            tenant = new ComboSelect() {
                Hint = "Tenant",
                Icon = Icons.Tenant,
                IsRequired = true,
                SelectedValuePath = nameof(Tenant.Id),
                ItemTemplate = new TenantTemplate(nameof(viewModel.TenantQuery), viewModel),
                ItemsSource = nameof(viewModel.Tenants),
                Error = nameof(viewModel.ErrorTenantId),
                Query = nameof(viewModel.TenantQuery),
                FilterParameter = SelectQuery.Tenant,
                FilterCommand = viewModel.FilterCommand,
                SelectedValue = $"{nameof(viewModel.Edited)}.{nameof(Lease.TenantId)}",
                NonEditable = new Binding($"{nameof(viewModel.Selected)}.{nameof(Lease.TenantId)}") { Converter = Converters.tenantId2TenantName }
            };
            business = new ComboText() {
                Hint = "Business",
                Icon = Icons.Business,
                IsRequired = true,
                IsMultiline = true,
                Editable = $"{nameof(viewModel.Edited)}.{nameof(Lease.Business)}",
                NonEditable = $"{nameof(viewModel.Selected)}.{nameof(Lease.Business)}",
                Error = nameof(viewModel.ErrorBusiness)
            };
            startDate = new ComboDate() {
                Hint = "Date",
                IsRequired = true,
                Editable = $"{nameof(viewModel.Edited)}.{nameof(Lease.DateStart)}",
                NonEditable = $"{nameof(viewModel.Selected)}.{nameof(Lease.DateStart)}",
                Error = nameof(viewModel.ErrorStartDate),
                Margin = new Thickness(0,7,0,0)
            };
            errorCharges = new Run() {
                Foreground = Brushes.Coral,
                FontStyle = FontStyles.Italic
            };
            chargesBlock = new TextBlock() {
                Margin = new Thickness(0, 7, 0, 0),
                Inlines = {
                    new Run() {
                        Text = "Fixed charges",
                        FontSize = 16,
                        Foreground = Brushes.Gray
                    },
                    errorCharges
                }
            };
            divider = new Separator() { };

            receivableHeads = new SelectItem() {
                Hint = "Receivable",
                IsRequired = true,
                Icon = Icons.Head,
                SelectedValuePath = nameof(Head.Id),
                DisplayPath = nameof(Head.Name),
                FilterParameter = SelectQuery.Head,
                FilterCommand = viewModel.FilterCommand
            };
            Grid.SetColumnSpan(receivableHeads, 2);

            receivableAmount = new EditText() {
                Hint = "Amount",
                IsRequired = true,
                Icon = Icons.Amount
            };
            Grid.SetRow(receivableAmount, 1);
            addReceivable = new CommandButton() {
                Icon = Icons.Plus,
                Command = viewModel.AddReceivable,
                Width = 18,
                Height = 18
            };
            Grid.SetRow(addReceivable, 1);
            Grid.SetColumn(addReceivable, 1);
            editableReceivables = new ItemsControl() { 
                ItemTemplate = new ReceivableTemplate(new Binding(nameof(viewModel.RemoveReceivable)) { Source = viewModel })
            };
            Grid.SetRow(editableReceivables, 2);
            Grid.SetColumnSpan(editableReceivables, 2);
            receivableGrid = new Grid() {
                Visibility = Visibility.Hidden,
                Margin = new Thickness(0,10,0,0),
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto }
                },
                RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition()
                },
                Children = { receivableHeads, receivableAmount, addReceivable, editableReceivables }
            };
            receivables = new ItemsControl() { ItemTemplate = new ReceivableTemplate() };
            isExpired = new ComboBiState() {
                Text = "Is expired?",
                Editable = $"{nameof(viewModel.Edited)}.{nameof(Lease.IsExpired)}",
                NonEditable = $"{nameof(viewModel.Selected)}.{nameof(Lease.IsExpired)}",
                VerticalAlignment = VerticalAlignment.Center
            };
            endDate = new ComboDate() {
                Hint = "Expired Date",
                IsRequired = true,
                Editable = $"{nameof(viewModel.Edited)}.{nameof(Lease.DateEnd)}",
                NonEditable = $"{nameof(viewModel.Selected)}.{nameof(Lease.DateEnd)}",
                Error = nameof(viewModel.ErrorEndDate)
            };
            Grid.SetColumn(endDate, 1);
            expireGrid = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(){ Width = new GridLength(1, GridUnitType.Star) },
                    new ColumnDefinition(){ Width = new GridLength(3, GridUnitType.Star) },
                },
                Children = { isExpired, endDate }
            };
            buttons = new ComboButton() {
                EditCommand = viewModel.SetIsOnEdit,
                CancelCommand = viewModel.ResetIsOnEdit,
                SaveCommand = viewModel.Save,
                IsValid = nameof(viewModel.IsValid)
            };
            Grid.SetRow(space, 1);
            Grid.SetRow(tenant, 2);
            Grid.SetRow(business, 3);
            Grid.SetRow(startDate, 4);
            Grid.SetRow(chargesBlock, 5);
            Grid.SetRow(divider, 6);
            Grid.SetRow(receivables, 7);
            Grid.SetRow(receivableGrid, 7);
            Grid.SetRow(expireGrid, 8);
            Grid.SetRow(buttons, 9);
        }
        void bind() {            
            nonEditablePlots.SetBinding(SelectItem.SelectedvalueProperty, new Binding(nameof(viewModel.SelectedPlot)));
            //plots.SetBinding(SelectItem.ErrorProperty, new Binding(nameof(viewModel.ErrorPlotId)));
            nonEditablePlots.SetBinding(SelectItem.ItemsSourceProperty, new Binding(nameof(viewModel.NonEditablePlots)));
            nonEditablePlots.SetBinding(SelectItem.QueryProperty, new Binding(nameof(viewModel.NonEditablePlotQuery)) { Mode = BindingMode.OneWayToSource });
            
            leaseList.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(viewModel.Editables)));
            leaseList.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(viewModel.Selected)));

            var isonEdit = new Binding(nameof(viewModel.IsOnEdit));
            plot.SetBinding(ComboSelect.IsOnEditProperty, isonEdit);
            space.SetBinding(ComboSelect.IsOnEditProperty, isonEdit);
            tenant.SetBinding(ComboSelect.IsOnEditProperty, isonEdit);
            business.SetBinding(ComboText.IsOnEditProperty, isonEdit);
            startDate.SetBinding(ComboDate.IsOnEditProperty, isonEdit);
            endDate.SetBinding(ComboDate.IsOnEditProperty, isonEdit);
            isExpired.SetBinding(ComboBiState.IsOnEditProperty, isonEdit);
            buttons.SetBinding(ComboButton.IsOnEditProperty, isonEdit);

            receivables.SetBinding(ItemsControl.VisibilityProperty, new Binding(nameof(viewModel.IsOnEdit)) { Converter = Converters.bool2invisibility });
            receivableGrid.SetBinding(Grid.VisibilityProperty, new Binding(nameof(viewModel.IsOnEdit)) { Converter = Converters.bool2visibility });

            receivables.SetBinding(ItemsControl.ItemsSourceProperty, new Binding($"{nameof(viewModel.Selected)}.{nameof(Lease.FixedReceivables)}"));
            editableReceivables.SetBinding(ItemsControl.ItemsSourceProperty, new Binding($"{nameof(viewModel.Edited)}.{nameof(Lease.FixedReceivables)}"));
            receivableHeads.SetBinding(SelectItem.SelectedvalueProperty, new Binding($"{nameof(viewModel.NewReceivable)}.{nameof(Receivable.HeadId)}"));
            receivableHeads.SetBinding(SelectItem.ErrorProperty, new Binding(nameof(viewModel.ErrorHeadId)));
            receivableHeads.SetBinding(SelectItem.ItemsSourceProperty, new Binding(nameof(viewModel.ReceivableHeads)));
            receivableHeads.SetBinding(SelectItem.QueryProperty, new Binding(nameof(viewModel.HeadQuery)) { Mode = BindingMode.OneWayToSource });
            errorCharges.SetBinding(Run.TextProperty, new Binding(nameof(viewModel.ErrorCharge)));
            receivableAmount.SetBinding(EditText.TextProperty, new Binding(nameof(viewModel.Amount)));
            receivableAmount.SetBinding(EditText.ErrorProperty, new Binding(nameof(viewModel.ErrorAmount)));
            addReceivable.SetBinding(IsEnabledProperty, new Binding(nameof(viewModel.IsReceivableValid)));

            isExpired.Resources.Add(typeof(ComboBiState), new Style() {
                Triggers = {
                    new MultiDataTrigger() {
                        Conditions = {
                            new Condition() {
                                Binding = new Binding($"{nameof(viewModel.Selected)}.{nameof(Lease.IsExpired)}"),
                                Value = true
                            },
                            new Condition() {
                                Binding = new Binding($"{nameof(viewModel.Edited)}.{nameof(Lease.IsExpired)}"),
                                Value = true
                            }
                        },
                        Setters = { new Setter(IsEnabledProperty, false) }
                    }
                }
            });
            endDate.SetBinding(ComboDate.VisibilityProperty, new MultiBinding() {
                Bindings = {
                    isonEdit,
                    new Binding($"{nameof(viewModel.Selected)}.{nameof(Lease.IsExpired)}"),
                    new Binding($"{nameof(viewModel.Edited)}.{nameof(Lease.IsExpired)}")
                },
                Converter = Converters.leaseExpiryDate,
                ConverterParameter = "lease"
            });

            filter.SetBinding(TriState.StateProperty, new Binding(nameof(viewModel.FilterState)));
            search.SetBinding(EditText.TextProperty, new Binding(nameof(viewModel.EditableQuery)) { Mode = BindingMode.OneWayToSource});
            counter.SetBinding(CountBlock.CountProperty, new Binding("Items.Count") { Source = leaseList });
        }    
    }
}
