﻿using RentManager.Abstracts;
using RentManager.CustomControls;
using RentManager.Helpers;
using RentManager.Models;
using RentManager.ViewModels.Add;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace RentManager.Views.Add
{
    class AddSpace : CardView
    {
        public override string Header => "Space";
       
        SelectItem plot;
        EditText name, description;
        CommandButton button;
        AddSpaceVM viewModel;
        public AddSpace() : base() {
            viewModel = new AddSpaceVM();
            DataContext = viewModel;
            initializeUI();
            bind();
        }
        void initializeUI() {
            plot = new SelectItem() {
                Hint = "Plot",
                IsRequired = true,
                Icon = Icons.Plot,
                SelectedValuePath = nameof(Plot.Id),
                DisplayPath = nameof(Plot.Name)
            };
            name = new EditText() {
                Hint = "Name",
                IsRequired = true,
                Icon = Icons.Space
            };
            Grid.SetRow(name, 1);
            description = new EditText() {
                Hint = "Description",
                IsRequired = true,
                IsMultiline = true,
                Icon = Icons.Description
            };
            Grid.SetRow(description, 2);
            button = new CommandButton() {
                Width = 24,
                Height = 24,
                Icon = Icons.Add,
                Command = viewModel.Add,
                HorizontalAlignment = HorizontalAlignment.Right
            };
            Grid.SetRow(button, 3);
            var grid = new Grid() {
                RowDefinitions = {
                    new RowDefinition() { Height = GridLength.Auto },
                    new RowDefinition() { Height = GridLength.Auto },
                    new RowDefinition(),
                    new RowDefinition() { Height = GridLength.Auto }
                },
                Children = { plot, name, description, button }
            };
            setContent(grid);
        }
        void bind() {
            plot.SetBinding(SelectItem.SelectedvalueProperty, new Binding($"{nameof(viewModel.TObject)}.{nameof(Space.PlotId)}"));
            plot.SetBinding(SelectItem.ErrorProperty, new Binding(nameof(viewModel.ErrorPlotId)));
            plot.SetBinding(SelectItem.ItemsSourceProperty, new Binding(nameof(viewModel.Plots)));
            plot.SetBinding(SelectItem.QueryProperty, new Binding(nameof(viewModel.Query)) { Mode = BindingMode.OneWayToSource });
            
            name.SetBinding(EditText.TextProperty, new Binding($"{nameof(viewModel.TObject)}.{nameof(Space.Name)}"));
            description.SetBinding(EditText.TextProperty, new Binding($"{nameof(viewModel.TObject)}.{nameof(Space.Description)}"));
            name.SetBinding(EditText.ErrorProperty, new Binding(nameof(viewModel.ErrorName)));
            description.SetBinding(EditText.ErrorProperty, new Binding(nameof(viewModel.ErrorDescription)));
            button.SetBinding(IsEnabledProperty, new Binding(nameof(viewModel.IsValid)));
        }
    }
}
