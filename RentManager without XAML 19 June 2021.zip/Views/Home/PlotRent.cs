﻿using RentManager.Abstracts;
using RentManager.CustomControls;
using RentManager.Helpers;
using RentManager.ViewModels.Home;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace RentManager.Views.Home
{
    class PlotRent : CardView
    {
        public override string Header => "Charge & Collections";

        MultiLineChart chart;
        CommandButton refresh;
        BiState state;
        PlotRentVM viewModel;
        public PlotRent() {
            viewModel = new PlotRentVM();
            DataContext = viewModel;
            initializeUI();
            bind();
        }
        void refreshCommand() {
            if (BusyWindow.IsOpened) return;
            var position = PointToScreen(new Point(0, 0));
            position.X += Constants.CardMargin.Left;
            position.Y += Constants.CardMargin.Top;
            var width = ActualWidth - Constants.CardMargin.Left - Constants.CardMargin.Right;
            var height = ActualHeight - Constants.CardMargin.Top - Constants.CardMargin.Bottom;

            BusyWindow.Activate(position.X, position.Y, width, height, "Reloading ...");
            viewModel.Refresh.Invoke();
            BusyWindow.Terminate();
        }

        void initializeUI() {
            chart = new MultiLineChart();
            refresh = new CommandButton() {
                Command = refreshCommand,
                Icon = Icons.Refresh,
                ToolTip = "Reload",
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Top,
                Margin = new Thickness(0, -28, 0, 0)
            };
            state = new BiState() {
                IsTrue = true,
                Text = "All",
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Top,
                Margin = new Thickness(0, -27, 26, 0)
            };
            var grid = new Grid() {
                Children = { chart, state, refresh }
            };
            setContent(grid);
        }
        void bind() {
            chart.SetBinding(MultiLineChart.ItemsSourceProperty, new Binding(nameof(viewModel.Data)));
            state.SetBinding(BiState.IsTrueProperty, new Binding(nameof(viewModel.State)));
        }
    }
}
