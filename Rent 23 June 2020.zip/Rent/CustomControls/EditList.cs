﻿using System.Collections;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Rent.CustomControls
{
    public class EditList : Control
    {
        static EditList()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(EditList), new FrameworkPropertyMetadata(typeof(EditList)));
        }

        public IEnumerable Editable
        {
            get { return (IEnumerable)GetValue(EditableProperty); }
            set { SetValue(EditableProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Editable.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty EditableProperty =
            DependencyProperty.Register("Editable", typeof(IEnumerable), typeof(EditList), new PropertyMetadata(null));


        public IEnumerable NonEditable
        {
            get { return (IEnumerable)GetValue(NonEditableProperty); }
            set { SetValue(NonEditableProperty, value); }
        }

        // Using a DependencyProperty as the backing store for NonEditable.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty NonEditableProperty =
            DependencyProperty.Register("NonEditable", typeof(IEnumerable), typeof(EditList), new PropertyMetadata(null));


        public DataTemplate EditableTemplate
        {
            get { return (DataTemplate)GetValue(EditableTemplateProperty); }
            set { SetValue(EditableTemplateProperty, value); }
        }

        // Using a DependencyProperty as the backing store for EditableTemplate.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty EditableTemplateProperty =
            DependencyProperty.Register("EditableTemplate", typeof(DataTemplate), typeof(EditList), new PropertyMetadata(null));


        public DataTemplate NonEditableTemplate
        {
            get { return (DataTemplate)GetValue(NonEditableTemplateProperty); }
            set { SetValue(NonEditableTemplateProperty, value); }
        }

        // Using a DependencyProperty as the backing store for NonEditableTemplate.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty NonEditableTemplateProperty =
            DependencyProperty.Register("NonEditableTemplate", typeof(DataTemplate), typeof(EditList), new PropertyMetadata(null));


        public int AmountText
        {
            get { return (int)GetValue(AmountTextProperty); }
            set { SetValue(AmountTextProperty, value); }
        }

        // Using a DependencyProperty as the backing store for AmountText.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty AmountTextProperty =
            DependencyProperty.Register("AmountText", typeof(int), typeof(EditList), new FrameworkPropertyMetadata(0, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));


        public ICommand AddReceivableCommand
        {
            get { return (ICommand)GetValue(AddReceivableCommandProperty); }
            set { SetValue(AddReceivableCommandProperty, value); }
        }

        // Using a DependencyProperty as the backing store for AddReceivableCommand.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty AddReceivableCommandProperty =
            DependencyProperty.Register("AddReceivableCommand", typeof(ICommand), typeof(EditList), new PropertyMetadata(null));





        public bool IsOnEdit
        {
            get { return (bool)GetValue(IsOnEditProperty); }
            set { SetValue(IsOnEditProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsOnEdit.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsOnEditProperty =
            DependencyProperty.Register("IsOnEdit", typeof(bool), typeof(EditList), new PropertyMetadata(false, OnIsOnEditChanged));

        static void OnIsOnEditChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if ((bool)e.NewValue) (d as EditList).IsNotOnEdit = false;
            else (d as EditList).IsNotOnEdit = true;
        }

        public bool IsNotOnEdit
        {
            get { return (bool)GetValue(IsNotOnEditProperty); }
            set { SetValue(IsNotOnEditProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsNotOnEdit.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsNotOnEditProperty =
            DependencyProperty.Register("IsNotOnEdit", typeof(bool), typeof(EditList), new PropertyMetadata(true));
    }
}
