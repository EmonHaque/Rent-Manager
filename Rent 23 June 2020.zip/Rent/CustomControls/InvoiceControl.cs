﻿using Rent.Model;
using System.Collections;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Rent.CustomControls
{
    public class InvoiceControl : Control
    {
        static InvoiceControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(InvoiceControl), new FrameworkPropertyMetadata(typeof(InvoiceControl)));
        }


        public string Title
        {
            get { return (string)GetValue(TitleProperty); }
            set { SetValue(TitleProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Title.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TitleProperty =
            DependencyProperty.Register("Title", typeof(string), typeof(InvoiceControl), new PropertyMetadata(null));


        public string Address
        {
            get { return (string)GetValue(AddressProperty); }
            set { SetValue(AddressProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Address.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty AddressProperty =
            DependencyProperty.Register("Address", typeof(string), typeof(InvoiceControl), new PropertyMetadata(null));

        public string ContactNo
        {
            get { return (string)GetValue(ContactNoProperty); }
            set { SetValue(ContactNoProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ContactNo.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ContactNoProperty =
            DependencyProperty.Register("ContactNo", typeof(string), typeof(InvoiceControl), new PropertyMetadata(null));

        public string Period
        {
            get { return (string)GetValue(PeriodProperty); }
            set { SetValue(PeriodProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Period.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty PeriodProperty =
            DependencyProperty.Register("Period", typeof(string), typeof(InvoiceControl), new PropertyMetadata(null));


        public IEnumerable Reportables
        {
            get { return (IEnumerable)GetValue(ReportablesProperty); }
            set { SetValue(ReportablesProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Reportables.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ReportablesProperty =
            DependencyProperty.Register("Reportables", typeof(IEnumerable), typeof(InvoiceControl), new PropertyMetadata(null));


        public int TotalReceivable
        {
            get { return (int)GetValue(TotalReceivableProperty); }
            set { SetValue(TotalReceivableProperty, value); }
        }

        // Using a DependencyProperty as the backing store for TotalReceivable.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TotalReceivableProperty =
            DependencyProperty.Register("TotalReceivable", typeof(int), typeof(InvoiceControl), new PropertyMetadata(0));



        public Invoice TenantInvoice
        {
            get { return (Invoice)GetValue(TenantInvoiceProperty); }
            set { SetValue(TenantInvoiceProperty, value); }
        }

        // Using a DependencyProperty as the backing store for TenantInvoice.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TenantInvoiceProperty =
            DependencyProperty.Register("TenantInvoice", typeof(Invoice), typeof(InvoiceControl), new PropertyMetadata(null, OnChanged));

        static void OnChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var x = e.NewValue as Invoice;
            var o = (d as InvoiceControl);
            o.Title = x.Title;
            o.Address = x.Address;
            o.ContactNo = x.ContactNo;
            o.Period = x.Period;
            o.Reportables = x.Reportables;
            o.TotalReceivable = x.Reportables.Sum(x => x.Receivable);
        }
    }
}
