﻿using System.Windows;
using System.Windows.Controls;

namespace Rent.CustomControls
{
    public class DayPicker : DatePicker
    {
        static DayPicker()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(DayPicker), new FrameworkPropertyMetadata(typeof(DayPicker)));
        }
    }
}
