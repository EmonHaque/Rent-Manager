﻿using Rent.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;

namespace Rent.Common
{
    public static class Extensions
    {
        public static T DeepClone<T>(this T obj)
        {
            using (var ms = new MemoryStream())
            {
                var formatter = new BinaryFormatter();
                formatter.Serialize(ms, obj);
                ms.Position = 0;

                return (T)formatter.Deserialize(ms);
            }
        }

        public static bool IsEqualTo<T>(this T original, T edited)
        {
            var properties = typeof(T).GetProperties();

            foreach (var p in properties)
            {
                var x = p.GetValue(original);
                var y = p.GetValue(edited);

                if(x != null && x.GetType().IsGenericType)
                {
                    var ix = x as IEnumerable<Receivable>;
                    var iy = y as IEnumerable<Receivable>;

                    if (ix.Count() != iy.Count()) return false;
                    else
                    {
                        ix = ix.ToList().OrderBy(x => x.HeadId);
                        iy = iy.ToList().OrderBy(x => x.HeadId);

                        foreach (var item in ix.Zip(iy))
                        {
                            if (item.First.HeadId == item.Second.HeadId &&
                                item.First.Amount == item.Second.Amount) continue;
                            else return false;
                        }
                    }
                }
                else
                {
                    var s1 = x == null ? "" : x.ToString().Trim();
                    var s2 = y == null ? "" : y.ToString().Trim();

                    if (s1.Equals(s2, StringComparison.OrdinalIgnoreCase)) continue;
                    else return false;
                }
            }
            return true;
        }

        public static IEnumerable<TSource> DistinctBy<TSource, TKey> (this IEnumerable<TSource> source, Func<TSource, TKey> keySelector)
        {
            HashSet<TKey> seenKeys = new HashSet<TKey>();
            foreach (TSource element in source)
            {
                if (seenKeys.Add(keySelector(element)))
                {
                    yield return element;
                }
            }
        }
    }
}
