﻿using System.Windows.Controls;

namespace Rent.View.Ledger
{
    /// <summary>
    /// Interaction logic for TenantLedger.xaml
    /// </summary>
    public partial class TenantLedger : UserControl
    {
        public TenantLedger()
        {
            InitializeComponent();
        }
    }
}
