﻿using System.Windows.Controls;

namespace Rent.View.Edit
{
    /// <summary>
    /// Interaction logic for SpaceView.xaml
    /// </summary>
    public partial class SpaceView : UserControl
    {
        public SpaceView()
        {
            InitializeComponent();
        }
    }
}
