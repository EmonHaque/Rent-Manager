﻿using System.Windows.Controls;

namespace Rent.View.Edit
{
    /// <summary>
    /// Interaction logic for PlotView.xaml
    /// </summary>
    public partial class PlotView : UserControl
    {
        public PlotView()
        {
            InitializeComponent();
        }
    }
}
