﻿using System.Windows.Controls;

namespace Rent.View.Edit
{
    /// <summary>
    /// Interaction logic for TenantView.xaml
    /// </summary>
    public partial class TenantView : UserControl
    {
        public TenantView()
        {
            InitializeComponent();
        }
    }
}
