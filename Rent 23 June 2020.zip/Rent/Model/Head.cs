﻿using Rent.VM;
using System;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace Rent.Model
{
    [Serializable]
	public class Head : INotifyPropertyChanged
	{

		int id;
		public int Id { get => id; set { id = value; OnPropertyChanged(); } }

		int controlId;
		public int ControlId { get => controlId; set { controlId = value; OnPropertyChanged(); } }

		string name;
		public string Name { get => name; set { name = value; OnPropertyChanged(); } }

		string description;
		public string Description { get => description; set { description = value; OnPropertyChanged(); } }

		public bool IsValid()
		{
			return !MainVM.HeadBusy && 
				Id > 0 &&
				ControlId > 0 &&
				!string.IsNullOrWhiteSpace(Name) &&
				!string.IsNullOrWhiteSpace(Description);
		}

		public bool IsInsertValid()
		{
			return !MainVM.HeadBusy && 
				Id > 0 &&
				ControlId > 0 &&
				!string.IsNullOrWhiteSpace(Name) &&
				!string.IsNullOrWhiteSpace(Description) &&
				MainVM.Heads.Where(x => x.ControlId == MainVM.SelectedControlHead.Id)
							.FirstOrDefault(x => x.Name.ToLower() == Name.Trim().ToLower()) == null;
		}

		#region Notify Property Changed Members
		[field: NonSerialized]
		public event PropertyChangedEventHandler PropertyChanged;
		void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
		#endregion
	}

}
