﻿using System.Collections.Generic;

namespace Rent.Model
{
    public class Invoice
    {
        public string Title { get; set; }
        public string Address { get; set; }
        public string Period { get; set; }
        public string ContactNo { get; set; }
        public List<Reportable> Reportables { get; set; }
    }
}
