﻿using RentManager.Common;
using RentManager.Model;
using System.Collections.ObjectModel;

namespace RentManager.ViewModel.Add
{
    public class AddPlotVM : AddBase<Plot>
    {
        public AddPlotVM() : base() => NewObject.Id = MainVM.GetId(MainVM.plots);

        #region base implementation
        protected override ViewType type => ViewType.Plot;
        protected override ObservableCollection<Plot> collection => MainVM.plots;
        protected override void insertInDatabase()
        {
            using var cmd = SQLHelper.connection.CreateCommand();
            cmd.CommandText = "INSERT INTO Plots (Name, Description) VALUES(@Name, @Description)";
            cmd.Parameters.AddWithValue("@Name", NewObject.Name);
            cmd.Parameters.AddWithValue("@Description", NewObject.Description);
            SQLHelper.NonQuery(cmd);
        }
        protected override void renewNewObject() => NewObject = new Plot() { Id = NewObject.Id + 1 };
        #endregion
    }
}
