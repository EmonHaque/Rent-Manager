﻿namespace RentManager.Interface
{
    public interface IInsertable
    {
        bool IsInsertionValid();
    }
}
