﻿using System.Windows.Controls;

namespace RentManager.View.Edit
{
    /// <summary>
    /// Interaction logic for EditTransaction.xaml
    /// </summary>
    public partial class EditTransactionView : UserControl
    {
        public EditTransactionView()
        {
            InitializeComponent();
        }
    }
}
