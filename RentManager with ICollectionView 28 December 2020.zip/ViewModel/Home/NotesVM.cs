﻿namespace RentManager.ViewModel.Home
{
    public class NotesVM
    {

    }
}
