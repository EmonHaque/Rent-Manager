﻿using Microsoft.Data.Sqlite;
using RentManager.Common;
using RentManager.Model;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Data;

namespace RentManager.ViewModel.Transact
{
    public class ChargeRentVM : Notifiable
    {
        public RentListStats Stats { get; set; }
        public CommonNarration MonthlyNarration { get; set; }
        public ICollectionView Leases { get; set; }
        public Command PassEntries { get; set; }

        public ChargeRentVM()
        {
            Leases = new CollectionViewSource()
            {
                Source = MainVM.leases,
                IsLiveFilteringRequested = true,
                LiveFilteringProperties = { nameof(Lease.IsExpired) },
                IsLiveSortingRequested = true,
                LiveSortingProperties = { nameof(Lease.SpaceId) },
                IsLiveGroupingRequested = true,
                LiveGroupingProperties = { nameof(Lease.PlotId) }
            }.View;
            Leases.GroupDescriptions.Add(new PropertyGroupDescription(nameof(Lease.PlotId)));
            Leases.SortDescriptions.Add(new SortDescription(nameof(Lease.SpaceId), ListSortDirection.Ascending));
            Leases.Filter = filter;

            initializeProperties();
            PassEntries = new Command(passEntries, areEntriesValid);
        }

        void initializeProperties()
        {
            Stats = new RentListStats();
            MonthlyNarration = new CommonNarration();
            OnPropertyChanged(nameof(Stats));
            OnPropertyChanged(nameof(MonthlyNarration));
        }

        bool filter(object o) => !(o as Lease).IsExpired;

        void passEntries(object o)
        {
            var leases = MainVM.leases.Where(x => !x.IsExpired);
            if (Stats.Selected > 0)
            {
                var excluded = o as IEnumerable<object>;
                leases = leases.Except(excluded.Cast<Lease>());
            }

            var commands = new List<SqliteCommand>();
            foreach (var lease in leases)
            {
                foreach (var receivable in lease.FixedReceivables)
                    commands.Add(monthlyCommand(lease, receivable));
            }
            SQLHelper.Transaction(commands);
            MonthlyNarration = new CommonNarration();
            foreach (var command in commands) command.Dispose();

            MainVM.PopupMessage = $"Fixed monthly receivables\r\ncharged for {Stats.Total - Stats.Selected} lease(s)";
            MainVM.Popup();
        }

        bool areEntriesValid(object o)
        {
            return
                Stats.Selected < Stats.Total &&
                Stats.Total > 0 &&
                !string.IsNullOrWhiteSpace(MonthlyNarration.Narration);
        }

        SqliteCommand monthlyCommand(Lease lease, Receivable receivable)
        {
            var cmd = new SqliteCommand(@$"INSERT INTO Transactions (Date, PlotId, SpaceId, TenantId, ControlId, HeadId, Amount, IsCash, Narration) 
                                        VALUES('{MonthlyNarration.Date.ToString("yyyy-MM-dd")}', {lease.PlotId}, {lease.SpaceId}, {lease.TenantId}, 
                                        {MainVM.controlIdOfReceivable}, {receivable.HeadId}, {receivable.Amount}, 0, @Narration)");
            cmd.Parameters.AddWithValue("@Narration", MonthlyNarration.Narration);
            return cmd;
        }
    }
}
