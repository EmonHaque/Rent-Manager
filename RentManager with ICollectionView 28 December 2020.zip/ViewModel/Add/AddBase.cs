﻿using RentManager.Common;
using RentManager.Interface;
using RentManager.Model;
using System.Collections.ObjectModel;

namespace RentManager.ViewModel.Add
{
    public abstract class AddBase<T> : Notifiable where T : IInsertable, new() 
    {
        public T NewObject { get; set; }
        public Command Add { get; set; }
        public AddBase()
        {
            NewObject = new T();
            Add = new Command(addNewObject, (o) => NewObject.IsInsertionValid());
        }
        protected bool isFocused => MainVM.SelectedMenu.Name == Constants.Add;
        protected abstract ViewType type { get; }
        protected abstract ObservableCollection<T> collection { get; }
        protected abstract void insertInDatabase();
        protected abstract void renewNewObject();
        
        void addNewObject(object o)
        {
            MainVM.DoAsync(type, () =>
            {
                lock (SQLHelper.key) { insertInDatabase(); }
                collection.Add(NewObject);
                renewNewObject();
                OnPropertyChanged(nameof(NewObject));
            });
        }
    }
}
