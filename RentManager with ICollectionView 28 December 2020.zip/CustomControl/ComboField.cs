﻿using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace RentManager.CustomControl
{
    public class ComboField : Control
    {
        static ComboField()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(ComboField), new FrameworkPropertyMetadata(typeof(ComboField)));
        }

        public string Label
        {
            get { return (string)GetValue(LabelProperty); }
            set { SetValue(LabelProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Label.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty LabelProperty =
            DependencyProperty.Register("Label", typeof(string), typeof(ComboField), new PropertyMetadata(null));


        public DataTemplate UserTemplate
        {
            get { return (DataTemplate)GetValue(UserTemplateProperty); }
            set { SetValue(UserTemplateProperty, value); }
        }

        // Using a DependencyProperty as the backing store for UserTemplate.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty UserTemplateProperty =
            DependencyProperty.Register("UserTemplate", typeof(DataTemplate), typeof(ComboField), new PropertyMetadata(null));


        public string Display
        {
            get { return (string)GetValue(DisplayProperty); }
            set { SetValue(DisplayProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Display.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty DisplayProperty =
            DependencyProperty.Register("Display", typeof(string), typeof(ComboField), new PropertyMetadata(null));


        public int? SelectedValue
        {
            get { return (int?)GetValue(SelectedValueProperty); }
            set { SetValue(SelectedValueProperty, value); }
        }

        // Using a DependencyProperty as the backing store for SelectedValue.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SelectedValueProperty =
            DependencyProperty.Register("SelectedValue", typeof(int?), typeof(ComboField), new FrameworkPropertyMetadata() 
            { 
                DefaultValue = 0,
                DefaultUpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged,
                BindsTwoWayByDefault = true
            });

        public string SelectedValuePath
        {
            get { return (string)GetValue(SelectedValuePathProperty); }
            set { SetValue(SelectedValuePathProperty, value); }
        }

        // Using a DependencyProperty as the backing store for SelectedValuePath.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SelectedValuePathProperty =
            DependencyProperty.Register("SelectedValuePath", typeof(string), typeof(ComboField), new PropertyMetadata(string.Empty));


        public IEnumerable Source
        {
            get { return (IEnumerable)GetValue(SourceProperty); }
            set { SetValue(SourceProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Source.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SourceProperty =
            DependencyProperty.Register("Source", typeof(IEnumerable), typeof(ComboField), new PropertyMetadata(null, onChanged));

        static void onChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (e.NewValue is ICollectionView)
            {
                if (e.OldValue != null)
                    (e.OldValue as ICollectionView).CollectionChanged -= onCollectionChanged;
                (e.NewValue as ICollectionView).CollectionChanged += onCollectionChanged;
            }
        }

        static void onCollectionChanged(object sender, NotifyCollectionChangedEventArgs e) { }

        public GroupStyle CustomGroupStyle
        {
            get { return (GroupStyle)GetValue(CustomGroupStyleProperty); }
            set { SetValue(CustomGroupStyleProperty, value); }
        }

        // Using a DependencyProperty as the backing store for CustomGroupStyle.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty CustomGroupStyleProperty =
            DependencyProperty.Register("CustomGroupStyle", typeof(GroupStyle), typeof(ComboField), new PropertyMetadata(null));

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            if(CustomGroupStyle != null)
            {
                var combo = GetTemplateChild("combo") as Combo;
                combo.GroupStyle.Add(CustomGroupStyle);
                ScrollViewer.SetCanContentScroll(combo, false);
            }          
        }
    }
}
