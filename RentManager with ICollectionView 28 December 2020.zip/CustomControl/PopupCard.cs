﻿using System.Windows;
using System.Windows.Controls;

namespace RentManager.CustomControl
{
    public class PopupCard : Control
    {
        static PopupCard()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(PopupCard), new FrameworkPropertyMetadata(typeof(PopupCard)));
        }

        public string Message
        {
            get { return (string)GetValue(MessageProperty); }
            set { SetValue(MessageProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Message.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MessageProperty =
            DependencyProperty.Register("Message", typeof(string), typeof(PopupCard), new PropertyMetadata(null, OnMessageChanged));

        static void OnMessageChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            (d as PopupCard).UpdateLayout();
        }
    }
}
