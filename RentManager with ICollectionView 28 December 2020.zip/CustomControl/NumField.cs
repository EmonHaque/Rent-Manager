﻿using System.Windows;
using System.Windows.Controls;

namespace RentManager.CustomControl
{
    public class NumField : Control
    {
        static NumField()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(NumField), new FrameworkPropertyMetadata(typeof(NumField)));
        }

        public string Label
        {
            get { return (string)GetValue(LabelProperty); }
            set { SetValue(LabelProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Label.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty LabelProperty =
            DependencyProperty.Register("Label", typeof(string), typeof(NumField), new PropertyMetadata(null));


        public string Text
        {
            get { return (string)GetValue(TextProperty); }
            set { SetValue(TextProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Text.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TextProperty =
            DependencyProperty.Register("Text", typeof(string), typeof(NumField), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, OnTextChanged));

        static void OnTextChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var dp = (d as NumField);
            int result;
            if (int.TryParse(dp.Text, out result))
            {
                if (result < 0) dp.Text = "0";
            }
            else dp.Text = "0";
        }
    }
}
