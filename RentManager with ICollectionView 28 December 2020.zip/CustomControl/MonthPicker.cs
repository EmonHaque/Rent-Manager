﻿using RentManager.Common;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace RentManager.CustomControl
{
    public class MonthPicker : Control
    {
        public ICommand Popup
        {
            get { return (ICommand)GetValue(PopupProperty); }
            set { SetValue(PopupProperty, value); }
        }

        // Using a DependencyProperty as the backing store for command.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty PopupProperty =
            DependencyProperty.Register("Popup", typeof(ICommand), typeof(MonthPicker), new PropertyMetadata(null));

        public ICommand Increment
        {
            get { return (ICommand)GetValue(IncrementProperty); }
            set { SetValue(IncrementProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Increment.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IncrementProperty =
            DependencyProperty.Register("Increment", typeof(ICommand), typeof(MonthPicker), new PropertyMetadata(null));

        public ICommand Decrement
        {
            get { return (ICommand)GetValue(DecrementProperty); }
            set { SetValue(DecrementProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Decrement.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty DecrementProperty =
            DependencyProperty.Register("Decrement", typeof(ICommand), typeof(MonthPicker), new PropertyMetadata(null));

        static MonthPicker()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(MonthPicker), new FrameworkPropertyMetadata(typeof(MonthPicker)));
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            Popup = new Command(popup, (o) => true);
            Increment = new Command(increment, (o) => true);
            Decrement = new Command(decrement, (o) => true);
            EventManager.RegisterClassHandler(typeof(MonthButton), MonthButton.MonthClickedEvent, new RoutedEventHandler(MonthClickHandler));
        }

        public int Year
        {
            get { return (int)GetValue(YearProperty); }
            set { SetValue(YearProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Year.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty YearProperty =
            DependencyProperty.Register("Year", typeof(int), typeof(MonthPicker), new FrameworkPropertyMetadata(DateTime.Today.Year, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));


        public bool IsPopupOpen
        {
            get { return (bool)GetValue(IsPopupOpenProperty); }
            set { SetValue(IsPopupOpenProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsPopupOpen.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsPopupOpenProperty =
            DependencyProperty.Register("IsPopupOpen", typeof(bool), typeof(MonthPicker), new FrameworkPropertyMetadata(false, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));


        public string Narration
        {
            get { return (string)GetValue(NarrationProperty); }
            set { SetValue(NarrationProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Narration.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty NarrationProperty =
            DependencyProperty.Register("Narration", typeof(string), typeof(MonthPicker), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));

        void popup(object o) => IsPopupOpen = true;
        void increment(object o) => Year++;
        void decrement(object o) => Year--;

        void MonthClickHandler(object sender, RoutedEventArgs e)
        {
            Narration = e.OriginalSource.ToString() + ", " + Year.ToString();
            IsPopupOpen = false;
        }
    }
}
