﻿namespace RentManager.Model
{
    public class PeriodicSummary
    {
        public string Plot { get; set; }
        public int SpaceId { get; set; }
        public string Tenant { get; set; }
        public int Receivable { get; set; }
        public int ReceiptInCash { get; set; }
        public int ReceiptInKind { get; set; }
        public int Due { get; set; }
    }
}
