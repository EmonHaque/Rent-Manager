﻿class TransactionSummary : Notifiable
{
    int cashReceipt;
    public int CashReceipt {
        get { return cashReceipt; }
        set {
            if (cashReceipt != value) {
                cashReceipt = value;
                OnPropertyChanged(nameof(CashReceipt));
            }
        }
    }
    int kindReceipt;
    public int KindReceipt {
        get { return kindReceipt; }
        set {
            if (kindReceipt != value) {
                kindReceipt = value;
                OnPropertyChanged(nameof(KindReceipt));
            }
        }
    }
    int mobileReceipt;
    public int MobileReceipt {
        get { return mobileReceipt; }
        set { 
            if(mobileReceipt != value) {
                mobileReceipt = value;
                OnPropertyChanged(nameof(MobileReceipt));
            }
        }
    }

    int cashPayment;
    public int CashPayment {
        get { return cashPayment; }
        set {
            if (cashPayment != value) {
                cashPayment = value;
                OnPropertyChanged(nameof(CashPayment));
            }
        }
    }
    int kindPayment;
    public int KindPayment {
        get { return kindPayment; }
        set {
            if (kindPayment != value) {
                kindPayment = value;
                OnPropertyChanged(nameof(KindPayment));
            }
        }
    }
    int mobilePayment;
    public int MobilePayment {
        get { return mobilePayment; }
        set {
            if (mobilePayment != value) {
                mobilePayment = value;
                OnPropertyChanged(nameof(MobilePayment));
            }
        }
    }

    int receivable;
    public int Receivable {
        get { return receivable; }
        set {
            if (receivable != value) {
                receivable = value;
                OnPropertyChanged(nameof(Receivable));
            }
        }
    }

}
