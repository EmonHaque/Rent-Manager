﻿class RentPayment
{
    public DateTime Date { get; set; }
    public string Plot { get; set; }
    public string Space { get; set; }
    public string Tenant { get; set; }
    public int Due { get; set; }
    public int Cash { get; set; }
    public int Mobile { get; set; }
    public int Kind { get; set; }
    public int TotalPaid { get; set; }
}
