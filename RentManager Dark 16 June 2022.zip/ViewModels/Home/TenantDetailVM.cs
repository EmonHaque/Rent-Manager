﻿class TenantDetailVM : Notifiable
{
    bool isSelectedByUser;
    string query;
    public string Query {
        get { return query; }
        set {
            if (query != value) {
                query = value?.Trim().ToLower();
                Tenants.Refresh();
            }
        }
    }
    int? selectedTenant;
    public int? SelectedTenant {
        get { return selectedTenant; }
        set {
            if (selectedTenant != value) {
                selectedTenant = value;
                onTenatChanged(value);
            }
        }
    }
    bool state;
    public bool State {
        get { return state; }
        set {
            if (state != value) {
                state = value;
                Tenants.Refresh();
                if (isSelectedByUser) isSelectedByUser = false;
                else {
                    SelectedTenant = Tenants.CurrentItem == null ? null : ((Tenant)Tenants.CurrentItem).Id;
                    OnPropertyChanged(nameof(SelectedTenant));
                }
            }
        }
    }
    public List<RentPayment> Data { get; set; }
    public Action Refresh { get; set; }
    public bool IsRefreshvalid { get; set; }
    public ICollectionView Tenants { get; set; }
    public string Deposit { get; set; }

    public TenantDetailVM() {
        Tenants = new CollectionViewSource() { Source = AppData.tenants }.View;
        Tenants.Filter = filterTenants;
        RentDetailVM.SelectionChanged += setTenant; ;
        Refresh = () => onTenatChanged(SelectedTenant);
        State = true;
    }

    void setTenant(int? o) {
        if (!State) {
            isSelectedByUser = true;
            State = true;
            OnPropertyChanged(nameof(State));
        }
        SelectedTenant = o;
        OnPropertyChanged(nameof(SelectedTenant));
    }

    bool filterTenants(object o) {
        var tenant = (Tenant)o;
        switch (State) {
            case true:
                return string.IsNullOrWhiteSpace(Query) ? true && !tenant.HasLeft : tenant.Name.ToLower().Contains(Query) && !tenant.HasLeft;
            case false:
                return string.IsNullOrWhiteSpace(Query) ? true && tenant.HasLeft : tenant.Name.ToLower().Contains(Query) && tenant.HasLeft;
        }
    }

    void onTenatChanged(int? id) {
        var date = DateTime.Today.AddMonths(-12);
        if (SelectedTenant == null) {
            Data = null;
            IsRefreshvalid = false;
            Deposit = null;
            OnPropertyChanged(nameof(IsRefreshvalid));
            OnPropertyChanged(nameof(Data));
            OnPropertyChanged(nameof(Deposit));
            return;
        }
        if (AppData.tenants.First(x => x.Id == SelectedTenant).HasLeft) {
            object lastDate;
            lock (SQL.key) {
                SQL.command.CommandText = $"SELECT MAX(Date) FROM Transactions WHERE TenantId = {id}";
                lastDate = SQL.command.ExecuteScalar();
            }
            if (lastDate != null) {
                var dateParts = lastDate.ToString().Split('-');
                date = new DateTime(Convert.ToInt32(dateParts[0]), Convert.ToInt32(dateParts[1]), Convert.ToInt32(dateParts[2]));
                date = date.AddMonths(-12);
            }
        }
        Data = new List<RentPayment>();

        lock (SQL.key) {
            SQL.command.CommandText = $@"WITH t0(Date, Plot, Space, Tenant, Control, Due, Cash, Mobile, Kind) AS(
                                	SELECT '' Date, '' Plot, '' Space, '' Tenant, tn.ControlId,
                                	SUM(CASE WHEN ControlId = 1 THEN Amount ELSE 0 END) -
                                	SUM(CASE WHEN ControlId <> 1 THEN Amount ELSE 0 END) Due,
                                	0 Cash, 0 Mobile, 0 Kind FROM Transactions tn
                                	WHERE TenantId = {id} AND ControlId <> 3 AND HeadId <> 4 AND Date < '{date.ToString("yyyy-MM-dd")}'
                                	GROUP BY Plot, Space
                                ),
                                t1 AS(
                                	SELECT Date, p.Name Plot, s.Name Space, t.Name Tenant, tn.ControlId,
                                	SUM(CASE WHEN ControlId = 1 THEN Amount ELSE 0 END) Due,
                                	SUM(CASE WHEN ControlId <> 1 AND IsCash = 1 THEN Amount ELSE 0 END) Cash,
                                    SUM(CASE WHEN ControlId <> 1 AND IsCash = 2 THEN Amount ELSE 0 END) Mobile,
                                	SUM(CASE WHEN ControlId <> 1 AND IsCash = 0 THEN Amount ELSE 0 END) Kind
                                    FROM Transactions tn
                                	LEFT JOIN Plots p ON p.Id = tn.PlotId
                                	LEFT JOIN Spaces s ON s.Id = tn.SpaceId
                                	LEFT JOIN Tenants t ON t.Id = tn.TenantId
                                	WHERE TenantId = {id} AND ControlId <> 3 AND HeadId <> 4 AND Date >= '{date.ToString("yyyy-MM-dd")}'
                                	GROUP BY Plot, Space, HeadId, Date
                                	ORDER BY Date, ControlId DESC
                                ),
                                t2 AS(SELECT * FROM t0 UNION ALL SELECT * FROM t1),
                                t3 AS(SELECT *, ROW_NUMBER() OVER(ORDER BY (SELECT 1)) RowNum FROM t2),
                                t4 AS(SELECT *, SUM(Due - Cash - Mobile - Kind) OVER(ORDER BY RowNum) Balance FROM t3),
                                t5 AS(SELECT *, LAG(Balance, 1, 0) OVER (ORDER BY RowNum) Pos FROM t4)	
                                SELECT Date, Plot, Space, Tenant, Cash, Mobile, Kind, Pos AS Due FROM t5
                                WHERE Cash > 0 OR Mobile > 0 OR Kind > 0
                                ORDER BY Date";
            var reader = SQL.command.ExecuteReader();
            while (reader.Read()) {
                var rp = new RentPayment() {
                    Date = reader.GetDateTime(0),
                    Plot = reader.GetString(1),
                    Space = reader.GetString(2),
                    Tenant = reader.GetString(3),
                    Cash = reader.GetInt32(4),
                    Mobile = reader.GetInt32(5),
                    Kind = reader.GetInt32(6),
                    Due = reader.GetInt32(7)
                };
                rp.TotalPaid = rp.Cash + rp.Mobile + rp.Kind;
                Data.Add(rp);
            }
            reader.Close();
            SQL.command.CommandText = $@"SELECT coalesce(SUM(CASE WHEN HeadId = 4 THEN Amount ELSE -Amount END), 0) Deposit
                                    FROM Transactions WHERE
                                    TenantId = {id} AND HeadId IN(4, 6)";

            Deposit = "Deposit: " + Convert.ToInt32(SQL.command.ExecuteScalar()).ToString("N0");
            reader.DisposeAsync();
        }
        IsRefreshvalid = true;
        OnPropertyChanged(nameof(Deposit));
        OnPropertyChanged(nameof(IsRefreshvalid));
        OnPropertyChanged(nameof(Data));
    }
}
