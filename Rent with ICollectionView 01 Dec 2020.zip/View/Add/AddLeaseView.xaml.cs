﻿using System.Windows.Controls;

namespace RentManager.View.Add
{
    /// <summary>
    /// Interaction logic for AddLeaseView.xaml
    /// </summary>
    public partial class AddLeaseView : UserControl
    {
        public AddLeaseView()
        {
            InitializeComponent();
        }
    }
}
