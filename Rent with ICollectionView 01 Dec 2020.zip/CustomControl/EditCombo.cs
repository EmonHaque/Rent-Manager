﻿using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;

namespace RentManager.CustomControl
{
    public class EditCombo : Control
    {
        static EditCombo()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(EditCombo), new FrameworkPropertyMetadata(typeof(EditCombo)));
        }

        public string Label
        {
            get { return (string)GetValue(LabelProperty); }
            set { SetValue(LabelProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Label.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty LabelProperty =
            DependencyProperty.Register("Label", typeof(string), typeof(EditCombo), new PropertyMetadata(null));


        public string NonEditable
        {
            get { return (string)GetValue(NonEditableProperty); }
            set { SetValue(NonEditableProperty, value); }
        }

        // Using a DependencyProperty as the backing store for NonEditable.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty NonEditableProperty =
            DependencyProperty.Register("NonEditable", typeof(string), typeof(EditCombo), new PropertyMetadata(null));

        public int? Editable
        {
            get { return (int?)GetValue(EditableProperty); }
            set { SetValue(EditableProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Editable.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty EditableProperty =
            DependencyProperty.Register("Editable", typeof(int?), typeof(EditCombo), new FrameworkPropertyMetadata(0, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, onValueChanged));

        static void onValueChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var o = d as EditCombo;
            o.SelectedValue = e.NewValue as int?;
        }

        public int? SelectedValue
        {
            get { return (int?)GetValue(SelectedValueProperty); }
            set { SetValue(SelectedValueProperty, value); }
        }

        // Using a DependencyProperty as the backing store for SelectedValue.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SelectedValueProperty =
            DependencyProperty.Register("SelectedValue", typeof(int?), typeof(EditCombo), new FrameworkPropertyMetadata(0, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));


        public string SelectedValuePath
        {
            get { return (string)GetValue(SelectedValuePathProperty); }
            set { SetValue(SelectedValuePathProperty, value); }
        }

        // Using a DependencyProperty as the backing store for SelectedValuePath.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SelectedValuePathProperty =
            DependencyProperty.Register("SelectedValuePath", typeof(string), typeof(EditCombo), new PropertyMetadata(null));


        public string Display
        {
            get { return (string)GetValue(DisplayProperty); }
            set { SetValue(DisplayProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Display.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty DisplayProperty =
            DependencyProperty.Register("Display", typeof(string), typeof(EditCombo), new PropertyMetadata(string.Empty));


        public DataTemplate UserTemplate
        {
            get { return (DataTemplate)GetValue(UserTemplateProperty); }
            set { SetValue(UserTemplateProperty, value); }
        }

        // Using a DependencyProperty as the backing store for dataTemplate.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty UserTemplateProperty =
            DependencyProperty.Register("UserTemplate", typeof(DataTemplate), typeof(EditCombo), new PropertyMetadata(null));


        public IEnumerable Source
        {
            get { return (IEnumerable)GetValue(SourceProperty); }
            set { SetValue(SourceProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Source.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SourceProperty =
            DependencyProperty.Register("Source", typeof(IEnumerable), typeof(EditCombo), new PropertyMetadata(null, onSourceChanged));

        static void onSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if(e.NewValue is ICollectionView)
            {
                if (e.OldValue != null) 
                    (e.OldValue as ICollectionView).CollectionChanged -= onCollectionChanged;
                (e.NewValue as ICollectionView).CollectionChanged += onCollectionChanged;
            }
        }

        private static void onCollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            var view = sender as ICollectionView;
            switch (e.Action)
            {
                case NotifyCollectionChangedAction.Reset:
                    if (e.NewItems == null && !view.IsEmpty)
                        view.MoveCurrentToFirst();
                    break;
            }
        }

        public bool IsOnEdit
        {
            get { return (bool)GetValue(IsOnEditProperty); }
            set { SetValue(IsOnEditProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsOnEdit.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsOnEditProperty =
            DependencyProperty.Register("IsOnEdit", typeof(bool), typeof(EditCombo), new PropertyMetadata(false, OnIsOnEditChanged));

        static void OnIsOnEditChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if ((bool)e.NewValue) (d as EditCombo).IsNotOnEdit = false;
            else (d as EditCombo).IsNotOnEdit = true;
        }

        public bool IsNotOnEdit
        {
            get { return (bool)GetValue(IsNotOnEditProperty); }
            set { SetValue(IsNotOnEditProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsNotOnEdit.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsNotOnEditProperty =
            DependencyProperty.Register("IsNotOnEdit", typeof(bool), typeof(EditCombo), new PropertyMetadata(true));
    }
}
