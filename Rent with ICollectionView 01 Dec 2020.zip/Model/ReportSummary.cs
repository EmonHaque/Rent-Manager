﻿using RentManager.Common;

namespace RentManager.Model
{
    public class ReportSummary : Notifiable
    {
        public int TotalReceivable { get; set; }
        public int TotalReceipt { get; set; }
        public string Heading { get; set; }
    }
}
