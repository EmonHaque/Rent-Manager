﻿using Microsoft.Data.Sqlite;
using RentManager.Common;
using RentManager.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Windows.Data;

namespace RentManager.ViewModel.Transact
{
    public class PassEntryVM : Notifiable
    {
        Tenant selectedTenant;
        int? selectedPlot;
        bool isFocused => MainVM.SelectedMenu.Name == Constants.Transact;
        ObservableCollection<int?> plots;
        ObservableCollection<Transaction> entries;
        bool filterState;
        public bool FilterState
        {
            get => filterState;
            set { filterState = value; Tenants.Refresh(); }
        }
        public Transaction Entry { get; set; }
        public int TotalAmount { get; set; }
        public ICollectionView Plots { get; set; }
        public ICollectionView Spaces { get; set; }
        public ICollectionView Tenants { get; set; }
        public ICollectionView Heads { get; set; }
        public ICollectionView Entries { get; set; }

        public Command AddEntry { get; set; }
        public Command RemoveEntry { get; set; }
        public Command PassEntries { get; set; }

        public PassEntryVM()
        {
            Entry = new Transaction();
            initializeCollections();
            subscribe();
            initializeFilters();
            initializeCommands();
        }

        #region for Constructor
        void initializeCollections()
        {
            plots = new ObservableCollection<int?>();
            entries = new ObservableCollection<Transaction>();
            BindingOperations.EnableCollectionSynchronization(entries, entries);
            Tenants = new CollectionViewSource() 
            { 
                Source = MainVM.tenants,
                IsLiveFilteringRequested = true,
                LiveFilteringProperties = { nameof(Tenant.HasLeft) }
            }.View;
            Heads = new CollectionViewSource() { Source = MainVM.heads }.View;
            Plots = CollectionViewSource.GetDefaultView(new List<int?>());
            Entries = new CollectionViewSource() 
            { 
                Source = entries, 
                IsLiveGroupingRequested = true,
                LiveGroupingProperties = { nameof(Transaction.HeadId) }
            }.View;
            Entries.GroupDescriptions.Add(new PropertyGroupDescription(nameof(Transaction.HeadId)));
        }

        void subscribe()
        {
            Tenants.CurrentChanged += onTenantChanged;
            MainVM.ControlHeads.CurrentChanged += onControlHeadChanged;
            MainVM.OnSelectedMenuChanged += onMenuChanged;
            Plots.CurrentChanged += onPlotChanged;
        }

        void initializeFilters()
        {
            Tenants.Filter = filterTenants;
            Heads.Filter = filterHeads;
        }

        void initializeCommands()
        {
            AddEntry = new Command(addEntry, (o) => Entry.IsValid());
            RemoveEntry = new Command(removeEntry, (o) => entries.Count > 0);
            PassEntries = new Command(passEntries, (o) => !MainVM.TenantBusy && entries.Count > 0);
        }
        #endregion

        #region eventHandlers
        void onMenuChanged()
        {
            if (!isFocused) return;
            refreshPlots();
            Heads.Refresh();
        }

        void onTenantChanged(object sender, EventArgs e)
        {
            if(selectedTenant != Tenants.CurrentItem)
            {
                selectedTenant = Tenants.CurrentItem as Tenant;
                if (!isFocused) return;
                refreshPlots();
            }      
        }

        void onPlotChanged(object sender, EventArgs e)
        {
            if (selectedPlot != Plots.CurrentItem as int?)
            {
                selectedPlot = Plots.CurrentItem as int?;
                Spaces.Refresh();
            }
        }

        void onControlHeadChanged(object sender, EventArgs e)
        {
            if (!isFocused) return;
            Heads.Refresh();
            Entry.IsCash = (MainVM.ControlHeads.CurrentItem as ControlHead).Id == MainVM.controlIdOfReceivable ? false : true;
            Entry.OnPropertyChanged(nameof(Entry.IsCash));
        }
        #endregion

        #region filters
        bool filterTenants(object o) => FilterState ? !(o as Tenant).HasLeft : (o as Tenant).HasLeft;
        bool filterHeads(object o) => MainVM.ControlHeads.CurrentItem == null ? false : (o as Head).ControlId == (MainVM.ControlHeads.CurrentItem as ControlHead).Id;
        bool filterSpaces(object o) => (o as Lease).PlotId == selectedPlot;
        #endregion

        #region ICommands
        void addEntry(object o)
        {
            entries.Add(Entry);
            TotalAmount += Entry.Amount;
            Entry = Entry.Clone();
            Entry.Amount = 0;
            OnPropertyChanged(nameof(TotalAmount));
            OnPropertyChanged(nameof(Entry));
        }

        void removeEntry(object o)
        {
            var tran = o as Transaction;
            TotalAmount -= tran.Amount;
            entries.Remove(tran);
            OnPropertyChanged(nameof(TotalAmount));
        }

        void passEntries(object o)
        {
            MainVM.DoAsync(ViewType.Tenant, () =>
            {
                var commands = new List<SqliteCommand>(entries.Count);
                foreach (var entry in entries)
                {
                    var narrattion = string.IsNullOrWhiteSpace(entry.Narration) ? (object)DBNull.Value : entry.Narration;
                    var cmd = new SqliteCommand(@$"INSERT INTO Transactions (Date, PlotId, SpaceId, TenantId, ControlId, HeadId, Amount, IsCash, Narration) 
                                                VALUES(@Date, @PlotId, @SpaceId, @TenantId, @ControlId, @HeadId, @Amount, @IsCash, @Narration)");
                    cmd.Parameters.AddWithValue("@Date", entry.Date.ToString("yyyy-MM-dd"));
                    cmd.Parameters.AddWithValue("@PlotId", entry.PlotId);
                    cmd.Parameters.AddWithValue("@SpaceId", entry.SpaceId);
                    cmd.Parameters.AddWithValue("@TenantId", entry.TenantId);
                    cmd.Parameters.AddWithValue("@ControlId", entry.ControlId);
                    cmd.Parameters.AddWithValue("@HeadId", entry.HeadId);
                    cmd.Parameters.AddWithValue("@Amount", entry.Amount);
                    cmd.Parameters.AddWithValue("@IsCash", Convert.ToInt32(entry.IsCash));
                    cmd.Parameters.AddWithValue("@Narration", narrattion);
                    commands.Add(cmd);
                }
                SQLHelper.Transaction(commands);
                foreach (var command in commands) command.Dispose();

                var num = entries.Count;
                entries.Clear();
                TotalAmount = 0;
                OnPropertyChanged(nameof(TotalAmount));

                MainVM.PopupMessage = $"{num} transaction(s) recorded";
                MainVM.Popup();
            });
        }
        #endregion

        void refreshPlots()
        {
            if (selectedTenant == null) 
            {
                plots.Clear();
                return;
            }
            var leases = MainVM.leases.Where(x => x.TenantId == selectedTenant.Id);
            if (leases.Count() > 0)
            {
                leases = leases.ToList();
                Spaces = CollectionViewSource.GetDefaultView(leases);
                OnPropertyChanged(nameof(Spaces));
                Spaces.Filter = filterSpaces;

                Plots.CurrentChanged -= onPlotChanged;
                plots = new ObservableCollection<int?>(leases.Select(x => x.PlotId).Distinct());
                Plots = CollectionViewSource.GetDefaultView(plots);
                Plots.CurrentChanged += onPlotChanged;
                OnPropertyChanged(nameof(Plots));
            }
            else plots.Clear();
        }
    }
}
