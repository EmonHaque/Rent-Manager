﻿using RentManager.Common;
using RentManager.Model;
using RentManager.View.Edit;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RentManager.ViewModel
{
    public class EditVM
    {
        static Tab selectedTab;
        public static Tab SelectedTab
        {
            get { return selectedTab; }
            set { selectedTab = value; OnSelectedTabChanged?.Invoke(); }
        }
        public List<Tab> Tabs { get; set; }
        public static event Action OnSelectedTabChanged;
        public EditVM()
        {
            initializeTabs();
            SelectedTab = Tabs.First();
        }

        void initializeTabs()
        {
            Tabs = new List<Tab>()
            {
                new Tab("Plot", ViewType.Plot, new EditPlotView(), Constants.PlotIcon),
                new Tab("Space", ViewType.Space, new EditSpaceView(), Constants.SpaceIcon),
                new Tab("Tenant", ViewType.Tenant, new EditTenantView(), Constants.TenantIcon),
                new Tab("Lease", ViewType.Lease, new EditLeaseView(), Constants.LeaseIcon),
                new Tab("Head", ViewType.Head, new EditHeadView(), Constants.HeadIcon),
                new Tab("Transaction", ViewType.Transaction, new EditTransactionView(), Constants.TransactIcon),
            };          
        }
    }
}
