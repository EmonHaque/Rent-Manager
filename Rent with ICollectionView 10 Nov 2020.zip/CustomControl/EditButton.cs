﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace RentManager.CustomControl
{
    public class EditButton : Control
    {
        static EditButton()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(EditButton), new FrameworkPropertyMetadata(typeof(EditButton)));
        }

        public bool IsOnEdit
        {
            get { return (bool)GetValue(IsOnEditProperty); }
            set { SetValue(IsOnEditProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsOnEdit.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsOnEditProperty =
            DependencyProperty.Register("IsOnEdit", typeof(bool), typeof(EditButton), new PropertyMetadata(false, OnIsOnEditChanged));

        static void OnIsOnEditChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if ((bool)e.NewValue) (d as EditButton).IsNotOnEdit = false;
            else (d as EditButton).IsNotOnEdit = true;
        }

        public bool IsNotOnEdit
        {
            get { return (bool)GetValue(IsNotOnEditProperty); }
            set { SetValue(IsNotOnEditProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsNotOnEdit.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsNotOnEditProperty =
            DependencyProperty.Register("IsNotOnEdit", typeof(bool), typeof(EditButton), new PropertyMetadata(true));


        public ICommand EditCommand
        {
            get { return (ICommand)GetValue(EditCommandProperty); }
            set { SetValue(EditCommandProperty, value); }
        }

        // Using a DependencyProperty as the backing store for EditCommand.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty EditCommandProperty =
            DependencyProperty.Register("EditCommand", typeof(ICommand), typeof(EditButton), new PropertyMetadata(null));


        public ICommand CancelCommand
        {
            get { return (ICommand)GetValue(CancelCommandProperty); }
            set { SetValue(CancelCommandProperty, value); }
        }

        // Using a DependencyProperty as the backing store for CancelCommand.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty CancelCommandProperty =
            DependencyProperty.Register("CancelCommand", typeof(ICommand), typeof(EditButton), new PropertyMetadata(null));


        public ICommand SaveCommand
        {
            get { return (ICommand)GetValue(SaveCommandProperty); }
            set { SetValue(SaveCommandProperty, value); }
        }

        // Using a DependencyProperty as the backing store for SaveCommand.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SaveCommandProperty =
            DependencyProperty.Register("SaveCommand", typeof(ICommand), typeof(EditButton), new PropertyMetadata(null));


    }
}
