﻿using RentManager.Common;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace RentManager.CustomControl
{
    public class DayPicker : DatePicker
    {
        static DayPicker()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(DayPicker), new FrameworkPropertyMetadata(typeof(DayPicker)));
        }

        public ICommand Popup
        {
            get { return (ICommand)GetValue(PopupProperty); }
            set { SetValue(PopupProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Popup.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty PopupProperty =
            DependencyProperty.Register("Popup", typeof(ICommand), typeof(DayPicker), new PropertyMetadata(null));

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            Popup = new Command(popup, (o) => true);
        }

        void popup(object o) => IsDropDownOpen = true;
    }
}
