﻿using RentManager.Common;
using RentManager.Model;
using System.Diagnostics;
using System.Windows.Data;

namespace RentManager.ViewModel.Edit
{
    public class EditPlotVM : EditBase<Plot>
    {
        public EditPlotVM()
        {
            selected = MainVM.Plots.CurrentItem as Plot;
            Editables = CollectionViewSource.GetDefaultView(MainVM.plots);
        }

        #region base implementation
        protected override ViewType type => ViewType.Plot;
        protected override void save()
        {
            lock (SQLHelper.key)
            {
                using var cmd = SQLHelper.connection.CreateCommand();
                cmd.CommandText = "UPDATE Plots SET Name = @Name, Description = @Description WHERE Id = @Id";
                cmd.Parameters.AddWithValue("@Name", Edited.Name);
                cmd.Parameters.AddWithValue("@Description", Edited.Description);
                cmd.Parameters.AddWithValue("@Id", Edited.Id);
                SQLHelper.NonQuery(cmd);
            }
            base.notifyLeaseForNameChange(selected.Name, Edited.Name, selected);
        }
        #endregion
    }
}
