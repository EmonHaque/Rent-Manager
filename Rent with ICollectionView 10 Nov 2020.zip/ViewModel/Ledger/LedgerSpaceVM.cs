﻿using RentManager.Common;
using RentManager.Model;
using System.ComponentModel;
using System.Linq;
using System.Windows.Data;

namespace RentManager.ViewModel.Ledger
{
    public class LedgerSpaceVM : LedgerBase
    {
        public ICollectionView Spaces { get; set; }
        public LedgerSpaceVM()
        {
            Spaces = new CollectionViewSource() { Source = MainVM.spaces }.View;
            Spaces.GroupDescriptions.Add(new PropertyGroupDescription(nameof(Space.PlotId)));
        }

        #region base implementation
        protected override ViewType type => ViewType.Space;
        protected override string particulars => "t.Name";
        protected override string where => "SpaceId";
        protected override void setTitleAndSubTitle()
        {
            var space = MainVM.spaces.First(x => x.Id == base.Id);
            base.reportTitle = space.Name + " of " + MainVM.plots.First(x => x.Id == space.PlotId).Name;
            base.reportSubTitle = space.Description;
        }
        #endregion
    }
}
