﻿namespace RentManager.Model
{
    public enum ViewType
    {
        Plot,
        Space,
        Tenant,
        Lease,
        Head,
        Transaction,
        CurrentBalance,
        Periodic
    }
}
