﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace RentManager.Abstracts
{
    abstract class View : FrameworkElement
    {
        public virtual string Icon { get; }
        public abstract FrameworkElement container { get; }
        protected override Size MeasureOverride(Size availableSize) {
            if (container is ViewContainer) {
                container.Width = availableSize.Width;
                container.Height = availableSize.Height;
            }
            container.Measure(availableSize);
            return container.DesiredSize;
        }
        protected override Size ArrangeOverride(Size finalSize) {
            container.Arrange(new Rect(container.DesiredSize));
            return finalSize;
        }
        protected override Visual GetVisualChild(int index) => container;
        protected override int VisualChildrenCount => 1;
    }
}
