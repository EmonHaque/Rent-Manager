﻿using RentManager.CustomControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace RentManager.Abstracts
{
    abstract class ViewContainer : Grid
    {
        int selectedIndex, newIndex;
        bool isAnimating;
        List<View> containers;
        StackPanel navbar;
        DoubleAnimation getIn, getOut;
        public virtual string Icon { get; }
        
        public ViewContainer() {
            ClipToBounds = true;
            containers = new List<View>();
            var duration = TimeSpan.FromSeconds(1);
            var ease = new CubicEase() { EasingMode = EasingMode.EaseInOut };
            getIn = new DoubleAnimation() {
                To = 0,
                Duration = duration,
                EasingFunction = ease
            };
            getOut = new DoubleAnimation() {
                Duration = duration,
                EasingFunction = ease
            };          

            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
            navbar = new StackPanel() { Margin = new Thickness(0,10,0,0)};
            SetColumn(navbar, 1);
            Children.Add(navbar);
            getOut.Completed += reset;
        }

        void reset(object sender, EventArgs e) {
            containers[selectedIndex].Visibility = Visibility.Hidden;
            selectedIndex = newIndex;
            isAnimating = ((TransitButton)navbar.Children[selectedIndex]).isActing = false;
        }

        void go(int o) {
            var index = o;
            var oldIndex = selectedIndex;
            if (!isAnimating && index != oldIndex) {
                isAnimating = true;
                ((TransitButton)navbar.Children[index]).isActing = true;
                ((TransitButton)navbar.Children[index]).IsSelected = true;
                ((TransitButton)navbar.Children[selectedIndex]).IsSelected = false;

                newIndex = index;
                if (newIndex > oldIndex) {
                    getIn.From = Height;
                    getOut.To = -Height;
                }
                else {
                    getIn.From = -Height;
                    getOut.To = Height;
                }
                containers[oldIndex].RenderTransform.BeginAnimation(TranslateTransform.YProperty, getOut);
                containers[newIndex].RenderTransform.BeginAnimation(TranslateTransform.YProperty, getIn);
                containers[newIndex].Visibility = Visibility.Visible;
            }
        }
        protected override void OnVisualChildrenChanged(DependencyObject visualAdded, DependencyObject visualRemoved) {
            if (visualAdded is View) {
                var container = visualAdded as View;
                container.RenderTransform = new TranslateTransform(0, 0);
                containers.Add(container);
                if (!containers.ElementAt(selectedIndex).Equals(container))
                    container.Visibility = Visibility.Hidden;

                var button = new TransitButton(32);
                button.Icon = container.Icon;
                navbar.Children.Add(button);
                button.Command = go;
                button.index = navbar.Children.IndexOf(button);
                if (button.index == 0) button.IsSelected = true;
            }
        }
    }
}
