﻿using RentManager.Abstracts;
using RentManager.CustomControls;
using RentManager.Helpers;
using RentManager.Models;
using RentManager.ViewModels.Add;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace RentManager.Views.Add
{
    class AddTenant : CardView
    {
        public override string Header => "Tenant";
        EditText name, father, mother, husband, address, nid, phone;
        CommandButton button;
        AddTenantVM viewModel;
        public AddTenant() : base() {
            viewModel = new AddTenantVM();
            DataContext = viewModel;
            initializeUI();
            bind();
        }

        void initializeUI() {
            name = new EditText() {
                Hint = "Name",
                IsRequired = true,
                Icon = Icons.Tenant
            };
            father = new EditText() {
                Hint = "Father",
                IsRequired = true,
                Icon = Icons.Father
            };
            Grid.SetRow(father, 1);
            mother = new EditText() {
                Hint = "Mother",
                Icon = Icons.Mother
            };
            Grid.SetRow(mother, 2);
            husband = new EditText() {
                Hint = "Husband",
                Icon = Icons.Husband
            };
            Grid.SetRow(husband, 3);
            address = new EditText() {
                Hint = "Address",
                IsRequired = true,
                IsMultiline = true,
                Icon = Icons.Address
            };
            Grid.SetRow(address, 4);
            nid = new EditText() {
                Hint = "National ID",
                Icon = Icons.ID
            };
            Grid.SetRow(nid, 5);
            phone = new EditText() {
                Hint = "Phone",
                IsRequired = true,
                Icon = Icons.Phone
            };
            Grid.SetRow(phone, 6);
            button = new CommandButton() {
                Width = 24,
                Height = 24,
                Icon = Icons.Add,
                Command = viewModel.Add,
                HorizontalAlignment = HorizontalAlignment.Right
            };
            Grid.SetRow(button, 7);
            var grid = new Grid() {
                RowDefinitions = {
                    new RowDefinition() { Height = GridLength.Auto },
                    new RowDefinition() { Height = GridLength.Auto },
                    new RowDefinition() { Height = GridLength.Auto },
                    new RowDefinition() { Height = GridLength.Auto },
                    new RowDefinition(),
                    new RowDefinition() { Height = GridLength.Auto },
                    new RowDefinition() { Height = GridLength.Auto },
                    new RowDefinition() { Height = GridLength.Auto },
                },
                Children = { name, father, mother, husband, address, nid, phone, button }
            };
            var viewer = new ScrollViewer() {
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                CanContentScroll = true,
                Content = grid
            };
            setContent(viewer);
        }

        void bind() {
            name.SetBinding(EditText.TextProperty, new Binding($"{nameof(viewModel.TObject)}.{nameof(Tenant.Name)}"));
            father.SetBinding(EditText.TextProperty, new Binding($"{nameof(viewModel.TObject)}.{nameof(Tenant.Father)}"));
            mother.SetBinding(EditText.TextProperty, new Binding($"{nameof(viewModel.TObject)}.{nameof(Tenant.Mother)}"));
            husband.SetBinding(EditText.TextProperty, new Binding($"{nameof(viewModel.TObject)}.{nameof(Tenant.Husband)}"));
            address.SetBinding(EditText.TextProperty, new Binding($"{nameof(viewModel.TObject)}.{nameof(Tenant.Address)}"));
            nid.SetBinding(EditText.TextProperty, new Binding($"{nameof(viewModel.TObject)}.{nameof(Tenant.NID)}"));
            phone.SetBinding(EditText.TextProperty, new Binding($"{nameof(viewModel.TObject)}.{nameof(Tenant.ContactNo)}"));

            name.SetBinding(EditText.ErrorProperty, new Binding(nameof(viewModel.ErrorName)));
            father.SetBinding(EditText.ErrorProperty, new Binding(nameof(viewModel.ErrorFather)));
            address.SetBinding(EditText.ErrorProperty, new Binding(nameof(viewModel.ErrorAddress)));
            phone.SetBinding(EditText.ErrorProperty, new Binding(nameof(viewModel.ErrorContactNo)));
            button.SetBinding(IsEnabledProperty, new Binding(nameof(viewModel.IsValid)));
        }
    }
}
