﻿using RentManager.Abstracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace RentManager.CustomControls
{
    class RootPanel : Panel
    {
        double navWidth = 32;
        int selectedIndex, newIndex;
        bool isAnimating;
        List<UIElement> containers;
        List<TransitButton> buttons;
        Border border;
        Grid navContainer;
        DoubleAnimation getIn, getOut;
        TextBlock title;
        Size size;
        public RootPanel() {
            containers = new List<UIElement>();
            buttons = new List<TransitButton>();
            title = new TextBlock() {
                Text = "Rent Manager",
                FontWeight = FontWeights.Bold,
                FontSize = 20,
                Foreground = Brushes.Gray,
                VerticalAlignment = VerticalAlignment.Bottom,
                LayoutTransform = new RotateTransform(-90),
                Margin = new Thickness(0,0,0,10)
            };
            navContainer = new Grid() {
                Margin = new Thickness(0,0,0,5),
                RowDefinitions = { new RowDefinition() },
                Children = { title }
            };
            border = new Border() {
                Background = Brushes.LightGray,
                Width = navWidth,
                Child = navContainer,
                CornerRadius = new CornerRadius(0, 0, 0, 5)
            };
            SetZIndex(border, 1);
            Children.Add(border);

            var duration = TimeSpan.FromSeconds(1);
            var ease = new CubicEase() { EasingMode = EasingMode.EaseInOut };
            getIn = new DoubleAnimation() {
                To = 0,
                Duration = duration,
                EasingFunction = ease
            };
            getOut = new DoubleAnimation() {
                Duration = duration,
                EasingFunction = ease
            };
            getOut.Completed += reset;
            Loaded += onLoaded;
        }

        void onLoaded(object sender, RoutedEventArgs e) {
            int row = 1;
            foreach (TransitButton button in buttons) {
                navContainer.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
                Grid.SetRow(button, row++);
                navContainer.Children.Add(button);
            }
            SetZIndex(border, 2);
            title.Height = title.ActualWidth;
        }

        void reset(object sender, EventArgs e) {
            containers[selectedIndex].Visibility = Visibility.Hidden;
            selectedIndex = newIndex;
            isAnimating = buttons[selectedIndex].isActing = false;
        }

        void go(int o) {
            var index = o;
            var oldIndex = selectedIndex;
            if (!isAnimating && index != oldIndex) {
                isAnimating = true;
                buttons[index].isActing = true;
                buttons[index].IsSelected = true;
                buttons[selectedIndex].IsSelected = false;

                newIndex = index;

                if(newIndex > oldIndex) {
                    getIn.From = navWidth - size.Width;
                    getOut.To = size.Width - navWidth;
                }
                else {
                    getIn.From = size.Width;
                    getOut.To = -size.Width;
                }
                containers[oldIndex].RenderTransform.BeginAnimation(TranslateTransform.XProperty, getOut);
                containers[newIndex].RenderTransform.BeginAnimation(TranslateTransform.XProperty, getIn);
                containers[newIndex].Visibility = Visibility.Visible;
            }
        }

        protected override Size ArrangeOverride(Size finalSize) {
            size = finalSize;
            foreach (TransitButton item in buttons) 
                item.Width = item.Height = navWidth;
              
            foreach (FrameworkElement item in containers) {
                item.Width = finalSize.Width - navWidth;
                item.Height = finalSize.Height;
                item.Measure(finalSize);
                item.Arrange(new Rect(new Point(navWidth, 0), item.DesiredSize));
                if (!containers.ElementAt(selectedIndex).Equals(item))
                    item.Visibility = Visibility.Hidden;
            }
            border.Height = finalSize.Height;
            border.Measure(finalSize);
            border.Arrange(new Rect(new Point(0, 0), border.DesiredSize));
            return finalSize;
        }

        protected override void OnVisualChildrenChanged(DependencyObject visualAdded, DependencyObject visualRemoved) {
            if (visualAdded is ViewContainer) {
                var container = visualAdded as ViewContainer;
                container.RenderTransform = new TranslateTransform(0, 0);
                containers.Add(container);
                SetZIndex(container, 0);

                var button = new TransitButton(32);
                button.Icon = container.Icon;
                buttons.Add(button);
                button.Command = go;
                button.index = buttons.IndexOf(button);
                if (button.index == 0) button.IsSelected = true;
            }
            else if (visualAdded is View) {
                var container = visualAdded as View;
                container.RenderTransform = new TranslateTransform(0, 0);
                containers.Add(container);
                SetZIndex(container, 0);

                var button = new TransitButton(32);
                button.Icon = container.Icon;
                buttons.Add(button);
                button.Command = go;
                button.index = buttons.IndexOf(button);
                if (button.index == 0) button.IsSelected = true;
            }
        }
    }
}
