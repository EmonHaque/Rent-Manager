﻿using RentManager.Helpers;
using RentManager.Models;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace RentManager.ViewModels.Add
{
    public class AddPlotVM : AddBase<Plot>
    {
        public string ErrorName { get; set; }
        public string ErrorDescription { get; set; }
        public bool IsValid { get; set; }

        public AddPlotVM() : base() {
            TObject.Id = AppData.GetId(AppData.plots);
            initializeValidationProperties();
            TObject.PropertyChanged += validate;
        }

        void initializeValidationProperties() {
            IsValid = false;
            ErrorName = "Name is required";
            ErrorDescription = "Description is required";
            OnPropertyChanged(nameof(ErrorName));
            OnPropertyChanged(nameof(ErrorDescription));
            OnPropertyChanged(nameof(IsValid));
        }

        #region validation rules
        void validate(object sender, PropertyChangedEventArgs e) {
            switch (e.PropertyName) {
                case nameof(Plot.Name): validateName(); break;
                case nameof(Plot.Description): validateDescription(); break;
            }
            IsValid = ErrorName == string.Empty && ErrorDescription == string.Empty;
            OnPropertyChanged(nameof(IsValid));
        }
        void validateName() {
            ErrorName = string.Empty;
            if (string.IsNullOrWhiteSpace(TObject.Name)) {
                ErrorName = "Name is required";
            }
            else {
                for (int i = 0; i < AppData.plots.Count; i++) {
                    if (string.Equals(AppData.plots[i].Name, TObject.Name.Trim(), StringComparison.OrdinalIgnoreCase)) {
                        ErrorName = "Name exits";
                        break;
                    }
                }
            }
            OnPropertyChanged(nameof(ErrorName));
        }
        void validateDescription() {
            ErrorDescription = string.Empty;
            if (string.IsNullOrWhiteSpace(TObject.Description)) {
                ErrorDescription = "Description is required";
            }
            OnPropertyChanged(nameof(ErrorDescription));
        }
        #endregion

        #region base implementation
        protected override ObservableCollection<Plot> collection => AppData.plots;
        protected override void insertInDatabase()
        {
            using var cmd = SQLHelper.connection.CreateCommand();
            cmd.CommandText = "INSERT INTO Plots (Name, Description) VALUES(@Name, @Description)";
            cmd.Parameters.AddWithValue("@Name", TObject.Name);
            cmd.Parameters.AddWithValue("@Description", TObject.Description);
            SQLHelper.NonQuery(cmd);
        }
        protected override void renewTObject() {
            TObject.PropertyChanged -= validate;
            
            TObject = new Plot() { Id = TObject.Id + 1 };
            OnPropertyChanged(nameof(TObject));
            TObject.PropertyChanged += validate;
            initializeValidationProperties();
        }
        #endregion
    }
}
