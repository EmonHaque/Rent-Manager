﻿using RentManager.Abstracts;
using RentManager.CustomControls;
using RentManager.DataTemplates;
using RentManager.Helpers;
using RentManager.Models;
using RentManager.ViewModels.Home;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;

namespace RentManager.Views.Home
{
    class TenantDetail : CardView
    {
        public override string Header => "Due & Payments";

        MultiBarchart bar;
        SelectItem tenant;
        BiState state;
        TextBlock deposit;
        CommandButton refresh;
        TenantDetailVM viewModel;

        public TenantDetail() {
            viewModel = new TenantDetailVM();
            DataContext = viewModel;
            initializeUI();
            bind();
        }
        void refreshCommand() {
            if (BusyWindow.IsOpened) return;
            var position = PointToScreen(new Point(0, 0));
            var dpi = VisualTreeHelper.GetDpi(this);
            position.X /= dpi.DpiScaleX;
            position.Y /= dpi.DpiScaleY;
            position.X += Constants.CardMargin.Left;
            position.Y += Constants.CardMargin.Top;
            var width = ActualWidth - Constants.CardMargin.Left - Constants.CardMargin.Right;
            var height = ActualHeight - Constants.CardMargin.Top - Constants.CardMargin.Bottom;

            BusyWindow.Activate(position.X, position.Y, width, height, "Reloading ...");
            viewModel.Refresh.Invoke();
            BusyWindow.Terminate();
        }

        void initializeUI() {
            refresh = new CommandButton() {
                Command = refreshCommand,
                Icon = Icons.Refresh,
                ToolTip = "Reload",
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Top,
                Margin = new Thickness(0, -28, 0, 0),
                Focusable = false
            };
            tenant = new SelectItem() {
                Hint = "Tenant",
                IsRequired = true,
                Icon = Icons.Tenant,
                SelectedValuePath = nameof(Tenant.Id),
                ItemTemplate = new TenantTemplate(nameof(viewModel.Query), viewModel)
            };
            state = new BiState() {
                Text = "Existing",
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(5,0,0,0)
            };
            Grid.SetColumn(state, 1);
            var selectionGrid = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto }
                },
                Children = { tenant, state }
            };
            deposit = new TextBlock() { 
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(0,0,10,0),
                Foreground = Brushes.Gray,
                FontStyle = FontStyles.Italic
            };
            bar = new MultiBarchart();
            Grid.SetRow(deposit, 1);
            Grid.SetRow(bar, 2);
            var grid = new Grid() {
                RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(),
                },
                Children = { refresh, selectionGrid, deposit, bar }
            };
            setContent(grid);
        }
        void bind() {
            bar.SetBinding(MultiBarchart.ItemSourceProperty, new Binding(nameof(viewModel.Data)));
            refresh.SetBinding(CommandButton.IsEnabledProperty, new Binding(nameof(viewModel.IsRefreshvalid)));

            tenant.SetBinding(SelectItem.SelectedvalueProperty, new Binding(nameof(viewModel.SelectedTenant)));
            //tenant.SetBinding(SelectItem.ErrorProperty, new Binding(nameof(viewModel.ErrorTenantId)));
            tenant.SetBinding(SelectItem.ItemsSourceProperty, new Binding(nameof(viewModel.Tenants)));
            tenant.SetBinding(SelectItem.QueryProperty, new Binding(nameof(viewModel.Query)) { Mode = BindingMode.OneWayToSource });
            state.SetBinding(BiState.IsTrueProperty, new Binding(nameof(viewModel.State)));
            deposit.SetBinding(TextBlock.TextProperty, new Binding(nameof(viewModel.Deposit)));
        }
    }
}
