﻿using RentManager.Enums;
using RentManager.Helpers;
using System;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace RentManager.CustomControls
{
    class MonthPicker : Border
    {
        Grid grid, monthYearContainer, headerContainer;
        TextBlock headerBlock, hintBlock;
        ContentControl selectedContent;
        TextBox inputBox;
        Path leftIcon;
        Border selectedBorder, headerBorder;
        CommandButton button;
        DateTime currentDate;
        CalendarState currentState;
        Popup pop;
        Card card;
        SolidColorBrush brush;
        Run errorText, formatText;
        TranslateTransform translateHint;
        ScaleTransform scaleHint;
        DoubleAnimation translateHintAnim, scaleHintAnim;
        ColorAnimation brushAnim;
        bool isHintMoved;

        string hint;
        public string Hint {
            get { return hint; }
            set { hint = value; hintBlock.Inlines.Add(value); }
        }
        string monthFormat;
        public string MonthFormat {
            get { return monthFormat; }
            set {
                monthFormat = value;
                formatText = new Run() {
                    Text = $" [{value}]",
                    FontStyle = FontStyles.Italic,
                    Foreground = Brushes.Gray
                };
                hintBlock.Inlines.Add(formatText);
            }
        }
        bool isRequired;
        public bool IsRequired {
            get { return isRequired; }
            set { isRequired = value; }
        }

        public MonthPicker() {
            Margin = new Thickness(5);
            brush = new SolidColorBrush(Colors.SkyBlue);
            errorText = new Run() {
                Foreground = Brushes.Coral,
                FontStyle = FontStyles.Italic
            };
            currentState = CalendarState.Month;
            initializeSelectedItemControls();
            initializeAnimations();
            addHeader();
            initializeControls();

            grid = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(){Width = GridLength.Auto},
                    new ColumnDefinition(),
                    new ColumnDefinition(){Width = GridLength.Auto}
                },
                Children = { leftIcon, inputBox, hintBlock, selectedBorder, button }
            };

            BorderThickness = new Thickness(0, 0, 0, 1);
            BorderBrush = brush;
            Child = grid;

            initializeContainer();
            
            var panel = new StackPanel() { Children = { headerContainer, monthYearContainer } };

            card.Content = panel;
            pop = new Popup() {
                AllowsTransparency = true,
                StaysOpen = false,
                Placement = PlacementMode.Bottom,
                PlacementTarget = this,
                Child = card
            };
            pop.Opened += setIcon;
            pop.Closed += resetIcon;
            monthYearContainer.MouseLeftButtonUp += onMonthYearClicked;
            Unloaded += onUnloaded;
        }

        void onUnloaded(object sender, RoutedEventArgs e) {
            pop.Opened -= setIcon;
            pop.Closed -= resetIcon;
            monthYearContainer.MouseLeftButtonUp -= onMonthYearClicked;
            Unloaded -= onUnloaded;
            inputBox.KeyUp -= setMonth;
            selectedBorder.MouseLeftButtonUp -= showCalendar;
            headerBorder.MouseUp -= resetState;
        }
        void resetIcon(object sender, EventArgs e) => button.Icon = Icons.CalendarEdit;
        void setIcon(object sender, EventArgs e) => button.Icon = Icons.CalendarSearch;

        void onMonthYearClicked(object sender, MouseButtonEventArgs e) {
            if (e.Source is MonthYear) {
                var element = e.Source as MonthYear;
                foreach (MonthYear item in monthYearContainer.Children) {
                    if (item.IsSelected) {
                        item.IsSelected = false;
                        break;
                    }
                }
                if (element.state == CalendarState.Month) {
                    currentDate = new DateTime(currentDate.Year, element.number, 1);
                    SelectedDate = currentDate;
                    setSelectedItem();
                }
                else {
                    currentDate = new DateTime(element.number, 1, 1);
                    addMonths();
                }
                element.IsSelected = true;
            }
        }
        void initializeAnimations() {
            var duration = TimeSpan.FromMilliseconds(250);
            var ease = new CubicEase { EasingMode = EasingMode.EaseInOut };
            scaleHintAnim = new DoubleAnimation {
                Duration = duration,
                EasingFunction = ease
            };
            translateHintAnim = new DoubleAnimation {
                Duration = duration,
                EasingFunction = ease
            };
            brushAnim = new ColorAnimation {
                Duration = duration,
                EasingFunction = ease
            };
        }
        void initializeControls() {
            leftIcon = new Path() {
                Fill = brush,
                Data = Geometry.Parse(Icons.Calendar),
                Stretch = Stretch.Uniform,
                Width = 18,
                Height = 18
            };
            translateHint = new TranslateTransform();
            scaleHint = new ScaleTransform();

            hintBlock = new TextBlock {
                Padding = new Thickness(5, 0, 5, 0),
                Foreground = Brushes.Gray,
                Background = Brushes.White,
                HorizontalAlignment = HorizontalAlignment.Left,
                VerticalAlignment = VerticalAlignment.Center,
                RenderTransform = new TransformGroup {
                    Children = { scaleHint, translateHint }
                }
            };
            Grid.SetColumn(hintBlock, 1);
            inputBox = new TextBox() {
                Margin = new Thickness(5),
                BorderThickness = new Thickness(0)
            };
            Grid.SetColumn(inputBox, 1);
            button = new CommandButton() {
                Width = 18,
                Height = 18,
                Icon = Icons.CalendarEdit,
                Command = showCalendar
            };
            Grid.SetColumn(button, 2);
            inputBox.KeyUp += setMonth;
        }
        void initializeContainer() {
            monthYearContainer = new Grid();
            currentDate = DateTime.Today;
            card = new Card() { Width = 350, Height = 250 };
            addMonths();
        }
        void initializeSelectedItemControls() {
            selectedContent = new ContentControl() {
                Margin = new Thickness(10, 0, 0, 0),
                VerticalAlignment = VerticalAlignment.Center,
                FocusVisualStyle = null,
            };
            var close = new CommandButton() {
                Width = 16,
                Height = 16,
                Icon = Icons.CloseCircle,
                Command = removeSelected
            };
            Grid.SetColumn(close, 1);
            selectedBorder = new Border() {
                Background = Brushes.WhiteSmoke,
                Margin = new Thickness(5, 0, 5, 0),
                CornerRadius = new CornerRadius(5),
                Padding = new Thickness(5, 0, 5, 0),
                Visibility = Visibility.Hidden,
                Child = new Grid() {
                    ColumnDefinitions = {
                        new ColumnDefinition(),
                        new ColumnDefinition(){Width = GridLength.Auto}
                    },
                    Children = { selectedContent, close }
                }
            };
            Grid.SetColumn(selectedBorder, 1);
            selectedBorder.MouseLeftButtonUp += showCalendar;
        }
        void showCalendar(object sender, MouseButtonEventArgs e) => pop.IsOpen = true;
        void removeSelected() {
            selectedBorder.Visibility = Visibility.Hidden;
            inputBox.Text = string.Empty;
            inputBox.IsEnabled = true;
            SelectedDate = null;
            hintBlock.Inlines.Add(formatText);
            if (IsRequired) hintBlock.Inlines.Add(errorText);
            if (isHintMoved) moveHintDown();
        }
        void animateHint() {
            translateHint.BeginAnimation(TranslateTransform.YProperty, translateHintAnim);
            scaleHint.BeginAnimation(ScaleTransform.ScaleYProperty, scaleHintAnim);
            scaleHint.BeginAnimation(ScaleTransform.ScaleXProperty, scaleHintAnim);
        }
        void moveHintUp() {
            isHintMoved = true;
            scaleHintAnim.To = 0.9;
            translateHintAnim.To = -20;
            animateHint();
        }
        void moveHintDown() {
            isHintMoved = false;
            scaleHintAnim.To = 1;
            translateHintAnim.To = 0;
            animateHint();
        }
        void increase() {
            switch (currentState) {
                case CalendarState.Month:
                    currentDate = currentDate.AddYears(1);
                    addMonths();
                    break;
                case CalendarState.Year:
                    currentDate = currentDate.AddYears(12);
                    addYears();
                    break;
            }
        }
        void decrease() {
            switch (currentState) {
                case CalendarState.Month:
                    currentDate = currentDate.AddYears(-1);
                    addMonths();
                    break;
                case CalendarState.Year:
                    currentDate = currentDate.AddYears(-12);
                    addYears();
                    break;
            }
        }
        void addHeader() {
            headerBlock = new TextBlock() {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                FontWeight = FontWeights.Bold,
                FontSize = 16,
                Text = currentDate.ToString("yyyy")
            };
            headerBorder = new Border() {
                Background = Brushes.Transparent,
                Child = headerBlock,
            };
            Grid.SetColumn(headerBorder, 1);
            var back = new CommandButton() {
                Width = 24,
                Height = 24,
                Icon = Icons.ScrollLeft,
                Command = decrease,
                Margin = new Thickness(5, 0, 0, 0)
            };
            var forward = new CommandButton() {
                Width = 24,
                Height = 24,
                Icon = Icons.ScrollRight,
                Command = increase,
                Margin = new Thickness(0, 0, 5, 0)
            };
            Grid.SetColumn(forward, 2);
            headerContainer = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto }
                },
                Children = { back, headerBorder, forward }
            };
            headerBorder.MouseUp += resetState;
        }
        void addMonths() {
            currentState = CalendarState.Month;
            headerBlock.Text = currentDate.ToString("yyyy");
            monthYearContainer.Children.Clear();
            monthYearContainer.RowDefinitions.Clear();
            monthYearContainer.ColumnDefinitions.Clear();
            for (int i = 0; i < 3; i++)
                monthYearContainer.ColumnDefinitions.Add(new ColumnDefinition());

            var today = DateTime.Today;
            int currentMonth = 1;
            for (int i = 0; i < 4; i++) {
                monthYearContainer.RowDefinitions.Add(new RowDefinition());
                for (int j = 0; j < 3; j++) {
                    var month = new MonthYear(currentMonth, currentState);
                    if (SelectedDate.HasValue) {
                        if (currentMonth == SelectedDate.Value.Month && currentDate.Year == SelectedDate.Value.Year)
                            month.IsSelected = true;
                    }
                    if (currentMonth == today.Month && currentDate.Year == today.Year)
                        month.IsThisMonthOrYear = true;
                    Grid.SetRow(month, i);
                    Grid.SetColumn(month, j);
                    monthYearContainer.Children.Add(month);
                    currentMonth++;
                }
            }
        }
        void addYears() {
            currentState = CalendarState.Year;
            headerBlock.Text = (currentDate.Year - 11) + " - " + currentDate.Year;
            var today = DateTime.Today;
            int currentYear = currentDate.Year - 11;
            monthYearContainer.Children.Clear();
            for (int i = 0; i < 4; i++) {
                for (int j = 0; j < 3; j++) {
                    var year = new MonthYear(currentYear, currentState);
                    if (SelectedDate.HasValue) {
                        if (currentYear == SelectedDate.Value.Year)
                            year.IsSelected = true;
                    }
                    if (currentYear == today.Year)
                        year.IsThisMonthOrYear = true;
                    Grid.SetRow(year, i);
                    Grid.SetColumn(year, j);
                    monthYearContainer.Children.Add(year);
                    currentYear++;
                }
            }
        }
        void showCalendar() {
            addMonths();
            pop.IsOpen = true;
        }
        void resetState(object sender, MouseButtonEventArgs e) {
            switch (currentState) {
                case CalendarState.Month: addYears(); break;
                case CalendarState.Year: addMonths(); break;
            }
        }
        void setMonth(object sender, KeyEventArgs e) {
            if (e.Key != Key.Enter) return;
            DateTime input;
            if (DateTime.TryParseExact(inputBox.Text, MonthFormat, null, DateTimeStyles.None, out input)) {
                currentDate = input;
                SelectedDate = input;
                setSelectedItem();
            }
        }
        void setSelectedItem() {
            if (!isHintMoved) moveHintUp();
            inputBox.IsEnabled = false;
            selectedContent.Content = SelectedDate.Value.ToString("MMMM yyyy");
            selectedBorder.Visibility = Visibility.Visible;
            hintBlock.Inlines.Remove(formatText);
            if (IsRequired) hintBlock.Inlines.Remove(errorText);
            pop.IsOpen = false;
            Keyboard.Focus(selectedContent);
        }

        protected override void OnMouseEnter(MouseEventArgs e) {
            if (string.IsNullOrWhiteSpace(inputBox.Text)) {
                inputBox.Focus();
                brushAnim.To = Colors.CornflowerBlue;
                brush.BeginAnimation(SolidColorBrush.ColorProperty, brushAnim);
            }
        }
        protected override void OnGotKeyboardFocus(KeyboardFocusChangedEventArgs e) {
            if (!isHintMoved) moveHintUp();
            brushAnim.To = Colors.CornflowerBlue;
            brush.BeginAnimation(SolidColorBrush.ColorProperty, brushAnim);
        }
        protected override void OnPreviewLostKeyboardFocus(KeyboardFocusChangedEventArgs e) {
            if (inputBox.IsEnabled && string.IsNullOrWhiteSpace(inputBox.Text) && !pop.IsOpen)
                moveHintDown();
            if (!pop.IsOpen) {
                brushAnim.To = Colors.SkyBlue;
                brush.BeginAnimation(SolidColorBrush.ColorProperty, brushAnim);
            }
        }

        public DateTime? SelectedDate {
            get { return (DateTime?)GetValue(SelectedDateProperty); }
            set { SetValue(SelectedDateProperty, value); }
        }
        public string Error {
            get { return (string)GetValue(ErrorProperty); }
            set { SetValue(ErrorProperty, value); }
        }

        public static readonly DependencyProperty ErrorProperty =
            DependencyProperty.Register("Error", typeof(string), typeof(MonthPicker), new PropertyMetadata(null, onErrorChanged));

        public static readonly DependencyProperty SelectedDateProperty =
            DependencyProperty.Register("SelectedDate", typeof(DateTime?), typeof(MonthPicker), new FrameworkPropertyMetadata() {
                DefaultValue = null,
                BindsTwoWayByDefault = true,
                PropertyChangedCallback = onDateChanged
            });

        static void onDateChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
            var o = d as MonthPicker;
            if (e.NewValue == null) o.removeSelected();
            else o.setSelectedItem();
        }

        static void onErrorChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
            var o = d as MonthPicker;
            if (e.NewValue != null) {
                o.errorText.Text = e.NewValue.ToString();
                if (o.IsRequired) o.hintBlock.Inlines.Add(o.errorText);
            }
        }
    }
}
