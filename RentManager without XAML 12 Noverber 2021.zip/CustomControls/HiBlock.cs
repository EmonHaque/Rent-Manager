﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;

namespace RentManager.CustomControls
{
    class HiBlock : TextBlock
    {
        public string Query {
            get { return (string)GetValue(QueryProperty); }
            set { SetValue(QueryProperty, value); }
        }
        public static readonly DependencyProperty QueryProperty =
            DependencyProperty.Register("Query", typeof(string), typeof(HiBlock), new PropertyMetadata(null, onQueryChanged));

        static void onQueryChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {            
            var block = d as HiBlock;
            if (block.Visibility == Visibility.Collapsed) return;
            var query = block.Query;
            var text = block.Text;         
            if (!string.IsNullOrWhiteSpace(text)) {
                block.Inlines.Clear();
                if (string.IsNullOrWhiteSpace(query)) block.Inlines.Add(text);
                else {
                    int index = text.IndexOf(query, StringComparison.OrdinalIgnoreCase);
                    if (index < 0) block.Inlines.Add(text);
                    else {
                        int startIndex = 0;
                        for (
                            int i = text.IndexOf(query, StringComparison.OrdinalIgnoreCase);
                            i > -1;
                            i = text.IndexOf(query, i + 1, StringComparison.OrdinalIgnoreCase)) {
                            block.Inlines.Add(text.Substring(startIndex, i - startIndex));
                            block.Inlines.Add(new Run(text.Substring(i, query.Length)) { Background = Brushes.LightBlue });
                            startIndex = i + query.Length;
                        }
                        if (startIndex < text.Length) block.Inlines.Add(text.Substring(startIndex));
                    }
                }
            }
            else {
                List<Run> inlines = new(block.Inlines.Count);
                foreach (Run line in block.Inlines) {
                    inlines.Add(new Run() {
                        Text = line.Text,
                        FontStyle = line.FontStyle,
                        Foreground = line.Foreground,
                        FontWeight = line.FontWeight
                    });
                }
                block.Inlines.Clear();
                foreach (Run item in inlines) {
                    if (string.IsNullOrWhiteSpace(query)) block.Inlines.Add(item);
                    else {
                        int index = item.Text.IndexOf(query, StringComparison.OrdinalIgnoreCase);
                        if (index < 0) block.Inlines.Add(item);
                        else {
                            int startIndex = 0;
                            for (
                                int i = item.Text.IndexOf(query, StringComparison.OrdinalIgnoreCase);
                                i > -1;
                                i = item.Text.IndexOf(query, i + 1, StringComparison.OrdinalIgnoreCase)) {
                                block.Inlines.Add(new Run(item.Text.Substring(startIndex, i - startIndex)) {
                                    FontStyle = item.FontStyle,
                                    Foreground = item.Foreground,
                                    FontWeight = item.FontWeight
                                });
                                block.Inlines.Add(new Run(item.Text.Substring(i, query.Length)) {
                                    Background = Brushes.LightBlue,
                                    FontStyle = item.FontStyle,
                                    Foreground = item.Foreground,
                                    FontWeight = item.FontWeight
                                });
                                startIndex = i + query.Length;
                            }
                            if (startIndex < item.Text.Length) block.Inlines.Add(new Run(item.Text.Substring(startIndex)) {
                                FontStyle = item.FontStyle,
                                Foreground = item.Foreground,
                                FontWeight = item.FontWeight
                            });
                        }
                    }
                }
            }
        }
    }
}
