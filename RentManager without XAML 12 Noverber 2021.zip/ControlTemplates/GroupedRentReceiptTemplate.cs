﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;

namespace RentManager.ControlTemplates
{
    class GroupedRentReceiptTemplate : ControlTemplate
    {
        public GroupedRentReceiptTemplate() {
            TargetType = typeof(GroupItem);
            var grid = new FrameworkElementFactory(typeof(Grid));
            var row1 = new FrameworkElementFactory(typeof(RowDefinition));
            var row2 = new FrameworkElementFactory(typeof(RowDefinition));
            var headerBorder = new FrameworkElementFactory(typeof(Border));
            var items = new FrameworkElementFactory(typeof(ItemsPresenter));
            var header = new FrameworkElementFactory(typeof(TextBlock));
            row1.SetValue(RowDefinition.HeightProperty, GridLength.Auto);
            headerBorder.SetValue(Border.BorderThicknessProperty, new Thickness(0, 0, 0, 1));
            headerBorder.SetValue(Border.BorderBrushProperty, Brushes.LightBlue);
            header.SetValue(TextBlock.FontWeightProperty, FontWeights.Bold);
            header.SetBinding(TextBlock.TextProperty, new Binding(nameof(GroupItem.Name)));

            items.SetValue(Grid.RowProperty, 1);
            items.SetValue(ItemsPresenter.MarginProperty, new Thickness(10, 0, 0, 0));
            headerBorder.AppendChild(header);

            grid.AppendChild(row1);
            grid.AppendChild(row2);
            grid.AppendChild(headerBorder);
            grid.AppendChild(items);
            VisualTree = grid;
        }
    }
}
