﻿class TriState : Grid
    {
        Path icon;
        TextBlock block;
        SolidColorBrush brush;
        Color normalColor, highlightColor, downColor;
        ColorAnimation anim;
        public string CheckedIcon { get; set; }
        public string UncheckedIcon { get; set; }
        public string UndefinedIcon { get; set; }
        public string CheckedTip { get; set; }
        public string UncheckedTip { get; set; }
        public string UndefinedTip { get; set; }
        public bool IsIconInfront { get; set; }
        public TriState() {
            normalColor = Colors.CornflowerBlue;
            highlightColor = Colors.Coral;
            downColor = Colors.Red;
            brush = new SolidColorBrush(normalColor);
            block = new TextBlock() { VerticalAlignment = VerticalAlignment.Center };
            icon = new Path() {
                Height = 12,
                Width = 12,
                Stretch = Stretch.Uniform,
                Fill = brush,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(5, 0, 0, 0)
            };
            SetColumn(icon, 1);
            Background = Brushes.Transparent;
            ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
            ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
            Children.Add(block);
            Children.Add(icon);

            anim = new ColorAnimation() {
                Duration = TimeSpan.FromMilliseconds(250),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
            Loaded += onLoaded;
            Unloaded += onUnloaded;
        }

        void onUnloaded(object sender, RoutedEventArgs e) {
            Loaded -= onLoaded;
            Unloaded -= onUnloaded;
        }
        void onLoaded(object sender, RoutedEventArgs e) {
            if (CheckedIcon == null) CheckedIcon = Icons.Existing;
            if (UncheckedIcon == null) UncheckedIcon = Icons.LeftOrExpired;
            if (UndefinedIcon == null) UndefinedIcon = Icons.All;
            if (Text != null) block.SetBinding(TextBlock.TextProperty, new Binding(nameof(Text)) { Source = this });
            icon.Data = Geometry.Parse(CheckedIcon);
            ToolTip = CheckedTip;
            if (IsIconInfront) {
                icon.Margin = new Thickness(0, 0, 5, 0);
                Grid.SetColumn(icon, 0);
                Grid.SetColumn(block, 1);
            }
        }
        void animateBrush(Color c) {
            anim.To = c;
            brush.BeginAnimation(SolidColorBrush.ColorProperty, anim);
        }
        protected override void OnMouseEnter(MouseEventArgs e) => animateBrush(highlightColor);
        protected override void OnMouseLeave(MouseEventArgs e) => animateBrush(normalColor);
        protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e) {
            if (State.HasValue) {
                if (State.Value) {
                    State = false;
                    ToolTip = UncheckedTip;
                }
                else {
                    State = null;
                    ToolTip = UndefinedTip;
                }
            }
            else {
                State = true;
                ToolTip = CheckedTip;
            }
        }
        protected override void OnMouseDown(MouseButtonEventArgs e) => animateBrush(downColor);

        public bool? State {
            get { return (bool?)GetValue(StateProperty); }
            set { SetValue(StateProperty, value); }
        }
        public string Text {
            get { return (string)GetValue(TextProperty); }
            set { SetValue(TextProperty, value); }
        }
        public static readonly DependencyProperty TextProperty =
            DependencyProperty.Register("Text", typeof(string), typeof(TriState), new PropertyMetadata(null));

        public static readonly DependencyProperty StateProperty =
            DependencyProperty.Register("State", typeof(bool?), typeof(TriState), new FrameworkPropertyMetadata() {
                DefaultValue = true,
                BindsTwoWayByDefault = true,
                PropertyChangedCallback = (s, e) => {
                    var o = (TriState)s;
                    bool? state = (bool?)e.NewValue;
                    if (state.HasValue) {
                        if (state.Value) o.icon.Data = Geometry.Parse(o.CheckedIcon);
                        else  o.icon.Data = Geometry.Parse(o.UncheckedIcon);
                    }
                    else o.icon.Data = Geometry.Parse(o.UndefinedIcon);
                }
            });
    }
