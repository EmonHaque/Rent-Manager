﻿class BalancePage
{
    double margin, remainingHeight;
    StackPanel header;
    Grid content;
    Border footer, columnNames, pageTotal;
    TextBlock title, subTitle, asAt, totalSecurity, totalRent, totalDue, footNoteBlock;
    ItemsControl entries;
    Run currentPage, totalPage;

    public FixedPage Page { get; set; }
    public Size PageSize { get; set; }
    public int PageNo { get; set; }
    public string Title { get; set; }
    public string SubTitle { get; set; }
    public string AsAt { get; set; }
    public int TotalSecurity { get; set; }
    public int TotalRent { get; set; }
    public int TotalDue { get; set; }

    string footNote;
    public string FootNote {
        get { return footNote; }
        set { footNote = value; footNoteBlock.Text = value; measure(); }
    }
    bool isComplete;
    public bool IsComplete {
        get { return isComplete; }
        set {
            isComplete = value;
            entries.UpdateLayout();
            addPageTotals();
        }
    }
    int numberOfPage;
    public int NumberOfPage {
        get { return numberOfPage; }
        set { numberOfPage = value; totalPage.Text = value.ToString(); }
    }
    public BalancePage(Size pageSize) {
        margin = 96d * 0.7;
        initializeHeader();
        initializeContent();
        initializeFooter();
        PageSize = pageSize;
        PageNo = 1;
        Page = new FixedPage() {
            Width = PageSize.Width,
            Height = PageSize.Height,
            Margin = new Thickness(margin),
            Children = { header, content, footer }
        };
    }
    public BalancePage(BalancePage previousPage) : this(previousPage.PageSize) {
        Title = previousPage.Title;
        SubTitle = previousPage.SubTitle;
        AsAt = previousPage.AsAt;
        PageNo = previousPage.PageNo + 1;
        FootNote = previousPage.FootNote;
        AddEntry(new Balance() {
            Count = 1,
            Tenant = "balance b/d",
            Security = previousPage.TotalSecurity,
            Rent = previousPage.TotalRent,
            Due = previousPage.TotalDue
        });
    }

    void measure() {
        var availableSize = new Size(PageSize.Width - 2 * margin, PageSize.Height - 2 * margin);
        title.Text = Title;
        subTitle.Text = SubTitle;
        asAt.Text = AsAt;
        currentPage.Text = "Page: " + PageNo;

        double y = 0;
        foreach (FrameworkElement item in Page.Children) {
            item.Width = availableSize.Width;
            item.Measure(availableSize);
            FixedPage.SetTop(item, y);
            y += item.DesiredSize.Height;
        }
        var contentHeight = availableSize.Height - header.DesiredSize.Height - footer.DesiredSize.Height;
        content.Height = contentHeight;
        remainingHeight = contentHeight - pageTotal.DesiredSize.Height;
        FixedPage.SetTop(footer, header.DesiredSize.Height + contentHeight);
    }
    void initializeHeader() {
        title = new TextBlock() { FontSize = 16, TextAlignment = TextAlignment.Center };
        subTitle = new TextBlock() { FontSize = 14, TextAlignment = TextAlignment.Center };
        asAt = new TextBlock() { FontSize = 12, TextAlignment = TextAlignment.Center };

        var colNameAndSpaces = new TextBlock() { Text = "Name and Space", HorizontalAlignment = HorizontalAlignment.Left };
        var colFrom = new TextBlock() { Text = "From", HorizontalAlignment = HorizontalAlignment.Center };
        var colSecurity = new TextBlock() { Text = "Security", HorizontalAlignment = HorizontalAlignment.Right };
        var colRent = new TextBlock() { Text = "Rent", HorizontalAlignment = HorizontalAlignment.Right };
        var colDue = new TextBlock() { Text = "Due", HorizontalAlignment = HorizontalAlignment.Right };
        Grid.SetColumn(colFrom, 1);
        Grid.SetColumn(colSecurity, 2);
        Grid.SetColumn(colRent, 3);
        Grid.SetColumn(colDue, 4);
        var columnGrid = new Grid() {
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = new GridLength(150) },
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) }
                },
            Children = { colNameAndSpaces, colFrom, colSecurity, colRent, colDue }
        };
        columnNames = new Border() {
            BorderThickness = new Thickness(0, .5, 0, .5),
            BorderBrush = Brushes.Black,
            Child = columnGrid
        };
        header = new StackPanel() {
            Resources = {
                    {
                        typeof(TextBlock),
                        new Style() {
                            Setters = {
                                new Setter(TextBlock.FontWeightProperty, FontWeights.Bold)
                            }
                        }
                    }
                },
            Children = { title, subTitle, asAt, columnNames }
        };
    }
    void initializeContent() {
        entries = new ItemsControl() { 
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            Background = null
        };
        var totalText = new TextBlock() { Text = "Total", FontWeight = FontWeights.Bold };
        totalSecurity = new TextBlock() {
            FontWeight = FontWeights.Bold,
            HorizontalAlignment = HorizontalAlignment.Right
        };
        totalRent = new TextBlock() {
            FontWeight = FontWeights.Bold,
            HorizontalAlignment = HorizontalAlignment.Right
        };
        totalDue = new TextBlock() {
            FontWeight = FontWeights.Bold,
            HorizontalAlignment = HorizontalAlignment.Right
        };
        Grid.SetColumn(totalSecurity, 1);
        Grid.SetColumn(totalRent, 2);
        Grid.SetColumn(totalDue, 3);
        var totalGrid = new Grid() {
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) }
                },
            Children = { totalText, totalSecurity, totalRent, totalDue }
        };
        pageTotal = new Border() {
            BorderThickness = new Thickness(0, .5, 0, 0),
            BorderBrush = Brushes.Black,
            Child = totalGrid
        };
        Grid.SetRow(pageTotal, 1);
        content = new Grid() {
            RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto }
                },
            Children = { entries, pageTotal }
        };
    }
    void initializeFooter() {
        footNoteBlock = new TextBlock();
        currentPage = new Run();
        totalPage = new Run();
        var pageNo = new TextBlock() {
            Inlines = {
                    currentPage,
                    new Run(){Text = "/" },
                    totalPage
                }
        };
        Grid.SetColumn(pageNo, 1);
        var grid = new Grid() {
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto }
                },
            Children = { footNoteBlock, pageNo }
        };
        footer = new Border() {
            BorderThickness = new Thickness(0, .5, 0, 0),
            BorderBrush = Brushes.Black,
            Child = grid
        };
    }
    void addPageTotals() {
        totalSecurity.Text = TotalSecurity.ToString(Constants.NumberFormat);
        totalRent.Text = TotalRent.ToString(Constants.NumberFormat);
        totalDue.Text = TotalDue.ToString(Constants.NumberFormat);
    }

    public bool AddEntry(object entry) {
        ContentControl content = null;
        Balance balance = null;
        bool isBalance = false;
        if (entry is string) content = new HeaderItem((string)entry);
        else if (entry is Balance) {
            isBalance = true;
            balance = (Balance)entry;
            content = new EntryItem(balance);
        }
        else content = new FooterItem((Tuple<int, int, int>)entry);
        content.Measure(PageSize);
        content.UpdateLayout();
        remainingHeight -= content.DesiredSize.Height;
        if (remainingHeight < 0) return false;

        entries.Items.Add(content);
        if (isBalance) {
            TotalSecurity += balance.Security;
            TotalRent += balance.Rent;
            TotalDue += balance.Due;
        }
        return true;
    }
}

class HeaderItem : ContentControl
{
    public HeaderItem(string item) {
        Content = new Border() {
            BorderThickness = new Thickness(0, 0, 0, 0.5),
            BorderBrush = Brushes.Black,
            Child = new TextBlock() {
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Black,
                Text = item
            }
        };
    }
}
class EntryItem : ContentControl
{
    public EntryItem(Balance item) {
        var name = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Left };
        if (item.Count > 1) {
            var space = new Run() { Text = item.Space };
            name.Inlines.Add(space);
            name.Margin = new Thickness(10, 0, 0, 0);
        }
        else {
            var tenant = new Run() { Text = item.Tenant, FontWeight = FontWeights.Bold };
            name.Inlines.Add(tenant);
            if (item.Space != null) {
                var space = new Run() { Text = " - " + item.Space };
                name.Inlines.Add(space);
            }
        }
        if (item.IsExpired) {
            var expDate = new Run() {
                Text = $" (expired on {item.DateEnd.Value.ToString("dd MMMM yyyy")})",
                FontStyle = FontStyles.Italic
            };
            name.Inlines.Add(expDate);
        }
        var date = new TextBlock() { Text = item.DateStart == null ? "" : item.DateStart.Value.ToString("dd MMMM yyyy"), HorizontalAlignment = HorizontalAlignment.Center };
        var security = new TextBlock() { Text = item.Security.ToString(Constants.NumberFormat) };
        var rent = new TextBlock() { Text = item.Rent.ToString(Constants.NumberFormat) };
        var due = new TextBlock() { Text = item.Due.ToString(Constants.NumberFormat) };
        Grid.SetColumn(date, 1);
        Grid.SetColumn(security, 2);
        Grid.SetColumn(rent, 3);
        Grid.SetColumn(due, 4);
        Content = new Grid() {
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = new GridLength(150) },
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) }
                },
            Children = { name, date, security, rent, due },
            Resources = {
                    {
                        typeof(TextBlock),
                        new Style() {
                            Setters = {
                                new Setter(TextBlock.ForegroundProperty, Brushes.Black),
                                new Setter(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right)
                            }
                        }
                    }
                },
        };
    }
}
class FooterItem : ContentControl
{
    public FooterItem(Tuple<int, int, int> values) {
        var separator = new Separator() { Background = Brushes.Black, Height = 0.5 };
        var security = new TextBlock() { Text = values.Item1.ToString(Constants.NumberFormat) };
        var rent = new TextBlock() { Text = values.Item2.ToString(Constants.NumberFormat) };
        var due = new TextBlock() { Text = values.Item3.ToString(Constants.NumberFormat) };
        Grid.SetColumn(security, 1);
        Grid.SetColumn(rent, 2);
        Grid.SetColumn(due, 3);
        Grid.SetColumn(separator, 1);
        Grid.SetColumnSpan(separator, 3);
        Content = new Grid() {
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) }
                },
            RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition()
                },
            Resources = {
                    {
                        typeof(TextBlock),
                        new Style() {
                            Setters = {
                                new Setter(TextBlock.FontWeightProperty, FontWeights.Bold),
                                new Setter(TextBlock.ForegroundProperty, Brushes.Black),
                                new Setter(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right),
                                new Setter(Grid.RowProperty, 1)
                            }
                        }
                    }
                },
            Children = { separator, security, rent, due }
        };
    }
}
