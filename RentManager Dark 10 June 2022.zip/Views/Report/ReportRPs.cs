﻿class ReportRPs : CardView
{
    public override string Icon => Icons.Periodic;
    public override string Header => "Receipt and Payments";

    TextBlock title;
    EditText search;
    DayPicker from, to;
    CommandButton refresh, print;
    ListBox entries;
    Grid entryGrid;
    ReportRPsVM viewModel;

    public ReportRPs() : base() {
        viewModel = new ReportRPsVM();
        DataContext = viewModel;
        initializeUI();
        bind();
    }

    void initializeUI() {
        search = new EditText() {
            Hint = "Search",
            Icon = Icons.Search,
            IsTrimBottomRequested = true
        };
        title = new TextBlock() {
            Text = "for the period",
            FontSize = 18,
            FontWeight = FontWeights.Bold,
            Foreground = Brushes.Gray,
            VerticalAlignment = VerticalAlignment.Center,
            Margin = new Thickness(10, 0, 10, 0)
        };
        from = new DayPicker() {
            Hint = "From",
            DateFormat = "dd/MM/yyyy",
            IsRequired = true,
        };
        to = new DayPicker() {
            Hint = "To",
            DateFormat = "dd/MM/yyyy",
            IsRequired = true,
        };
        refresh = new CommandButton() {
            Icon = Icons.Refresh,
            ToolTip = "Refresh",
            Command = viewModel.Refresh,
            Margin = new Thickness(0, 5, 0, 0)
        };
        print = new CommandButton() {
            Icon = Icons.Print,
            ToolTip = "Print",
            Command = viewModel.Print,
            Margin = new Thickness(5, 5, 0, 0)
        };
        Grid.SetColumn(title, 1);
        Grid.SetColumn(from, 2);
        Grid.SetColumn(to, 3);
        Grid.SetColumn(refresh, 4);
        Grid.SetColumn(print, 5);

        var headerGrid = new Grid() {
            Margin = new Thickness(0, 5, 0, 0),
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto }
                },
            Children = { search, title, from, to, refresh, print }
        };
        initializeEntryGrid();
        Grid.SetRow(entryGrid, 1);
        var grid = new Grid() {
            RowDefinitions = {
                    new RowDefinition(){Height = GridLength.Auto},
                    new RowDefinition()
                },
            Children = { headerGrid, entryGrid }
        };
        setContent(grid);
    }

    void initializeEntryGrid() {
        var particulars = new TextBlock() { Text = "Particulars", HorizontalAlignment = HorizontalAlignment.Left };
        var cash = new TextBlock() { Text = "Cash" };
        var kind = new TextBlock() { Text = "Kind" };
        var total = new TextBlock() { Text = "Total" };
        Grid.SetColumn(cash, 1);
        Grid.SetColumn(kind, 2);
        Grid.SetColumn(total, 3);
        var grid = new Grid() {
            Margin = new Thickness(2, 0, 5, 0),
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) }
                },
            Children = { particulars, cash, kind, total },
            Resources = {{
                        typeof(TextBlock),
                        new Style() {
                            Setters = {
                                new Setter(TextBlock.FontWeightProperty, FontWeights.Bold),
                                new Setter(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right)
                            }
                        }
                    }
                }
        };
        var header = new Border() {
            Margin = new Thickness(0, 0, Constants.ScrollBarThickness, 0),
            Padding = new Thickness(0, 2, 0, 2),
            BorderThickness = new Thickness(0, 0, 0, 1),
            BorderBrush = Brushes.LightGray,
            Child = grid
        };
        Grid.SetColumnSpan(header, 4);
        entries = new ListBox() {
            ItemTemplate = new RPTemplate(nameof(viewModel.Query), viewModel),
            GroupStyle = {
                    new GroupStyle() {
                        ContainerStyle = new Style(typeof(GroupItem)) {
                            Setters = {
                                new Setter(GroupItem.TemplateProperty, new GroupedRPTemplate(nameof(viewModel.Query), viewModel))
                            }
                        }
                    }
                },
            Resources = {{
                        typeof(ScrollViewer),
                        new Style() {
                            Setters = {
                                new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                                new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate(false)),
                            }
                        }
                    }
                }
        };
        Grid.SetRow(entries, 1);
        Grid.SetColumnSpan(entries, 4);
        entryGrid = new Grid() {
            RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition()
                },
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) }
                },
            Children = { header, entries }
        };
    }

    void bind() {
        from.SetBinding(DayPicker.SelectedDateProperty, new Binding(nameof(viewModel.From)));
        from.SetBinding(DayPicker.ErrorProperty, new Binding(nameof(viewModel.ErrorFrom)));
        to.SetBinding(DayPicker.SelectedDateProperty, new Binding(nameof(viewModel.To)));
        to.SetBinding(DayPicker.ErrorProperty, new Binding(nameof(viewModel.ErrorTo)));
        entries.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(viewModel.RPs)));
        search.SetBinding(EditText.TextProperty, new Binding(nameof(viewModel.Query)) { Mode = BindingMode.OneWayToSource });
        refresh.SetBinding(CommandButton.IsEnabledProperty, new Binding(nameof(viewModel.IsRefreshValid)));
        print.SetBinding(CommandButton.IsEnabledProperty, new Binding(nameof(viewModel.IsPrintValid)));
    }
}
