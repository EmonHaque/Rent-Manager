﻿class ReportTenant : LedgerView
    {
        public override string Icon => Icons.Tenant;
        public override string Header => "Tenant";
        ReportTenantVM vm = new();
        protected override ReportBase viewModel => vm;
        protected override DataTemplate template => new TenantTemplate(nameof(vm.Query), vm, true);
        public ReportTenant() : base() {
        }
    }
