﻿class NormalTransaction : View
    {
        NormalTransactionContainer views;
        public NormalTransaction() {
            views = new NormalTransactionContainer();
            AddVisualChild(views);
        }
        public override FrameworkElement container => views;
    }

    class NormalTransactionContainer : ViewContainer
    {
        public NormalTransactionContainer() {
            Children.Add(new RegularTransaction());
            Children.Add(new IrregularTransaction());
        }
    }
