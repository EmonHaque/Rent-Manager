﻿class PlotRentVM : Notifiable
    {
        int? currentId;
        bool state;
        public bool State {
            get { return state; }
            set {
                if (state != value) {
                    state = value;
                    if (state) getData();
                    else if (currentId != null) getData(currentId);
                    else {
                        Data = null;
                        OnPropertyChanged(nameof(Data));
                    }
                }
            }
        }
        public List<PlotwiseRent> Data { get; set; }
        public Action Refresh { get; set; }

        public PlotRentVM() {
            Refresh = refresh;
            RentVM.SelectionChanged += onSelectionChanged;
        }
        void refresh() {
            if (State) getData();
            else getData(currentId);
        }
        void onSelectionChanged(int? id, List<DepositDueRent> list) {
            if (currentId == id) return;
            currentId = id;
            if (!State) getData(currentId);
            else {
                State = false;
                OnPropertyChanged(nameof(State));
            }
        }
        void getData() {
            Data = new List<PlotwiseRent>();
            lock (SQLHelper.key) {
                SQLHelper.connection.Open();
                var cmd = SQLHelper.connection.CreateCommand();
                cmd.CommandText = $@"SELECT 'All plots', t.Name, strftime('%m - %Y', Date) Month, 
                                        coalesce(SUM(CASE WHEN ControlId=1 THEN Amount END), 0) Rent,
                                        coalesce(SUM(CASE WHEN ControlId=2 AND HeadId=5 AND IsCash=1 THEN Amount END),0) Cash,
                                        coalesce(SUM(CASE WHEN ControlId=2 AND HeadId=5 AND IsCash=0 THEN Amount END),0) Kind,
                                    tn.PlotId
                                    From Transactions tn
                                    LEFT JOIN Tenants t ON t.Id = tn.TenantId
                                    WHERE Date > '{DateTime.Today.AddYears(-2).ToString("yyyy-MM-dd")}'
                                    GROUP BY TenantId, strftime('%m-%Y', Date) 
                                    ORDER BY strftime('%Y', Date), strftime('%m', Date)";
                var reader = cmd.ExecuteReader();
                while (reader.Read()) {
                    var pr = new PlotwiseRent() {
                        Plot = reader.GetString(0),
                        Tenant = reader.GetString(1),
                        Month = reader.GetString(2),
                        Rent = reader.GetInt32(3),
                        Cash = reader.GetInt32(4),
                        Kind = reader.GetInt32(5),
                        PlotId = reader.GetInt32(6)
                    };
                    pr.Total = pr.Cash + pr.Kind;
                    Data.Add(pr);
                }
                cmd.Dispose();
                SQLHelper.connection.Close();
            }
            OnPropertyChanged(nameof(Data));
        }
        void getData(int? id) {
            if(id == null) {
                Data = null;
                OnPropertyChanged(nameof(Data));
                return;
            }
            var date = DateTime.Today.AddYears(-2);
            date = new DateTime(date.Year, date.Month, 1);
            Data = new List<PlotwiseRent>();
            lock (SQLHelper.key) {
                SQLHelper.connection.Open();
                var cmd = SQLHelper.connection.CreateCommand();
                cmd.CommandText = $@"SELECT p.Name, t.Name, strftime('%m - %Y', Date) Month, 
                                        coalesce(SUM(CASE WHEN ControlId=1 THEN Amount END), 0) Rent,
                                        coalesce(SUM(CASE WHEN ControlId=2 AND HeadId=5 AND IsCash=1 THEN Amount END), 0) Cash,
                                        coalesce(SUM(CASE WHEN ControlId=2 AND HeadId=5 AND IsCash=0 THEN Amount END), 0) Kind,
                                    tn.PlotId
                                    From Transactions tn
                                    LEFT JOIN Plots p ON p.Id = tn.PlotId
                                    LEFT JOIN Tenants t ON t.Id = tn.TenantId
                                    WHERE PlotId = {id} AND Date > '{date.ToString("yyyy-MM-dd")}'
                                    GROUP BY TenantId, strftime('%m-%Y', Date) 
                                    ORDER BY strftime('%Y', Date), strftime('%m', Date)";
                var reader = cmd.ExecuteReader();
                while (reader.Read()) {
                    var pr = new PlotwiseRent() {
                        Plot = reader.GetString(0),
                        Tenant = reader.GetString(1),
                        Month = reader.GetString(2),
                        Rent = reader.GetInt32(3),
                        Cash = reader.GetInt32(4),
                        Kind = reader.GetInt32(5),
                        PlotId = reader.GetInt32(6)
                    };
                    pr.Total = pr.Cash + pr.Kind;
                    Data.Add(pr);
                }
                cmd.Dispose();
                SQLHelper.connection.Close();
            }
            OnPropertyChanged(nameof(Data));
        }
    }
