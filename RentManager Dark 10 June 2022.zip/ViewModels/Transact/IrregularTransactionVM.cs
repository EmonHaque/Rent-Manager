﻿class IrregularTransactionVM : Notifiable
    {
        ObservableCollection<Transaction> entries;
        bool filterState;
        public bool FilterState {
            get { return filterState; }
            set {
                if (filterState != value) {
                    filterState = value;
                    Tenants.Refresh();
                }
            }
        }
        string amount;
        public string Amount {
            get { return amount; }
            set {
                if (amount != value) {
                    amount = value;
                    OnPropertyChanged(nameof(Amount));
                    validateAmount();
                }
            }
        }
        public string TenantQuery { get; set; }
        public string PlotQuery { get; set; }
        public string SpaceQuery { get; set; }
        public string ControlQuery { get; set; }
        public string HeadQuery { get; set; }
        public string ErrorTenant { get; set; }
        public string ErrorPlot { get; set; }
        public string ErrorSpace { get; set; }
        public string ErrorControl { get; set; }
        public string ErrorHead { get; set; }
        public string ErrorDate { get; set; }
        public string ErrorAmount { get; set; }
        public string ErrorNarration { get; set; }
        public bool IsValid { get; set; }
        public bool CanClickInsert { get; set; }

        public Transaction Entry { get; set; }
        public TransactionSummary Summary { get; set; }
        public ICollectionView Tenants { get; set; }
        public ICollectionView Plots { get; set; }
        public ICollectionView Spaces { get; set; }
        public ICollectionView ControlHeads { get; set; }
        public ICollectionView Heads { get; set; }
        public ICollectionView Entries { get; set; }

        public Action AddEntry { get; set; }
        public Action<Transaction> RemoveEntry { get; set; }
        public Action PassEntries { get; set; }
        public Action<SelectQuery, string> FilterCommand { get; set; }

        public IrregularTransactionVM() {
            Entry = new Transaction();
            Summary = new TransactionSummary();
            initializeCollections();
            initializeCommands();
            initializeValidationProperties();
            Entry.PropertyChanged += validate;
            ErrorTenant = ErrorPlot = ErrorSpace = ErrorControl = ErrorHead = " is required";
            FilterCommand = filterCommand;
        }
        void filterCommand(SelectQuery parameter, string query) {
            switch (parameter) {
                case SelectQuery.Plot: PlotQuery = query; Plots.Refresh(); break;
                case SelectQuery.Space: SpaceQuery = query; Spaces.Refresh(); break;
                case SelectQuery.Tenant: TenantQuery = query; Tenants.Refresh(); break;
                case SelectQuery.ControlHead: ControlQuery = query; ControlHeads.Refresh(); break;
                case SelectQuery.Head: HeadQuery = query; Heads.Refresh(); break;
            }
        }

        #region validation rules
        void validate(object sender, PropertyChangedEventArgs e) {
            switch (e.PropertyName) {
                case nameof(Transaction.TenantId): validateTenantId(); break;
                case nameof(Transaction.PlotId): validatePlotId(); break;
                case nameof(Transaction.SpaceId): validateSpaceId(); break;
                case nameof(Transaction.ControlId): validateControlId(); break;
                case nameof(Transaction.HeadId): validateHeadId(); break;
                case nameof(Transaction.Date): validateDate(); break;
                case nameof(Transaction.Narration): validateNarration(); break;
            }
            IsValid =
                ErrorTenant == string.Empty &&
                ErrorPlot == string.Empty &&
                ErrorSpace == string.Empty &&
                ErrorControl == string.Empty &&
                ErrorHead == string.Empty &&
                ErrorDate == string.Empty &&
                ErrorAmount == string.Empty &&
                ErrorNarration == string.Empty;
            OnPropertyChanged(nameof(IsValid));
        }
        void initializeValidationProperties() {
            IsValid = false;
            ErrorTenant = ErrorPlot = ErrorSpace = ErrorControl = ErrorHead = ErrorDate = string.Empty;
            ErrorAmount = "Amount is required";
            ErrorNarration = string.IsNullOrWhiteSpace(Entry.Narration) ? "Narration is required" : string.Empty;
        }
        void validateTenantId() {
            ErrorTenant = string.Empty;
            if (Entry.TenantId == null)
                ErrorTenant = " is required";
            OnPropertyChanged(nameof(ErrorTenant));
        }
        void validatePlotId() {
            ErrorPlot = string.Empty;
            if (Entry.PlotId == null)
                ErrorPlot = " is required";
            OnPropertyChanged(nameof(ErrorPlot));
            Spaces.Refresh();
            Entry.SpaceId = (Spaces.CurrentItem as Space)?.Id;
        }
        void validateSpaceId() {
            ErrorSpace = string.Empty;
            if (Entry.SpaceId == null)
                ErrorSpace = " is required";
            OnPropertyChanged(nameof(ErrorSpace));
        }
        void validateControlId() {
            ErrorControl = string.Empty;
            if (Entry.ControlId == null)
                ErrorControl = " is required";
            OnPropertyChanged(nameof(ErrorControl));
            Heads.Refresh();
            Entry.IsCash = Entry.ControlId != AppData.controlIdOfReceivable;
            Entry.HeadId = (Heads.CurrentItem as Head)?.Id;
        }
        void validateHeadId() {
            ErrorHead = string.Empty;
            if (Entry.HeadId == null)
                ErrorHead = " is required";
            OnPropertyChanged(nameof(ErrorHead));
        }
        void validateDate() {
            ErrorDate = string.Empty;
            if (Entry.Date == null)
                ErrorDate = " is required";
            OnPropertyChanged(nameof(ErrorDate));
        }
        void validateAmount() {
            ErrorAmount = string.Empty;
            if (string.IsNullOrWhiteSpace(Amount))
                ErrorAmount = "Amount in required";
            else {
                int x;
                if (int.TryParse(Amount, out x)) {
                    if (x > 0) {
                        Entry.Amount = x;
                        ErrorAmount = string.Empty;
                    }
                    else ErrorAmount = "Positive integers only";
                }
                else ErrorAmount = "Integer only";
            }
            OnPropertyChanged(nameof(ErrorAmount));
        }
        void validateNarration() {
            ErrorNarration = string.Empty;
            if (string.IsNullOrWhiteSpace(Entry.Narration))
                ErrorNarration = "Narration is required";
            OnPropertyChanged(nameof(ErrorNarration));
        }
        #endregion

        #region for Constructor
        void initializeCollections() {
            entries = new ObservableCollection<Transaction>();
            BindingOperations.EnableCollectionSynchronization(entries, entries);
            //plots = new ObservableCollection<Lease>();
            //spaces = new ObservableCollection<Lease>();

            Tenants = new CollectionViewSource() { Source = AppData.tenants }.View;
            Plots = CollectionViewSource.GetDefaultView(AppData.plots);
            Spaces = CollectionViewSource.GetDefaultView(AppData.spaces);
            ControlHeads = new CollectionViewSource() { Source = AppData.controlHeads }.View;
            Heads = new CollectionViewSource() { Source = AppData.heads }.View;
            Entries = new CollectionViewSource() {
                Source = entries,
                IsLiveGroupingRequested = true,
                LiveGroupingProperties = { nameof(Transaction.HeadId) }
            }.View;
            Entries.GroupDescriptions.Add(new PropertyGroupDescription(nameof(Transaction.HeadId)));

            Tenants.Filter = filterTenants;
            Plots.Filter = filterPlots;
            Spaces.Filter = filterSpaces;
            ControlHeads.Filter = filterControlHeads;
            Heads.Filter = filterHeads;
        }

        void initializeCommands() {
            AddEntry = addEntry;
            RemoveEntry = removeEntry;
            PassEntries = passEntries;
        }
        #endregion

        #region filters
        bool filterTenants(object o) {
            if (string.IsNullOrWhiteSpace(TenantQuery)) return true;
            return ((Tenant)o).Name.ToLower().Contains(TenantQuery);
        }
        bool filterPlots(object o) {
            //if (Entry.TenantId == null) return false;
            if (string.IsNullOrWhiteSpace(PlotQuery)) return true;
            return ((Plot)o).Name.ToLower().Contains(PlotQuery);
        }
        bool filterSpaces(object o) {
            //if (Entry.TenantId == null) return false;
            var space = (Space)o;
            var result = space.PlotId == Entry.PlotId;
            if (string.IsNullOrWhiteSpace(SpaceQuery)) return result;
            return result && space.Name.ToLower().Contains(SpaceQuery);
        }
        bool filterControlHeads(object o) {
            if (string.IsNullOrWhiteSpace(ControlQuery)) return true;
            return ((ControlHead)o).Name.ToLower().Contains(ControlQuery);
        }
        bool filterHeads(object o) {
            var head = (Head)o;
            var result = head.ControlId == Entry.ControlId;
            if (string.IsNullOrWhiteSpace(HeadQuery)) return result;
            return result && head.Name.ToLower().Contains(HeadQuery);
        }
        #endregion

        #region Commands
        void addEntry() {
            Entry.TenantName = AppData.tenants.First(x => x.Id == Entry.TenantId).Name;
            Entry.PropertyChanged -= validate;
            entries.Add(Entry);
            if (Entry.ControlId == AppData.controlIdOfReceivable) Summary.Receivable += Entry.Amount;
            else if (Entry.ControlId == AppData.controlIdOfPayment) {
                if (Entry.IsCash) Summary.CashPayment += Entry.Amount;
                else Summary.KindPayment += Entry.Amount;
            }
            else {
                if (Entry.IsCash) Summary.CashReceipt += Entry.Amount;
                else Summary.KindReceipt += Entry.Amount;
            }
            Entry = Clone(Entry);
            Entry.PropertyChanged += validate;

            Amount = string.Empty;
            initializeValidationProperties();
            OnPropertyChanged(nameof(Entry));
            Entry.OnPropertyChanged(nameof(Transaction.Amount));
            if (!CanClickInsert) {
                CanClickInsert = true;
                OnPropertyChanged(nameof(CanClickInsert));
            }
        }
        void removeEntry(object o) {
            var entry = (Transaction)o;
            if (entry.ControlId == AppData.controlIdOfReceivable) Summary.Receivable -= entry.Amount;
            else if (entry.ControlId == AppData.controlIdOfPayment) {
                if (entry.IsCash) Summary.CashPayment -= entry.Amount;
                else Summary.KindPayment -= entry.Amount;
            }
            else {
                if (entry.IsCash) Summary.CashReceipt -= entry.Amount;
                else Summary.KindReceipt -= entry.Amount;
            }
            entries.Remove(entry);

            if (entries.Count == 0) {
                CanClickInsert = false;
                OnPropertyChanged(nameof(CanClickInsert));
            }
        }
        void passEntries() {
            ConfirmWindow.Activate("Transaction", entries.Count + " entries will be recorded");

            if (ConfirmWindow.IsOk) {
                var commands = new List<SqliteCommand>(entries.Count);
                foreach (var entry in entries) {
                    var narrattion = string.IsNullOrWhiteSpace(entry.Narration) ? (object)DBNull.Value : entry.Narration;
                    var cmd = new SqliteCommand(@$"INSERT INTO Transactions (Date, PlotId, SpaceId, TenantId, ControlId, HeadId, Amount, IsCash, Narration) 
                                                VALUES(@Date, @PlotId, @SpaceId, @TenantId, @ControlId, @HeadId, @Amount, @IsCash, @Narration)");
                    cmd.Parameters.AddWithValue("@Date", entry.Date.Value.ToString("yyyy-MM-dd"));
                    cmd.Parameters.AddWithValue("@PlotId", entry.PlotId);
                    cmd.Parameters.AddWithValue("@SpaceId", entry.SpaceId);
                    cmd.Parameters.AddWithValue("@TenantId", entry.TenantId);
                    cmd.Parameters.AddWithValue("@ControlId", entry.ControlId);
                    cmd.Parameters.AddWithValue("@HeadId", entry.HeadId);
                    cmd.Parameters.AddWithValue("@Amount", entry.Amount);
                    cmd.Parameters.AddWithValue("@IsCash", Convert.ToInt32(entry.IsCash));
                    cmd.Parameters.AddWithValue("@Narration", narrattion);
                    commands.Add(cmd);
                }
                SQLHelper.Transaction(commands);
                foreach (var command in commands) command.Dispose();

                var num = entries.Count;
                entries.Clear();
            }
            Summary.CashReceipt = Summary.CashPayment = Summary.KindReceipt = Summary.KindPayment = Summary.Receivable = 0;
        }
        #endregion

        Transaction Clone(Transaction t) {
            return new Transaction() {
                Id = t.Id,
                PlotId = t.PlotId,
                SpaceId = t.SpaceId,
                TenantId = t.TenantId,
                ControlId = t.ControlId,
                HeadId = t.HeadId,
                Narration = t.Narration,
                IsCash = t.IsCash,
                Date = t.Date,
                Amount = 0
            };
        }
    }
