﻿class App : Application
{
    [STAThread]
    static void Main() => new App().Run();
    protected override void OnStartup(StartupEventArgs e) {
        LoadingWindow loading = null;
        var thread = new Thread(() => {
            loading = new LoadingWindow();
            loading.Show();
            Dispatcher.Run();
        });
        thread.SetApartmentState(ApartmentState.STA);
        thread.Start();
        Thread.Sleep(1000);
        setResourceAndStyles();
        new AppData();
        new Converters();
        Current.MainWindow = new RootWindow() {
            Content = new RootPanel() {
                Children = {
                        new HomeView(),
                        new AddView(),
                        new EditView(),
                        new TransactionView(),
                        new ReportView()
                    }
            }
        };
        Current.DispatcherUnhandledException += unhandledHandler;
        Current.MainWindow.Show();
        Current.MainWindow.Activate();
        loading.Dispatcher.Invoke(loading.Close);
        loading.Dispatcher.InvokeShutdown();
    }
    protected override void OnExit(ExitEventArgs e) {
        if (BusyWindow.IsOpened) BusyWindow.Terminate();
        Current.DispatcherUnhandledException -= unhandledHandler;
    }
    void unhandledHandler(object sender, DispatcherUnhandledExceptionEventArgs e) {
        if (BusyWindow.IsOpened) BusyWindow.Terminate();
        InfoWindow.Activate("Exception", e.Exception.StackTrace);
        e.Handled = true;
    }
    void setResourceAndStyles() {
        Current.Resources.Add(SystemParameters.VerticalScrollBarWidthKey, Constants.ScrollBarThickness);
        Current.Resources.Add(SystemParameters.HorizontalScrollBarHeightKey, Constants.ScrollBarThickness);

        Control.StyleProperty.OverrideMetadata(typeof(ScrollBar), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = { new Setter(ScrollBar.TemplateProperty, new VScrollTemplate()) },
                Triggers = {
                    new Trigger() {
                        Property = ScrollBar.OrientationProperty,
                        Value = Orientation.Horizontal,
                        Setters = { new Setter(ScrollBar.TemplateProperty, new HScrollTemplate()) }
                    }
                }
            }
        });

        Control.StyleProperty.OverrideMetadata(typeof(Control), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = {
                    new Setter(MenuItem.BorderThicknessProperty, new Thickness(0)),
                    new Setter(MenuItem.PaddingProperty, new Thickness(0)),
                    new Setter(ListBox.BorderThicknessProperty, new Thickness(0)),
                    //new Setter(ListBox.BorderBrushProperty, Constants.Background),
                    new Setter(ListBox.HorizontalContentAlignmentProperty, HorizontalAlignment.Stretch),
                    new Setter(ListBox.IsSynchronizedWithCurrentItemProperty, true),
                    new Setter(ListBoxItem.FocusVisualStyleProperty, null),
                    new Setter(Control.BackgroundProperty, Constants.Background),
                    new Setter(Control.ForegroundProperty, Brushes.LightGray)
                }
            }
        });
    }
}
