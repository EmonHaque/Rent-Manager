﻿public enum SelectQuery
    {
        Plot,
        Space,
        Tenant,
        ControlHead,
        Head,
        NonEditable
    }

