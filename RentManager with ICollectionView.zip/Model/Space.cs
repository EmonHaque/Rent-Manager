﻿using RentManager.Common;
using RentManager.ViewModel;
using System.Linq;

namespace RentManager.Model
{
    public class Space : Notifiable
	{
        public int? Id { get; set; }
        public int? PlotId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public bool IsVacant { get; set; }

        public Space() { }
        public Space(Space s)
        {
			Id = s.Id;
			PlotId = s.PlotId;
			Name = s.Name;
			Description = s.Description;
			IsVacant = s.IsVacant;
        }

		public bool IsEqualTo(Space s)
        {
			return
				string.Equals(Name, s.Name) &&
				string.Equals(Description, s.Description) &&
				IsVacant == s.IsVacant;
        }

        public bool IsValid()
		{
			return !MainVM.SpaceBusy &&
				Id > 0 &&
				PlotId > 0 &&
				!string.IsNullOrWhiteSpace(Name) &&
				!string.IsNullOrWhiteSpace(Description);
		}

		public bool IsInsertValid()
		{
			return !MainVM.SpaceBusy &&
				Id > 0 &&
				PlotId > 0 &&
				!string.IsNullOrWhiteSpace(Name) &&
				!string.IsNullOrWhiteSpace(Description) &&
				MainVM.spaces.Where(x => x.PlotId == (MainVM.Plots.CurrentItem as Plot).Id)
							 .FirstOrDefault(x => x.Name.ToLower() == Name.Trim().ToLower()) == null;
		}
	}
}
