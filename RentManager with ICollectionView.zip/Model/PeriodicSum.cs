﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RentManager.Model
{
    public class PeriodicSum
    {
        public int Receivable { get; set; }
        public int Cash { get; set; }
        public int Kind { get; set; }
        public int Due { get; set; }
    }
}
