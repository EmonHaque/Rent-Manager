﻿using RentManager.Common;
using RentManager.ViewModel;

namespace RentManager.Model
{
    public class Tenant : Notifiable
	{
        public int? Id { get; set; }
        public string Name { get; set; }
        public string Father { get; set; }
        public string Mother { get; set; }
        public string Husband { get; set; }
        public string Address { get; set; }
        public string NID { get; set; }
        public string ContactNo { get; set; }
        public bool HasLeft { get; set; }

        public Tenant() { }
        public Tenant(Tenant t)
        {
            Id = t.Id;
            Name = t.Name;
            Father = t.Father;
            Mother = t.Mother;
            Husband = t.Husband;
            Address = t.Address;
            NID = t.NID;
            ContactNo = t.ContactNo;
            HasLeft = t.HasLeft;
        }

        public bool IsEqualTo(Tenant t)
        {
            return
                string.Equals(Name, t.Name) &&
                string.Equals(Father, t.Father) &&
                string.Equals(Mother, t.Mother) &&
                string.Equals(Husband, t.Husband) &&
                string.Equals(Address, t.Address) &&
                string.Equals(NID, t.NID) &&
                string.Equals(ContactNo, t.ContactNo) &&
                HasLeft == t.HasLeft;
        }

        public bool IsValid()
		{
			return !MainVM.TenantBusy &&
				Id > 0 &&
				!string.IsNullOrWhiteSpace(Name) &&
				!string.IsNullOrWhiteSpace(Father) &&
				!string.IsNullOrWhiteSpace(Address) &&
				!string.IsNullOrWhiteSpace(ContactNo);
		}
	}
}
