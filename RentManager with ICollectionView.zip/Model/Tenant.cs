﻿using RentManager.Common;
using RentManager.Interface;
using RentManager.ViewModel;

namespace RentManager.Model
{
    public class Tenant : Notifiable, IEditable<Tenant>
    {
        public int? Id { get; set; }
        public string Name { get; set; }
        public string Father { get; set; }
        public string Mother { get; set; }
        public string Husband { get; set; }
        public string Address { get; set; }
        public string NID { get; set; }
        public string ContactNo { get; set; }
        public bool HasLeft { get; set; }

        public bool IsEqualTo(Tenant t)
        {
            return
                string.Equals(Name, t.Name) &&
                string.Equals(Father, t.Father) &&
                string.Equals(Mother, t.Mother) &&
                string.Equals(Husband, t.Husband) &&
                string.Equals(Address, t.Address) &&
                string.Equals(NID, t.NID) &&
                string.Equals(ContactNo, t.ContactNo) &&
                HasLeft == t.HasLeft;
        }

        public bool IsValid()
        {
            return !MainVM.TenantBusy &&
                Id > 0 &&
                !string.IsNullOrWhiteSpace(Name) &&
                !string.IsNullOrWhiteSpace(Father) &&
                !string.IsNullOrWhiteSpace(Address) &&
                !string.IsNullOrWhiteSpace(ContactNo);
        }

        public Tenant Clone()
        {
            return new Tenant()
            {
                Id = Id,
                Name = Name,
                Father = Father,
                Mother = Mother,
                Husband = Husband,
                Address = Address,
                NID = NID,
                ContactNo = ContactNo,
                HasLeft = HasLeft
            };
        }

        public void Update(Tenant Edited)
        {
            Name = Edited.Name;
            Father = Edited.Father;
            Mother = Edited.Mother;
            Husband = Edited.Husband;
            Address = Edited.Address;
            NID = Edited.NID;
            ContactNo = Edited.ContactNo;
            HasLeft = Edited.HasLeft;
        }
    }
}
