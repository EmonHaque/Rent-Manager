﻿using System.Windows.Controls;

namespace RentManager.Model
{
    public class Menu
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string Geometry { get; set; }
        public UserControl View { get; set; }

        public Menu(string name, string description, UserControl view, string geometry)
        {
            Name = name;
            Description = description;
            View = view;
            Geometry = geometry;
        }
    }
}
