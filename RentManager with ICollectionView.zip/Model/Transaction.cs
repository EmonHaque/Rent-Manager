﻿using RentManager.Common;
using System;

namespace RentManager.Model
{
    public class Transaction : Notifiable
    {
        public int Id { get; set; }
        public int? PlotId { get; set; }
        public int? SpaceId { get; set; }
        public int? TenantId { get; set; }
        public int? ControlId { get; set; }
        public int? HeadId { get; set; }
        public DateTime Date { get; set; }
        public int Amount { get; set; }
        public string Narration { get; set; }
        public bool IsCash { get; set; }

        public Transaction()
        {
            Date = DateTime.Now;
            IsCash = true;
        }
        public Transaction(Transaction t)
        {
            Id = t.Id;
            PlotId = t.PlotId;
            SpaceId = t.SpaceId;
            TenantId = t.TenantId;
            ControlId = t.ControlId;
            HeadId = t.HeadId;
            Narration = t.Narration;
            IsCash = t.IsCash;
            Date = t.Date;
            Amount = t.Amount;
        }

        public bool IsEqualTo(Transaction t)
        {
            return
                PlotId == t.PlotId &&
                SpaceId == t.SpaceId &&
                TenantId == t.TenantId &&
                ControlId == t.ControlId &&
                HeadId == t.HeadId &&
                IsCash == t.IsCash &&
                string.Equals(Narration, t.Narration) &&
                Date == t.Date;
        }

		public bool IsValid()
		{
			return PlotId > 0 &&
				SpaceId > 0 &&
				TenantId > 0 &&
				HeadId > 0 &&
				Amount > 0;
		}
	}
}
