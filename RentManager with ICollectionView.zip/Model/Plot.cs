﻿using RentManager.Common;
using RentManager.Interface;
using RentManager.ViewModel;
using System.Linq;

namespace RentManager.Model
{
    public class Plot : Notifiable, IEditable<Plot>
    {
        public int? Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        public bool IsEqualTo(Plot p)
        {
            return
                string.Equals(Name, p.Name) &&
                string.Equals(Description, p.Description);
        }

        public bool IsValid()
        {
            return
                !MainVM.PlotBusy &&
                Id > 0 &&
                !string.IsNullOrWhiteSpace(Name) &&
                !string.IsNullOrWhiteSpace(Description);
        }

        public bool IsInsertValid()
        {
            return
                !MainVM.PlotBusy &&
                Id > 0 &&
                !string.IsNullOrWhiteSpace(Name) &&
                !string.IsNullOrWhiteSpace(Description) &&
                MainVM.plots.FirstOrDefault(x => x.Name.ToLower() == Name.Trim().ToLower()) == null;
        }

        public Plot Clone()
        {
            return new Plot()
            {
                Id = Id,
                Name = Name,
                Description = Description
            };
        }

        public void Update(Plot Edited)
        {
            Name = Edited.Name;
            Description = Edited.Description;
        }
    }
}
