﻿using RentManager.Common;
using RentManager.ViewModel;
using System.Linq;

namespace RentManager.Model
{
    public class Head : Notifiable
	{
        public int? Id { get; set; }
        public int? ControlId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        public Head() { }
        public Head(Head h)
        {
			Id = h.Id;
			ControlId = h.ControlId;
			Name = h.Name;
			Description = h.Description;
        }

		public bool IsEqualTo(Head h)
        {
			return
				string.Equals(Name, h.Name) &&
				string.Equals(Description, h.Description);
        }

		public bool IsValid()
		{
			return !MainVM.HeadBusy &&
				Id > 0 &&
				ControlId > 0 &&
				!string.IsNullOrWhiteSpace(Name) &&
				!string.IsNullOrWhiteSpace(Description);
		}

		public bool IsInsertValid()
		{
			return !MainVM.HeadBusy &&
				Id > 0 &&
				ControlId > 0 &&
				!string.IsNullOrWhiteSpace(Name) &&
				!string.IsNullOrWhiteSpace(Description) &&
				MainVM.heads.Where(x => x.ControlId == (MainVM.ControlHeads.CurrentItem as ControlHead).Id)
							.FirstOrDefault(x => x.Name.ToLower() == Name.Trim().ToLower()) == null;
		}
	}
}
