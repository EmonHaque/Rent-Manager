﻿using System.Collections.Generic;

namespace RentManager.Model
{
    public class Invoice
    {
        public string Title { get; set; }
        public string Address { get; set; }
        public string Period { get; set; }
        public string ContactNo { get; set; }
        public List<ReportEntry> Reportables { get; set; }
    }
}
