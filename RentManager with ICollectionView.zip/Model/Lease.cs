﻿using RentManager.Common;
using RentManager.Interface;
using RentManager.ViewModel;
using System;
using System.Collections.ObjectModel;

namespace RentManager.Model
{
    public class Lease : Notifiable, IEditable<Lease>, IInsertable
	{
        public int Id { get; set; }
        public int? PlotId { get; set; }
        public int? SpaceId { get; set; }
        public int? TenantId { get; set; }
        public DateTime DateStart { get; set; }
        public DateTime? DateEnd { get; set; }
        public string Business { get; set; }
        public bool IsExpired { get; set; }
        public Bag<Receivable> FixedReceivables { get; set; }

        public Lease() => App.Current.Dispatcher.Invoke(() => FixedReceivables = new Bag<Receivable>());

        public bool IsEqualTo(Lease l)
        {        
            return
                PlotId == l.PlotId &&
                SpaceId == l.SpaceId &&
                TenantId == l.TenantId &&
                DateTime.Compare(DateStart, l.DateStart) == 0 &&
                string.Equals(Business, l.Business) &&
                IsExpired == l.IsExpired &&
                IsFixedReceivablesEqual(l.FixedReceivables);
        }

        public bool IsInsertionValid() => IsValid();


        public bool IsValid()
		{
			return 
                !MainVM.LeaseBusy &&
				Id > 0 &&
				PlotId > 0 &&
				SpaceId > 0 &&
				TenantId > 0 &&
				!string.IsNullOrWhiteSpace(Business) &&
				FixedReceivables.Count > 0;
		}

        bool IsFixedReceivablesEqual(Bag<Receivable> r)
        {
            if (FixedReceivables.Count != r.Count) return false;

            bool isEqual = false;
            for (int i = 0; i < r.Count; i++)
                isEqual = r[i].IsEqualTo(FixedReceivables[i]);
            
            return isEqual;
        }

        public Lease Clone()
        {
            var lease = new Lease()
            {
                Id = Id,
                PlotId = PlotId,
                SpaceId = SpaceId,
                TenantId = TenantId,
                DateStart = DateStart,
                DateEnd = DateEnd,
                Business = Business,
                IsExpired = IsExpired,
                FixedReceivables = new Bag<Receivable>()
            };
            foreach (var receivable in FixedReceivables)
                lease.FixedReceivables.Add(new Receivable(receivable));
            return lease;
        }

        public void Update(Lease Edited)
        {
            PlotId = Edited.PlotId;
            SpaceId = Edited.SpaceId;
            TenantId = Edited.TenantId;
            DateStart = Edited.DateStart;
            DateEnd = Edited.DateEnd;
            Business = Edited.Business;
            IsExpired = Edited.IsExpired;
            FixedReceivables = Edited.FixedReceivables;
        }
    }
}
