﻿using RentManager.Common;
using RentManager.ViewModel;
using System;
using System.Collections.ObjectModel;

namespace RentManager.Model
{
    public class Lease : Notifiable
	{
        public int Id { get; set; }
        public int? PlotId { get; set; }
        public int? SpaceId { get; set; }
        public int? TenantId { get; set; }
        public DateTime DateStart { get; set; }
        public DateTime? DateEnd { get; set; }
        public string Business { get; set; }
        public bool IsExpired { get; set; }
        public ObservableCollection<Receivable> FixedReceivables { get; set; }

        public Lease() => App.Current.Dispatcher.Invoke(() => FixedReceivables = new ObservableCollection<Receivable>());
        public Lease(Lease l)
        {
            Id = l.Id;
            PlotId = l.PlotId;
            SpaceId = l.SpaceId;
            TenantId = l.TenantId;
            DateStart = l.DateStart;
            DateEnd = l.DateEnd;
            Business = l.Business;
            IsExpired = l.IsExpired;
            FixedReceivables = new ObservableCollection<Receivable>();
            foreach (var receivable in l.FixedReceivables)
                FixedReceivables.Add(new Receivable(receivable));
        }

        public bool IsEqualTo(Lease l)
        {
            
            return
                PlotId == l.PlotId &&
                SpaceId == l.SpaceId &&
                TenantId == l.TenantId &&
                DateTime.Compare(DateStart, l.DateStart) == 0 &&
                string.Equals(Business, l.Business) &&
                IsExpired == l.IsExpired &&
                IsFixedReceivablesEqual(l.FixedReceivables);
        }
		
		public bool IsValid()
		{
			return 
                !MainVM.LeaseBusy &&
				Id > 0 &&
				PlotId > 0 &&
				SpaceId > 0 &&
				TenantId > 0 &&
				!string.IsNullOrWhiteSpace(Business) &&
				FixedReceivables.Count > 0;
		}

        bool IsFixedReceivablesEqual(ObservableCollection<Receivable> r)
        {
            if (FixedReceivables.Count != r.Count) return false;

            bool isEqual = false;
            for (int i = 0; i < r.Count; i++)
                isEqual = r[i].IsEqualTo(FixedReceivables[i]);
            
            return isEqual;
        }
	}
}
