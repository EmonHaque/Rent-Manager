﻿using RentManager.Common;

namespace RentManager.Model
{
    public class RentListStats : Notifiable
    {
        public int Selected { get; set; }
        public int Total { get; set; }
    }
}
