﻿using RentManager.Common;
using System;

namespace RentManager.Model
{
    public class CommonNarration : Notifiable
    {
        public DateTime Date { get; set; }
        public string Narration { get; set; }

        public CommonNarration() => Date = DateTime.Now;

        public bool IsValid() => !string.IsNullOrWhiteSpace(Narration);
    }
}
