﻿using System;

namespace RentManager.Model
{
    public class OutstandingSummary
    {
        public string Tenant { get; set; }
        public string Space { get; set; }
        public DateTime DateStart { get; set; }
        public DateTime? DateEnd { get; set; }
        public int Security { get; set; }
        public int Rent { get; set; }
        public int Due { get; set; }
        public bool IsExpired { get; set; }
    }
}
