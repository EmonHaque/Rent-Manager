﻿using RentManager.Common;

namespace RentManager.Model
{
    public class LedgerHeader : Notifiable
    {
        string title;
        public string Title { get => title; set { title = value; OnPropertyChanged(); } }

        string description;
        public string Description { get => description; set { description = value; OnPropertyChanged(); } }

        string period;
        public string Period { get => period; set { period = value; OnPropertyChanged(); } }

        double columnWidth;
        public double ColumnWidth { get => columnWidth; set { columnWidth = value; OnPropertyChanged(); } }
    }
}
