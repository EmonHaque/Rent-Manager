﻿namespace RentManager.Model
{
    public class TransactionSummary
    {
        public string Plot { get; set; }
        public string Space { get; set; }
        public string Tenant { get; set; }
        public int Security { get; set; }
        public int Receivable { get; set; }
        public int Receipt { get; set; }
        public int Payment { get; set; }
        public int Due { get; set; }
        public bool IsExpired { get; set; }
    }
}
