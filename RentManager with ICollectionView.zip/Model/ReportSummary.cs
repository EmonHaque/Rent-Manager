﻿using RentManager.Common;

namespace RentManager.Model
{
    public class ReportSummary : Notifiable
    {

        int totalReceivable;
        public int TotalReceivable { get => totalReceivable; set { totalReceivable = value; OnPropertyChanged(); } }

        int totalReceipt;
        public int TotalReceipt { get => totalReceipt; set { totalReceipt = value; OnPropertyChanged(); } }

        string heading;
        public string Heading { get => heading; set { heading = value; OnPropertyChanged(); } }

        //public int TotalReceivable { get; set; }
        //public int TotalReceipt { get; set; }
        //public string Heading { get; set; }
    }
}
