﻿namespace RentManager.Model
{
    public class Receivable
	{
		public int LeaseId { get; set; }
        public int? HeadId { get; set; }
        public int Amount { get; set; }

		public Receivable() { }
        public Receivable(Receivable r)
        {
			LeaseId = r.LeaseId;
			HeadId = r.HeadId;
			Amount = r.Amount;
        }

		public bool IsEqualTo(Receivable r)
        {
			return
				LeaseId == r.LeaseId &&
				HeadId == r.HeadId &&
				Amount == r.Amount;
        }

        public bool IsValid()
		{
			return LeaseId > 0 &&
				HeadId > 0 &&
				Amount > 0;
		}
	}
}
