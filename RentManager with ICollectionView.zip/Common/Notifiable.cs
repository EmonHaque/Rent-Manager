﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace RentManager.Common
{
    [Serializable]
    public abstract class Notifiable : INotifyPropertyChanged
    {
        [field: NonSerialized]
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
