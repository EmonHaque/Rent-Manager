﻿using System.Collections.Generic;
using System.Collections.Specialized;

namespace RentManager.Common
{
    public class Bag<T> : List<T>, INotifyCollectionChanged
    {
        public Bag() : base() { }
        public Bag(IEnumerable<T> enumerable) : base(enumerable) { }

        public event NotifyCollectionChangedEventHandler CollectionChanged;
        public void OnCollectionChanged(NotifyCollectionChangedEventArgs e) => CollectionChanged?.Invoke(this, e);
    }
}
