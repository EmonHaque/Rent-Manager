﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Data;

namespace RentManager.Common
{
    public class Bag<T> : IList, IList<T>, INotifyCollectionChanged
    {
        readonly List<T> list;

        #region constructiors
        public Bag() => list = new List<T>();
        public Bag(IEnumerable<T> enumerable) => list = enumerable.ToList();
        public Bag(List<T> list) => this.list = list;
        #endregion

        #region IList implementation
        public bool IsFixedSize => ((IList)list).IsFixedSize;
        public bool IsReadOnly => ((IList)list).IsReadOnly;
        public bool IsSynchronized => ((IList)list).IsSynchronized;
        public object SyncRoot => ((IList)list).SyncRoot;
        object IList.this[int index] { get => ((IList)list)[index]; set => ((IList)list)[index] = value; }
        public int Add(object value) => ((IList)list).Add((T)value);
        public bool Contains(object value) => list.Contains((T)value);
        public int IndexOf(object value) => list.IndexOf((T)value);
        public void Insert(int index, object value) => list.Insert(index, (T)value);
        public void Remove(object value) => list.Remove((T)value);
        public void CopyTo(Array array, int index) => list.CopyTo((T[])array, index);
        #endregion

        #region IList<T> implementation
        public T this[int index] { get => list[index]; set => list[index] = value; }
        public int Count => list.Count;
        public void Add(T item) => list.Add(item);
        public void Insert(int index, T item) => list.Insert(index, item);
        public void CopyTo(T[] array, int arrayIndex) => list.CopyTo(array, arrayIndex);
        public bool Contains(T item) => list.Contains(item);
        public int IndexOf(T item) => list.IndexOf(item);
        public bool Remove(T item) => list.Remove(item);
        public void RemoveAt(int index) => list.RemoveAt(index);
        public void Clear() => list.Clear();
        public IEnumerator<T> GetEnumerator() => list.GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
        #endregion

        #region List<T>
        public void AddRange(IEnumerable<T> source) => list.AddRange(source);
        public void InsertRange(int index, IEnumerable<T> source) => list.InsertRange(index, source);
        public void RmoveRange(int index, int count) => list.RemoveRange(index, count);
        public List<T> GetRange(int index, int count) => list.GetRange(index, count);
        #endregion

        #region INotifyCollectionChanged implementation
        public event NotifyCollectionChangedEventHandler CollectionChanged;
        public void OnCollectionChanged(NotifyCollectionChangedEventArgs e) => CollectionChanged?.Invoke(this, e);
        #endregion
    }
}
