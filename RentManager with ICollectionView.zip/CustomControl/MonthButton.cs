﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace RentManager.CustomControl
{
    public class MonthButton : Button
    {
        static MonthButton()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(MonthButton), new FrameworkPropertyMetadata(typeof(MonthButton)));
        }

        public string MonthName
        {
            get { return (string)GetValue(MonthNameProperty); }
            set { SetValue(MonthNameProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MonthName.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MonthNameProperty =
            DependencyProperty.Register("MonthName", typeof(string), typeof(MonthButton), new PropertyMetadata(null));


        public int Year
        {
            get { return (int)GetValue(YearProperty); }
            set { SetValue(YearProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Year.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty YearProperty =
            DependencyProperty.Register("Year", typeof(int), typeof(MonthButton), new PropertyMetadata(0, OnYearChanged));

        static void OnYearChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var button = d as MonthButton;
            var today = DateTime.Today;
            button.IsThisMonth = today.ToString("MMMM") == button.MonthName && today.Year == button.Year;
        }

        public bool IsThisMonth
        {
            get { return (bool)GetValue(IsThisMonthProperty); }
            set { SetValue(IsThisMonthProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsThisMonth.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsThisMonthProperty =
            DependencyProperty.Register("IsThisMonth", typeof(bool), typeof(MonthButton), new PropertyMetadata(false));


        public event RoutedEventHandler MonthClicked
        {
            add { AddHandler(MonthClickedEvent, value); }
            remove { RemoveHandler(MonthClickedEvent, value); }
        }

        public static readonly RoutedEvent MonthClickedEvent =
            EventManager.RegisterRoutedEvent("MonthClicked", RoutingStrategy.Direct, typeof(RoutedEventHandler), typeof(MonthButton));

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            Click += handler;
        }

        void handler(object sender, RoutedEventArgs e) => RaiseEvent(new RoutedEventArgs(MonthClickedEvent, MonthName));
    }
}
