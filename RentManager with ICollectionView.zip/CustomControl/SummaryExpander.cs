﻿using System.Windows;
using System.Windows.Controls;

namespace RentManager.CustomControl
{
    public class SummaryExpander : Expander
    {
        static SummaryExpander()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(SummaryExpander), new FrameworkPropertyMetadata(typeof(SummaryExpander)));
        }
    }
}
