﻿using RentManager.Model;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;

namespace RentManager.CustomControl
{
    public class OutstandingPage : ContentPresenter
    {
        ItemsControl content { get; set; }
        public double AvailableHeight { get; set; }
        public FixedPage Page { get; set; }

        ICollectionView internalView;
        ObservableCollection<OutstandingSummary> internalList;

        static OutstandingPage()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(OutstandingPage), new FrameworkPropertyMetadata(typeof(OutstandingPage)));
        }
        public OutstandingPage() { }
        public OutstandingPage(OutstandingPage page)
        {
            Width = page.Width;
            Height = page.Height;
            Title = page.Title;
            SubTitle = page.SubTitle;
            Date = page.Date;
            FootNote = page.FootNote;
            PageNo = page.PageNo + 1;
            IsFinished = false;

            var grid = new Grid() { Children = { this } };
            grid.Measure(new Size(this.Width, this.Height));
            grid.Arrange(new Rect(grid.DesiredSize));
        }
        public override void OnApplyTemplate()
        {
            Page = GetTemplateChild("page") as FixedPage;
            content = GetTemplateChild("content") as ItemsControl;
            var header = GetTemplateChild("header") as StackPanel;
            var contentGrid = GetTemplateChild("contentGrid") as Grid;
            var pageTotal = GetTemplateChild("pageTotal") as Border;
            var footer = GetTemplateChild("footer") as Border;
            double margin = 96d;
            Page.Margin = new Thickness(margin);
            contentGrid.Height = AvailableHeight = Height - 2 * margin - heightOf(header) - heightOf(pageTotal) - heightOf(footer);
            contentGrid.Width = Width - 2 * margin;

            internalList = new ObservableCollection<OutstandingSummary>();
            internalView = CollectionViewSource.GetDefaultView(internalList);
            internalView.GroupDescriptions.Add(new PropertyGroupDescription("Tenant"));
            content.ItemsSource = internalView;
        }
        double heightOf(UIElement element)
        {
            element.Measure(new Size(Width, Height));
            element.Arrange(new Rect(element.DesiredSize));
            return element.DesiredSize.Height;
        }
        public double AddItem(OutstandingSummary item)
        {
            internalList.Add(item);
            content.UpdateLayout();
            return content.DesiredSize.Height;
        }
        public void RemoveItem(OutstandingSummary item)
        {
            internalList.Remove(item);
            content.UpdateLayout();
        }

        public void RaiseFinished() => IsFinished = true;
        public void RefreshInternalView() => internalView.Refresh();

        public string Title
        {
            get { return (string)GetValue(TitleProperty); }
            set { SetValue(TitleProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Title.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TitleProperty =
            DependencyProperty.Register("Title", typeof(string), typeof(OutstandingPage), new PropertyMetadata(null));


        public string SubTitle
        {
            get { return (string)GetValue(SubTitleProperty); }
            set { SetValue(SubTitleProperty, value); }
        }

        // Using a DependencyProperty as the backing store for SubTitle.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SubTitleProperty =
            DependencyProperty.Register("SubTitle", typeof(string), typeof(OutstandingPage), new PropertyMetadata(null));


        public string Date
        {
            get { return (string)GetValue(DateProperty); }
            set { SetValue(DateProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Date.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty DateProperty =
            DependencyProperty.Register("Date", typeof(string), typeof(OutstandingPage), new PropertyMetadata(null));


        public int TotalSecurity
        {
            get { return (int)GetValue(TotalSecurityProperty); }
            set { SetValue(TotalSecurityProperty, value); }
        }

        // Using a DependencyProperty as the backing store for TotalSecurity.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TotalSecurityProperty =
            DependencyProperty.Register("TotalSecurity", typeof(int), typeof(OutstandingPage), new PropertyMetadata(0));


        public int TotalRent
        {
            get { return (int)GetValue(TotalRentProperty); }
            set { SetValue(TotalRentProperty, value); }
        }

        // Using a DependencyProperty as the backing store for TotalRent.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TotalRentProperty =
            DependencyProperty.Register("TotalRent", typeof(int), typeof(OutstandingPage), new PropertyMetadata(0));


        public int TotalDue
        {
            get { return (int)GetValue(TotalDueProperty); }
            set { SetValue(TotalDueProperty, value); }
        }

        // Using a DependencyProperty as the backing store for TotalDue.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TotalDueProperty =
            DependencyProperty.Register("TotalDue", typeof(int), typeof(OutstandingPage), new PropertyMetadata(0));


        public string FootNote
        {
            get { return (string)GetValue(FootNoteProperty); }
            set { SetValue(FootNoteProperty, value); }
        }

        // Using a DependencyProperty as the backing store for FootNote.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty FootNoteProperty =
            DependencyProperty.Register("FootNote", typeof(string), typeof(OutstandingPage), new PropertyMetadata(null));


        public int PageNo
        {
            get { return (int)GetValue(PageNoProperty); }
            set { SetValue(PageNoProperty, value); }
        }

        // Using a DependencyProperty as the backing store for PageNo.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty PageNoProperty =
            DependencyProperty.Register("PageNo", typeof(int), typeof(OutstandingPage), new PropertyMetadata(0));


        public bool IsFinished
        {
            get { return (bool)GetValue(IsFinishedProperty); }
            set { SetValue(IsFinishedProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsFinished.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsFinishedProperty =
            DependencyProperty.Register("IsFinished", typeof(bool), typeof(OutstandingPage), new PropertyMetadata(false));
    }
}
