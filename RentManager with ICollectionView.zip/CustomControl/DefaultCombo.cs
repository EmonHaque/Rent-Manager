﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RentManager.CustomControl
{
    public class DefaultCombo : ComboBox
    {
        static DefaultCombo()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(DefaultCombo), new FrameworkPropertyMetadata(typeof(DefaultCombo)));
        }
        protected override void OnItemsChanged(NotifyCollectionChangedEventArgs e)
        {
            //switch (e.Action)
            //{
            //    case NotifyCollectionChangedAction.Add:
            //        if (SelectedItem != e.NewItems[0])
            //            SelectedItem = e.NewItems[0];
            //        break;
            //    case NotifyCollectionChangedAction.Reset:
            //        if (e.NewItems == null && !Items.IsEmpty)
            //            Items.MoveCurrentToFirst();
            //        break;
            //}
        }
    }
}
