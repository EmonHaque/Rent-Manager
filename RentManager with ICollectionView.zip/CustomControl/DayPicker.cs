﻿using System.Windows;
using System.Windows.Controls;

namespace RentManager.CustomControl
{
    public class DayPicker : DatePicker
    {
        static DayPicker()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(DayPicker), new FrameworkPropertyMetadata(typeof(DayPicker)));
        }
    }
}
