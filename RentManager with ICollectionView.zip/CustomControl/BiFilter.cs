﻿using System.Windows;
using System.Windows.Controls;

namespace RentManager.CustomControl
{
    public class BiFilter : CheckBox
    {
        static BiFilter()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(BiFilter), new FrameworkPropertyMetadata(typeof(BiFilter)));
        }
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            IsChecked = true;
        }
    }
}
