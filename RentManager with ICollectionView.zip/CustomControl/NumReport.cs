﻿using System.Windows;
using System.Windows.Controls;

namespace RentManager.CustomControl
{
    public class NumReport : Control
    {
        static NumReport()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(NumReport), new FrameworkPropertyMetadata(typeof(NumReport)));
        }

        public int Text
        {
            get { return (int)GetValue(TextProperty); }
            set { SetValue(TextProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Text.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TextProperty =
            DependencyProperty.Register("Text", typeof(int), typeof(NumReport), new PropertyMetadata(0));
    }
}
