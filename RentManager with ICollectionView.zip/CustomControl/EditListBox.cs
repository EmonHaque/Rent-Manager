﻿using System;
using System.Collections.Specialized;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace RentManager.CustomControl
{
    public class EditListBox : ListBox
    {
        static EditListBox()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(EditListBox), new FrameworkPropertyMetadata(typeof(EditListBox)));
        }
        protected override void OnItemsChanged(NotifyCollectionChangedEventArgs e) { }
    }
}
