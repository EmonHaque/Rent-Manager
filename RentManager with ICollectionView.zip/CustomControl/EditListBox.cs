﻿using System.Collections.Specialized;
using System.Windows;
using System.Windows.Controls;

namespace RentManager.CustomControl
{
    public class EditListBox : ListBox
    {
        static EditListBox()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(EditListBox), new FrameworkPropertyMetadata(typeof(EditListBox)));
        }
        protected override void OnItemsChanged(NotifyCollectionChangedEventArgs e) { }
    }
}
