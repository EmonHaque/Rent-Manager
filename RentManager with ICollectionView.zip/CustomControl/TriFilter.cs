﻿using System.Windows;
using System.Windows.Controls;

namespace RentManager.CustomControl
{
    public class TriFilter : CheckBox
    {
        static TriFilter()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(TriFilter), new FrameworkPropertyMetadata(typeof(TriFilter)));
        }
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            IsChecked = true;
        }
        public string ExpiredOrLeft
        {
            get { return (string)GetValue(ExpiredOrLeftProperty); }
            set { SetValue(ExpiredOrLeftProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ExpiredOrLeft.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ExpiredOrLeftProperty =
            DependencyProperty.Register("ExpiredOrLeft", typeof(string), typeof(TriFilter), new PropertyMetadata("Left"));
    }
}
