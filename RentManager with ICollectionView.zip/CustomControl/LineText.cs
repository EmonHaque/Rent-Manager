﻿using System.Windows;
using System.Windows.Controls;

namespace RentManager.CustomControl
{
    public class LineText : TextBox
    {
        static LineText()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(LineText), new FrameworkPropertyMetadata(typeof(LineText)));
        }

        protected override void OnGotFocus(RoutedEventArgs e)
        {
            base.OnGotFocus(e);
            SelectAll();
        }
    }
}
