﻿using System;
using System.Collections.Specialized;
using System.Windows;
using System.Windows.Controls;

namespace RentManager.CustomControl
{
    public class CountingListbox : ListBox
    {
        static CountingListbox()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(CountingListbox), new FrameworkPropertyMetadata(typeof(CountingListbox)));
        }

        public GroupStyle CustomGroupStyle
        {
            get { return (GroupStyle)GetValue(CustomGroupStyleProperty); }
            set { SetValue(CustomGroupStyleProperty, value); }
        }

        // Using a DependencyProperty as the backing store for CustomGroupStyle.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty CustomGroupStyleProperty =
            DependencyProperty.Register("CustomGroupStyle", typeof(GroupStyle), typeof(CountingListbox), new PropertyMetadata(onStyleChanged));

        static void onStyleChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var box = d as CountingListbox;
            if (box == null) throw new InvalidOperationException("Can only add GroupStyle to CountingListbox");
            var @new = e.NewValue as GroupStyle;
            if (@new != null) box.GroupStyle.Add(@new);
        }

        public int Total
        {
            get { return (int)GetValue(TotalProperty); }
            set { SetValue(TotalProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Total.  This enables animation, styling, binding, etc...
        static readonly DependencyProperty TotalProperty =
            DependencyProperty.Register("Total", typeof(int), typeof(CountingListbox), new PropertyMetadata(0));

        public int Selected
        {
            get { return (int)GetValue(SelectedProperty); }
            set { SetValue(SelectedProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Selected.  This enables animation, styling, binding, etc...
        static readonly DependencyProperty SelectedProperty =
            DependencyProperty.Register("Selected", typeof(int), typeof(CountingListbox), new PropertyMetadata(0));


        protected override void OnSelectionChanged(SelectionChangedEventArgs e)
        {
            base.OnSelectionChanged(e);
            Selected = SelectedItems.Count;
        }
        protected override void OnItemsChanged(NotifyCollectionChangedEventArgs e)
        {
            Total = Items.Count;
        }
    }
}
