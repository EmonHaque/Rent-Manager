﻿using System.Collections.Specialized;
using System.Windows;
using System.Windows.Controls;

namespace RentManager.CustomControl
{
    public class Combo : ComboBox
    {
        static Combo()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(Combo), new FrameworkPropertyMetadata(typeof(Combo)));
        }
        protected override void OnItemsChanged(NotifyCollectionChangedEventArgs e) { }
    }
}
