﻿using System.Windows.Controls;

namespace RentManager.View.Transact
{
    /// <summary>
    /// Interaction logic for PassEntryEntry.xaml
    /// </summary>
    public partial class PassEntry : UserControl
    {
        public PassEntry()
        {
            InitializeComponent();
        }
    }
}
