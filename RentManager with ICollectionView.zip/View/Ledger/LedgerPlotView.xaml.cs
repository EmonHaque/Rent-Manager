﻿using System.Windows.Controls;

namespace RentManager.View.Ledger
{
    /// <summary>
    /// Interaction logic for LedgerPlotView.xaml
    /// </summary>
    public partial class LedgerPlotView : UserControl
    {
        public LedgerPlotView()
        {
            InitializeComponent();
        }
    }
}
