﻿using System.Windows.Controls;

namespace RentManager.View.Ledger
{
    /// <summary>
    /// Interaction logic for LedgerOutStandingView.xaml
    /// </summary>
    public partial class LedgerOutstandingView : UserControl
    {
        public LedgerOutstandingView()
        {
            InitializeComponent();
        }
    }
}
