﻿using System.Windows.Controls;

namespace RentManager.View.Ledger
{
    /// <summary>
    /// Interaction logic for LedgerSpaceView.xaml
    /// </summary>
    public partial class LedgerSpaceView : UserControl
    {
        public LedgerSpaceView()
        {
            InitializeComponent();
        }
    }
}
