﻿using System.Windows.Controls;

namespace RentManager.View.Add
{
    /// <summary>
    /// Interaction logic for AddPlotView.xaml
    /// </summary>
    public partial class AddPlotView : UserControl
    {
        public AddPlotView()
        {
            InitializeComponent();
        }
    }
}
