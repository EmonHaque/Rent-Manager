﻿using System.Windows.Controls;

namespace RentManager.View.Add
{
    /// <summary>
    /// Interaction logic for AddHeadView.xaml
    /// </summary>
    public partial class AddHeadView : UserControl
    {
        public AddHeadView()
        {
            InitializeComponent();
        }
    }
}
