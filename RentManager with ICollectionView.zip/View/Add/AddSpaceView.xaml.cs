﻿using System.Windows.Controls;

namespace RentManager.View.Add
{
    /// <summary>
    /// Interaction logic for AddSpaceView.xaml
    /// </summary>
    public partial class AddSpaceView : UserControl
    {
        public AddSpaceView()
        {
            InitializeComponent();
        }
    }
}
