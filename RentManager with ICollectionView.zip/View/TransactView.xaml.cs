﻿using System.Windows.Controls;

namespace RentManager.View
{
    /// <summary>
    /// Interaction logic for TransactView.xaml
    /// </summary>
    public partial class TransactView : UserControl
    {
        public TransactView()
        {
            InitializeComponent();
        }
    }
}
