﻿using System.Windows.Controls;

namespace RentManager.View.Edit
{
    /// <summary>
    /// Interaction logic for PlotView.xaml
    /// </summary>
    public partial class EditPlotView : UserControl
    {
        public EditPlotView()
        {
            InitializeComponent();
        }
    }
}
