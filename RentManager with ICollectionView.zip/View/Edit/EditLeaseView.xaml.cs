﻿using System.Windows.Controls;

namespace RentManager.View.Edit
{
    /// <summary>
    /// Interaction logic for LeaseView.xaml
    /// </summary>
    public partial class EditLeaseView : UserControl
    {
        public EditLeaseView()
        {
            InitializeComponent();
        }
    }
}
