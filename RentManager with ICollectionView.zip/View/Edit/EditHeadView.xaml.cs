﻿using System.Windows.Controls;

namespace RentManager.View.Edit
{
    /// <summary>
    /// Interaction logic for HeadView.xaml
    /// </summary>
    public partial class EditHeadView : UserControl
    {
        public EditHeadView()
        {
            InitializeComponent();
        }
    }
}
