﻿using System.Windows.Controls;

namespace RentManager.View.Edit
{
    /// <summary>
    /// Interaction logic for SpaceView.xaml
    /// </summary>
    public partial class EditSpaceView : UserControl
    {
        public EditSpaceView()
        {
            InitializeComponent();
        }
    }
}
