﻿using System.Windows.Controls;

namespace RentManager.View.Home
{
    /// <summary>
    /// Interaction logic for HeadView.xaml
    /// </summary>
    public partial class HeadView : UserControl
    {
        public HeadView()
        {
            InitializeComponent();
        }
    }
}
