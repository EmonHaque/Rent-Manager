﻿using System.Windows.Controls;

namespace RentManager.View.Home
{
    /// <summary>
    /// Interaction logic for OccupationView.xaml
    /// </summary>
    public partial class OccupationView : UserControl
    {
        public OccupationView()
        {
            InitializeComponent();
        }
    }
}
