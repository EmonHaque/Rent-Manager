﻿using RentManager.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace RentManager.Interface
{
    public interface IEditable<T> 
    {
        public T Clone();
        public bool IsEqualTo(T source);
        public bool IsValid();
        public void Update(T Edited);
    }
}
