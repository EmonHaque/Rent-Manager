﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RentManager.Interface
{
    public interface IInsertable
    {
        public bool IsInsertionValid();
    }
}
