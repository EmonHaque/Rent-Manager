﻿using RentManager.Common;
using RentManager.CustomControl;
using RentManager.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace RentManager.ViewModel.Home
{
    public class TransactionVM : Notifiable
	{
        bool hasLeft;
        public bool HasLeft
        {
            get { return hasLeft; }
            set { hasLeft = value; getSummary(); }
        }
        public ICollectionView Summary { get; set; }

		public TransactionVM()
        {
			MainVM.OnSelectedMenuChanged += () => 
			{ 
				if (MainVM.SelectedMenu.Name == Constants.Home)
                {
					getSummary();
				}	
			};
		}

		void getSummary()
		{
			var summary = new List<TransactionSummary>();
			lock (SQLHelper.key)
            {
				var cmd = SQLHelper.connection.CreateCommand();
				cmd.CommandText = $@"WITH t0(Plot, Space, Tenant, Amount, ControlId, HeadId, TenantId, SpaceId) AS(
									SELECT p.Name, s.Name, t.Name, SUM(tn.Amount), tn.ControlId, tn.HeadId, tn.TenantId, tn.SpaceId FROM Transactions tn
									LEFT JOIN Plots p ON p.Id = tn.PlotId
									LEFT JOIN Spaces s ON s.Id = tn.SpaceId
									LEFT JOIN Tenants t ON t.Id = tn.TenantId
									WHERE tn.TenantId IN (SELECT Id FROM Tenants WHERE HasLeft = {Convert.ToInt32(HasLeft)})
									GROUP BY p.Name, s.Name, t.Name, tn.HeadId
									ORDER BY p.Name, s.Name
								),
								t1(Plot, Space, Tenant, Security, Receivable, Receipt, Payment, TenantId, SpaceId) AS(
									SELECT Plot, Space, Tenant, 
									SUM(CASE HeadId WHEN 4 THEN 1 WHEN 6 THEN -1 ELSE 0 END * Amount) Security,
									SUM(CASE ControlId WHEN 1 THEN Amount ELSE 0 END) Receivable,
									SUM(CASE WHEN HeadId=5 THEN Amount ELSE 0 END) Receipt,
									SUM(CASE WHEN ControlId=3 AND HeadID<>6 THEN Amount ELSE 0 END) Payment,
									TenantId, SpaceId FROM t0
									GROUP BY Plot, Space, Tenant
								)
								SELECT Plot, Space, Tenant, Security, Receivable, Receipt, Payment, (Receivable + Payment - Receipt) Due, l.IsExpired FROM t1 tn
								LEFT JOIN Leases l on l.TenantId = tn.TenantId AND l.SpaceId = tn.SpaceId";

				SQLHelper.connection.Open();
				var reader = cmd.ExecuteReader();
				
				while (reader.Read())
				{
					summary.Add(new TransactionSummary()
					{
						Plot = reader.GetString(0),
						Space = reader.GetString(1),
						Tenant = reader.GetString(2),
						Security = reader.GetInt32(3),
						Receivable = reader.GetInt32(4),
						Receipt = reader.GetInt32(5),
						Payment = reader.GetInt32(6),
						Due = reader.GetInt32(7),
						IsExpired = reader.GetBoolean(8)
					});
				}
				cmd.Dispose();
				SQLHelper.connection.Close();
			}
			Summary = CollectionViewSource.GetDefaultView(summary);
			Summary.GroupDescriptions.Add(new PropertyGroupDescription(nameof(TransactionSummary.Plot)));
			OnPropertyChanged(nameof(Summary));
		}
	}

    public class GroupSummaryConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
			var list = ((IEnumerable<object>)value).OfType<TransactionSummary>();
			
			var t1 = new TextBlock() { Text = "Total", FontWeight = FontWeights.Bold };
			var t2 = new NumReport() { Text = list.Sum(x => x.Security) };
			var t3 = new NumReport() { Text = list.Sum(x => x.Receivable) };
			var t4 = new NumReport() { Text = list.Sum(x => x.Receipt) };
			var t5 = new NumReport() { Text = list.Sum(x => x.Payment) };
			var t6 = new NumReport() { Text = list.Sum(x => x.Due) };

			Grid.SetColumn(t1, 0);
			Grid.SetColumn(t2, 2);
			Grid.SetColumn(t3, 3);
			Grid.SetColumn(t4, 4);
			Grid.SetColumn(t5, 5);
			Grid.SetColumn(t6, 6);

			var grid = new Grid()
			{
				ColumnDefinitions =
				{
					new ColumnDefinition(){Width = new GridLength(200)},
					new ColumnDefinition(){Width = new GridLength(2, GridUnitType.Star)},
					new ColumnDefinition(){Width = new GridLength(100)},
					new ColumnDefinition(){Width = new GridLength(100)},
					new ColumnDefinition(){Width = new GridLength(100)},
					new ColumnDefinition(){Width = new GridLength(100)},
					new ColumnDefinition(){Width = new GridLength(100)}
				},
				Children = {t1, t2, t3, t4, t5, t6},
                Resources =
                {
                    {
                        typeof(NumReport),
                        new Style()
                        {
                            Setters =
                            {
                                new Setter()
                                {
                                    Property = TextBlock.FontWeightProperty,
                                    Value = FontWeights.Bold
                                }
                            }
                        }
                    }
                }
            };
			return grid;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
