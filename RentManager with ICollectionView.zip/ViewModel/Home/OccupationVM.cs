﻿using RentManager.Common;
using RentManager.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;

namespace RentManager.ViewModel.Home
{
    public class OccupationVM
    {
        public static ICollectionView Spaces { get; set; }
        public static ICollectionView Leases { get; set; }

        public OccupationVM()
        {
            Spaces = new CollectionViewSource() { Source = MainVM.spaces }.View;
            Leases = new CollectionViewSource() { Source = MainVM.leases }.View;
            Spaces.GroupDescriptions.Add(new PropertyGroupDescription(nameof(Space.PlotId)));
            Leases.GroupDescriptions.Add(new PropertyGroupDescription(nameof(Lease.PlotId)));
            Leases.Filter = filterLeases;
            
            MainVM.OnSelectedMenuChanged += () => 
            {
                if (MainVM.SelectedMenu.Name == Constants.Home)
                    Leases.Refresh();
            };
        }

        bool filterLeases(object o) => !(o as Lease).IsExpired;
    }

    public class GroupNameConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            int spaces = 0;
            IEnumerable<Lease> leases = null;

            foreach (var item in OccupationVM.Spaces.Groups)
            {
                var group = (CollectionViewGroup)item;
                if ((int)group.Name == (int)value)
                {
                    spaces = group.Items.Count;
                    break;
                }
            }
            foreach (var item in OccupationVM.Leases.Groups)
            {
                var group = (CollectionViewGroup)item;
                if (group.Name == value)
                {
                    leases = group.Items.Cast<Lease>();
                    break;
                }
            }

            var firstBlock = new TextBlock()
            {
                Inlines =
                {
                    new Run(MainVM.plots.First(x => x.Id == (int)value).Name + " : "),
                    new Run(leases.Count() +"/"+ spaces)
                }
            };
            var secondBlock = new TextBlock() 
            { 
                Text = leases.Sum(x => x.FixedReceivables.Sum(x => x.Amount)).ToString("N0"), 
                HorizontalAlignment = HorizontalAlignment.Right 
            };

            var panel = new DockPanel() 
            { 
                Margin = new Thickness(0,0,10,0),
                Children = {firstBlock, secondBlock} 
            };
            return panel;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public class ListToSumConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return ((IEnumerable<Receivable>)value).Sum(x => x.Amount);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
