﻿using RentManager.Model;
using System.ComponentModel;
using System.Windows.Data;

namespace RentManager.ViewModel.Home
{
    public class HeadVM
    {
        public ICollectionView Heads { get; set; }
        public HeadVM()
        {
            Heads = new CollectionViewSource() 
            { 
                Source = MainVM.heads, 
                IsLiveGroupingRequested = true, 
                LiveGroupingProperties = { nameof(Head.ControlId) } 
            }.View;
            Heads.GroupDescriptions.Add(new PropertyGroupDescription(nameof(Head.ControlId)));
        }
    }
}
