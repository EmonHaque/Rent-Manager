﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RentManager.ViewModel.Home
{
    public class NotesVM
    {

    }
}
