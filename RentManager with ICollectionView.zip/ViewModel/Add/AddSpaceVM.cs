﻿using RentManager.Common;
using RentManager.Model;

namespace RentManager.ViewModel.Add
{
    public class AddSpaceVM : AddBase<Space>
    {
        public AddSpaceVM() : base()
        {
            NewObject.Id = MainVM.GetId(MainVM.spaces);
            NewObject.IsVacant = true;
        }
        
        #region base implementation
        protected override ViewType type => ViewType.Space;
        protected override Bag<Space> bag => MainVM.spaces; 
        protected override void insertInDatabase()
        {
            using var cmd = SQLHelper.connection.CreateCommand();
            cmd.CommandText = "INSERT INTO Spaces (PlotId, Name, Description, IsVacant) VALUES(@PlotId, @Name, @Description, 1)";
            cmd.Parameters.AddWithValue("@PlotId", NewObject.PlotId);
            cmd.Parameters.AddWithValue("@Name", NewObject.Name);
            cmd.Parameters.AddWithValue("@Description", NewObject.Description);
            SQLHelper.NonQuery(cmd);    
        }
        protected override void renewNewObject()
        {
            NewObject = new Space()
            {
                Id = NewObject.Id + 1,
                PlotId = NewObject.PlotId,
                IsVacant = true
            };
        }
        #endregion
    }
}
