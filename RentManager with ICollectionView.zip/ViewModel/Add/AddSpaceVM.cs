﻿using RentManager.Common;
using RentManager.Model;

namespace RentManager.ViewModel.Add
{
    public class AddSpaceVM : AddBase
    {
        int? id;
        int? plotId;
        public Space NewSpace { get; set; }

        public AddSpaceVM()
        {
            NewSpace = new Space()
            {
                Id = MainVM.GetId(MainVM.spaces),
                IsVacant = true
            };
        }
        
        #region base implementation
        protected override ViewType Type => ViewType.Space;
        protected override bool isObjectValid(object o) => NewSpace.IsInsertValid();       
        protected override void add()
        {
            using var cmd = SQLHelper.connection.CreateCommand();
            cmd.CommandText = "INSERT INTO Spaces (PlotId, Name, Description, IsVacant) VALUES(@PlotId, @Name, @Description, 1)";
            cmd.Parameters.AddWithValue("@PlotId", NewSpace.PlotId);
            cmd.Parameters.AddWithValue("@Name", NewSpace.Name);
            cmd.Parameters.AddWithValue("@Description", NewSpace.Description);
            SQLHelper.NonQuery(cmd);
            MainVM.spaces.Add(NewSpace);     
        }
        protected override void renew()
        {
            id = NewSpace.Id + 1;
            plotId = NewSpace.PlotId;
            NewSpace = new Space()
            {
                Id = id,
                PlotId = plotId,
                IsVacant = true
            };
            OnPropertyChanged(nameof(NewSpace));
        }
        #endregion
    }
}
