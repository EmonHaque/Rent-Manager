﻿using RentManager.Common;
using RentManager.Model;

namespace RentManager.ViewModel.Add
{
    public class AddSpaceVM : AddBase<Space>
    {
        int? id, plotId;
        public AddSpaceVM() : base()
        {
            NewObject.Id = MainVM.GetId(MainVM.spaces);
            NewObject.IsVacant = true;
        }
        
        #region base implementation
        protected override ViewType type => ViewType.Space;
        protected override Bag<Space> collection => MainVM.spaces;
        protected override bool isNewObjectValid(object o) => NewObject.IsInsertValid();       
        protected override void insertInDatabase()
        {
            using var cmd = SQLHelper.connection.CreateCommand();
            cmd.CommandText = "INSERT INTO Spaces (PlotId, Name, Description, IsVacant) VALUES(@PlotId, @Name, @Description, 1)";
            cmd.Parameters.AddWithValue("@PlotId", NewObject.PlotId);
            cmd.Parameters.AddWithValue("@Name", NewObject.Name);
            cmd.Parameters.AddWithValue("@Description", NewObject.Description);
            SQLHelper.NonQuery(cmd);    
        }
        protected override void renewNewObject()
        {
            id = NewObject.Id + 1;
            plotId = NewObject.PlotId;
            NewObject = new Space()
            {
                Id = id,
                PlotId = plotId,
                IsVacant = true
            };
        }
        #endregion
    }
}
