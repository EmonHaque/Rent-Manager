﻿using RentManager.Common;
using RentManager.Model;

namespace RentManager.ViewModel.Add
{
    public class AddPlotVM : AddBase
    {
        int? id;
        public Plot NewPlot { get; set; }
        public AddPlotVM() => NewPlot = new Plot() { Id = MainVM.GetId(MainVM.plots) };

        #region base implementation
        protected override ViewType type => ViewType.Plot;
        protected override bool isObjectValid(object o) => NewPlot.IsInsertValid();
        protected override void add()
        {
            using var cmd = SQLHelper.connection.CreateCommand();
            cmd.CommandText = "INSERT INTO Plots (Name, Description) VALUES(@Name, @Description)";
            cmd.Parameters.AddWithValue("@Name", NewPlot.Name);
            cmd.Parameters.AddWithValue("@Description", NewPlot.Description);
            SQLHelper.NonQuery(cmd);

            MainVM.plots.Add(NewPlot);
        }
        protected override void renew()
        {
            id = NewPlot.Id + 1;
            NewPlot = new Plot() { Id = id };
            OnPropertyChanged(nameof(NewPlot));
        }
        #endregion
    }
}
