﻿using RentManager.Common;
using RentManager.Model;
using System.Collections.Specialized;

namespace RentManager.ViewModel.Add
{
    public class AddPlotVM : AddBase<Plot>
    {
        int? id;
        public AddPlotVM() : base() => NewObject.Id = MainVM.GetId(MainVM.plots);

        #region base implementation
        protected override ViewType type => ViewType.Plot;
        protected override Bag<Plot> collection => MainVM.plots;
        protected override bool isNewObjectValid(object o) => NewObject.IsInsertValid();
        protected override void insertInDatabase()
        {
            using var cmd = SQLHelper.connection.CreateCommand();
            cmd.CommandText = "INSERT INTO Plots (Name, Description) VALUES(@Name, @Description)";
            cmd.Parameters.AddWithValue("@Name", NewObject.Name);
            cmd.Parameters.AddWithValue("@Description", NewObject.Description);
            SQLHelper.NonQuery(cmd);
        }
        protected override void renewNewObject()
        {
            id = NewObject.Id + 1;
            NewObject = new Plot() { Id = id };
        }
        #endregion
    }
}
