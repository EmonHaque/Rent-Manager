﻿using RentManager.Common;
using RentManager.Model;
using System.Collections.Specialized;

namespace RentManager.ViewModel.Add
{
    public abstract class AddBase<T> : Notifiable where T : new() 
    {
        public T NewObject { get; set; }
        public Command Add { get; set; }
        public AddBase()
        {
            NewObject = new T();
            Add = new Command(addNewObject, isNewObjectValid);
        }
        protected abstract ViewType type { get; }
        protected bool isFocused => MainVM.SelectedMenu.Name == Constants.Add;
        protected abstract Bag<T> collection { get; }
        protected abstract bool isNewObjectValid(object o);
        protected abstract void insertInDatabase();
        protected abstract void renewNewObject();
        void raiseCollectionChanged()
        {
            App.Current.Dispatcher.Invoke(() =>
                collection.OnCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Add, NewObject)));
        }
        void addNewObject(object o)
        {
            MainVM.DoAsync(type, () =>
            {
                lock (SQLHelper.key) { insertInDatabase(); }
                collection.Add(NewObject);
                raiseCollectionChanged();
                renewNewObject();
                OnPropertyChanged(nameof(NewObject));
            });
        }
    }
}
