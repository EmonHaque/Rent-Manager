﻿using RentManager.Common;
using RentManager.Model;

namespace RentManager.ViewModel.Add
{
    public abstract class AddBase : Notifiable
    {
        public Command Add { get; set; }
        public AddBase()
        {
            Add = new Command(addObject, isObjectValid);
        }
        protected abstract ViewType type { get; }
        protected abstract bool isObjectValid(object o);
        protected abstract void add();
        protected abstract void renew();

        protected bool isFocused => MainVM.SelectedMenu.Name == Constants.Add;
        void addObject(object o)
        {
            MainVM.DoAsync(type, () =>
            {
                lock (SQLHelper.key) 
                { add(); }
                renew();
            });
        }
    }
}
