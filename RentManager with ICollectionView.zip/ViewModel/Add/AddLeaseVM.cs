﻿using Microsoft.Data.Sqlite;
using RentManager.Common;
using RentManager.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Data;

namespace RentManager.ViewModel.Add
{
    public class AddLeaseVM : AddBase
    {
        Plot selectedPlot;       
        int? spaceId, tenantId;

        public Lease NewLease { get; set; }
        public Receivable NewReceivable { get; set; }
        public ICollectionView VacantSpaces { get; set; }
        public ICollectionView AvailableTenants { get; set; }
        public ICollectionView ReceivableHeads { get; set; }

        public Command AddReceivable { get; set; }
        public Command RemoveReceivable { get; set; }

        public AddLeaseVM()
        {
            initializeCollections();
            subscribe();
            selectedPlot = MainVM.Plots.CurrentItem as Plot;
            initializeProperties();        
            initializeFilters();
            initializeCommands();
        }

        #region For Constructor
        void initializeCollections()
        {
            VacantSpaces = new CollectionViewSource() 
            { 
                Source = MainVM.spaces, 
                IsLiveFilteringRequested = true, 
                LiveFilteringProperties = { nameof(Space.IsVacant) } 
            }.View;

            AvailableTenants = new CollectionViewSource() 
            { 
                Source = MainVM.tenants, 
                IsLiveFilteringRequested = true, 
                LiveFilteringProperties = { nameof(Tenant.HasLeft) } 
            }.View;

            ReceivableHeads = new CollectionViewSource() { Source = MainVM.heads }.View;
        }

        void subscribe()
        {
            MainVM.Plots.CurrentChanged += onPlotChanged;
            MainVM.OnSelectedMenuChanged += onMenuChanged;
        }

        void initializeProperties()
        {
            NewLease = new Lease()
            {
                Id = ++MainVM.maxLeaseId,
                DateStart = DateTime.Now
            };
            NewReceivable = new Receivable() { LeaseId = NewLease.Id };
        }

        void initializeFilters()
        {
            VacantSpaces.Filter = filterSpaces;
            AvailableTenants.Filter = filterTenant;
            ReceivableHeads.Filter = filterReceivableHeads;
        }

        void initializeCommands()
        {
            AddReceivable = new Command(addReceivable, (o) => NewReceivable.IsValid());
            RemoveReceivable = new Command(removeReceivable, (o) => true);
        }
        #endregion

        #region ICommands
        void addReceivable(object o)
        {
            NewLease.FixedReceivables.Add(NewReceivable);
            var head = ReceivableHeads.CurrentItem as Head;
            NewReceivable = new Receivable()
            {
                HeadId = head == null ? 0 : head.Id,
                LeaseId = NewLease.Id
            };
            OnPropertyChanged(nameof(NewReceivable));
            ReceivableHeads.Refresh();
        }

        void removeReceivable(object o)
        {
            NewLease.FixedReceivables.Remove(o as Receivable);
            ReceivableHeads.Refresh();
            if (ReceivableHeads.CurrentItem == null)
                ReceivableHeads.MoveCurrentToFirst();
        }
        #endregion

        #region Filters
        bool filterReceivableHeads(object o)
        {
            var head = o as Head;
            return head.ControlId == MainVM.controlIdOfReceivable
                && NewLease.FixedReceivables.FirstOrDefault(x => x.HeadId == head.Id) == null;
        }

        bool filterTenant(object o) => !(o as Tenant).HasLeft;

        bool filterSpaces(object o)
        {
            if (selectedPlot == null) return false;
            var item = o as Space;
            return item.IsVacant && item.PlotId == selectedPlot.Id;
        }
        #endregion

        #region EventHandlers
        void onMenuChanged()
        {
            if (IsFocused) VacantSpaces.Refresh();
        }

        void onPlotChanged(object sender, EventArgs e)
        {
            selectedPlot = MainVM.Plots.CurrentItem as Plot;
            if (!IsFocused) return;        
            VacantSpaces.Refresh();
        }
        #endregion

        #region base implementation
        protected override ViewType Type => ViewType.Lease;
        protected override bool isObjectValid(object o) => NewLease.IsValid();
        protected override void add()
        {
            var commands = new List<SqliteCommand>();
            var cmd = new SqliteCommand(@"INSERT INTO Leases(PlotId, SpaceId, TenantId, DateStart, Business, IsExpired)
                                         VALUES(@PlotId, @SpaceId, @TenantId, @Date, @Business, 0);
                                        UPDATE Spaces SET IsVacant = 0 WHERE Id = @Id;");
            cmd.Parameters.AddWithValue("@PlotId", NewLease.PlotId);
            cmd.Parameters.AddWithValue("@SpaceId", NewLease.SpaceId);
            cmd.Parameters.AddWithValue("@TenantId", NewLease.TenantId);
            cmd.Parameters.AddWithValue("@Date", NewLease.DateStart.ToString("yyyy-MM-dd"));
            cmd.Parameters.AddWithValue("@Business", NewLease.Business);
            cmd.Parameters.AddWithValue("@Id", NewLease.SpaceId);
            commands.Add(cmd);

            foreach (var item in NewLease.FixedReceivables)
                commands.Add(new SqliteCommand($"INSERT INTO Receivables VALUES({NewLease.Id}, {item.HeadId}, {item.Amount})"));

            SQLHelper.Transaction(commands);
            foreach (var command in commands) command.Dispose();

            MainVM.leases.Add(NewLease);
        }
        protected override void renew()
        {
            tenantId = NewLease.TenantId;
            spaceId = NewLease.SpaceId;
            NewLease = new Lease()
            {
                Id = ++MainVM.maxLeaseId,
                PlotId = selectedPlot.Id,
                TenantId = tenantId,
                DateStart = DateTime.Now
            };
            OnPropertyChanged(nameof(NewLease));
            NewReceivable.LeaseId = NewLease.Id;
            var space = MainVM.spaces.First(x => x.Id == spaceId);
            space.IsVacant = false;
            space.OnPropertyChanged(nameof(space.IsVacant));
            App.Current.Dispatcher.Invoke(ReceivableHeads.Refresh);
        }
        #endregion
    }
}
