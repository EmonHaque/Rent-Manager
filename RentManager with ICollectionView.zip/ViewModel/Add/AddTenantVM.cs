﻿using RentManager.Common;
using RentManager.Model;
using System;

namespace RentManager.ViewModel.Add
{
    public class AddTenantVM : AddBase<Tenant>
    {
        int? id;
        public AddTenantVM() : base() => NewObject.Id = MainVM.GetId(MainVM.tenants);

        #region base implementation
        protected override ViewType type => ViewType.Tenant;
        protected override Bag<Tenant> collection => MainVM.tenants;
        protected override bool isNewObjectValid(object o) => NewObject.IsValid();       
        protected override void insertInDatabase()
        {
            var mother = string.IsNullOrWhiteSpace(NewObject.Mother) ? (object)DBNull.Value : NewObject.Mother;
            var husband = string.IsNullOrWhiteSpace(NewObject.Husband) ? (object)DBNull.Value : NewObject.Husband;
            var nid = string.IsNullOrWhiteSpace(NewObject.NID) ? (object)DBNull.Value : NewObject.NID;

            using var cmd = SQLHelper.connection.CreateCommand();
            cmd.CommandText = @"INSERT INTO Tenants (Name, Father, Mother, Husband, Address, NID, ContactNo, HasLeft) 
                                VALUES(@Name, @Father, @Mother, @Husband, @Address, @NID, @ContactNo, 0)";
            cmd.Parameters.AddWithValue("@Name", NewObject.Name);
            cmd.Parameters.AddWithValue("@Father", NewObject.Father);
            cmd.Parameters.AddWithValue("@Mother", mother);
            cmd.Parameters.AddWithValue("@Husband", husband);
            cmd.Parameters.AddWithValue("@Address", NewObject.Address);
            cmd.Parameters.AddWithValue("@NID", nid);
            cmd.Parameters.AddWithValue("@ContactNo", NewObject.ContactNo);
            SQLHelper.NonQuery(cmd);
        }
        protected override void renewNewObject()
        {
            id = NewObject.Id + 1;
            NewObject = new Tenant() { Id = id };
        }
        #endregion
    }
}
