﻿using RentManager.Common;
using RentManager.Model;
using System;

namespace RentManager.ViewModel.Add
{
    public class AddTenantVM : AddBase
    {
        int? id;
        public Tenant NewTenant { get; set; }
        public AddTenantVM() => NewTenant = new Tenant() { Id = MainVM.GetId(MainVM.tenants) };
       
        #region base implementation
        protected override ViewType type => ViewType.Tenant;
        protected override bool isObjectValid(object o) => NewTenant.IsValid();       
        protected override void add()
        {
            var mother = string.IsNullOrWhiteSpace(NewTenant.Mother) ? (object)DBNull.Value : NewTenant.Mother;
            var husband = string.IsNullOrWhiteSpace(NewTenant.Husband) ? (object)DBNull.Value : NewTenant.Husband;
            var nid = string.IsNullOrWhiteSpace(NewTenant.NID) ? (object)DBNull.Value : NewTenant.NID;

            using var cmd = SQLHelper.connection.CreateCommand();
            cmd.CommandText = @"INSERT INTO Tenants (Name, Father, Mother, Husband, Address, NID, ContactNo, HasLeft) 
                                VALUES(@Name, @Father, @Mother, @Husband, @Address, @NID, @ContactNo, 0)";
            cmd.Parameters.AddWithValue("@Name", NewTenant.Name);
            cmd.Parameters.AddWithValue("@Father", NewTenant.Father);
            cmd.Parameters.AddWithValue("@Mother", mother);
            cmd.Parameters.AddWithValue("@Husband", husband);
            cmd.Parameters.AddWithValue("@Address", NewTenant.Address);
            cmd.Parameters.AddWithValue("@NID", nid);
            cmd.Parameters.AddWithValue("@ContactNo", NewTenant.ContactNo);
            SQLHelper.NonQuery(cmd);

            MainVM.tenants.Add(NewTenant);
        }
        protected override void renew()
        {
            id = NewTenant.Id + 1;
            NewTenant = new Tenant() { Id = id };
            OnPropertyChanged(nameof(NewTenant));
        }
        #endregion
    }
}
