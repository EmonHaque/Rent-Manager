﻿using RentManager.Common;
using RentManager.Model;

namespace RentManager.ViewModel.Add
{
    public class AddHeadVM : AddBase
    {
        int? id;
        int? controlId;
        public Head NewHead { get; set; }
        public AddHeadVM() => NewHead = new Head() { Id = MainVM.GetId(MainVM.heads) };

        #region base Implementation
        protected override ViewType Type => ViewType.Head;
        protected override bool isObjectValid(object o) => NewHead.IsInsertValid();
        protected override void add()
        {
            using var cmd = SQLHelper.connection.CreateCommand();
            cmd.CommandText = "INSERT INTO Heads (ControlId, Name, Description) VALUES(@ControlId, @Name, @Description)";
            cmd.Parameters.AddWithValue("@ControlId", NewHead.ControlId);
            cmd.Parameters.AddWithValue("@Name", NewHead.Name);
            cmd.Parameters.AddWithValue("@Description", NewHead.Description);
            SQLHelper.NonQuery(cmd);
            MainVM.heads.Add(NewHead);
        }
        protected override void renew()
        {
            id = NewHead.Id + 1; ;
            controlId = NewHead.ControlId;
            NewHead = new Head()
            {
                Id = id,
                ControlId = controlId
            };
            OnPropertyChanged(nameof(NewHead));
        }
        #endregion
    }
}
