﻿using Microsoft.Win32;
using RentManager.Common;
using RentManager.CustomControl;
using RentManager.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;

namespace RentManager.ViewModel.Ledger
{
    public abstract class LedgerBase : Notifiable
    {
        public List<ReportEntry> Reportables { get; set; }
        public ReportDates Dates { get; set; }
        public ReportSummary Summary { get; set; }
        public Command RefreshReport { get; set; }
        public Command ExportCSV { get; set; }
        public Command PrintReport { get; set; }

        public LedgerBase()
        {
            initializeProperties();
            initializeCommands();
            MainVM.OnSelectedMenuChanged += requery;
            LedgerVM.OnSelectedTabChanged += requery;
        }

        int? controlIdOfPayment;
        List<ReportEntry> reserved;
        bool isInLedgerView => MainVM.SelectedMenu.Name == Constants.Ledger;
        bool isFocused => LedgerVM.SelectedTab.Type == type;
        int? id;
        public int? Id
        {
            get { return id; }
            set { id = value; updateReportables(); }
        }
      
        protected abstract ViewType type { get; }
        protected abstract string particulars { get; }
        protected abstract string where { get; }
        protected abstract void setTitleAndSubTitle();

        protected string reportTitle { get; set; }
        protected string reportSubTitle { get; set; }

        #region for Constructor
        void initializeProperties()
        {
            controlIdOfPayment = MainVM.controlHeads.First(x => x.Name == "Payment").Id;
            Dates = new ReportDates();
            Summary = new ReportSummary();
            OnPropertyChanged(nameof(Dates));
            OnPropertyChanged(nameof(Summary));
        }

        void initializeCommands()
        {
            RefreshReport = new Command(refreshReport, isRefreshValid);
            ExportCSV = new Command(exportCSV, isPrintOrExportValid);
            PrintReport = new Command(printReport, isPrintOrExportValid);
        }

        void requery()
        {
            if (isInLedgerView && isFocused)
                updateReportables();
        }
        #endregion

        #region ICommands
        void refreshReport(object o)
        {
            var lastEntry = reserved.LastOrDefault(x => x.Date < Dates.From);
            var newReportables = new List<ReportEntry>();
            if (lastEntry != null)
            {
                newReportables.Add(new ReportEntry()
                {
                    Date = Dates.From,
                    Balance = lastEntry.Balance,
                    Particulars = "balance b/d"
                });
            }
            var entries = reserved.Where(x => x.Date >= Dates.From && x.Date <= Dates.To).ToList();
            var receivable = entries.Sum(x => x.Receivable);
            var receipt = entries.Sum(x => x.Receipt);
            newReportables.AddRange(entries);

            Reportables = newReportables;
            Summary.TotalReceivable = receivable;
            Summary.TotalReceipt = receipt;
            OnPropertyChanged(nameof(Summary));
            OnPropertyChanged(nameof(Reportables));
        }

        void exportCSV(object o)
        {
            var dialog = new SaveFileDialog()
            {
                FileName = "Report",
                Filter = "CSV files (.csv)|*.csv"
            };

            if (dialog.ShowDialog() == true)
            {
                var builder = new StringBuilder();
                builder.Append("Date, Particulars, Receivable/Payment, Receipt, Balance").AppendLine();
                foreach (var item in Reportables)
                {
                    builder
                        .Append(item.Date.ToShortDateString()).Append(",")
                        .Append("\"").Append(item.Particulars).Append(item.Narration).Append("\"").Append(",")
                        .Append(item.Receivable).Append(",")
                        .Append(item.Receipt).Append(",")
                        .Append(item.Balance).AppendLine();
                }
                File.WriteAllText(Path.GetFullPath(dialog.FileName), builder.ToString());
            }
        }

        void printReport(object o)
        {
            refreshReport(null);
            var dialog = new PrintDialog();
            if (dialog.ShowDialog() != true) return;

            var size = new Size(dialog.PrintableAreaWidth, dialog.PrintableAreaHeight);
            var doc = new FixedDocument();
            doc.DocumentPaginator.PageSize = size;
            doc.DocumentPaginator.PageSize = size;

            LedgerPage pageControl = getPage(doc, null); ;
            for (int i = 0; i < Reportables.Count; i++)
            {
                if (pageControl.AddItem(Reportables[i]) > pageControl.AvailableHeight)
                {
                    pageControl.RemoveItem(Reportables[i]);
                    pageControl.LastEntry = Reportables[i - 1];
                    pageControl = getPage(doc, pageControl);
                    pageControl.AddItem(Reportables[i]);
                }
            }
            pageControl.RaiseFinished();
            dialog.PrintDocument(doc.DocumentPaginator, "");
        }

        bool isRefreshValid(object o)
        {
            return
                !isBusy() &&
                reserved != null &&
                Dates.From <= Dates.To &&
                Dates.To >= reserved.First().Date;
        }

        bool isPrintOrExportValid(object o)
        {
            return
                !MainVM.TenantBusy &&
                !MainVM.SpaceBusy &&
                !MainVM.PlotBusy &&
                Reportables != null &&
                Reportables.Count > 0;
        }
        #endregion

        void updateReportables()
        {
            if (!isInLedgerView) return;
            if (!isFocused) return;
            if (Id == null)
            {
                clearReportables();
                return;
            }
            MainVM.DoAsync(type, () =>
            {
                reserved = new List<ReportEntry>();
                int receivable, receipt, balance;
                receivable = receipt = balance = 0;

                lock (SQLHelper.key)
                {
                    SQLHelper.connection.Open();
                    using var cmd = SQLHelper.connection.CreateCommand();
                    cmd.CommandText = $@"SELECT tn.Date, {particulars} ||' -> '|| c.Name ||' - '|| h.Name, tn.Narration, 
                                                tn.ControlId, tn.TenantId, tn.Amount FROM Transactions tn
                                        LEFT JOIN Plots p ON p.Id = tn.PlotId
                                        LEFT JOIN Spaces s ON s.Id = tn.SpaceId
                                        LEFT JOIN Tenants t ON t.Id = tn.TenantId
                                        LEFT JOIN Heads h ON h.Id = tn.HeadId
                                        LEFT JOIN ControlHeads c ON c.Id = tn.ControlId
                                        WHERE tn.{where}={Id} ORDER by tn.Date";

                    var reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        var entry = new ReportEntry()
                        {
                            Date = reader.GetDateTime(0),
                            Particulars = reader.GetString(1),
                            Narration = reader.IsDBNull(2) ? " | No explanation" : " | " + reader.GetString(2),
                            ControlId = reader.GetInt32(3),
                            TenantId = reader.GetInt32(4)
                        };
                        var amount = reader.GetInt32(5);

                        if (entry.ControlId == MainVM.controlIdOfReceivable || entry.ControlId == controlIdOfPayment)
                        {
                            receivable += amount;
                            balance -= amount;
                            entry.Receivable = amount;
                        }
                        else
                        {
                            receipt += amount;
                            balance += amount;
                            entry.Receipt = amount;
                        }

                        entry.Balance = balance;
                        reserved.Add(entry);
                    }

                    cmd.Dispose();
                    SQLHelper.connection.Close();
                }

                if (reserved.Count > 0)
                {
                    Dates.Start = reserved.First().Date;
                    Dates.End = reserved.Last().Date;
                    Dates.From = reserved.First().Date;
                    Dates.To = reserved.Last().Date;

                    Summary.Heading = $"available from {Dates.From.ToString("dd MMMM, yyyy")} to {Dates.To.ToString("dd MMMM, yyyy")}";
                    Summary.TotalReceipt = receipt;
                    Summary.TotalReceivable = receivable;
                    OnPropertyChanged(nameof(Summary));

                    Reportables = reserved;
                    OnPropertyChanged(nameof(Reportables));
                }
                else clearReportables();
            });
        }

        void clearReportables()
        {
            Dates.Start = Dates.End = Dates.From = Dates.To = DateTime.Today;
            Summary.TotalReceipt = Summary.TotalReceivable = 0;
            Summary.Heading = string.Empty;
            Reportables = reserved = null;

            OnPropertyChanged(nameof(Dates));
            OnPropertyChanged(nameof(Summary));
            OnPropertyChanged(nameof(Reportables));
        }

        bool isBusy()
        {
            if (LedgerVM.SelectedTab == null) return false;
            return LedgerVM.SelectedTab.Type switch
            {
                ViewType.Plot => MainVM.PlotBusy,
                ViewType.Space => MainVM.SpaceBusy,
                ViewType.Tenant => MainVM.TenantBusy,
                _ => false
            };
        }

        LedgerPage getPage(FixedDocument doc, LedgerPage oldPage)
        {
            LedgerPage page;
            if (oldPage == null)
            {
                setTitleAndSubTitle();
                page = new LedgerPage()
                {
                    Width = doc.DocumentPaginator.PageSize.Width,
                    Height = doc.DocumentPaginator.PageSize.Height,
                    Title = reportTitle,
                    SubTitle = reportSubTitle,
                    Date = $"period from {Dates.From.ToString("dd MMMM, yyyy")} to {Dates.To.ToString("dd MMMM, yyyy")}",
                    FootNote = $"System generated report at {DateTime.Now.ToString("dd MMMM, yyyy | hh:mm:ss tt")}",
                    PageNo = 1
                };
                var grid = new Grid() { Children = { page } };
                grid.Measure(new Size(page.Width, page.Height));
                grid.Arrange(new Rect(grid.DesiredSize));
            }
            else page = new LedgerPage(oldPage);
            doc.Pages.Add(new PageContent() { Child = page.Page });
            return page;
        }
    }
}
