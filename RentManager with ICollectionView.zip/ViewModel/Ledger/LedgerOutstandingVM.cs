﻿using Microsoft.Win32;
using RentManager.Common;
using RentManager.CustomControl;
using RentManager.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;

namespace RentManager.ViewModel.Ledger
{
    public class LedgerOutStandingVM : Notifiable
    {
        IList<OutstandingSummary> summary;
        int? plotId;
        bool hasLeft;
        public int? PlotId
        {
            get => plotId;
            set { plotId = value; getData(value); }
        }
        public bool HasLeft
        {
            get => hasLeft;
            set { hasLeft = value; getData(PlotId); }
        }
        public ICollectionView CurrentBalance { get; set; }
        public Command Reload { get; set; }
        public Command PrintReport { get; set; }
        public Command ExportCSV { get; set; }

        public LedgerOutStandingVM()
        {
            initializeCommand();
            MainVM.OnSelectedMenuChanged += update;
            LedgerVM.OnSelectedTabChanged += update;
        }

        void initializeCommand()
        {
            Reload = new Command(reload, (o) => PlotId != null & !MainVM.BalanceBusy);
            PrintReport = new Command(printReport, isPrintOrExportValid);
            ExportCSV = new Command(exportCSV, isPrintOrExportValid);
        }

        #region ICommands
        void reload(object o) => getData(PlotId);
        bool isPrintOrExportValid(object o) => CurrentBalance != null && !CurrentBalance.IsEmpty;
        void printReport(object o)
        {
            var dialog = new PrintDialog();
            if (dialog.ShowDialog() != true) return;

            var size = new Size(dialog.PrintableAreaWidth, dialog.PrintableAreaHeight);
            var doc = new FixedDocument();
            doc.DocumentPaginator.PageSize = size;
            OutstandingPage pageControl = getPage(doc, null);

            int totalSecurity, totalRent, totalDue;
            totalSecurity = totalRent = totalDue = 0;

            foreach (CollectionViewGroup group in CurrentBalance.Groups)
            {
                var items = group.Items.Cast<OutstandingSummary>().ToList();
                int securitySum, rentSum, dueSum;
                securitySum = rentSum = dueSum = 0;
                foreach (var item in items)
                {
                    securitySum += item.Security;
                    rentSum += item.Rent;
                    dueSum += item.Due;

                    totalSecurity += item.Security;
                    totalRent += item.Rent;
                    totalDue += item.Due;

                    if (pageControl.AddItem(item) > pageControl.AvailableHeight)
                    {
                        pageControl.RemoveItem(item);
                        securitySum -= item.Security;
                        rentSum -= item.Rent;
                        dueSum -= item.Due;

                        totalSecurity -= item.Security;
                        totalRent -= item.Rent;
                        totalDue -= item.Due;

                        pageControl.TotalSecurity = totalSecurity;
                        pageControl.TotalRent = totalRent;
                        pageControl.TotalDue = totalDue;
                        pageControl.RefreshInternalView();

                        pageControl = getPage(doc, pageControl);
                        pageControl.AddItem(new OutstandingSummary()
                        {
                            Tenant = "balance",
                            Space = "",
                            Security = totalSecurity,
                            Rent = totalRent,
                            Due = totalDue
                        });
                        if (securitySum != 0 && rentSum != 0)
                        {
                            pageControl.AddItem(new OutstandingSummary()
                            {
                                Tenant = item.Tenant,
                                Space = "balance b/d",
                                Security = securitySum,
                                Rent = rentSum,
                                Due = dueSum
                            });
                        }
                        pageControl.AddItem(item);
                        totalSecurity += item.Security;
                        totalRent += item.Rent;
                        totalDue += item.Due;
                    }
                }
            }

            pageControl.TotalSecurity = totalSecurity;
            pageControl.TotalRent = totalRent;
            pageControl.TotalDue = totalDue;

            pageControl.RefreshInternalView();
            pageControl.RaiseFinished();
            dialog.PrintDocument(doc.DocumentPaginator, "");
        }

        void exportCSV(object o)
        {
            var dialog = new SaveFileDialog()
            {
                FileName = "Report",
                Filter = "CSV files (.csv)|*.csv"
            };

            if (dialog.ShowDialog() == true)
            {
                var builder = new StringBuilder();
                builder.Append("Tenant, Space, Date, Security, Rent, Due").AppendLine();
                foreach (var item in summary)
                {
                    builder
                        .Append("\"").Append(item.Tenant).Append("\"").Append(",")
                        .Append("\"").Append(item.Space).Append("\"").Append(",")
                        .Append(item.DateStart.ToString("MM/dd/yyyy")).Append(",")
                        .Append(item.Security).Append(",")
                        .Append(item.Rent).Append(",")
                        .Append(item.Due).AppendLine();
                }
                File.WriteAllText(Path.GetFullPath(dialog.FileName), builder.ToString());
            }
        }
        #endregion

        void getData(int? plotId)
        {
            if (MainVM.SelectedMenu.Name != Constants.Ledger) return;
            if (LedgerVM.SelectedTab.Type != ViewType.CurrentBalance) return;
            if (plotId == null)
            {
                CurrentBalance = null;
                summary = null;
                return;
            }
            MainVM.DoAsync(ViewType.CurrentBalance, () =>
            {
                lock (SQLHelper.key)
                {
                    SQLHelper.connection.Open();
                    var cmd = SQLHelper.connection.CreateCommand();
                    cmd.CommandText = $@"WITH t0(Space, Tenant, Amount, ControlId, HeadId, TenantId, SpaceId) AS(
									SELECT s.Name, t.Name, SUM(tn.Amount), tn.ControlId, tn.HeadId, tn.TenantId, tn.SpaceId FROM Transactions tn
									LEFT JOIN Plots p ON p.Id = tn.PlotId
									LEFT JOIN Spaces s ON s.Id = tn.SpaceId
									LEFT JOIN Tenants t ON t.Id = tn.TenantId
									WHERE tn.PlotId = {PlotId} AND TenantId IN (SELECT Id FROM Tenants WHERE HasLeft = {Convert.ToInt32(HasLeft)})
									GROUP BY t.Name, s.Name, tn.HeadId
									ORDER BY s.Name
								),
								t1(Space, Tenant, Security, Receivable, Receipt, TenantId, SpaceId) AS(
									SELECT Space, Tenant, 
									SUM(CASE HeadId WHEN 4 THEN 1 WHEN 6 THEN -1 ELSE 0 END * Amount) Security,
									SUM(CASE ControlId WHEN 1 THEN Amount ELSE 0 END) Receivable,
									SUM(CASE WHEN HeadId=5 THEN Amount ELSE 0 END) Receipt,
									TenantId, SpaceId FROM t0
									GROUP BY Tenant, Space
								),
								t2 (Space, Tenant, Security, Due, TenantId, SpaceId) AS (
									SELECT Space, Tenant, Security, (Receivable - Receipt) Due, TenantId, SpaceId FROM t1
								),
								t3(Space, Tenant, Security, Due, LeaseId, DateStart, DateEnd, IsExpired) AS(
									SELECT Space, Tenant, Security, Due, l.Id, l.DateStart, l.DateEnd, l.IsExpired FROM t2 tn
									LEFT JOIN Leases l ON l.TenantId = tn.TenantId AND l.SpaceId = tn.SpaceId
								),
								t4(Space, Tenant, Security, Rent, Due, DateStart, DateEnd, IsExpired) AS(
									SELECT Space, Tenant, Security, COALESCE(SUM(r.Amount), 0), Due, DateStart, DateEnd, IsExpired FROM t3 tn
									LEFT JOIN Receivables r ON r.LeaseId = tn.LeaseId
									GROUP BY tn.LeaseId
								),
								t5(Space, Tenant, Security, Rent, Due, DateStart, DateEnd, IsExpired, Counts) AS (
                                	SELECT *, COUNT(Tenant)
                                	FROM t4 GROUP BY Tenant
                                )
                                SELECT t1.Space, t1.Tenant, t1.Security, t1.Rent, t1.Due, t1.DateStart, t1.DateEnd, t1.IsExpired FROM t4 t1
                                LEFT JOIN t5 t2 ON t1.Tenant = t2.Tenant
                                ORDER BY t2.Counts DESC";

                    var reader = cmd.ExecuteReader();
                    summary = new List<OutstandingSummary>();
                    while (reader.Read())
                    {
                        summary.Add(new OutstandingSummary()
                        {
                            Space = reader.GetString(0),
                            Tenant = reader.GetString(1),
                            Security = reader.GetInt32(2),
                            Rent = reader.GetInt32(3),
                            Due = reader.GetInt32(4),
                            DateStart = reader.GetDateTime(5),
                            DateEnd = reader.IsDBNull(6) ? (DateTime?)null : reader.GetDateTime(6),
                            IsExpired = reader.GetBoolean(7)
                        });
                    }
                    cmd.Dispose();
                    SQLHelper.connection.Close();

                    CurrentBalance = CollectionViewSource.GetDefaultView(summary);
                    CurrentBalance.GroupDescriptions.Add(new PropertyGroupDescription(nameof(OutstandingSummary.Tenant)));
                    OnPropertyChanged(nameof(CurrentBalance));
                }

            });
        }

        void update()
        {
            if (MainVM.SelectedMenu.Name == Constants.Ledger &&
                LedgerVM.SelectedTab.Type == ViewType.CurrentBalance)
                getData(PlotId);
        }

        OutstandingPage getPage(FixedDocument doc, OutstandingPage oldPage)
        {
            OutstandingPage page;
            if (oldPage == null)
            {
                page = new OutstandingPage()
                {
                    Width = doc.DocumentPaginator.PageSize.Width,
                    Height = doc.DocumentPaginator.PageSize.Height,
                    Title = MainVM.plots.First(x => x.Id == PlotId).Name,
                    SubTitle = HasLeft ? "Deposit, Rent and Dues of Tenants who left" : "Tenants' Deposit, Rent and Dues",
                    Date = "as at " + DateTime.Today.ToString("dd MMMM, yyyy"),
                    FootNote = $"System generated report at {DateTime.Now.ToString("hh:mm:ss tt")}",
                    PageNo = 1
                };
                var grid = new Grid() { Children = { page } };
                grid.Measure(new Size(page.Width, page.Height));
                grid.Arrange(new Rect(grid.DesiredSize));
            }
            else page = new OutstandingPage(oldPage);

            doc.Pages.Add(new PageContent() { Child = page.Page });
            return page;
        }
    }

    public class GroupSummaryConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var list = ((IEnumerable<object>)value).OfType<OutstandingSummary>();

            var t1 = new NumReport() { Text = list.Sum(x => x.Security) };
            var t2 = new NumReport() { Text = list.Sum(x => x.Rent) };
            var t3 = new NumReport() { Text = list.Sum(x => x.Due) };

            var s1 = new Separator() { Background = Brushes.LightBlue };
            var s2 = new Separator() { Background = Brushes.LightBlue };

            Grid.SetColumn(t1, 2);
            Grid.SetColumn(t2, 3);
            Grid.SetColumn(t3, 4);
            Grid.SetColumn(s1, 2);

            Grid.SetColumnSpan(s1, 3);
            Grid.SetColumnSpan(s2, 5);

            Grid.SetRow(t1, 1);
            Grid.SetRow(t2, 1);
            Grid.SetRow(t3, 1);
            Grid.SetRow(s2, 2);

            var grid = new Grid()
            {
                Margin = new Thickness(0, 0, 10, 0),
                RowDefinitions =
                {
                    new RowDefinition(){Height = GridLength.Auto},
                    new RowDefinition(){Height = new GridLength(1, GridUnitType.Star)},
                    new RowDefinition(){Height = GridLength.Auto},
                },
                ColumnDefinitions =
                {
                    new ColumnDefinition(){Width = new GridLength(1, GridUnitType.Star)},
                    new ColumnDefinition(){Width = new GridLength(200)},
                    new ColumnDefinition(){Width = new GridLength(100)},
                    new ColumnDefinition(){Width = new GridLength(100)},
                    new ColumnDefinition(){Width = new GridLength(100)}
                },
                Children = { s1, t1, t2, t3, s2 },
                Resources =
                {
                    {
                        typeof(NumReport),
                        new Style()
                        {
                            Setters =
                            {
                                new Setter()
                                {
                                    Property = TextBlock.FontWeightProperty,
                                    Value = FontWeights.Bold
                                },
                                new Setter()
                                {
                                    Property = TextBlock.MarginProperty,
                                    Value = new Thickness(10, 0, 0, 0)
                                }
                            }
                        }
                    }
                }
            };
            return grid;
        }


        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public class GroupSummaryForPrintConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var list = ((IEnumerable<object>)value).OfType<OutstandingSummary>();

            var t1 = new NumReport() { Text = list.Sum(x => x.Security) };
            var t2 = new NumReport() { Text = list.Sum(x => x.Rent) };
            var t3 = new NumReport() { Text = list.Sum(x => x.Due) };

            var s1 = new Separator();
            var s2 = new Separator();

            Grid.SetColumn(t1, 2);
            Grid.SetColumn(t2, 3);
            Grid.SetColumn(t3, 4);
            Grid.SetColumn(s1, 2);

            Grid.SetColumnSpan(s1, 3);
            Grid.SetColumnSpan(s2, 5);

            Grid.SetRow(t1, 1);
            Grid.SetRow(t2, 1);
            Grid.SetRow(t3, 1);
            Grid.SetRow(s2, 2);

            var grid = new Grid()
            {
                RowDefinitions =
                {
                    new RowDefinition(){Height = GridLength.Auto},
                    new RowDefinition(){Height = new GridLength(1, GridUnitType.Star)},
                    new RowDefinition(){Height = GridLength.Auto},
                },
                ColumnDefinitions =
                {
                    new ColumnDefinition(){Width = new GridLength(1, GridUnitType.Star)},
                    new ColumnDefinition(){Width = new GridLength(200)},
                    new ColumnDefinition(){Width = new GridLength(70)},
                    new ColumnDefinition(){Width = new GridLength(70)},
                    new ColumnDefinition(){Width = new GridLength(70)}
                },
                Children = { s1, t1, t2, t3, s2 },
                Resources =
                {
                    {
                        typeof(NumReport),
                        new Style()
                        {
                            Setters =
                            {
                                new Setter()
                                {
                                    Property = TextBlock.FontWeightProperty,
                                    Value = FontWeights.Bold
                                },
                                new Setter()
                                {
                                    Property = TextBlock.MarginProperty,
                                    Value = new Thickness(10, 0, 0, 0)
                                }
                            }
                        }
                    }
                }
            };
            return grid;
        }


        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public class GrandSummaryConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var items = value as ICollectionView;
            if (items == null) return null;
            int securitySum, rentSum, dueSum;
            securitySum = rentSum = dueSum = 0;
            if (items.Groups == null) return null;
            foreach (CollectionViewGroup group in items.Groups)
            {
                var g = group.Items.Cast<OutstandingSummary>();
                securitySum += g.Sum(x => x.Security);
                rentSum += g.Sum(x => x.Rent);
                dueSum += g.Sum(x => x.Due);
            }
            var n1 = new NumReport() { Text = securitySum };
            var n2 = new NumReport() { Text = rentSum };
            var n3 = new NumReport() { Text = dueSum };

            Grid.SetColumn(n2, 1);
            Grid.SetColumn(n3, 2);
            var grid = new Grid()
            {
                ColumnDefinitions =
                {
                    new ColumnDefinition(){Width = new GridLength(100)},
                    new ColumnDefinition(){Width = new GridLength(100)},
                    new ColumnDefinition(){Width = new GridLength(100)}
                },
                Children = { n1, n2, n3 }
            };
            return grid;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
