﻿using RentManager.Common;
using RentManager.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace RentManager.ViewModel.Ledger
{
    public class PeriodicVM : Notifiable
    {
        List<PeriodicSummary> list;
        public ReportDates Dates { get; set; }
        public PeriodicSum Sums { get; set; }
        public ICollectionView PeriodicBalance { get; set; }
        public Command Generate { get; set; }
        public PeriodicVM()
        {
            Generate = new Command(generate, (o) => true);
            Dates = new ReportDates()
            {
                Start = new DateTime(),
                From = DateTime.Today.AddMonths(-1),
                To = DateTime.Today
            };
        }

        void generate(object o)
        {
            MainVM.DoAsync(ViewType.Periodic, () =>
            {
                list = new List<PeriodicSummary>();
                Sums = new PeriodicSum();

                lock (SQLHelper.key)
                {
                    SQLHelper.connection.Open();
                    var cmd = SQLHelper.connection.CreateCommand();
                    cmd.CommandText = @$"WITH t0(Plot, Space, Tenant, Receivable, InCash, InKind) AS (
                                    	SELECT PlotId, SpaceId, TenantId, 
                                    	SUM(coalesce(CASE WHEN ControlId=1 THEN Amount END, 0)),
                                    	SUM(coalesce(CASE WHEN ControlId=2 AND IsCash=1 AND HeadId <> 4 THEN Amount END, 0)),
                                    	SUM(coalesce(CASE WHEN ControlId=2 AND IsCash=0 AND HeadId <> 4 THEN Amount END, 0))
                                    	FROM Transactions 
                                    	WHERE Date BETWEEN '{Dates.From.ToString("yyyy-MM-dd")}' AND '{Dates.To.ToString("yyyy-MM-dd")}'
                                    	GROUP BY SpaceId, TenantId
                                    ),
                                    t1(Plot, Space, Tenant, Dues) AS (
                                    	SELECT PlotId, SpaceId, TenantId,
                                    	SUM(coalesce(CASE WHEN ControlId=1 THEN Amount END, 0)) -
                                    	SUM(coalesce(CASE WHEN ControlId=2 AND HeadId <> 4 THEN Amount END, 0))
                                        FROM Transactions 
                                    	WHERE TenantId IN (SELECT Tenant FROM t0)
                                    	GROUP BY SpaceId, TenantId
                                    ),
                                    t3(Plot, Space, Tenant, Receivable, InCash, InKind, Dues) AS (
                                    	SELECT p.Name, t.Space, q.Name, t.Receivable, t.InCash, t.InKind, s.Dues FROM t0 t 
                                    	LEFT JOIN t1 s ON s.Plot = t.Plot AND s.Space = t.Space AND s.Tenant = t.Tenant
                                    	LEFT JOIN Plots p ON p.Id = t.Plot
                                    	LEFT JOIN Tenants q ON q.Id = t.Tenant
                                    ),
                                    t4(Plot, Space, Tenant, Receivable, InCash, InKind, Dues, Counts) AS (
                                        SELECT *, COUNT(Tenant) 
                                        FROM t3 
                                    	GROUP BY Tenant
                                    )
                                    SELECT t1.Plot, t1.Space, t1.Tenant, t1.Receivable, t1.InCash, t1.InKind, t1.Dues FROM t3 t1
                                    LEFT JOIN t4 t2 ON t1.Tenant = t2.Tenant
                                    ORDER BY t2.Counts DESC";
                    var reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        var summary = new PeriodicSummary()
                        {
                            Plot = reader.GetString(0),
                            SpaceId = reader.GetInt32(1),
                            Tenant = reader.GetString(2),
                            Receivable = reader.GetInt32(3),
                            ReceiptInCash = reader.GetInt32(4),
                            ReceiptInKind = reader.GetInt32(5),
                            Due = reader.GetInt32(6),
                        };
                        list.Add(summary);
                        Sums.Receivable += summary.Receivable;
                        Sums.Cash += summary.ReceiptInCash;
                        Sums.Kind += summary.ReceiptInKind;
                        Sums.Due += summary.Due;
                    }

                    cmd.Dispose();
                    SQLHelper.connection.Close();
                };
                PeriodicBalance = CollectionViewSource.GetDefaultView(list);
                PeriodicBalance.GroupDescriptions.Add(new PropertyGroupDescription(nameof(PeriodicSummary.Plot)));
                PeriodicBalance.GroupDescriptions.Add(new PropertyGroupDescription(nameof(PeriodicSummary.Tenant)));

                OnPropertyChanged(nameof(PeriodicBalance));
                OnPropertyChanged(nameof(Sums));
            });
            
        }
    }

    public class PeriodicSummaryConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            int sumReceivable, sumCash, sumKind, sumDue;
            sumReceivable = sumCash = sumKind = sumDue = 0;
            var s1 = new Separator() { Margin = new Thickness(0,0,20,0)};

            var group = value as CollectionViewGroup;
            if (group.IsBottomLevel)
            {
                var items = ((IEnumerable<object>)group.Items).OfType<PeriodicSummary>();
                sumReceivable = items.Sum(x => x.Receivable);
                sumCash = items.Sum(x => x.ReceiptInCash);
                sumKind = items.Sum(x => x.ReceiptInKind);
                sumDue = items.Sum(x => x.Due);

                Grid.SetColumn(s1, 1);
                Grid.SetColumnSpan(s1, 4);
            }
            else
            {
                foreach (CollectionViewGroup subGroup in group.Items)
                {
                    var items = ((IEnumerable<object>)subGroup.Items).OfType<PeriodicSummary>();
                    sumReceivable += items.Sum(x => x.Receivable);
                    sumCash += items.Sum(x => x.ReceiptInCash);
                    sumKind += items.Sum(x => x.ReceiptInKind);
                    sumDue += items.Sum(x => x.Due);
                }
                Grid.SetColumnSpan(s1, 5);
            }
            var n1 = new TextBlock() { Text = sumReceivable.ToString("#,##0;(#,##0);-") };
            var n2 = new TextBlock() { Text = sumCash.ToString("#,##0;(#,##0);-") };
            var n3 = new TextBlock() { Text = sumKind.ToString("#,##0;(#,##0);-") };
            var n4 = new TextBlock() { Text = sumDue.ToString("#,##0;(#,##0);-"), Margin = new Thickness(0,0,20,0) };
            
            Grid.SetColumn(n1, 1);
            Grid.SetColumn(n2, 2);
            Grid.SetColumn(n3, 3);
            Grid.SetColumn(n4, 4);
            
            var grid = new Grid()
            {
                ColumnDefinitions =
                {
                    new ColumnDefinition(){ Width = new GridLength(1, GridUnitType.Star)},
                    new ColumnDefinition(){ Width = new GridLength(80)},
                    new ColumnDefinition(){ Width = new GridLength(70)},
                    new ColumnDefinition(){ Width = new GridLength(70)},
                    new ColumnDefinition(){ Width = new GridLength(100)}
                },
                RowDefinitions =
                {
                    new RowDefinition(),
                    new RowDefinition()
                },
                Children = {s1, n1, n2, n3, n4},
                Resources =
                {
                    {
                        typeof(TextBlock),
                        new Style()
                        {
                            Setters =
                            {
                                new Setter()
                                {
                                    Property = TextBlock.FontWeightProperty,
                                    Value = FontWeights.Bold
                                },
                                new Setter()
                                {
                                    Property = TextBlock.HorizontalAlignmentProperty,
                                    Value = HorizontalAlignment.Right
                                },
                                new Setter()
                                {
                                    Property = Grid.RowProperty,
                                    Value = 1
                                }
                            }
                        }
                    }
                }
            };
            return grid;

        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
