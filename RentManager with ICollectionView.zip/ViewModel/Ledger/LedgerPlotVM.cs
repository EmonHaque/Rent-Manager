﻿using RentManager.Common;
using RentManager.Model;
using System.Linq;

namespace RentManager.ViewModel.Ledger
{
    public class LedgerPlotVM : LedgerBase
    {
        #region base implementation
        protected override ViewType type => ViewType.Plot;
        protected override string particulars => "s.Name ||' -> '|| t.Name";
        protected override string where => "PlotId";
        protected override void setTitleAndSubTitle()
        {
            var plot = MainVM.plots.First(x => x.Id == base.Id);
            base.reportTitle = plot.Name;
            base.reportSubTitle = plot.Description;
        }
        #endregion
    }
}
