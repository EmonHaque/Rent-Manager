﻿using RentManager.Common;
using RentManager.Model;
using System.ComponentModel;
using System.Linq;
using System.Windows.Data;

namespace RentManager.ViewModel.Ledger
{
    public class LedgerTenantVM : LedgerBase
    {
        bool filterState;
        public bool FilterState
        {
            get { return filterState; }
            set { filterState = value; Tenants.Refresh(); }
        }
        public ICollectionView Tenants { get; set; }

        public LedgerTenantVM()
        {
            Tenants = new CollectionViewSource() { Source = MainVM.tenants, IsLiveFilteringRequested = true, LiveFilteringProperties = { "HasLeft" } }.View;
            Tenants.Filter = filterTenants;
        }
        bool filterTenants(object o) => FilterState ? !(o as Tenant).HasLeft : (o as Tenant).HasLeft;

        #region base implementation
        protected override ViewType type => ViewType.Tenant;
        protected override string particulars => "p.Name ||' -> '|| s.Name ";
        protected override string where => "TenantId";
        protected override void setTitleAndSubTitle()
        {
            var tenant = MainVM.tenants.First(x => x.Id == base.Id);
            base.reportTitle = tenant.Name;
            base.reportSubTitle = tenant.Address;
        }
        #endregion
    }
}
