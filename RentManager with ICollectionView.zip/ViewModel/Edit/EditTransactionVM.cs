﻿using RentManager.Common;
using RentManager.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Data;

namespace RentManager.ViewModel.Edit
{
    public class EditTransactionVM : EditBase<Transaction>
    {
        ControlHead selectedControl;
        Tenant selectedTenant;
        int? selectedPlot;
        Bag<Transaction> transactions;

        DateTime transactionDate;
        public DateTime TransactionDate
        {
            get { return transactionDate; }
            set { if (transactionDate != value) { transactionDate = value; refreshTransactions(); } }
        }
        public ICollectionView Plots { get; set; }
        public ICollectionView Spaces { get; set; }
        public ICollectionView Transactions { get; set; }
        public ICollectionView Tenants { get; set; }
        public ICollectionView Heads { get; set; }
        public Command Delete { get; set; }

        public EditTransactionVM()
        {
            initializeCollections();
            subscribe();
            Delete = new Command(delete, (o) => selected != null);
        }

        #region for Constructor
        void initializeCollections()
        {
            Heads = new CollectionViewSource() { Source = MainVM.heads }.View;
            Tenants = new CollectionViewSource() { Source = MainVM.tenants }.View;
            Transactions = CollectionViewSource.GetDefaultView(new List<Transaction>());
            Plots = CollectionViewSource.GetDefaultView(new List<int?>());
            Heads.Filter = filterHeads;
            TransactionDate = DateTime.Today;
        }

        void subscribe()
        {
            MainVM.ControlHeads.CurrentChanged += onControlHeadChanged;
            Tenants.CurrentChanged += onTenantChanged;
            Transactions.CurrentChanged += onTransactionChanged;
            Plots.CurrentChanged += onPlotChanged;
        }
        #endregion

        #region eventHandlers
        void onTenantChanged(object sender, EventArgs e)
        {
            selectedTenant = Tenants.CurrentItem as Tenant;
            resetPlotsAndSpaces();
        }

        void onControlHeadChanged(object sender, EventArgs e)
        {
            selectedControl = MainVM.ControlHeads.CurrentItem as ControlHead;
            if (isInEditView && isFocused)
            {
                if (!IsOnEdit) return;
                Heads.Refresh();
            }
        }

        void onTransactionChanged(object sender, EventArgs e)
        {
            selected = Transactions.CurrentItem as Transaction;
            base.resetIsOnEdit();
        }

        void onPlotChanged(object o, EventArgs e)
        {
            if (selectedPlot != Plots.CurrentItem as int?)
            {
                selectedPlot = Plots.CurrentItem as int?;
                Spaces.Refresh();
            }
        }
        #endregion

        void delete(object o)
        {
            var message = MainVM.controlHeads.First(x => x.Id == selected.ControlId).Name + " : " +
                          MainVM.heads.First(x => x.Id == selected.HeadId).Name + " amounting " + selected.Amount.ToString("N0") +
                          "\r\nfrom " + MainVM.tenants.First(x => x.Id == selected.TenantId).Name +
                          "\r\non" + selected.Date.ToString("dd MMMM, yyyy") + " has been deleted";
            lock (SQLHelper.key)
            {
                using var cmd = SQLHelper.connection.CreateCommand();
                cmd.CommandText = @$"DELETE FROM Transactions WHERE Id = {selected.Id}";
                SQLHelper.NonQuery(cmd);
            }
            transactions.Remove(selected);
            MainVM.PopupMessage = message;
            MainVM.Popup();
        }

        #region filters
        bool filterSpaces(object o) => selectedPlot == null ? false : (o as Lease).PlotId == selectedPlot;
        bool filterHeads(object o) => selectedControl == null ? false : (o as Head).ControlId == selectedControl.Id;
        bool filterTransactions(object o) => (o as Transaction).Date == TransactionDate;
        #endregion

        #region overrides
        protected override void refresh()
        {
            if (Transactions.IsEmpty)
                getTransactions();
        }
        protected override void setOnEdit(object o)
        {
            base.setOnEdit(o);
            Tenants.MoveCurrentTo(MainVM.tenants.First(x => x.Id == selected.TenantId));
            MainVM.ControlHeads.MoveCurrentTo(MainVM.controlHeads.First(x => x.Id == selected.ControlId));
            selectedTenant = Tenants.CurrentItem as Tenant;
            selectedControl = MainVM.ControlHeads.CurrentItem as ControlHead;

            resetPlotsAndSpaces();
            Spaces.Filter = filterSpaces;
            Heads.Refresh();

            Heads.MoveCurrentTo(MainVM.heads.First(x => x.Id == selected.HeadId));
            Plots.MoveCurrentTo(selected.PlotId);
            Spaces.MoveCurrentTo(Spaces.SourceCollection.Cast<Lease>().First(x => x.SpaceId == selected.SpaceId));
        }
        #endregion

        #region base implementation
        protected override ViewType type => ViewType.Transaction;
        protected override void save()
        {
            var narration = Edited.Narration == null ? (object)DBNull.Value : Edited.Narration;
            lock (SQLHelper.key)
            {
                using var cmd = SQLHelper.connection.CreateCommand();
                cmd.CommandText = @$"UPDATE Transactions SET Date = '{Edited.Date.ToString("yyyy-MM-dd")}', PlotId = {Edited.PlotId}, SpaceId ={Edited.SpaceId},
                                     TenantId ={Edited.TenantId}, ControlId = {Edited.ControlId}, HeadId = {Edited.HeadId}, IsCash = {Edited.IsCash}, 
                                        Narration = @Narration, Amount = {Edited.Amount} WHERE Id = {Edited.Id}";
                cmd.Parameters.AddWithValue("@Narration", narration);
                SQLHelper.NonQuery(cmd);
            }
        }
        #endregion

        void getTransactions()
        {
            if (!isInEditView) return;
            if (!isFocused) return;

            transactions = new Bag<Transaction>();
            lock (SQLHelper.key)
            {
                using var cmd = SQLHelper.connection.CreateCommand();
                cmd.CommandText = $"SELECT * FROM Transactions WHERE Date = '{TransactionDate.ToString("yyyy-MM-dd")}'";
                SQLHelper.connection.Open();
                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    transactions.Add(new Transaction()
                    {
                        Id = reader.GetInt32(0),
                        Date = reader.GetDateTime(1),
                        PlotId = reader.GetInt32(2),
                        SpaceId = reader.GetInt32(3),
                        TenantId = reader.GetInt32(4),
                        ControlId = reader.GetInt32(5),
                        HeadId = reader.GetInt32(6),
                        Amount = reader.GetInt32(7),
                        IsCash = reader.GetBoolean(8),
                        Narration = reader.IsDBNull(9) ? null : reader.GetString(9)
                    });
                }
                SQLHelper.connection.Close();
            }
            Transactions.CurrentChanged -= onTransactionChanged;
            Transactions = new CollectionViewSource()
            {
                Source = transactions,
                IsLiveFilteringRequested = true,
                IsLiveGroupingRequested = true,
                LiveFilteringProperties = { nameof(Transaction.Date) },
                LiveGroupingProperties = { nameof(Transaction.PlotId) }
            }.View;
            Transactions.CurrentChanged += onTransactionChanged;
            Transactions.GroupDescriptions.Add(new PropertyGroupDescription(nameof(Transaction.PlotId)));
            Transactions.Filter = filterTransactions;
            OnPropertyChanged(nameof(Transactions));
        }

        void resetPlotsAndSpaces()
        {
            if (selectedTenant == null) return;
            var leases = MainVM.leases.Where(x => x.TenantId == selectedTenant.Id);
            if (leases.Count() > 0)
            {
                leases = leases.ToList();
                Spaces = CollectionViewSource.GetDefaultView(leases);
                OnPropertyChanged(nameof(Spaces));

                Plots.CurrentChanged -= onPlotChanged;
                Plots = CollectionViewSource.GetDefaultView(leases.Select(x => x.PlotId).Distinct().ToList());
                Plots.CurrentChanged += onPlotChanged;
                OnPropertyChanged(nameof(Plots));
            }
        }

        void refreshTransactions()
        {
            if (isInEditView && isFocused)
                getTransactions();
        }
    }
}
