﻿using Microsoft.Data.Sqlite;
using RentManager.Common;
using RentManager.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Data;

namespace RentManager.ViewModel.Edit
{
    public class EditTenantVM : EditBase<Tenant>
    {
        string filterName;
        public string FilterName
        {
            get { return filterName; }
            set { filterName = value; Tenants.Refresh(); }
        }
        bool? filterState;
        public bool? FilterState
        {
            get { return filterState; }
            set { filterState = value; Tenants.Refresh(); }
        }

        public ICollectionView Tenants { get; set; }
        public ICollectionView Leases { get; set; }

        public EditTenantVM()
        {
            initializeCollections();
            Tenants.CurrentChanged += onTenantChanged;
        }

        void initializeCollections()
        {
            Tenants = new CollectionViewSource() 
            { 
                Source = MainVM.tenants, 
                IsLiveFilteringRequested = true, 
                LiveFilteringProperties = { "HasLeft" },
                IsLiveSortingRequested = true,
                LiveSortingProperties = { "Name" }
            }.View;
            Leases = new CollectionViewSource() { Source = MainVM.leases }.View;
            Tenants.SortDescriptions.Add(new SortDescription("Name", ListSortDirection.Ascending));
            Tenants.Filter = filterTenants;
            Leases.Filter = filterLeases;
        }

        void onTenantChanged(object sender, EventArgs e)
        {
            selected = Tenants.CurrentItem as Tenant;
            if(isInEditView && isFocused)
            {
                base.resetIsOnEdit();
                Leases.Refresh();
            }           
        }        

        #region filters
        bool filterTenants(object o)
        {
            if (MainVM.tenants.Count > 0)
            {
                var tenant = (o as Tenant);
                switch (FilterState)
                {
                    case true:
                        return string.IsNullOrWhiteSpace(FilterName) ? true && !tenant.HasLeft : tenant.Name.ToLower().Contains(FilterName.ToLower()) && !tenant.HasLeft;
                    case false:
                        return string.IsNullOrWhiteSpace(FilterName) ? true && tenant.HasLeft : tenant.Name.ToLower().Contains(FilterName.ToLower()) && tenant.HasLeft;
                    default:
                        return string.IsNullOrWhiteSpace(FilterName) ? true : tenant.Name.ToLower().Contains(FilterName.ToLower());
                }
            }
            return false;
        }

        bool filterLeases(object o)
        {
            if (selected == null) return false;
            return (o as Lease).TenantId == selected.Id;
        }
        #endregion

        #region overrides
        protected override void refresh() => Leases.Refresh();
        #endregion

        #region base implementation
        protected override ViewType type => ViewType.Tenant;     
        protected override bool isCloneNotOriginal => !Edited.IsEqualTo(selected);
        protected override void clone()
        {
            Edited = new Tenant(selected);
            OnPropertyChanged(nameof(Edited));
        }
        protected override bool isCloneValid(object o) => Edited.IsValid();   
        protected override void save()
        {
            var spaces = new Dictionary<string, string>();
            var tenantName = string.Empty;

            var commands = new List<SqliteCommand>();
            if (Edited.HasLeft && !selected.HasLeft)
            {
                var leases = MainVM.leases.Where(x => !x.IsExpired && x.TenantId == Edited.Id).ToList();
                if (leases.Count > 0)
                {
                    tenantName = Edited.Name;
                    foreach (var lease in leases)
                    {
                        var space = MainVM.spaces.FirstOrDefault(x => x.Id == lease.SpaceId);
                        spaces.Add(space.Name, MainVM.plots.First(x => x.Id == space.PlotId).Name);

                        commands.Add(new SqliteCommand($"UPDATE Leases SET DateEnd = '{DateTime.Now.ToString("yyyy-MM-dd")}', IsExpired = 1 WHERE Id = {lease.Id}"));
                        commands.Add(new SqliteCommand($"UPDATE Spaces SET IsVacant = 1 WHERE Id = {space.Id}"));

                        space.IsVacant = true;
                        lease.IsExpired = true;
                        lease.DateEnd = DateTime.Now;
                    }
                }
            }

            var cmd = new SqliteCommand(@"UPDATE Tenants SET Name = @Name, Father = @Father, Mother = @Mother, Husband = @Husband,
                                            Address = @Address, NID = @NID, ContactNo = @ContactNo, HasLeft = @HasLeft WHERE Id = @Id");

            cmd.Parameters.AddWithValue("@Name", Edited.Name);
            cmd.Parameters.AddWithValue("@Father", Edited.Father);
            cmd.Parameters.AddWithValue("@Mother", string.IsNullOrWhiteSpace(Edited.Mother) ? (object)DBNull.Value : Edited.Mother);
            cmd.Parameters.AddWithValue("@Husband", string.IsNullOrWhiteSpace(Edited.Husband) ? (object)DBNull.Value : Edited.Husband);
            cmd.Parameters.AddWithValue("@Address", Edited.Address);
            cmd.Parameters.AddWithValue("@NID", string.IsNullOrWhiteSpace(Edited.NID) ? (object)DBNull.Value : Edited.NID);
            cmd.Parameters.AddWithValue("@ContactNo", Edited.ContactNo);
            cmd.Parameters.AddWithValue("@HasLeft", Edited.HasLeft);
            cmd.Parameters.AddWithValue("@Id", Edited.Id);
            commands.Add(cmd);

            lock (SQLHelper.key)
            {
                SQLHelper.Transaction(commands);
            }
            foreach (var command in commands) command.Dispose();
            base.notifyLeaseForNameChange(selected.Name, Edited.Name, selected);

            if (!string.IsNullOrEmpty(tenantName) && spaces.Count > 0)
            {
                MainVM.PopupMessage = "Space(s) occupied:";
                foreach (var item in spaces)
                    MainVM.PopupMessage += $"\r\n\t{item.Key} of {item.Value}";

                MainVM.PopupMessage += $"\r\n\r\nby {tenantName} now available to let out";
                MainVM.Popup();
            }
        }     
        protected override void update()
        {
            selected.Name = Edited.Name;
            selected.Father = Edited.Father;
            selected.Mother = Edited.Mother;
            selected.Husband = Edited.Husband;
            selected.Address = Edited.Address;
            selected.NID = Edited.NID;
            selected.ContactNo = Edited.ContactNo;
            selected.HasLeft = Edited.HasLeft;
            selected.OnPropertyChanged(string.Empty);
        }
        #endregion
    }
}
