﻿using RentManager.Common;
using RentManager.Model;
using System;
using System.ComponentModel;
using System.Windows.Data;

namespace RentManager.ViewModel.Edit
{
    public class EditHeadVM : EditBase<Head>
    {
        int? selectedControl;
        public int? SelectedControl
        {
            get { return selectedControl; }
            set { selectedControl = value; if (isFocused) reset(); }
        }

        public EditHeadVM()
        {
            Editables = new CollectionViewSource() { Source = MainVM.heads }.View;
            Editables.Filter = filterHeads;
        }  

        bool filterHeads(object o) => SelectedControl == null ? false : (o as Head).ControlId == SelectedControl;
        void reset()
        {
            if(IsOnEdit) base.resetIsOnEdit();
            Editables.Refresh();
        }
        protected override void refresh() => Editables.Refresh();

        #region base implementation
        protected override ViewType type => ViewType.Head;


        protected override void save()
        {
            lock (SQLHelper.key)
            {
                using var cmd = SQLHelper.connection.CreateCommand();
                cmd.CommandText = "UPDATE Heads SET Name = @Name, Description = @Description WHERE Id = @Id";
                cmd.Parameters.AddWithValue("@Name", Edited.Name);
                cmd.Parameters.AddWithValue("@Description", Edited.Description);
                cmd.Parameters.AddWithValue("@Id", Edited.Id);
                SQLHelper.NonQuery(cmd);
            }
        }
        #endregion
    }
}
