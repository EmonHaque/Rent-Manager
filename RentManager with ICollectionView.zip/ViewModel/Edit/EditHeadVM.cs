﻿using RentManager.Common;
using RentManager.Model;
using System;
using System.ComponentModel;
using System.Windows.Data;

namespace RentManager.ViewModel.Edit
{
    public class EditHeadVM : EditBase
    {
        ControlHead selectedControlHead;
        Head selectedHead;
        public Head EditedHead { get; set; }
        public ICollectionView Heads { get; set; }

        public EditHeadVM()
        {
            selectedControlHead = MainVM.ControlHeads.CurrentItem as ControlHead;
            EditedHead = new Head();
            Heads = new CollectionViewSource() { Source = MainVM.heads }.View;
            subscribe();
            Heads.Filter = filter;     
        }

        void subscribe()
        {
            MainVM.ControlHeads.CurrentChanged += onControlHeadChanged;
            Heads.CurrentChanged += onHeadChanged;
        }

        bool filter(object o) => selectedControlHead == null ? false : (o as Head).ControlId == selectedControlHead.Id;

        #region eventHandlers
        void onControlHeadChanged(object s, EventArgs e)
        {
            selectedControlHead = MainVM.ControlHeads.CurrentItem as ControlHead;
            if(isInEditView && isFocused)
            {
                base.resetIsOnEdit();
                Heads.Refresh();
            }         
        }

        void onHeadChanged(object sender, EventArgs e) => selectedHead = Heads.CurrentItem as Head;
        #endregion       

        #region overrides
        protected override void refresh() => Heads.Refresh();
        #endregion

        #region base implementation
        protected override ViewType type => ViewType.Head;
        protected override bool isCloneNotOriginal => !EditedHead.IsEqualTo(selectedHead);
        protected override bool canEdit(object o) => selectedHead != null;
        protected override void clone()
        {
            EditedHead = new Head(selectedHead);
            OnPropertyChanged(nameof(EditedHead));
        }
        protected override bool isCloneValid(object o) => EditedHead.IsValid();
        protected override void update()
        {
            selectedHead.Name = EditedHead.Name;
            selectedHead.Description = EditedHead.Description;
            selectedHead.OnPropertyChanged(string.Empty);
        }
        protected override void save()
        {
            lock (SQLHelper.key)
            {
                using var cmd = SQLHelper.connection.CreateCommand();
                cmd.CommandText = "UPDATE Heads SET Name = @Name, Description = @Description WHERE Id = @Id";
                cmd.Parameters.AddWithValue("@Name", EditedHead.Name);
                cmd.Parameters.AddWithValue("@Description", EditedHead.Description);
                cmd.Parameters.AddWithValue("@Id", EditedHead.Id);
                SQLHelper.NonQuery(cmd);
            }
        }
        #endregion
    }
}
