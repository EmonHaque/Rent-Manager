﻿using RentManager.Common;
using RentManager.Model;
using System;
using System.ComponentModel;
using System.Windows.Data;

namespace RentManager.ViewModel.Edit
{
    public class EditHeadVM : EditBase<Head>
    {
        ControlHead selectedControlHead;
        public ICollectionView Heads { get; set; }

        public EditHeadVM()
        {
            selectedControlHead = MainVM.ControlHeads.CurrentItem as ControlHead;
            Heads = new CollectionViewSource() { Source = MainVM.heads }.View;
            MainVM.ControlHeads.CurrentChanged += onControlHeadChanged;
            //Heads.CurrentChanged += onHeadChanged;
            Heads.Filter = filterHeads;
        }

        void onHeadChanged(object sender, EventArgs e)
        {
            selected = Heads.CurrentItem as Head;
            if(IsOnEdit)
                base.resetIsOnEdit();
        }

        void onControlHeadChanged(object s, EventArgs e)
        {
            selectedControlHead = MainVM.ControlHeads.CurrentItem as ControlHead;
            if(isInEditView && isFocused)
            {
                base.resetIsOnEdit();
                Heads.Refresh();
            }         
        }   

        bool filterHeads(object o) => selectedControlHead == null ? false : (o as Head).ControlId == selectedControlHead.Id;
        protected override void refresh() => Heads.Refresh();

        #region base implementation
        protected override ViewType type => ViewType.Head;
        protected override void save()
        {
            lock (SQLHelper.key)
            {
                using var cmd = SQLHelper.connection.CreateCommand();
                cmd.CommandText = "UPDATE Heads SET Name = @Name, Description = @Description WHERE Id = @Id";
                cmd.Parameters.AddWithValue("@Name", Edited.Name);
                cmd.Parameters.AddWithValue("@Description", Edited.Description);
                cmd.Parameters.AddWithValue("@Id", Edited.Id);
                SQLHelper.NonQuery(cmd);
            }
        }
        #endregion
    }
}
