﻿using Microsoft.Data.Sqlite;
using RentManager.Common;
using RentManager.Model;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows.Data;

namespace RentManager.ViewModel.Edit
{
    public class EditLeaseVM : EditBase<Lease>
    {
        Plot selectedPlot;
        Head selectedHead;
        bool? filterState;
        public bool? FilterState
        {
            get { return filterState; }
            set { filterState = value; Leases.Refresh(); }
        }
        public Receivable NewReceivable { get; set; }
        public ICollectionView Leases { get; set; }
        public ICollectionView ReceivableHeads { get; set; }
        public Command AddReceivable { get; set; }
        public Command RemoveReceivable { get; set; }

        public EditLeaseVM()
        {
            selectedPlot = MainVM.Plots.CurrentItem as Plot;
            NewReceivable = new Receivable();
            initializeCollections();
            subscribe();
            initializeFilters();
            initializeCommands();
        }

        #region for Constructor
        void initializeCollections()
        {
            Leases = new CollectionViewSource() 
            { 
                Source = MainVM.leases, 
                IsLiveFilteringRequested = true, 
                LiveFilteringProperties = { nameof(Lease.IsExpired) } 
            }.View;
            ReceivableHeads = new CollectionViewSource() { Source = MainVM.heads }.View;
        }

        void subscribe()
        {
            MainVM.Plots.CurrentChanged += onPlotChanged;
            Leases.CurrentChanged += onLeaseChanged;
            ReceivableHeads.CurrentChanged += onHeadChanged;
        }

        void initializeCommands()
        {
            AddReceivable = new Command(addReceivable, (o) => NewReceivable.IsValid());
            RemoveReceivable = new Command(removeReceivable, (o) => true);
        }

        void initializeFilters()
        {
            Leases.Filter = filterLeases;
            ReceivableHeads.Filter = filterReceivableHeads;
        }
        #endregion

        #region ICommands
        void addReceivable(object o)
        {
            Edited.FixedReceivables.Add(NewReceivable);
            Edited.FixedReceivables.OnCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Add, NewReceivable));
            NewReceivable = new Receivable()
            {
                LeaseId = selected.Id,
                HeadId = selectedHead.Id
            };
            OnPropertyChanged(nameof(NewReceivable));
            ReceivableHeads.Refresh();
        }

        void removeReceivable(object o)
        {
            var receivable = o as Receivable;
            var index = Edited.FixedReceivables.IndexOf(receivable);
            Edited.FixedReceivables.Remove(receivable);
            Edited.FixedReceivables.OnCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Remove, receivable, index));
            ReceivableHeads.Refresh();
            if (ReceivableHeads.CurrentItem == null)
                ReceivableHeads.MoveCurrentToFirst();
        }
        #endregion

        #region eventHandler
        void onPlotChanged(object o, EventArgs e)
        {
            selectedPlot = MainVM.Plots.CurrentItem as Plot;
            if (isInEditView && isFocused)
                Leases.Refresh();
        }

        void onLeaseChanged(object sender, EventArgs e)
        {
            base.resetIsOnEdit();
            selected = Leases.CurrentItem as Lease;
        }

        void onHeadChanged(object sender, EventArgs e) => selectedHead = ReceivableHeads.CurrentItem as Head;
        #endregion

        #region filters
        bool filterLeases(object o)
        {
            if (selectedPlot == null) return false;
            if (MainVM.leases.Count > 0)
            {
                var lease = (o as Lease);
                switch (FilterState)
                {
                    case true:
                        return lease.PlotId == selectedPlot.Id && !lease.IsExpired;
                    case false:
                        return lease.PlotId == selectedPlot.Id && lease.IsExpired;
                    default:
                        return lease.PlotId == selectedPlot.Id;
                }
            }
            return false;
        }

        bool filterReceivableHeads(object o)
        {
            var head = o as Head;
            return head.ControlId == MainVM.controlIdOfReceivable
                && Edited.FixedReceivables.FirstOrDefault(x => x.HeadId == head.Id) == null;
        }
        #endregion

        #region overrides
        protected override void refresh() => Leases.Refresh();
        protected override void setOnEdit(object o)
        {
            base.setOnEdit(o);
            NewReceivable.LeaseId = Edited.Id;
            ReceivableHeads.Refresh();
        }
        #endregion

        #region base implementation
        protected override ViewType type => ViewType.Lease;
        protected override void save()
        {
            var spaceName = string.Empty;
            object dateExpired = DBNull.Value;
            var commands = new List<SqliteCommand>();

            if (Edited.IsExpired && !selected.IsExpired)
            {
                commands.Add(new SqliteCommand($"UPDATE Spaces SET IsVacant = 1 WHERE Id = {Edited.SpaceId}"));
                var space = MainVM.spaces.FirstOrDefault(x => x.Id == Edited.SpaceId);
                space.IsVacant = true;
                spaceName = space.Name;
                dateExpired = DateTime.Now.ToString("yyyy-MM-dd");
            }
            else
            {
                commands.Add(new SqliteCommand($"DELETE FROM Receivables WHERE LeaseId = {Edited.Id}"));
                foreach (var item in Edited.FixedReceivables)
                    commands.Add(new SqliteCommand($"INSERT INTO Receivables VALUES({item.LeaseId}, {item.HeadId}, {item.Amount})"));
            }

            var cmd = new SqliteCommand("UPDATE Leases SET DateStart = @DateStart, DateEnd = @DateEnd, Business = @Business, IsExpired = @IsExpired WHERE Id = @Id");
            cmd.Parameters.AddWithValue("@DateStart", Edited.DateStart.ToString("yyyy-MM-dd"));
            cmd.Parameters.AddWithValue("@DateEnd", dateExpired);
            cmd.Parameters.AddWithValue("@Business", Edited.Business);
            cmd.Parameters.AddWithValue("@IsExpired", Edited.IsExpired);
            cmd.Parameters.AddWithValue("@Id", Edited.Id);
            commands.Add(cmd);
            lock (SQLHelper.key)
            {
                SQLHelper.Transaction(commands);
            }
            foreach (var command in commands) command.Dispose();

            if (!string.IsNullOrEmpty(spaceName))
            {
                MainVM.PopupMessage = $"{spaceName} is available to let out";
                MainVM.Popup();
            }
        }
        #endregion
    }
}