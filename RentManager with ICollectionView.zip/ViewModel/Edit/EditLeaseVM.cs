﻿using Microsoft.Data.Sqlite;
using RentManager.Common;
using RentManager.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows.Data;

namespace RentManager.ViewModel.Edit
{
    public class EditLeaseVM : EditBase
    {
        Plot selectedPlot;
        Lease selectedLease;
        Head selectedHead;
        bool? filterState;
        public bool? FilterState
        {
            get { return filterState; }
            set { filterState = value; Leases.Refresh(); }
        }
        public Lease EditedLease { get; set; }
        public Receivable NewReceivable { get; set; }
        public ICollectionView Leases { get; set; }
        public ICollectionView ReceivableHeads { get; set; }
        public Command AddReceivable { get; set; }
        public Command RemoveReceivable { get; set; }

        public EditLeaseVM()
        {
            selectedPlot = MainVM.Plots.CurrentItem as Plot;
            initializeProperties();
            initializeCollections();
            subscribe();
            initializeFilters();
            initializeCommands();
        }

        #region for Constructor
        void initializeProperties()
        {
            EditedLease = new Lease();
            NewReceivable = new Receivable();
        }

        void initializeCollections()
        {
            Leases = new CollectionViewSource() 
            { 
                Source = MainVM.leases, 
                IsLiveFilteringRequested = true, 
                LiveFilteringProperties = { nameof(Lease.IsExpired) } 
            }.View;
            ReceivableHeads = new CollectionViewSource() { Source = MainVM.heads }.View;
        }

        void subscribe()
        {
            MainVM.Plots.CurrentChanged += onPlotChanged;
            Leases.CurrentChanged += onLeaseChanged;
            ReceivableHeads.CurrentChanged += onHeadChanged;
        }

        void initializeCommands()
        {
            AddReceivable = new Command(addReceivable, (o) => NewReceivable.IsValid());
            RemoveReceivable = new Command(removeReceivable, (o) => true);
        }

        void initializeFilters()
        {
            Leases.Filter = filterLeases;
            ReceivableHeads.Filter = filterReceivableHeads;
        }
        #endregion

        #region ICommands
        void addReceivable(object o)
        {
            EditedLease.FixedReceivables.Add(NewReceivable);
            NewReceivable = new Receivable()
            {
                LeaseId = selectedLease.Id,
                HeadId = selectedHead.Id
            };
            OnPropertyChanged(nameof(NewReceivable));
            ReceivableHeads.Refresh();
        }

        void removeReceivable(object o)
        {
            EditedLease.FixedReceivables.Remove(o as Receivable);
            ReceivableHeads.Refresh();
            if (ReceivableHeads.CurrentItem == null)
                ReceivableHeads.MoveCurrentToFirst();
        }
        #endregion

        #region eventHandler
        void onPlotChanged(object o, EventArgs e)
        {
            selectedPlot = MainVM.Plots.CurrentItem as Plot;
            if (isInEditView && isFocused)
                Leases.Refresh();
        }

        void onLeaseChanged(object sender, EventArgs e)
        {
            base.resetIsOnEdit();
            selectedLease = Leases.CurrentItem as Lease;
        }

        void onHeadChanged(object sender, EventArgs e) => selectedHead = ReceivableHeads.CurrentItem as Head;
        #endregion

        #region filters
        bool filterLeases(object o)
        {
            if (selectedPlot == null) return false;
            if (MainVM.leases.Count > 0)
            {
                var lease = (o as Lease);
                switch (FilterState)
                {
                    case true:
                        return lease.PlotId == selectedPlot.Id && !lease.IsExpired;
                    case false:
                        return lease.PlotId == selectedPlot.Id && lease.IsExpired;
                    default:
                        return lease.PlotId == selectedPlot.Id;
                }
            }
            return false;
        }

        bool filterReceivableHeads(object o)
        {
            var head = o as Head;
            return head.ControlId == MainVM.controlIdOfReceivable
                && EditedLease.FixedReceivables.FirstOrDefault(x => x.HeadId == head.Id) == null;
        }
        #endregion

        #region overrides
        protected override void refresh() => Leases.Refresh();
        protected override void setOnEdit(object o)
        {
            base.setOnEdit(o);
            NewReceivable.LeaseId = EditedLease.Id;
            ReceivableHeads.Refresh();
        }
        #endregion

        #region base implementation
        protected override ViewType type => ViewType.Lease;
        protected override bool isCloneNotOriginal => !EditedLease.IsEqualTo(selectedLease);
        protected override bool canEdit(object o) => selectedLease != null;
        protected override void clone()
        {
            EditedLease = new Lease(selectedLease);
            OnPropertyChanged(nameof(EditedLease));
        }
        protected override bool isCloneValid(object o) => EditedLease.IsValid();
        protected override void save()
        {
            var spaceName = string.Empty;
            object dateExpired = DBNull.Value;
            var commands = new List<SqliteCommand>();

            if (EditedLease.IsExpired && !selectedLease.IsExpired)
            {
                commands.Add(new SqliteCommand($"UPDATE Spaces SET IsVacant = 1 WHERE Id = {EditedLease.SpaceId}"));
                var space = MainVM.spaces.FirstOrDefault(x => x.Id == EditedLease.SpaceId);
                space.IsVacant = true;
                spaceName = space.Name;
                dateExpired = DateTime.Now.ToString("yyyy-MM-dd");
            }
            else
            {
                commands.Add(new SqliteCommand($"DELETE FROM Receivables WHERE LeaseId = {EditedLease.Id}"));
                foreach (var item in EditedLease.FixedReceivables)
                    commands.Add(new SqliteCommand($"INSERT INTO Receivables VALUES({item.LeaseId}, {item.HeadId}, {item.Amount})"));
            }

            var cmd = new SqliteCommand("UPDATE Leases SET DateStart = @DateStart, DateEnd = @DateEnd, Business = @Business, IsExpired = @IsExpired WHERE Id = @Id");
            cmd.Parameters.AddWithValue("@DateStart", EditedLease.DateStart.ToString("yyyy-MM-dd"));
            cmd.Parameters.AddWithValue("@DateEnd", dateExpired);
            cmd.Parameters.AddWithValue("@Business", EditedLease.Business);
            cmd.Parameters.AddWithValue("@IsExpired", EditedLease.IsExpired);
            cmd.Parameters.AddWithValue("@Id", EditedLease.Id);
            commands.Add(cmd);
            lock (SQLHelper.key)
            {
                SQLHelper.Transaction(commands);
            }
            foreach (var command in commands) command.Dispose();

            if (!string.IsNullOrEmpty(spaceName))
            {
                MainVM.PopupMessage = $"{spaceName} is available to let out";
                MainVM.Popup();
            }
        }
        protected override void update()
        {
            selectedLease.PlotId = EditedLease.PlotId;
            selectedLease.SpaceId = EditedLease.SpaceId;
            selectedLease.TenantId = EditedLease.TenantId;
            selectedLease.DateStart = EditedLease.DateStart;
            selectedLease.DateEnd = EditedLease.DateEnd;
            selectedLease.Business = EditedLease.Business;
            selectedLease.IsExpired = EditedLease.IsExpired;
            selectedLease.FixedReceivables = EditedLease.FixedReceivables;
            selectedLease.OnPropertyChanged(string.Empty);
        }
        #endregion
    }
}