﻿using RentManager.Common;
using RentManager.Model;
using System.Diagnostics;

namespace RentManager.ViewModel.Edit
{
    public class EditPlotVM : EditBase
    {
        Plot selected;
        public Plot Edited { get; set; }

        public EditPlotVM()
        {
            Edited = new Plot();
            selected = MainVM.Plots.CurrentItem as Plot;
            MainVM.Plots.CurrentChanged += onPlotChanged;
        }

        void onPlotChanged(object sender, System.EventArgs e)
        {
            selected = MainVM.Plots.CurrentItem as Plot;
            if(isInEditView && isFocused)
                base.resetIsOnEdit();
        }

        #region base implementation
        protected override ViewType type => ViewType.Plot;
        protected override bool isCloneNotOriginal => !Edited.IsEqualTo(selected);
        protected override bool canEdit(object o) => selected != null;
        protected override void clone()
        {
            Edited = new Plot(selected);
            OnPropertyChanged(nameof(Edited));
        }
        protected override bool isCloneValid(object o) => Edited.IsValid();
        protected override void update()
        {
            selected.Name = Edited.Name;
            selected.Description = Edited.Description;
            selected.OnPropertyChanged(string.Empty);
        }
        protected override void save()
        {
            lock (SQLHelper.key)
            {
                using var cmd = SQLHelper.connection.CreateCommand();
                cmd.CommandText = "UPDATE Plots SET Name = @Name, Description = @Description WHERE Id = @Id";
                cmd.Parameters.AddWithValue("@Name", Edited.Name);
                cmd.Parameters.AddWithValue("@Description", Edited.Description);
                cmd.Parameters.AddWithValue("@Id", Edited.Id);
                SQLHelper.NonQuery(cmd);
            }
            base.notifyLeaseForNameChange(selected.Name, Edited.Name, selected);
        }
        #endregion
    }
}
