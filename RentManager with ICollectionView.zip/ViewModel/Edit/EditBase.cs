﻿using RentManager.Common;
using RentManager.Model;

namespace RentManager.ViewModel.Edit
{
    public abstract class EditBase : Notifiable
    {
        public bool IsOnEdit { get; set; }
        public Command SetIsOnEdit { get; set; }
        public Command ResetIsOnEdit { get; set; }
        public Command Save { get; set; }

        public EditBase()
        {
            SetIsOnEdit = new Command(setOnEdit, canEdit);
            ResetIsOnEdit = new Command(resetOnEdit, (o) => true);
            Save = new Command(saveAndUpdate, isCloneValid);
            MainVM.OnSelectedMenuChanged += refreshCollectionView;
            EditVM.OnSelectedTabChanged += refreshCollectionView;
        }
       
        protected abstract ViewType type { get; }
        protected abstract bool canEdit(object o);
        protected abstract void clone();
        protected abstract bool isCloneValid(object o);
        protected abstract bool isCloneNotOriginal { get; }
        protected abstract void save();
        protected abstract void update();

        protected virtual void refresh() { }      
        protected virtual void setOnEdit(object o)
        {
            clone();
            IsOnEdit = true;
            OnPropertyChanged(nameof(IsOnEdit));
        }

        protected bool isInEditView => MainVM.SelectedMenu.Name == Constants.Edit;
        protected bool isFocused => EditVM.SelectedTab.Type == type;
        protected void resetIsOnEdit()
        {
            IsOnEdit = false;
            OnPropertyChanged(nameof(IsOnEdit));
        }

        protected void notifyLeaseForNameChange(string oldName, string newName, object o)
        {
            if (!string.Equals(oldName, newName))
            {
                if (o is Plot)
                {
                    var plot = o as Plot;
                    foreach (var lease in MainVM.leases)
                    {
                        if (lease.PlotId == plot.Id)
                            lease.OnPropertyChanged(nameof(Lease.PlotId));
                    }
                }
                else if (o is Space)
                {
                    var space = o as Space;
                    foreach (var lease in MainVM.leases)
                    {
                        if (lease.SpaceId == space.Id)
                            lease.OnPropertyChanged(nameof(Lease.SpaceId));
                    }
                }
                else
                {
                    var tenant = o as Tenant;
                    foreach (var lease in MainVM.leases)
                    {
                        if (lease.TenantId == tenant.Id)
                            lease.OnPropertyChanged(nameof(Lease.TenantId));
                    }
                }               
            }
        }

        void refreshCollectionView()
        {
            if (isInEditView && isFocused)
                refresh();
        }
        void resetOnEdit(object o) => resetIsOnEdit();
        void saveAndUpdate(object o)
        {
            if (isCloneNotOriginal)
            {
                MainVM.DoAsync(type, () =>
                {
                    save();
                    update();
                    resetIsOnEdit();
                });
            }        
        }
    }
}
