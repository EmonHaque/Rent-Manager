﻿using Microsoft.Data.Sqlite;
using RentManager.Common;
using RentManager.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows.Data;

namespace RentManager.ViewModel.Edit
{
    public class EditSpaceVM : EditBase<Space>
    {
        Plot selectedPlot;
        public Lease LeaseInfo { get; set; }
        public Tenant OccupiedBy { get; set; }
        public ICollectionView Spaces { get; set; }

        public EditSpaceVM()
        {
            selectedPlot = MainVM.Plots.CurrentItem as Plot;
            Spaces = new CollectionViewSource()
            {
                Source = MainVM.spaces,
                IsLiveSortingRequested = true,
                LiveSortingProperties = { nameof(Space.Name) }
            }.View;
            subscribe();
            Spaces.SortDescriptions.Add(new SortDescription(nameof(Space.Name), ListSortDirection.Ascending));
            Spaces.Filter = filter;
        }

        void subscribe()
        {
            MainVM.Plots.CurrentChanged += onPlotChanged;
            Spaces.CurrentChanged += onSpaceChanged;
        }

        bool filter(object o) => selectedPlot == null ? false : (o as Space).PlotId == selectedPlot.Id;
        void updateLeaseInfo(Space space)
        {
            if (space != null)
            {
                LeaseInfo = MainVM.leases.FirstOrDefault(x => x.SpaceId == space.Id && !x.IsExpired);
                OccupiedBy = LeaseInfo != null ? MainVM.tenants.FirstOrDefault(x => x.Id == LeaseInfo.TenantId) : null;
            }
            else
            {
                LeaseInfo = null;
                OccupiedBy = null;
            }
            OnPropertyChanged(nameof(LeaseInfo));
            OnPropertyChanged(nameof(OccupiedBy));
        }

        #region eventHandlers
        void onPlotChanged(object o, EventArgs e)
        {
            selectedPlot = MainVM.Plots.CurrentItem as Plot;
            if (isInEditView && isFocused)
            {
                Spaces.Refresh();
                base.resetIsOnEdit();
            }
        }

        void onSpaceChanged(object sender, EventArgs e)
        {
            if (selected != Spaces.CurrentItem)
            {
                base.resetIsOnEdit();
                selected = Spaces.CurrentItem as Space;
                updateLeaseInfo(selected);
            }
        }
        #endregion

        #region overrides
        protected override void refresh() => Spaces.Refresh();
        protected override void setOnEdit(object o)
        {
            base.setOnEdit(o);
            //MainVM.Plots.MoveCurrentTo(MainVM.plots.First(x => x.Id == selected.PlotId));
        }
        #endregion

        #region base implementation
        protected override ViewType type => ViewType.Space;
        protected override bool isCloneNotOriginal => !Edited.IsEqualTo(selected);
        protected override void clone()
        {
            Edited = new Space(selected);
            OnPropertyChanged(nameof(Edited));
        }
        protected override bool isCloneValid(object o) => Edited.IsValid();
        protected override void update()
        {
            selected.Name = Edited.Name;
            selected.Description = Edited.Description;
            selected.IsVacant = Edited.IsVacant;
            selected.OnPropertyChanged(string.Empty);
        }
        protected override void save()
        {
            string tenantName, spaceName;
            tenantName = spaceName = string.Empty;

            var commands = new List<SqliteCommand>();
            if (Edited.IsVacant && !selected.IsVacant)
            {
                var lease = MainVM.leases.FirstOrDefault(x => !x.IsExpired && x.SpaceId == Edited.Id);
                tenantName = MainVM.tenants.First(x => x.Id == lease.TenantId).Name;
                spaceName = MainVM.spaces.First(x => x.Id == lease.SpaceId).Name;

                commands.Add(new SqliteCommand($"UPDATE Leases SET DateEnd = '{DateTime.Now.ToString("yyyy-MM-dd")}', IsExpired = 1 WHERE Id = {lease.Id}"));

                lease.DateEnd = DateTime.Now;
                lease.IsExpired = true;
                MainVM.spaces.First(x => x.Id == Edited.Id).IsVacant = true;
            }

            var cmd = new SqliteCommand("UPDATE Spaces SET Name = @Name, Description = @Description, IsVacant = @IsVacant WHERE Id = @Id");
            cmd.Parameters.AddWithValue("@Name", Edited.Name);
            cmd.Parameters.AddWithValue("@Description", Edited.Description);
            cmd.Parameters.AddWithValue("@IsVacant", Edited.IsVacant);
            cmd.Parameters.AddWithValue("@Id", Edited.Id);
            commands.Add(cmd);

            lock (SQLHelper.key)
            {
                SQLHelper.Transaction(commands);
            }
            foreach (var command in commands) command.Dispose();
            base.notifyLeaseForNameChange(selected.Name, Edited.Name, selected);

            if (!string.IsNullOrEmpty(tenantName))
            {
                MainVM.PopupMessage = $"{spaceName} was let out to {tenantName}\r\nand is vacant now";
                MainVM.Popup();
            }
        }      
        #endregion
    }
}
