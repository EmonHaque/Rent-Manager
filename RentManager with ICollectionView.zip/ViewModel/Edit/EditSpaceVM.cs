﻿using Microsoft.Data.Sqlite;
using RentManager.Common;
using RentManager.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows.Data;

namespace RentManager.ViewModel.Edit
{
    public class EditSpaceVM : EditBase<Space>
    {
        int? selectedPlot;
        public int? SelectedPlot
        {
            get { return selectedPlot; }
            set { selectedPlot = value; if (isFocused) reset(); }
        }

        public Lease LeaseInfo { get; set; }
        public Tenant OccupiedBy { get; set; }

        public EditSpaceVM()
        {
            Editables = new CollectionViewSource()
            {
                Source = MainVM.spaces,
                IsLiveSortingRequested = true,
                LiveSortingProperties = { nameof(Space.Name) }
            }.View;
            Editables.SortDescriptions.Add(new SortDescription(nameof(Space.Name), ListSortDirection.Ascending));
            Editables.Filter = filter;
        }

        bool filter(object o) => selectedPlot == null ? false : (o as Space).PlotId == selectedPlot;
        void reset()
        {
            if(IsOnEdit) base.resetIsOnEdit();
            Editables.Refresh();
        }
        void updateLeaseInfo(Space space)
        {
            if (space != null)
            {
                LeaseInfo = MainVM.leases.FirstOrDefault(x => x.SpaceId == space.Id && !x.IsExpired);
                OccupiedBy = LeaseInfo != null ? MainVM.tenants.FirstOrDefault(x => x.Id == LeaseInfo.TenantId) : null;
            }
            else
            {
                LeaseInfo = null;
                OccupiedBy = null;
            }
            OnPropertyChanged(nameof(LeaseInfo));
            OnPropertyChanged(nameof(OccupiedBy));
        }

        #region overrides
        protected override void refresh() => Editables.Refresh();
        protected override void doOtherStuff() => updateLeaseInfo(selected);
        #endregion

        #region base implementation
        protected override ViewType type => ViewType.Space;
        protected override void save()
        {
            string tenantName, spaceName;
            tenantName = spaceName = string.Empty;

            var commands = new List<SqliteCommand>();
            if (Edited.IsVacant && !selected.IsVacant)
            {
                var lease = MainVM.leases.FirstOrDefault(x => !x.IsExpired && x.SpaceId == Edited.Id);
                tenantName = MainVM.tenants.First(x => x.Id == lease.TenantId).Name;
                spaceName = MainVM.spaces.First(x => x.Id == lease.SpaceId).Name;

                commands.Add(new SqliteCommand($"UPDATE Leases SET DateEnd = '{DateTime.Now.ToString("yyyy-MM-dd")}', IsExpired = 1 WHERE Id = {lease.Id}"));

                lease.DateEnd = DateTime.Now;
                lease.IsExpired = true;
                MainVM.spaces.First(x => x.Id == Edited.Id).IsVacant = true;
            }

            var cmd = new SqliteCommand("UPDATE Spaces SET Name = @Name, Description = @Description, IsVacant = @IsVacant WHERE Id = @Id");
            cmd.Parameters.AddWithValue("@Name", Edited.Name);
            cmd.Parameters.AddWithValue("@Description", Edited.Description);
            cmd.Parameters.AddWithValue("@IsVacant", Edited.IsVacant);
            cmd.Parameters.AddWithValue("@Id", Edited.Id);
            commands.Add(cmd);

            lock (SQLHelper.key)
            {
                SQLHelper.Transaction(commands);
            }
            foreach (var command in commands) command.Dispose();
            base.notifyLeaseForNameChange(selected.Name, Edited.Name, selected);

            if (!string.IsNullOrEmpty(tenantName))
            {
                MainVM.PopupMessage = $"{spaceName} was let out to {tenantName}\r\nand is vacant now";
                MainVM.Popup();
            }
        }      
        #endregion
    }
}
