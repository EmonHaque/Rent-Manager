﻿using Microsoft.Data.Sqlite;
using RentManager.Common;
using RentManager.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Data;

namespace RentManager.ViewModel.Edit
{
    public class EditSpaceVM : EditBase
    {
        Plot selectedPlot;
        Space selectedSpace;

        public Space EditedSpace { get; set; }
        public Lease LeaseInfo { get; set; }
        public Tenant OccupiedBy { get; set; }
        public ICollectionView Spaces { get; set; }

        public EditSpaceVM()
        {
            selectedPlot = MainVM.Plots.CurrentItem as Plot;
            EditedSpace = new Space();
            Spaces = new CollectionViewSource()
            {
                Source = MainVM.spaces,
                IsLiveSortingRequested = true,
                LiveSortingProperties = { nameof(Space.Name) }
            }.View;
            subscribe();
            Spaces.SortDescriptions.Add(new SortDescription(nameof(Space.Name), ListSortDirection.Ascending));
            Spaces.Filter = filter;
        }

        void subscribe()
        {
            MainVM.Plots.CurrentChanged += onPlotChanged;
            Spaces.CurrentChanged += onSpaceChanged;
        }

        bool filter(object o) => selectedPlot == null ? false : (o as Space).PlotId == selectedPlot.Id;
        void updateLeaseInfo(Space space)
        {
            if (space != null)
            {
                LeaseInfo = MainVM.leases.FirstOrDefault(x => x.SpaceId == space.Id && !x.IsExpired);
                OccupiedBy = LeaseInfo != null ? MainVM.tenants.FirstOrDefault(x => x.Id == LeaseInfo.TenantId) : null;
            }
            else
            {
                LeaseInfo = null;
                OccupiedBy = null;
            }
            OnPropertyChanged(nameof(LeaseInfo));
            OnPropertyChanged(nameof(OccupiedBy));
        }

        #region eventHandlers
        void onPlotChanged(object o, EventArgs e)
        {
            selectedPlot = MainVM.Plots.CurrentItem as Plot;
            if (isInEditView && isFocused)
            {
                Spaces.Refresh();
                base.resetIsOnEdit();
            }
        }

        void onSpaceChanged(object sender, EventArgs e)
        {
            if (selectedSpace != Spaces.CurrentItem)
            {
                base.resetIsOnEdit();
                selectedSpace = Spaces.CurrentItem as Space;
                updateLeaseInfo(selectedSpace);
            }
        }
        #endregion

        #region overrides
        protected override void refresh() => Spaces.Refresh();
        protected override void setOnEdit(object o)
        {
            base.setOnEdit(o);
            //MainVM.Plots.MoveCurrentTo(MainVM.plots.First(x => x.Id == selectedSpace.PlotId));
        }
        #endregion

        #region base implementation
        protected override ViewType type => ViewType.Space;
        protected override bool isCloneNotOriginal => !EditedSpace.IsEqualTo(selectedSpace);
        protected override void clone()
        {
            EditedSpace = new Space(selectedSpace);
            OnPropertyChanged(nameof(EditedSpace));
        }
        protected override bool canEdit(object o) => selectedSpace != null;
        protected override bool isCloneValid(object o) => EditedSpace.IsValid();
        protected override void update()
        {
            selectedSpace.Name = EditedSpace.Name;
            selectedSpace.Description = EditedSpace.Description;
            selectedSpace.IsVacant = EditedSpace.IsVacant;
            selectedSpace.OnPropertyChanged(string.Empty);
        }
        protected override void save()
        {
            string tenantName, spaceName;
            tenantName = spaceName = string.Empty;

            var commands = new List<SqliteCommand>();
            if (EditedSpace.IsVacant && !selectedSpace.IsVacant)
            {
                var lease = MainVM.leases.FirstOrDefault(x => !x.IsExpired && x.SpaceId == EditedSpace.Id);
                tenantName = MainVM.tenants.First(x => x.Id == lease.TenantId).Name;
                spaceName = MainVM.spaces.First(x => x.Id == lease.SpaceId).Name;

                commands.Add(new SqliteCommand($"UPDATE Leases SET DateEnd = '{DateTime.Now.ToString("yyyy-MM-dd")}', IsExpired = 1 WHERE Id = {lease.Id}"));

                lease.DateEnd = DateTime.Now;
                lease.IsExpired = true;
                MainVM.spaces.First(x => x.Id == EditedSpace.Id).IsVacant = true;
            }

            var cmd = new SqliteCommand("UPDATE Spaces SET Name = @Name, Description = @Description, IsVacant = @IsVacant WHERE Id = @Id");
            cmd.Parameters.AddWithValue("@Name", EditedSpace.Name);
            cmd.Parameters.AddWithValue("@Description", EditedSpace.Description);
            cmd.Parameters.AddWithValue("@IsVacant", EditedSpace.IsVacant);
            cmd.Parameters.AddWithValue("@Id", EditedSpace.Id);
            commands.Add(cmd);

            lock (SQLHelper.key)
            {
                SQLHelper.Transaction(commands);
            }
            foreach (var command in commands) command.Dispose();
            base.notifyLeaseForNameChange(selectedSpace.Name, EditedSpace.Name, selectedSpace);

            if (!string.IsNullOrEmpty(tenantName))
            {
                MainVM.PopupMessage = $"{spaceName} was let out to {tenantName}\r\nand is vacant now";
                MainVM.Popup();
            }
        }      
        #endregion
    }
}
