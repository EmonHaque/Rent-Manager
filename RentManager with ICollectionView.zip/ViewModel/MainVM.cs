﻿using RentManager.Common;
using RentManager.Model;
using RentManager.View;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Input;

namespace RentManager.ViewModel
{
    public class MainVM : Notifiable
    {       
        public static Bag<Plot> plots;      
        public static Bag<Space> spaces;
        public static Bag<Tenant> tenants;
        public static Bag<Lease> leases;
        public static Bag<ControlHead> controlHeads;
        public static Bag<Head> heads;
        public static int maxLeaseId;
        public static int? controlIdOfReceivable;
        static bool plotBusy, spaceBusy, tenantBusy, leaseBusy, headBusy, transactionBusy, balanceBusy;
        static Menu selectedMenu;

        public static bool PlotBusy { get => plotBusy; set { plotBusy = value; OnStaticPropertyChanged(); } }
        public static bool SpaceBusy { get => spaceBusy; set { spaceBusy = value; OnStaticPropertyChanged(); } }
        public static bool TenantBusy { get => tenantBusy; set { tenantBusy = value; OnStaticPropertyChanged(); } }
        public static bool LeaseBusy { get => leaseBusy; set { leaseBusy = value; OnStaticPropertyChanged(); } }
        public static bool HeadBusy { get => headBusy; set { headBusy = value; OnStaticPropertyChanged(); } }
        public static bool TransactionBusy { get => transactionBusy; set { transactionBusy = value; OnStaticPropertyChanged(); } }
        public static bool BalanceBusy { get => balanceBusy; set { balanceBusy = value; OnStaticPropertyChanged(); } }
        public static Menu SelectedMenu { get => selectedMenu; set { selectedMenu = value; OnSelectedMenuChanged?.Invoke(); } }

        public string MaxRestoreTip { get; set; }
        public string MaxRestoreIcon { get; set; }   
        public List<Menu> Menus { get; set; }
        public static ICollectionView Plots { get; set; }
        public static ICollectionView ControlHeads { get; set; }
        public static string PopupMessage { get; set; }
        public static bool IsPopupOpen { get; set; }
        public Command Close { get; set; }
        public Command Minimize { get; set; }
        public Command MaxRestore { get; set; }
        public static event Action OnSelectedMenuChanged;

        public MainVM()
        {
            SelectedMenu = new Menu("", "", null, "");
            initializeCollections();
            checkDatabase();
            initializeCollectionViews();
            initializeMenu();
            App.Current.MainWindow.MouseDown += move;
            MaxRestoreTip = "Maximize";
            MaxRestoreIcon = Constants.MaximizeIcon;
            initializeCommands();
        }

        void checkDatabase()
        {
            if (!File.Exists(Constants.DBName)) createDatabase();
            else populateCollections();
        }

        void createDatabase()
        {
            using var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("RentManager.SQL.init.sql");
            using var sReader = new StreamReader(stream);
            SQLHelper.NonQuery(sReader.ReadToEnd());

            using var cmd = SQLHelper.connection.CreateCommand();
            cmd.CommandText = @"SELECT * FROM ControlHeads;
								SELECT * FROM Heads";
            SQLHelper.connection.Open();
            var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                controlHeads.Add(new ControlHead()
                {
                    Id = reader.GetInt32(0),
                    Name = reader.GetString(1)
                });
            }

            reader.NextResult();
            while (reader.Read())
            {
                heads.Add(new Head()
                {
                    Id = reader.GetInt32(0),
                    ControlId = reader.GetInt32(1),
                    Name = reader.GetString(2),
                    Description = reader.GetString(3)
                });
            }
            SQLHelper.connection.Close();
            controlIdOfReceivable = controlHeads.First(x => x.Name == "Receivable").Id;
        }

        void populateCollections()
        {
            using var cmd = SQLHelper.connection.CreateCommand();
            cmd.CommandText = @"SELECT * FROM Plots ORDER BY Name;
								SELECT * FROM Spaces ORDER BY PlotId, Name;
								SELECT * FROM ControlHeads ORDER BY Name;
								SELECT * FROM Heads ORDER BY ControlId, Name;
								SELECT * FROM Tenants ORDER BY Name;
								SELECT * FROM Leases ORDER BY PlotId, SpaceId;
								SELECT * FROM Receivables;
								SELECT MAX(Id) FROM Leases;";

            SQLHelper.connection.Open();
            var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                plots.Add(new Plot()
                {
                    Id = reader.GetInt32(0),
                    Name = reader.GetString(1),
                    Description = reader.GetString(2)
                });
            }

            reader.NextResult();
            while (reader.Read())
            {
                spaces.Add(new Space()
                {
                    Id = reader.GetInt32(0),
                    PlotId = reader.GetInt32(1),
                    Name = reader.GetString(2),
                    Description = reader.GetString(3),
                    IsVacant = reader.GetBoolean(4)
                });
            }

            reader.NextResult();
            while (reader.Read())
            {
                controlHeads.Add(new ControlHead()
                {
                    Id = reader.GetInt32(0),
                    Name = reader.GetString(1)
                });
            }

            reader.NextResult();
            while (reader.Read())
            {
                heads.Add(new Head()
                {
                    Id = reader.GetInt32(0),
                    ControlId = reader.GetInt32(1),
                    Name = reader.GetString(2),
                    Description = reader.GetString(3)
                });
            }

            reader.NextResult();
            while (reader.Read())
            {
                tenants.Add(new Tenant()
                {
                    Id = reader.GetInt32(0),
                    Name = reader.GetString(1),
                    Father = reader.GetString(2),
                    Mother = reader.IsDBNull(3) ? null : reader.GetString(3),
                    Husband = reader.IsDBNull(4) ? null : reader.GetString(4),
                    Address = reader.GetString(5),
                    NID = reader.IsDBNull(6) ? null : reader.GetString(6),
                    ContactNo = reader.GetString(7),
                    HasLeft = reader.GetBoolean(8)
                });
            }

            reader.NextResult();
            while (reader.Read())
            {
                leases.Add(new Lease()
                {
                    Id = reader.GetInt32(0),
                    PlotId = reader.GetInt32(1),
                    SpaceId = reader.GetInt32(2),
                    TenantId = reader.GetInt32(3),
                    DateStart = reader.GetDateTime(4),
                    DateEnd = reader.IsDBNull(5) ? (DateTime?)null : reader.GetDateTime(5),
                    Business = reader.GetString(6),
                    IsExpired = reader.GetBoolean(7)
                });
            }

            var list = new List<Receivable>();
            reader.NextResult();
            while (reader.Read())
            {
                list.Add(new Receivable()
                {
                    LeaseId = reader.GetInt32(0),
                    HeadId = reader.GetInt32(1),
                    Amount = reader.GetInt32(2)
                });
            }

            reader.NextResult();
            reader.Read();
            maxLeaseId = reader.IsDBNull(0) ? 0 : reader.GetInt32(0);

            SQLHelper.connection.Close();

            if (list.Count > 0)
            {
                foreach (var item in leases)
                    item.FixedReceivables = new Bag<Receivable>(list.Where(x => x.LeaseId == item.Id));
            }

            controlIdOfReceivable = controlHeads.First(x => x.Name == "Receivable").Id;
        }

        void initializeCollections()
        {
            plots = new Bag<Plot>();
            spaces = new Bag<Space>();
            tenants = new Bag<Tenant>();
            leases = new Bag<Lease>();
            controlHeads = new Bag<ControlHead>();
            heads = new Bag<Head>();
        }

        void initializeCollectionViews()
        {
            Plots = new CollectionViewSource() { Source = plots, IsLiveSortingRequested = true, LiveSortingProperties = { "Name" } }.View;
            Plots.SortDescriptions.Add(new SortDescription("Name", ListSortDirection.Ascending));           
            ControlHeads = CollectionViewSource.GetDefaultView(controlHeads);           
        }

        void initializeCommands()
        {
            Close = new Command(close, (o) => true);
            Minimize = new Command(minimize, (o) => true);
            MaxRestore = new Command(maxRestore, (o) => true);
        }

        void initializeMenu()
        {
            Menus = new List<Menu>()
            {
                new Menu(Constants.Home, Constants.HomeDescription, new HomeView(), Constants.HomeIcon),
                new Menu(Constants.Add, Constants.AddDescription, new AddView(), Constants.AddIcon),
                new Menu(Constants.Edit, Constants.EditDescription, new EditView(), Constants.EditIcon),
                new Menu(Constants.Transact, Constants.TransactDescription, new TransactView(), Constants.TransactIcon),
                new Menu(Constants.Ledger, Constants.LedgerDescription, new LedgerView(), Constants.LedgerIcon)
            };
            SelectedMenu = Menus.First();
            OnStaticPropertyChanged(nameof(SelectedMenu));
        }

        #region Commands
        void close(object o) => App.Current.Shutdown();

        void minimize(object o) => App.Current.MainWindow.WindowState = System.Windows.WindowState.Minimized;

        void maxRestore(object o)
        {
            switch (App.Current.MainWindow.WindowState)
            {
                case System.Windows.WindowState.Normal:
                    App.Current.MainWindow.WindowState = System.Windows.WindowState.Maximized;
                    MaxRestoreIcon = Constants.RestoreIcon;
                    MaxRestoreTip = "Restore";
                    break;
                case System.Windows.WindowState.Maximized:
                    App.Current.MainWindow.WindowState = System.Windows.WindowState.Normal;
                    MaxRestoreIcon = Constants.MaximizeIcon;
                    MaxRestoreTip = "Maximize";
                    break;
            }
            OnPropertyChanged(nameof(MaxRestoreIcon));
            OnPropertyChanged(nameof(MaxRestoreTip));
        }

        void move(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
                App.Current.MainWindow.DragMove();
        }
        #endregion

        public static async void DoAsync(ViewType type, Action task)
        {
            switch (type)
            {
                case ViewType.Plot: PlotBusy = true; break;
                case ViewType.Space: SpaceBusy = true; break;
                case ViewType.Tenant: TenantBusy = true; break;
                case ViewType.Lease: LeaseBusy = true; break;
                case ViewType.Head: HeadBusy = true; break;
                case ViewType.Transaction: TransactionBusy = true; break;
                case ViewType.CurrentBalance: BalanceBusy = true;break;
            }
            await Task.Delay(250);
            await Task.Run(task);
            await Task.Delay(250);
            switch (type)
            {
                case ViewType.Plot: PlotBusy = false; break;
                case ViewType.Space: SpaceBusy = false; break;
                case ViewType.Tenant: TenantBusy = false; break;
                case ViewType.Lease: LeaseBusy = false; break;
                case ViewType.Head: HeadBusy = false; break;
                case ViewType.Transaction: TransactionBusy = false; break;
                case ViewType.CurrentBalance: BalanceBusy = false; break;
            }
            CommandManager.InvalidateRequerySuggested();
        }

        public static int? GetId<T>(Bag<T> collection)
        {
            if (collection.Count > 0)
            {
                return collection switch
                {
                    Bag<Plot> p => p.Max(x => x.Id) + 1,
                    Bag<Space> p => p.Max(x => x.Id) + 1,
                    Bag<Tenant> p => p.Max(x => x.Id) + 1,
                    Bag<Head> p => p.Max(x => x.Id) + 1,
                };
            }
            else return 1;
        }

        public static void Popup()
        {
            OnStaticPropertyChanged(nameof(PopupMessage));
            IsPopupOpen = true;
            OnStaticPropertyChanged(nameof(IsPopupOpen));
        }

        #region Notify Static Property Changed Members
        public static event PropertyChangedEventHandler StaticPropertyChanged;
        static void OnStaticPropertyChanged([CallerMemberName] string name = "") => StaticPropertyChanged?.Invoke(null, new PropertyChangedEventArgs(name));
        #endregion
    }
}
