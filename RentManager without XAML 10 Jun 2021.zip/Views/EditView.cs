﻿using RentManager.Abstracts;
using RentManager.CustomControls;
using RentManager.Helpers;
using RentManager.Views.Edit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace RentManager.Views
{
    class EditView : ViewContainer
    {
        override public string Icon => Icons.Edit;
        public EditView() {
            Children.Add(new EditPlot());
            Children.Add(new EditSpace());
            Children.Add(new EditTenant());
            Children.Add(new EditHead());
            Children.Add(new EditLease());
            Children.Add(new EditTransaction());
        }
    }
}
