﻿using System;
using System.Windows;
using RentManager.Views;
using RentManager.CustomControls;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using RentManager.Helpers;

namespace RentManager
{
    class App : Application
    {
        public static Style scrollBarStyle;
        public static Style multilineTextScrollStyle;
        public static Style editableItemContainerStyle;
        public static Converter convert;

        [STAThread]
        static void Main() {
            var app = new App() { MainWindow = new RootWindow() };
            var loading = new LoadingWindow();
            loading.Show();
            loading.AnimationCompleted += () => {
                app.MainWindow.Show();
                loading.Close();
            };
            setStyles();
            
            new AppData();
            convert = new Converter();
            app.MainWindow.Content = new RootPanel() {
                Children = {
                    new HomeView(),
                    new AddView(),
                    new EditView(),
                    new TransactionView(),
                    new ReportView()
                }
            };
            app.Run();
        }

        static void setStyles() {
            Current.Resources.Add(SystemParameters.VerticalScrollBarWidthKey, Constants.ScrollBarThickness);
            Current.Resources.Add(SystemParameters.HorizontalScrollBarHeightKey, Constants.ScrollBarThickness);
            scrollBarStyle = new Style() {
                TargetType = typeof(ScrollBar),
                Setters = {
                    new Setter() {
                        Property = ScrollBar.TemplateProperty,
                        Value = new VScrollTemplate()
                    }
                },
                Triggers = {
                    new Trigger() {
                        Property = ScrollBar.OrientationProperty,
                        Value = Orientation.Horizontal,
                        Setters = {
                            new Setter() {
                                Property = ScrollBar.TemplateProperty,
                                Value = new HScrollTemplate()
                            }
                        }
                    }
                }
            };
            Control.StyleProperty.OverrideMetadata(typeof(ScrollBar), new FrameworkPropertyMetadata() { DefaultValue = scrollBarStyle });
            
            multilineTextScrollStyle = new Style(typeof(ScrollBar), scrollBarStyle) {
                Setters = { new Setter(ScrollBar.MarginProperty, new Thickness(0, 20, -26, 0)) }
            };
            editableItemContainerStyle = new Style() {
                TargetType = typeof(ListBoxItem),
                Setters = {
                        new Setter(ListBoxItem.MarginProperty, new Thickness(0,0,10,0)),
                        new Setter(ListBoxItem.FocusVisualStyleProperty, null)
                    }
            };
        }
    }
}
