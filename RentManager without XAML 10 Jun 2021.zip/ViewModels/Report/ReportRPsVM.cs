﻿using RentManager.Abstracts;
using RentManager.ControlTemplates;
using RentManager.CustomControls;
using RentManager.DataTemplates;
using RentManager.Helpers;
using RentManager.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;

namespace RentManager.ViewModels.Report
{
    class ReportRPsVM : Notifiable
    {
        List<ReceiptPayment> rps;
        DateTime? from;
        public DateTime? From {
            get { return from; }
            set {
                if (from != value) {
                    from = value;
                    validate();
                }
            }
        }
        DateTime? to;
        public DateTime? To {
            get { return to; }
            set {
                if (to != value) {
                    to = value;
                    validate();
                }
            }
        }
        string query;
        public string Query {
            get { return query; }
            set {
                if (query != value) {
                    query = value;
                    RPs.Refresh();
                }
            }
        }
        public string ErrorFrom { get; set; }
        public string ErrorTo { get; set; }
        public bool IsRefreshValid { get; set; }
        public bool IsPrintValid { get; set; }
        public Action Refresh { get; set; }
        public Action Print { get; set; }
        public ICollectionView RPs { get; set; }

        public ReportRPsVM() {
            To = DateTime.Today;
            From = DateTime.Today.AddMonths(-1);
            Refresh = refresh;
            Print = print;
            RPs = CollectionViewSource.GetDefaultView(new List<ReceiptPayment>());
        }
        bool filter(object o) {
            if (string.IsNullOrWhiteSpace(Query)) return true;
            var rp = (ReceiptPayment)o;
            var q = Query.Trim().ToLower();
            return
                rp.Plot.ToLower().Contains(q) ||
                rp.Head.ToLower().Contains(q) ||
                rp.Tenant.ToLower().Contains(q);
        }
        void validate() {
            ErrorFrom = ErrorTo = string.Empty;
            if (From == null) ErrorFrom = " required";
            if (To == null) ErrorTo = " required";
            IsRefreshValid = ErrorFrom == string.Empty && ErrorTo == string.Empty;
            OnPropertyChanged(nameof(ErrorFrom));
            OnPropertyChanged(nameof(ErrorTo));
            OnPropertyChanged(nameof(IsRefreshValid));
        }
        void refresh() {
            rps = new List<ReceiptPayment>();
            lock (SQLHelper.key) {
                SQLHelper.connection.Open();
                var cmd = SQLHelper.connection.CreateCommand();
                cmd.CommandText = $@"WITH t0(Plot, Space, Tenant, Control, Head, InCash, InKind) AS (
                                        	SELECT PlotId, SpaceId, TenantId, ControlId, HeadId,
                                        	SUM(coalesce(CASE WHEN IsCash=1 THEN Amount END, 0)),
                                        	SUM(coalesce(CASE WHEN IsCash=0 THEN Amount END, 0))
                                        	FROM Transactions 
                                        	WHERE ControlId <> 1 AND Date BETWEEN '{From.Value.ToString("yyyy-MM-dd")}' AND '{To.Value.ToString("yyyy-MM-dd")}'
                                        	GROUP BY SpaceId, TenantId, HeadId
                                        ) 
                                        SELECT p.Name Plot, s.Name Space, t.Name Tenant, c.Name Control, h.Name Head, InCash, InKind, (InCash + InKind) Total
                                        from t0 as tn
                                        LEFT JOIN Plots p ON p.Id = tn.Plot
                                        LEFT JOIN Spaces s ON s.Id = tn.Space
                                        LEFT JOIN Tenants t ON t.Id = tn.Tenant
                                        LEFT JOIN ControlHeads c ON c.Id = tn.Control
                                        LEFT JOIN Heads h ON h.Id = tn.Head";
                var reader = cmd.ExecuteReader();
                while (reader.Read()) {
                    var summary = new ReceiptPayment() {
                        Plot = reader.GetString(0),
                        Space = reader.GetString(1),
                        Tenant = reader.GetString(2),
                        Control = reader.GetString(3),
                        Head = reader.GetString(4),
                        Cash = reader.GetInt32(5),
                        Kind = reader.GetInt32(6),
                        Total = reader.GetInt32(7)
                    };
                    rps.Add(summary);
                }
                cmd.Dispose();
                SQLHelper.connection.Close();
            };
            if (rps.Count > 0) {
                rps =
                    rps.OrderByDescending(x => x.Control)
                    .ThenBy(x => x.Head)
                    .ThenBy(x => x.Plot)
                    .ThenBy(x => x.Tenant).ToList();
                RPs = CollectionViewSource.GetDefaultView(rps);
                RPs.GroupDescriptions.Add(new PropertyGroupDescription(nameof(ReceiptPayment.Control)));
                RPs.GroupDescriptions.Add(new PropertyGroupDescription(nameof(ReceiptPayment.Head)));
                RPs.GroupDescriptions.Add(new PropertyGroupDescription(nameof(ReceiptPayment.Plot)));
                RPs.GroupDescriptions.Add(new PropertyGroupDescription(nameof(ReceiptPayment.Tenant)));
                RPs.Filter = filter;
                IsPrintValid = true;
            }
            else {
                RPs = null;
                IsPrintValid = false;
            }
            OnPropertyChanged(nameof(RPs));
            OnPropertyChanged(nameof(IsPrintValid));
        }
    void print() {
        var dialog = new PrintDialog();
        if (dialog.ShowDialog() != true) return;
        var width = dialog.PrintableAreaWidth;
        var height = dialog.PrintableAreaHeight;
        var groupedEntries = 
            rps.GroupBy(x => x.Control)
            .Select(x => new {
                Name = x.Key,
                Cash = x.Sum(x => x.Cash),
                Kind = x.Sum(x => x.Kind),
                Total = x.Sum(x => x.Total),
                Head = x.GroupBy(x => x.Head)
                .Select(x => new {
                    Name = x.Key,
                    Cash = x.Sum(x => x.Cash),
                    Kind = x.Sum(x => x.Kind),
                    Total = x.Sum(x => x.Total),
                    Plot = x.GroupBy(x => x.Plot)
                    .Select(x => new {
                        Name = x.Key,
                        Cash = x.Sum(x => x.Cash),
                        Kind = x.Sum(x => x.Kind),
                        Total = x.Sum(x => x.Total),
                        Tenant = x.GroupBy(x => x.Tenant)
                        .Select(x => new {
                            Name = x.Key,
                            Cash = x.Sum(x => x.Cash),
                            Kind = x.Sum(x => x.Kind),
                            Total = x.Sum(x => x.Total),
                            Entry = x
                        })
                    })
                })
            });
        List<object> list = new();
        foreach (var control in groupedEntries) {
            list.Add(new Tuple<int, string>(0, control.Name));
            foreach (var head in control.Head) {
                list.Add(new Tuple<int, string>(1, head.Name));
                foreach (var plot in head.Plot) {
                    list.Add(new Tuple<int, string>(2, plot.Name));
                    foreach (var tenant in plot.Tenant) {
                        if(tenant.Entry.Count() > 1) {
                            list.Add(new Tuple<int, string>(3, tenant.Name));
                            foreach (var entry in tenant.Entry) 
                                list.Add(new Tuple<int, ReceiptPayment>(4, entry));
                            list.Add(new Tuple<int, string, int, int, int>(3, tenant.Name, tenant.Cash, tenant.Kind, tenant.Total));
                        }
                        else list.Add(new Tuple<int, ReceiptPayment>(3, tenant.Entry.First()));
                    }
                    list.Add(new Tuple<int, string, int, int, int>(2, plot.Name, plot.Cash, plot.Kind, plot.Total));
                }
                list.Add(new Tuple<int, string, int, int, int>(1, head.Name, head.Cash, head.Kind, head.Total));
            }
            list.Add(new Tuple<int, string, int, int, int>(0, control.Name, control.Cash, control.Kind, control.Total));
        }

        var document = new FixedDocument();
        var size = new Size(dialog.PrintableAreaWidth, dialog.PrintableAreaHeight);
        document.DocumentPaginator.PageSize = size;
        var pages = new List<RPPage>();
        var page = getPage(document, null);
        pages.Add(page);
        for (int i = 0; i < list.Count; i++) {
            if (!page.AddEntry(list[i])) {
                page = getPage(document, page);
                page.AddEntry(list[i]);
                pages.Add(page);
            }
        }
        foreach (var p in pages) 
            p.NumberOfPage = document.Pages.Count;
            
        dialog.PrintDocument(document.DocumentPaginator, "");

    }
        RPPage getPage(FixedDocument doc, RPPage previousPage) {
            RPPage page;
            if (previousPage == null) {
                page = new RPPage(doc.DocumentPaginator.PageSize) {
                    Title = "Receipt and Payments",
                    Period = "for the period from " + from.Value.ToString("dd MMMM yyyy") + " to " + to.Value.ToString("dd MMMM yyyy"),
                    FootNote = $"Generated on {DateTime.Now.ToString("dd MMMM, yyyy | hh:mm:ss tt")}",
                };
            }
            else page = new RPPage(previousPage);
            doc.Pages.Add(new PageContent() { Child = page.Page });
            return page;
        }
    }
}
