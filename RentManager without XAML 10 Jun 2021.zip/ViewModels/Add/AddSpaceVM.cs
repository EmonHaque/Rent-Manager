﻿using RentManager.Helpers;
using RentManager.Models;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows.Data;

namespace RentManager.ViewModels.Add
{
    public class AddSpaceVM : AddBase<Space>
    {
        CollectionViewSource plots;
        public string ErrorPlotId { get; set; }
        public string ErrorName { get; set; }
        public string ErrorDescription { get; set; }
        public bool IsValid { get; set; }
        public ICollectionView Plots { get; set; }
        string query;
        public string Query {
            get { return query; }
            set {
                if (query != value) {
                    query = value;
                    Plots.Refresh();
                }
            }
        }

        public AddSpaceVM() : base()
        {
            plots = new CollectionViewSource() { Source = AppData.plots };
            Plots = plots.View;
            Plots.Filter = filterPlot;
            TObject.Id = AppData.GetId(AppData.spaces);
            TObject.IsVacant = true;
            TObject.PropertyChanged += validate;
            initializeValidationProperties();
            validatePlotId();
        }
        void initializeValidationProperties() {
            IsValid = false;
            ErrorPlotId = " is required";
            ErrorName = "Name is required";
            ErrorDescription = "Description is required";
        }

        bool filterPlot(object o) {
            var plot = o as Plot;
            if (Query == null) return true;
            return plot.Name.ToLower().Contains(Query.ToLower());
        }

        #region validation rules
        void validate(object sender, PropertyChangedEventArgs e) {
            switch (e.PropertyName) {
                case nameof(Space.PlotId): validatePlotId(); break;
                case nameof(Space.Name): validateName(); break;
                case nameof(Space.Description): validateDescription(); break;
            }
            IsValid =
                ErrorPlotId == string.Empty &&
                ErrorName == string.Empty &&
                ErrorDescription == string.Empty
                ? true : false;
            OnPropertyChanged(nameof(IsValid));
        }
        void validatePlotId() {
            ErrorPlotId = string.Empty;
            if (TObject.PlotId == null) 
                ErrorPlotId = " is required";
            OnPropertyChanged(nameof(ErrorPlotId));
        }
        void validateName() {
            ErrorName = string.Empty;
            if (string.IsNullOrWhiteSpace(TObject.Name)) ErrorName = "Name is required";
            else {
                if(TObject.PlotId != null) {
                    for (int i = 0; i < AppData.spaces.Count; i++) {
                        if (AppData.spaces[i].PlotId == TObject.PlotId) {
                            if (string.Equals(AppData.spaces[i].Name, TObject.Name.Trim(), StringComparison.OrdinalIgnoreCase)) {
                                ErrorName = "Name exists";
                                break;
                            }
                        }
                    }
                }
            }
            OnPropertyChanged(nameof(ErrorName));
        }
        void validateDescription() {
            ErrorDescription = string.Empty;
            if (string.IsNullOrWhiteSpace(TObject.Description)) ErrorDescription = "Description is required";
            OnPropertyChanged(nameof(ErrorDescription));
        }
        #endregion

        #region base implementation
        protected override ObservableCollection<Space> collection => AppData.spaces; 
        protected override void insertInDatabase()
        {
            using var cmd = SQLHelper.connection.CreateCommand();
            cmd.CommandText = "INSERT INTO Spaces (PlotId, Name, Description, IsVacant) VALUES(@PlotId, @Name, @Description, 1)";
            cmd.Parameters.AddWithValue("@PlotId", TObject.PlotId);
            cmd.Parameters.AddWithValue("@Name", TObject.Name);
            cmd.Parameters.AddWithValue("@Description", TObject.Description);
            SQLHelper.NonQuery(cmd);    
        }
        protected override void renewTObject()
        {
            TObject.PropertyChanged -= validate;
            TObject.PlotName = AppData.plots.First(x => x.Id == TObject.PlotId).Name;
            initializeValidationProperties();
            TObject = new Space() {
                Id = TObject.Id + 1,
                PlotId = TObject.PlotId,
                IsVacant = true
            };
            OnPropertyChanged(string.Empty);
            TObject.PropertyChanged += validate;
            TObject.OnPropertyChanged(nameof(Space.PlotId));
        }
        #endregion
    }
}
