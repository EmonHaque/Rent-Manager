﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace RentManager.CustomControls
{
    class DependencyButton<T> : FrameworkElement
    {
        Border border;
        protected SolidColorBrush brush;
        protected ColorAnimation anim;
        protected Color normalColor, highlightColor, downColor;
        public DependencyButton() {
            Focusable = true;
            normalColor = Colors.CornflowerBlue;
            highlightColor = Colors.Coral;
            downColor = Colors.Red;
            brush = new SolidColorBrush(normalColor);
            border = new Border() {
                Background = Brushes.Transparent,
                Child = new Path() {
                    Fill = brush,
                    Stretch = Stretch.Uniform
                }
            };
            anim = new ColorAnimation() {
                Duration = TimeSpan.FromSeconds(0.5),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
            FocusVisualStyle = null;
            AddVisualChild(border);
        }
        protected void animateBrush(Color color) {
            anim.To = color;
            brush.BeginAnimation(SolidColorBrush.ColorProperty, anim);
        }
        protected override Size MeasureOverride(Size availableSize) {
            border.Measure(new Size(Width, Height));
            border.Arrange(new Rect(border.DesiredSize));
            return border.DesiredSize;
        }
        protected override Size ArrangeOverride(Size finalSize) => border.DesiredSize;
        protected override void OnMouseEnter(MouseEventArgs e) => animateBrush(highlightColor);
        protected override void OnMouseLeave(MouseEventArgs e) => animateBrush(normalColor);
        protected override void OnMouseUp(MouseButtonEventArgs e) => Command.Invoke(Parameter);
        protected override void OnMouseDown(MouseButtonEventArgs e) => animateBrush(downColor);
        protected override Visual GetVisualChild(int index) => border;
        protected override int VisualChildrenCount => 1;
       
        public Action<T> Command {
            get { return (Action<T>)GetValue(CommandProperty); }
            set { SetValue(CommandProperty, value); }
        }
        public T Parameter {
            get { return (T)GetValue(ParameterProperty); }
            set { SetValue(ParameterProperty, value); }
        }
        public string Icon {
            get { return (string)GetValue(IconProperty); }
            set { SetValue(IconProperty, value); }
        }
        public static readonly DependencyProperty CommandProperty =
            DependencyProperty.Register("Command", typeof(Action<T>), typeof(DependencyButton<T>), new PropertyMetadata(null));

        public static readonly DependencyProperty ParameterProperty =
            DependencyProperty.Register("Parameter", typeof(T), typeof(DependencyButton<T>), new PropertyMetadata(null));

        public static readonly DependencyProperty IconProperty =
            DependencyProperty.Register("Icon", typeof(string), typeof(DependencyButton<T>), new PropertyMetadata(null, onIconChanged));

        static void onIconChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
            var o = d as DependencyButton<T>;
            ((Path)o.border.Child).Data = Geometry.Parse(e.NewValue.ToString());
        }
    }
}
