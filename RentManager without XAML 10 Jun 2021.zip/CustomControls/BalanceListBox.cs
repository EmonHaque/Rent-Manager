﻿using RentManager.ControlTemplates;
using RentManager.Helpers;
using RentManager.Models;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;

namespace RentManager.CustomControls
{
    class BalanceListBox : ListBox
    {
        object item;
        bool isForPrinting;
        public BalanceListBox(bool isForPrinting = false) {
            this.isForPrinting = isForPrinting;
            HorizontalContentAlignment = HorizontalAlignment.Stretch;
            BorderThickness = new Thickness(0);
            Resources.Add(typeof(ScrollViewer), new Style() {
                Setters = {
                    new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                    new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate())
                }
            });
        }
        protected override bool IsItemItsOwnContainerOverride(object item) {
            this.item = item;
            return false;
        }
        protected override DependencyObject GetContainerForItemOverride() {
            if (item is string) return new HeaderItem((string)item, isForPrinting);
            if (item is Balance) return new EntryItem((Balance)item, isForPrinting);
            return new FooterItem((Tuple<int, int, int>)item, isForPrinting);
        }
    }
    class HeaderItem : ListBoxItem
    {
        public HeaderItem(string item, bool isForPrinting) {
            IsHitTestVisible = false;
            double thickness = 1;
            if (isForPrinting) {
                Padding = new Thickness(0);
                thickness = 0.5;
            }
            Content = new Border() {
                BorderThickness = new Thickness(0, 0, 0, thickness),
                BorderBrush = isForPrinting ? Brushes.Black : Brushes.LightBlue,
                Child = new TextBlock() {
                    FontWeight = FontWeights.Bold,
                    Text = item
                }
            };
        }
    }
    class EntryItem : ListBoxItem
    {
        public EntryItem(Balance item, bool isForPrinting) {
            FocusVisualStyle = null;
            if (isForPrinting) Padding = new Thickness(0);
            var name = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Left };
            if(item.Count > 1) {
                var space = new Run() { Text = item.Space };
                name.Inlines.Add(space);
                name.Margin = new Thickness(10, 0, 0, 0);
            }
            else {
                var tenant = new Run() { Text = item.Tenant, FontWeight = FontWeights.Bold };
                name.Inlines.Add(tenant);
                if(item.Space != null) {
                    var space = new Run() { Text = " - " + item.Space };
                    name.Inlines.Add(space);
                }
            }
            if (item.IsExpired) {
                var expDate = new Run() {
                    Text = $" (expired on {item.DateEnd.Value.ToString("dd MMMM yyyy") })",
                    FontStyle = FontStyles.Italic
                };
                name.Inlines.Add(expDate);
            }
            var date = new TextBlock() { Text = item.DateStart.Value.ToString("dd MMMM yyyy"), HorizontalAlignment = HorizontalAlignment.Center };
            var security = new TextBlock() { Text = item.Security.ToString(Constants.NumberFormat), HorizontalAlignment = HorizontalAlignment.Right };
            var rent = new TextBlock() { Text = item.Rent.ToString(Constants.NumberFormat), HorizontalAlignment = HorizontalAlignment.Right };
            var due = new TextBlock() { Text = item.Due.ToString(Constants.NumberFormat), HorizontalAlignment = HorizontalAlignment.Right };
            Grid.SetColumn(date, 1);
            Grid.SetColumn(security, 2);
            Grid.SetColumn(rent, 3);
            Grid.SetColumn(due, 4);
            var width = isForPrinting ? 70 : 100;
            Content = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = new GridLength(150) },
                    new ColumnDefinition(){ Width = new GridLength(width) },
                    new ColumnDefinition(){ Width = new GridLength(width) },
                    new ColumnDefinition(){ Width = new GridLength(width) }
                },
                Children = { name, date, security, rent, due }
            };
        }
    }
    class FooterItem : ListBoxItem
    { 
        public FooterItem(Tuple<int, int, int> values, bool isForPrinting) {
            IsHitTestVisible = false;
            if (isForPrinting) {
                Padding = new Thickness(0);
            }
            var separator = new Separator() { Background = isForPrinting ? Brushes.Black : Brushes.LightBlue };
            var security = new TextBlock() { Text = values.Item1.ToString(Constants.NumberFormat) };
            var rent = new TextBlock() { Text = values.Item2.ToString(Constants.NumberFormat) };
            var due = new TextBlock() { Text = values.Item3.ToString(Constants.NumberFormat) };
            Grid.SetColumn(security, 1);
            Grid.SetColumn(rent, 2);
            Grid.SetColumn(due, 3);
            Grid.SetColumn(separator, 1);
            Grid.SetColumnSpan(separator, 3);
            var width = isForPrinting ? 70 : 100;
            Content = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = new GridLength(width) },
                    new ColumnDefinition(){ Width = new GridLength(width) },
                    new ColumnDefinition(){ Width = new GridLength(width) }
                },
                RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition()
                },
                Resources = {
                    {
                        typeof(TextBlock),
                        new Style() {
                            Setters = {
                                new Setter(TextBlock.FontWeightProperty, FontWeights.Bold),
                                new Setter(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right),
                                new Setter(Grid.RowProperty, 1)
                            }
                        }
                    }
                },
                Children = {separator, security, rent, due }
            };
        }
    }
}
