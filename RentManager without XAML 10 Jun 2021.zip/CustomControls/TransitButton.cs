﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace RentManager.CustomControls
{
    class TransitButton : FrameworkElement
    {
        public bool isActing;
        public int index;
        Path iconPath;
        Border container;
        SolidColorBrush brush;
        ColorAnimation brushAnim;
        public Action<int> Command { get; set; }
        Color normalColor, highlightColor, selectedColor;
        bool isSelected;
        public bool IsSelected {
            get { return isSelected; }
            set { 
                isSelected = value;
                if (IsSelected) animateBrush(selectedColor);
                else animateBrush(normalColor);
            }
        }
        string icon;
        public string Icon {
            get { return icon; }
            set { icon = value; iconPath.Data = Geometry.Parse(value); }
        }

        public TransitButton(double widthAndHeight) {
            normalColor = Colors.Black;
            highlightColor = Colors.Coral;
            selectedColor = Colors.CornflowerBlue;
            brush = new SolidColorBrush(normalColor);
            iconPath = new Path() {
                Margin = new Thickness(5),
                Fill = brush,
                Stretch = Stretch.Uniform,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };

            container = new Border() {
                Width = widthAndHeight,
                Height = widthAndHeight,
                Background = Brushes.Transparent,
                Child = iconPath
            };
            AddVisualChild(container);

            brushAnim = new ColorAnimation() {
                Duration = TimeSpan.FromMilliseconds(250),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
        }
        void animateBrush(Color color) {
            brushAnim.To = color;
            brush.BeginAnimation(SolidColorBrush.ColorProperty, brushAnim);
        }
        protected override void OnMouseUp(MouseButtonEventArgs e) {
            if (!isActing) {
                //rippleEllipse.Center = e.GetPosition(this);
                //rippleEllipse.BeginAnimation(EllipseGeometry.RadiusXProperty, rippleAnim);
                //rippleEllipse.BeginAnimation(EllipseGeometry.RadiusYProperty, rippleAnim);
                Command.Invoke(index);
            }
        }
        protected override void OnMouseEnter(MouseEventArgs e) {
            if (IsSelected) return;
            animateBrush(highlightColor);
        }
        protected override void OnMouseLeave(MouseEventArgs e) {
            if (IsSelected) return;
            animateBrush(normalColor);
        }
        protected override Size ArrangeOverride(Size finalSize) {
            container.Measure(finalSize);
            container.Arrange(new Rect(container.DesiredSize));
            return finalSize;
        }
        protected override Visual GetVisualChild(int index) => container;
        protected override int VisualChildrenCount => 1;
    }
}
