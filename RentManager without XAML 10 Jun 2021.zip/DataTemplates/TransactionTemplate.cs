﻿using RentManager.CustomControls;
using RentManager.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;

namespace RentManager.DataTemplates
{
    class TransactionTemplate : DataTemplate
    {
        public TransactionTemplate() {
            var grid = new FrameworkElementFactory(typeof(Grid));
            var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var particulars = new FrameworkElementFactory(typeof(TextBlock));
            var amount = new FrameworkElementFactory(typeof(TextBlock));
            var isCash = new FrameworkElementFactory(typeof(BiState));

            var space = new FrameworkElementFactory(typeof(Run));
            var colon = new FrameworkElementFactory(typeof(Run));
            var tenant = new FrameworkElementFactory(typeof(Run));
            var pipe = new FrameworkElementFactory(typeof(Run));
            var control = new FrameworkElementFactory(typeof(Run));
            var arrow = new FrameworkElementFactory(typeof(Run));
            var head = new FrameworkElementFactory(typeof(Run));

            col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(1, GridUnitType.Auto));
            col3.SetValue(ColumnDefinition.WidthProperty, new GridLength(1, GridUnitType.Auto));
            isCash.SetValue(BiState.IsEnabledProperty, false);
            isCash.SetValue(BiState.VerticalAlignmentProperty, VerticalAlignment.Center);
            isCash.SetValue(Grid.ColumnProperty, 2);
            amount.SetValue(Grid.ColumnProperty, 1);
            amount.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
            amount.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
            amount.SetValue(TextBlock.MarginProperty, new Thickness(5, 0, 0, 0));
            particulars.SetValue(TextBlock.TextWrappingProperty, TextWrapping.Wrap);
            colon.SetValue(Run.TextProperty, " : ");
            pipe.SetValue(Run.TextProperty, " | ");
            arrow.SetValue(Run.TextProperty, " \u21D2 ");
          
            space.SetBinding(Run.TextProperty, new Binding(nameof(Transaction.SpaceId)) { Converter = App.convert.spaceId2spaceName });
            tenant.SetBinding(Run.TextProperty, new Binding(nameof(Transaction.TenantName)));
            control.SetBinding(Run.TextProperty, new Binding(nameof(Transaction.ControlId)) { Converter = App.convert.controlId2ControlName });
            head.SetBinding(Run.TextProperty, new Binding(nameof(Transaction.HeadId)) { Converter = App.convert.headId2headName });
            isCash.SetBinding(BiState.IsTrueProperty, new Binding(nameof(Transaction.IsCash)));
            amount.SetBinding(TextBlock.TextProperty, new Binding(nameof(Transaction.Amount)) { StringFormat = "N0" });

            particulars.AppendChild(space);
            particulars.AppendChild(colon);
            particulars.AppendChild(tenant);
            particulars.AppendChild(pipe);
            particulars.AppendChild(control);
            particulars.AppendChild(arrow);
            particulars.AppendChild(head);
            grid.AppendChild(col1);
            grid.AppendChild(col2);
            grid.AppendChild(col3);
            grid.AppendChild(particulars);
            grid.AppendChild(isCash);
            grid.AppendChild(amount);

            VisualTree = grid;
        }
    }
}
