﻿using System.Windows.Controls;

namespace RentManager.View.Ledger
{
    /// <summary>
    /// Interaction logic for PeriodicView.xaml
    /// </summary>
    public partial class PeriodicView : UserControl
    {
        public PeriodicView()
        {
            InitializeComponent();
        }
    }
}
