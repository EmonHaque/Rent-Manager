﻿using System.Windows.Controls;

namespace RentManager.View.Home
{
    /// <summary>
    /// Interaction logic for NotesView.xaml
    /// </summary>
    public partial class NotesView : UserControl
    {
        public NotesView()
        {
            InitializeComponent();
        }
    }
}
