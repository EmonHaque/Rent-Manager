﻿using RentManager.Common;
using RentManager.Model;
using RentManager.View.Ledger;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RentManager.ViewModel
{
    public class LedgerVM
    {
        public List<Tab> Tabs { get; set; }
        static Tab selectedTab;
        public static Tab SelectedTab
        {
            get { return selectedTab; }
            set { selectedTab = value; OnSelectedTabChanged?.Invoke(); }
        }

        public static event Action OnSelectedTabChanged;
        public LedgerVM()
        {
            Tabs = new List<Tab>()
            {
                new Tab("Plot", ViewType.Plot, new LedgerPlotView(), Constants.PlotIcon),
                new Tab("Space", ViewType.Space, new LedgerSpaceView(), Constants.SpaceIcon),
                new Tab("Tenant", ViewType.Tenant, new LedgerTenantView(), Constants.TenantIcon),
                new Tab("Balance", ViewType.CurrentBalance, new LedgerOutstandingView(), Constants.BalanceIcon),
                new Tab("Period", ViewType.Periodic, new PeriodicView(), Constants.PeriodicIcon)
            };
            SelectedTab = Tabs.First();
        }
    }
}
