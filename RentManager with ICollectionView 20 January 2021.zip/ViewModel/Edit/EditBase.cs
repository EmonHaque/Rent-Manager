﻿using RentManager.Common;
using RentManager.Interface;
using RentManager.Model;
using System.ComponentModel;

namespace RentManager.ViewModel.Edit
{
    public abstract class EditBase<T> : Notifiable where T : Notifiable, IEditable<T>, new()
    {
        public bool IsOnEdit { get; set; }
        public Command SetIsOnEdit { get; set; }
        public Command ResetIsOnEdit { get; set; }
        public Command Save { get; set; }
        ICollectionView editables;
        public ICollectionView Editables 
        {
            get { return editables; }
            set { editables = value; value.CurrentChanged += onSelectedChanged; }
        }
        public T Edited { get; set; }
        protected T selected;
        protected bool isFocused => MainVM.SelectedMenu.Name == Constants.Edit && EditVM.SelectedTab.Type == type;

        public EditBase()
        {
            Edited = new T();
            SetIsOnEdit = new Command(setOnEdit, (o) => selected != null);
            ResetIsOnEdit = new Command(resetOnEdit, (o) => true);
            Save = new Command(saveAndUpdate, (o) => Edited.IsValid());
            MainVM.OnSelectedMenuChanged += refreshCollectionView;
            EditVM.OnSelectedTabChanged += refreshCollectionView;
        }
        protected abstract ViewType type { get; }
        protected abstract void save();
        protected virtual void refresh() { }
        protected virtual void doOtherStuff() { }
        protected virtual void setOnEdit(object o)
        {
            Edited = selected.Clone();
            OnPropertyChanged(nameof(Edited));
            IsOnEdit = true;
            OnPropertyChanged(nameof(IsOnEdit));
        }

        protected void onSelectedChanged(object sender, System.EventArgs e)
        {
            if (selected != Editables.CurrentItem)
            {
                selected = Editables.CurrentItem as T;
                if (isFocused)
                {
                    if (IsOnEdit) resetIsOnEdit();
                    doOtherStuff();
                }
            }
        }

        protected void resetIsOnEdit()
        {
            IsOnEdit = false;
            OnPropertyChanged(nameof(IsOnEdit));
        }

        protected void notifyLeaseForNameChange(string oldName, string newName, object o)
        {
            if (!string.Equals(oldName, newName))
            {
                if (o is Plot)
                {
                    var plot = o as Plot;
                    foreach (var lease in MainVM.leases)
                    {
                        if (lease.PlotId == plot.Id)
                            lease.OnPropertyChanged(nameof(Lease.PlotId));
                    }
                }
                else if (o is Space)
                {
                    var space = o as Space;
                    foreach (var lease in MainVM.leases)
                    {
                        if (lease.SpaceId == space.Id)
                            lease.OnPropertyChanged(nameof(Lease.SpaceId));
                    }
                }
                else
                {
                    var tenant = o as Tenant;
                    foreach (var lease in MainVM.leases)
                    {
                        if (lease.TenantId == tenant.Id)
                            lease.OnPropertyChanged(nameof(Lease.TenantId));
                    }
                }               
            }
        }

        void refreshCollectionView()
        {
            if (isFocused) refresh();
        }
        void resetOnEdit(object o) => resetIsOnEdit();
        void saveAndUpdate(object o)
        {
            if (!Edited.IsEqualTo(selected))
            {
                MainVM.DoAsync(type, () =>
                {
                    save();
                    selected.Update(Edited);
                    selected.OnPropertyChanged(string.Empty);
                    resetIsOnEdit();
                });
            }        
        }
    }
}
