﻿using Microsoft.Data.Sqlite;
using RentManager.Common;
using RentManager.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Data;

namespace RentManager.ViewModel.Edit
{
    public class EditLeaseVM : EditBase<Lease>
    {
        bool? filterState;
        public bool? FilterState
        {
            get { return filterState; }
            set { filterState = value; Editables.Refresh(); Tenants.Refresh(); }
        }
        int? selectedPlot;
        public int? SelectedPlot
        {
            get { return selectedPlot; }
            set { selectedPlot = value; if (isFocused) reset(); }
        }

        public ICollectionView Tenants { get; set; }
        public ICollectionView Plots { get; set; }
        public ICollectionView Spaces { get; set; }
        public ICollectionView ReceivableHeads { get; set; }
        public Receivable NewReceivable { get; set; }
        public Command AddReceivable { get; set; }
        public Command RemoveReceivable { get; set; }

        public EditLeaseVM()
        {
            NewReceivable = new Receivable();
            initializeCollections();
            ReceivableHeads.CurrentChanged += (s, e) => { };
            initializeFilters();
            initializeCommands();
        }

        void reset()
        {
            if (IsOnEdit) base.resetIsOnEdit();
            Editables.Refresh();
        }

        #region for Constructor
        void initializeCollections()
        {
            Editables = new CollectionViewSource() 
            { 
                Source = MainVM.leases, 
                IsLiveFilteringRequested = true, 
                LiveFilteringProperties = { nameof(Lease.IsExpired) } 
            }.View;
            ReceivableHeads = new CollectionViewSource() { Source = MainVM.heads }.View;
            Tenants = new CollectionViewSource()
            {
                Source = MainVM.tenants,
                IsLiveFilteringRequested = true,
                LiveFilteringProperties = { nameof(Tenant.HasLeft) }
            }.View;
            Plots = new CollectionViewSource() { Source = MainVM.plots }.View;
            Spaces = new CollectionViewSource() { Source = MainVM.spaces }.View;
            Plots.CurrentChanged += refreshSpaces;
        }

        void initializeCommands()
        {
            AddReceivable = new Command(addReceivable, (o) => NewReceivable.IsValid());
            RemoveReceivable = new Command(removeReceivable, (o) => true);
        }

        void initializeFilters()
        {
            Editables.Filter = filterLeases;
            ReceivableHeads.Filter = filterReceivableHeads;
            Spaces.Filter = filterSpaces;
            Tenants.Filter = filterTenants;
        }     
        #endregion

        #region ICommands
        void addReceivable(object o)
        {
            Edited.FixedReceivables.Add(NewReceivable);
            NewReceivable = new Receivable() { LeaseId = selected.Id };
            OnPropertyChanged(nameof(NewReceivable));
            ReceivableHeads.Refresh();
        }

        void removeReceivable(object o)
        {
            var receivable = o as Receivable;
            Edited.FixedReceivables.Remove(receivable);
            ReceivableHeads.Refresh();
            if (ReceivableHeads.CurrentItem == null)
                ReceivableHeads.MoveCurrentToFirst();
        }
        #endregion

        #region filters
        bool filterLeases(object o)
        {
            if (selectedPlot == null) return false;
            if (MainVM.leases.Count > 0)
            {
                var lease = (o as Lease);
                switch (FilterState)
                {
                    case true:
                        return lease.PlotId == selectedPlot && !lease.IsExpired;
                    case false:
                        return lease.PlotId == selectedPlot && lease.IsExpired;
                    default:
                        return lease.PlotId == selectedPlot;
                }
            }
            return false;
        }

        bool filterReceivableHeads(object o)
        {
            var head = o as Head;
            return head.ControlId == MainVM.controlIdOfReceivable
                && Edited.FixedReceivables.FirstOrDefault(x => x.HeadId == head.Id) == null;
        }

        bool filterSpaces(object o)
        {
            if(Plots.CurrentItem != null)
                return (o as Space).PlotId == (Plots.CurrentItem as Plot).Id;
            return false;
        }
        bool filterTenants(object o)
        {
            return FilterState switch
            {
                true => !(o as Tenant).HasLeft,
                false => (o as Tenant).HasLeft,
                _ => true
            };
        }
        void refreshSpaces(object s, EventArgs e)
        {
            if (base.isFocused && base.IsOnEdit)
                Spaces.Refresh();
        }
        #endregion

        #region overrides
        protected override void refresh() => Editables.Refresh();
        protected override void setOnEdit(object o)
        {
            base.setOnEdit(o);
            NewReceivable.LeaseId = Edited.Id;
            ReceivableHeads.Refresh();
            Tenants.MoveCurrentTo(MainVM.tenants.First(x => x.Id == Edited.TenantId));
            Plots.MoveCurrentTo(MainVM.plots.First(x => x.Id == Edited.PlotId));
            Spaces.Refresh();
            Spaces.MoveCurrentTo(MainVM.spaces.First(x => x.Id == selected.SpaceId));
        }
        #endregion

        #region base implementation
        protected override ViewType type => ViewType.Lease;
        protected override void save()
        {
            if ((Edited.IsExpired && !selected.IsExpired) && (Edited.SpaceId != selected.SpaceId))
            {
                MainVM.PopupMessage = $"Changes of Space and Expiration cannot be set simultaneously!\r\nNothing's been saved!";
                MainVM.Popup();
                Edited = selected.Clone();
                return;
            }

            var spaceName = string.Empty;
            object dateExpired = DBNull.Value;
            var commands = new List<SqliteCommand>();

            if (Edited.IsExpired && !selected.IsExpired)
            {
                commands.Add(new SqliteCommand($"UPDATE Spaces SET IsVacant = 1 WHERE Id = {Edited.SpaceId}"));
                var space = MainVM.spaces.FirstOrDefault(x => x.Id == Edited.SpaceId);
                space.IsVacant = true;
                spaceName = space.Name;
                dateExpired = DateTime.Now.ToString("yyyy-MM-dd");
                space.OnPropertyChanged(nameof(Space.IsVacant));
            }
            else
            {
                if (Edited.IsExpired && selected.IsExpired) 
                    dateExpired = Edited.DateEnd.Value.ToString("yyyy-MM-dd");
                commands.Add(new SqliteCommand($"DELETE FROM Receivables WHERE LeaseId = {Edited.Id}"));
                foreach (var item in Edited.FixedReceivables)
                    commands.Add(new SqliteCommand($"INSERT INTO Receivables VALUES({item.LeaseId}, {item.HeadId}, {item.Amount})"));
            }

            if(Edited.SpaceId != selected.SpaceId)
            {
                commands.Add(new SqliteCommand($"UPDATE Spaces SET IsVacant = 1 WHERE Id = {selected.SpaceId}"));
                commands.Add(new SqliteCommand($"UPDATE Spaces SET IsVacant = 0 WHERE Id = {Edited.SpaceId}"));

                var space = MainVM.spaces.FirstOrDefault(x => x.Id == selected.SpaceId);
                space.IsVacant = true;
                space.OnPropertyChanged(nameof(Space.IsVacant));

                space = MainVM.spaces.FirstOrDefault(x => x.Id == Edited.SpaceId);
                space.IsVacant = false;
                space.OnPropertyChanged(nameof(Space.IsVacant));
            }
            var cmd = new SqliteCommand(@"UPDATE Leases SET PlotId = @PlotId, SpaceId = @SpaceId, TenantId = @TenantId, 
                                            DateStart = @DateStart, DateEnd = @DateEnd, Business = @Business, IsExpired = @IsExpired WHERE Id = @Id");
            cmd.Parameters.AddWithValue("@PlotId", Edited.PlotId);
            cmd.Parameters.AddWithValue("@SpaceId", Edited.SpaceId);
            cmd.Parameters.AddWithValue("@TenantId", Edited.TenantId);
            cmd.Parameters.AddWithValue("@DateStart", Edited.DateStart.ToString("yyyy-MM-dd"));
            cmd.Parameters.AddWithValue("@DateEnd", dateExpired);
            cmd.Parameters.AddWithValue("@Business", Edited.Business);
            cmd.Parameters.AddWithValue("@IsExpired", Edited.IsExpired);
            cmd.Parameters.AddWithValue("@Id", Edited.Id);
            commands.Add(cmd);
            lock (SQLHelper.key)
            {
                SQLHelper.Transaction(commands);
            }
            foreach (var command in commands) command.Dispose();

            if (!string.IsNullOrEmpty(spaceName))
            {
                MainVM.PopupMessage = $"{spaceName} is available to let out";
                MainVM.Popup();
            }
        }
        #endregion
    }
}