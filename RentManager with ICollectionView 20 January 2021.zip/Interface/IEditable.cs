﻿namespace RentManager.Interface
{
    public interface IEditable<T> 
    {
       T Clone();
       bool IsEqualTo(T source);
       bool IsValid();
       void Update(T Edited);
    }
}
