﻿class GroupedTransactionTemplate : ControlTemplate
    {
        public GroupedTransactionTemplate() {
            TargetType = typeof(GroupItem);
            var grid = new FrameworkElementFactory(typeof(Grid));
            var row1 = new FrameworkElementFactory(typeof(RowDefinition));
            var row2 = new FrameworkElementFactory(typeof(RowDefinition));
            var header = new FrameworkElementFactory(typeof(TextBlock));
            var plotName = new FrameworkElementFactory(typeof(Run));
            var colon = new FrameworkElementFactory(typeof(Run));
            var transactionCount = new FrameworkElementFactory(typeof(Run));
            var items = new FrameworkElementFactory(typeof(ItemsPresenter));

            row1.SetValue(RowDefinition.HeightProperty, new GridLength(1, GridUnitType.Auto));
            items.SetValue(Grid.RowProperty, 1);
            items.SetValue(ItemsPresenter.MarginProperty, new Thickness(10, 0, 0, 0));
            plotName.SetBinding(Run.TextProperty, new Binding(nameof(GroupItem.Name)) {
                Mode = BindingMode.OneWay, 
                Converter = Converters.plotId2plotName 
            });
            plotName.SetValue(Run.FontWeightProperty, FontWeights.Bold);
            colon.SetValue(Run.TextProperty, " : ");
            transactionCount.SetBinding(Run.TextProperty, new Binding("Items.Count") { Mode = BindingMode.OneWay });

            header.AppendChild(plotName);
            header.AppendChild(colon);
            header.AppendChild(transactionCount);
            grid.AppendChild(row1);
            grid.AppendChild(row2);
            grid.AppendChild(header);
            grid.AppendChild(items);

            VisualTree = grid;
        }
    }
