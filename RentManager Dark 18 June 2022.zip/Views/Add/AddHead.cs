﻿class AddHead : CardView
    {
        public override string Header => "Head";

        SelectItem control;
        EditText name, description;
        CommandButton button;
        AddHeadVM viewModel;
        public AddHead() : base() {
            viewModel = new AddHeadVM();
            DataContext = viewModel;
            initializeUI();
            bind();
        }
        void initializeUI() {
            control = new SelectItem() {
                Hint = "Control",
                IsRequired = true,
                Icon = Icons.ControlHead,
                SelectedValuePath = nameof(ControlHead.Id),
                DisplayPath = nameof(ControlHead.Name)
            };
            name = new EditText() {
                Hint = "Name",
                IsRequired = true,
                Icon = Icons.Head
            };
            Grid.SetRow(name, 1);
            description = new EditText() {
                Hint = "Description",
                IsRequired = true,
                IsMultiline = true,
                Icon = Icons.Description
            };
            Grid.SetRow(description, 2);
            button = new CommandButton() {
                Icon = Icons.Add,
                Command = viewModel.Add,
                HorizontalAlignment = HorizontalAlignment.Right
            };
            Grid.SetRow(button, 3);
            var grid = new Grid() {
                RowDefinitions = {
                    new RowDefinition() { Height = GridLength.Auto },
                    new RowDefinition() { Height = GridLength.Auto },
                    new RowDefinition(),
                    new RowDefinition() { Height = GridLength.Auto },
                },
                Children = { control, name, description, button }
            };
            setContent(grid);
        }

        void bind() {
            control.SetBinding(SelectItem.SelectedvalueProperty, new Binding($"{nameof(viewModel.TObject)}.{nameof(Head.ControlId)}"));
            control.SetBinding(SelectItem.ErrorProperty, new Binding(nameof(viewModel.ErrorControlId)));
            control.SetBinding(SelectItem.ItemsSourceProperty, new Binding(nameof(viewModel.ControlHeads)));
            control.SetBinding(SelectItem.QueryProperty, new Binding(nameof(viewModel.Query)) { Mode = BindingMode.OneWayToSource });

            name.SetBinding(EditText.TextProperty, new Binding($"{nameof(viewModel.TObject)}.{nameof(Head.Name)}"));
            description.SetBinding(EditText.TextProperty, new Binding($"{nameof(viewModel.TObject)}.{nameof(Head.Description)}"));
            name.SetBinding(EditText.ErrorProperty, new Binding(nameof(viewModel.ErrorName)));
            description.SetBinding(EditText.ErrorProperty, new Binding(nameof(viewModel.ErrorDescription)));
            button.SetBinding(IsEnabledProperty, new Binding(nameof(viewModel.IsValid)));
        }
    }
