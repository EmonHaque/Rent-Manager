﻿class HiTemplate : DataTemplate
    {
        public HiTemplate(string text, string query, object viewModel, bool hastrigger = false) {

            var block = new FrameworkElementFactory(typeof(HiBlock));
            block.SetBinding(HiBlock.TextProperty, new Binding(text));
            block.SetBinding(HiBlock.QueryProperty, new Binding(query) { Source = viewModel, IsAsync = true });

            if (hastrigger) {
                Triggers.Add(new MultiDataTrigger() {
                    Conditions = {
                        new Condition(new Binding("FilterState"){ Source = viewModel }, null),
                        new Condition(new Binding(nameof(Space.IsVacant)), true),
                    },
                    Setters = {
                        new Setter(TextElement.ForegroundProperty, Brushes.Gray),
                        new Setter(TextElement.FontStyleProperty, FontStyles.Italic),
                    }
                });
            }

            VisualTree = block;
        }
    }
