﻿class AddHeadVM : AddBase<Head>
{
    public string ErrorControlId { get; set; }
    public string ErrorName { get; set; }
    public string ErrorDescription { get; set; }
    public bool IsValid { get; set; }
    public ICollectionView ControlHeads { get; set; }
    string query;
    public string Query {
        get { return query; }
        set {
            if (query != value) {
                query = value?.Trim().ToLower();
                ControlHeads.Refresh();
            }
        }
    }

    public AddHeadVM() : base() {
        ControlHeads = new CollectionViewSource() { Source = AppData.controlHeads }.View;
        ControlHeads.Filter = filter;
        TObject.Id = AppData.GetId(AppData.heads);
        ErrorControlId = " is required";
        TObject.PropertyChanged += validate;
        initializeValidationProperties();
    }

    bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return true;
        return ((ControlHead)o).Name.ToLower().Contains(Query);
    }

    void initializeValidationProperties() {
        IsValid = false;
        ErrorName = "Name is required";
        ErrorDescription = "Description is required";
        OnPropertyChanged(nameof(ErrorName));
        OnPropertyChanged(nameof(ErrorDescription));
        OnPropertyChanged(nameof(IsValid));
    }

    #region validation rules
    void validate(object sender, PropertyChangedEventArgs e) {
        switch (e.PropertyName) {
            case nameof(Head.ControlId): validateControlId(); break;
            case nameof(Head.Name): validateName(); break;
            case nameof(Head.Description): validateDescription(); break;
        }
        IsValid =
            ErrorControlId == string.Empty &&
            ErrorName == string.Empty &&
            ErrorDescription == string.Empty
            ? true : false;
        OnPropertyChanged(nameof(IsValid));
    }
    void validateControlId() {
        ErrorControlId = string.Empty;
        if (TObject.ControlId == null)
            ErrorControlId = " isrequired";
        OnPropertyChanged(nameof(ErrorControlId));
    }
    void validateName() {
        ErrorName = string.Empty;
        if (string.IsNullOrWhiteSpace(TObject.Name)) ErrorDescription = "Name is required";
        else {
            int? selectedControlId = TObject.ControlId;
            if (selectedControlId != null) {
                for (int i = 0; i < AppData.heads.Count; i++) {
                    if (AppData.heads[i].ControlId == selectedControlId) {
                        if (string.Equals(AppData.heads[i].Name, TObject.Name.Trim(), StringComparison.OrdinalIgnoreCase)) {
                            ErrorName = "Name exists";
                            break;
                        }
                    }
                }
            }
        }
        OnPropertyChanged(nameof(ErrorName));
    }
    void validateDescription() {
        ErrorDescription = string.Empty;
        if (string.IsNullOrWhiteSpace(TObject.Description)) ErrorDescription = "Description is required";
        OnPropertyChanged(nameof(ErrorDescription));
    }
    #endregion

    #region base Implementation
    protected override ObservableCollection<Head> collection => AppData.heads;
    protected override void insertInDatabase() {
        lock (SQL.key) {
            SQL.command.CommandText = "INSERT INTO Heads (ControlId, Name, Description) VALUES(@ControlId, @Name, @Description)";
            SQL.command.Parameters.AddWithValue("@ControlId", TObject.ControlId);
            SQL.command.Parameters.AddWithValue("@Name", TObject.Name);
            SQL.command.Parameters.AddWithValue("@Description", TObject.Description);
            SQL.command.ExecuteNonQuery();
            SQL.command.Parameters.Clear();
        }      
    }
    protected override void renewTObject() {
        TObject.PropertyChanged -= validate;
        TObject = new Head() {
            Id = TObject.Id + 1,
            ControlId = TObject.ControlId
        };
        OnPropertyChanged(nameof(TObject));
        TObject.PropertyChanged += validate;
        initializeValidationProperties();
    }
    #endregion
}
