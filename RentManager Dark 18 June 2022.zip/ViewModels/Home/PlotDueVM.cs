﻿class PlotDueVM : Notifiable
{
    int? currentId;
    bool state;
    public bool State {
        get { return state; }
        set {
            if (state != value) {
                state = value;
                if (state) {
                    getData();
                }
                else if (currentId != null) {
                    getData(currentId);
                }
                else {
                    Data = null;
                    OnPropertyChanged(nameof(Data));
                    OnPropertyChanged(nameof(Name));
                }
            }
        }
    }
    public Action Refresh { get; set; }
    public List<PlotWiseDue> Data { get; set; }
    public string Name { get; set; }

    public PlotDueVM() {
        Refresh = refresh;
        RentVM.SelectionChanged += onSelectionChanged;
    }
    void refresh() {
        if (State) getData();
        else getData(currentId);
    }
    void onSelectionChanged(int? id, List<DepositDueRent> arg2) {
        if (currentId == id) return;
        currentId = id;
        if (!State) getData(currentId);
        else {
            State = false;
            OnPropertyChanged(nameof(State));
        }
    }
    void getData() {
        var date = DateTime.Today.AddYears(-2);
        date = new DateTime(date.Year, date.Month, 1);
        Data = new List<PlotWiseDue>();
        lock (SQL.key) {

            SQL.command.CommandText = $@"WITH t0(Date, Month, TenantId, Amount) AS(
                                   	SELECT '' Date, '' Month, TenantId,
                                   	SUM(CASE WHEN ControlId = 1 THEN Amount ELSE 0 END) -
                                   	SUM(CASE WHEN ControlId = 2 AND HeadId = 5 THEN Amount ELSE 0 END) Amount
                                   	FROM Transactions
                                   	WHERE Date < '{date.ToString("yyyy-MM-dd")}'
                                   	GROUP BY TenantId
                                   ),
                                   t1(Date, Month, TenantId, Amount) AS(
                                   	SELECT Date, strftime('%m - %Y', Date) Month, TenantId,
                                   	SUM(CASE WHEN ControlId = 1 THEN Amount ELSE 0 END) -
                                   	SUM(CASE WHEN ControlId = 2 AND HeadId = 5 THEN Amount ELSE 0 END) Amount	
                                   	FROM Transactions tn
                                   	WHERE Date >= '{date.ToString("yyyy-MM-dd")}'
                                   	GROUP BY TenantId, strftime('%m-%Y', Date)
                                   	ORDER BY strftime('%Y', Date), strftime('%m', Date)
                                   ),
                                   t3 AS(SELECT * FROM t0 UNION ALL SELECT * FROM t1),
                                   t4 AS(
                                   	SELECT Date, Month, TenantId, t.Name, Amount, ROW_NUMBER() OVER (PARTITION BY TenantId) RowNum
                                   	FROM t3
                                   	LEFT JOIN Tenants t ON t.Id = TenantId
                                   ),
                                   t5 AS(
                                   	SELECT Month, Name, SUM(Amount) OVER (PARTITION BY TenantId ORDER BY RowNum) Due, Date
                                   	FROM t4 
                                   )
                                   SELECT * FROM t5 WHERE Month <> ''
                                   ORDER BY strftime('%Y', Date), strftime('%m', Date)";
            var reader = SQL.command.ExecuteReader();
            while (reader.Read()) {
                Data.Add(new PlotWiseDue() {
                    Month = reader.GetString(0),
                    Tenant = reader.GetString(1),
                    Due = reader.GetInt32(2)
                });
            }
            reader.Close();
            reader.DisposeAsync();
        }
        Name = "in All plots";
        OnPropertyChanged(nameof(Data));
        OnPropertyChanged(nameof(Name));
    }
    void getData(int? id) {
        if (id == null) {
            Data = null;
            Name = null;
            OnPropertyChanged(nameof(Data));
            OnPropertyChanged(nameof(Name));
            return;
        }
        var date = DateTime.Today.AddYears(-2);
        date = new DateTime(date.Year, date.Month, 1);
        Data = new List<PlotWiseDue>();
        lock (SQL.key) {
            SQL.command.CommandText = $@"WITH t0(Date, Month, TenantId, Amount) AS(
                                    SELECT '' Date, '' Month, TenantId,
                                    SUM(CASE WHEN ControlId = 1 THEN Amount ELSE 0 END) -
                                    SUM(CASE WHEN ControlId = 2 AND HeadId = 5 THEN Amount ELSE 0 END) Amount
                                    FROM Transactions
                                    WHERE PlotId = {id} AND Date < '{date.ToString("yyyy-MM-dd")}'
                                    GROUP BY TenantId
                                   ),
                                   t1 AS(
                                   	SELECT Date, strftime('%m - %Y', Date) Month, TenantId,
                                   	SUM(CASE WHEN ControlId = 1 THEN Amount ELSE 0 END) -
                                   	SUM(CASE WHEN ControlId = 2 AND HeadId = 5 THEN Amount ELSE 0 END) Amount	
                                   	FROM Transactions tn
                                   	WHERE PlotId = {id} AND Date >= '{date.ToString("yyyy-MM-dd")}'
                                   	GROUP BY TenantId, strftime('%m-%Y', Date)
                                   	ORDER BY strftime('%Y', Date), strftime('%m', Date)
                                   ),
                                   t3 AS(SELECT * FROM t0 UNION ALL SELECT * FROM t1),
                                   t4 AS(
                                   	SELECT Date, Month, TenantId, t.Name, Amount, ROW_NUMBER() OVER (PARTITION BY TenantId) RowNum
                                   	FROM t3
                                   	LEFT JOIN Tenants t ON t.Id = TenantId
                                   ),
                                   t5 AS(SELECT Month, Name, SUM(Amount) OVER (PARTITION BY TenantId ORDER BY RowNum) Due, Date FROM t4)
                                   SELECT * FROM t5 WHERE Month <> ''
                                   ORDER BY strftime('%Y', Date), strftime('%m', Date)";
            var reader = SQL.command.ExecuteReader();
            while (reader.Read()) {
                Data.Add(new PlotWiseDue() {
                    Month = reader.GetString(0),
                    Tenant = reader.GetString(1),
                    Due = reader.GetInt32(2)
                });
            }
            reader.Close();
            reader.DisposeAsync();
        }
        Name = Data.Count > 0 ? "in " + AppData.plots.First(x => x.Id == id).Name : null;
        OnPropertyChanged(nameof(Data));
        OnPropertyChanged(nameof(Name));
    }
}
