﻿using RentManager.Models;
using RentManager.ToolTips;
using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace RentManager.CustomControls
{
    class Circle : FrameworkElement
    {
        public DepositDueRent value;
        int radius;
        Path path;
        EllipseGeometry circle;
        RadialGradientBrush radialBrush;
        GradientStop firstStop;
        DoubleAnimation gradStopAnim;
        DoubleAnimation scaleAnim;
        double leftBound, rightBound;
        HomeLineTip tip;
        bool isSelected;
        public bool IsSelected {
            get { return isSelected; }
            set {
                if (isSelected != value) {
                    isSelected = value;
                    if (!isSelected) {
                        gradStopAnim.To = 0.25;
                        scaleAnim.To = 0.75;
                        animate();
                    }
                }
            }
        }

        public Circle(DepositDueRent value) {
            this.value = value;
            tip = new HomeLineTip(value);
            radius = 4;
            firstStop = new GradientStop(Colors.CornflowerBlue, 0);
            radialBrush = new RadialGradientBrush() {
                GradientOrigin = new Point(0.5, 0.5),
                GradientStops = {
                    firstStop,
                    new GradientStop(Colors.Coral, 1)
                }
            };
            circle = new EllipseGeometry() { RadiusX = radius, RadiusY = radius };
            path = new Path() {
                Fill = radialBrush,
                Data = circle
            };
            gradStopAnim = new DoubleAnimation() {
                BeginTime = TimeSpan.FromSeconds(0.5),
                Duration = TimeSpan.FromSeconds(1),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
            scaleAnim = new DoubleAnimation() {
                Duration = TimeSpan.FromSeconds(1),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
            RenderTransform = new ScaleTransform();
            Loaded += appear;
            Pointer.Moved += onPointerIsOver;
            Unloaded += unsubscribe;
        }

        void appear(object sender, RoutedEventArgs e) {
            var anim = new DoubleAnimation() {
                BeginTime = TimeSpan.FromSeconds(0.75),
                Duration = TimeSpan.FromSeconds(0.5),
                To = 0.75,
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
            RenderTransform.BeginAnimation(ScaleTransform.ScaleXProperty, anim);
            RenderTransform.BeginAnimation(ScaleTransform.ScaleYProperty, anim);
        }     
        void onPointerIsOver(double x) {
            if(x == -1) {
                tip.IsOpen = false;
                if (IsSelected) IsSelected = false;
                gradStopAnim.To = 0.25;
                scaleAnim.To = 0.75;
                animate();
                return;
            }
            if (x >= leftBound && x <= rightBound) {
                tip.IsOpen = true;
                if (IsSelected) return;
                if (gradStopAnim.To != 1) {
                    gradStopAnim.To = scaleAnim.To = 1;
                    animate();
                }
            }
            else {
                tip.IsOpen = false;
                if (IsSelected) return;
                if (gradStopAnim.To == 1) {
                    gradStopAnim.To = 0.25;
                    scaleAnim.To = 0.75;
                    animate();
                }
            }            
        }
        void unsubscribe(object sender, RoutedEventArgs e) {
            Loaded -= appear;
            Pointer.Moved -= onPointerIsOver;
            Unloaded -= unsubscribe;
        }
        void animate() {
            firstStop.BeginAnimation(GradientStop.OffsetProperty, gradStopAnim);
            RenderTransform.BeginAnimation(ScaleTransform.ScaleXProperty, scaleAnim);
            RenderTransform.BeginAnimation(ScaleTransform.ScaleYProperty, scaleAnim);
        }
        public void SetCenter(Point center) {
            circle.Center = center;
            leftBound = center.X - radius;
            rightBound = center.X + radius;
            var transform = (ScaleTransform)RenderTransform;
            transform.ScaleX = transform.ScaleY = 0;
            transform.CenterX = center.X;
            transform.CenterY = center.Y;
            InvalidateVisual();
        }       
        protected override void OnRender(DrawingContext dc) => dc.DrawGeometry(radialBrush, null, path.Data);
    }
}
