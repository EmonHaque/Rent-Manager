﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace RentManager.CustomControls
{
    //class ActionButton : FrameworkElement
    //{
    //    Geometry geometry;
    //    ScaleTransform transform;
    //    ColorAnimation anim;
    //    double scaleFactor, cx, cy;
    //    protected SolidColorBrush brush;
    //    protected Color normalColor, highlightColor, downColor;
    //    public string Icon { get; set; }
    //    public Action Command { get; set; }
    //    public ActionButton() {
    //        normalColor = Colors.Black;
    //        highlightColor = Colors.Coral;
    //        downColor = Colors.Red;
    //        brush = new SolidColorBrush(normalColor);
    //        brush = new SolidColorBrush(normalColor);
    //        anim = new ColorAnimation() {
    //            Duration = TimeSpan.FromMilliseconds(500),
    //            EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
    //        };
    //    }
    //    protected void animateBrush(Color color) {
    //        anim.To = color;
    //        brush.BeginAnimation(SolidColorBrush.ColorProperty, anim);
    //    }
    //    protected override void OnInitialized(EventArgs e) {
    //        if(Width == 0) {
    //            Width = Height = 18;
    //        }
    //        geometry = Geometry.Parse(Icon);
    //        scaleFactor = Height / geometry.Bounds.Height;
    //        cx = geometry.Bounds.TopLeft.X;
    //        cy = geometry.Bounds.TopLeft.Y;
    //        transform = new ScaleTransform(scaleFactor, scaleFactor) { CenterX = cx, CenterY = cy };
    //    }
    //    protected override void OnRender(DrawingContext dc) {
    //        dc.PushTransform(transform);
    //        dc.DrawGeometry(brush, null, geometry);
    //    }
    //    protected override void OnMouseEnter(MouseEventArgs e) => animateBrush(highlightColor);
    //    protected override void OnMouseLeave(MouseEventArgs e) => animateBrush(normalColor);
    //    protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e) => Command.Invoke();
    //    protected override void OnMouseDown(MouseButtonEventArgs e) => animateBrush(downColor);
    //    protected override HitTestResult HitTestCore(PointHitTestParameters hitTestParameters) => new PointHitTestResult(this, hitTestParameters.HitPoint);
    //}

    class ActionButton : Border
    {
        string icon;
        public string Icon {
            get { return icon; }
            set { icon = value; ((Path)Child).Data = Geometry.Parse(value); }
        }
        public Action Command { get; set; }
        protected SolidColorBrush brush;
        protected ColorAnimation anim;
        protected Color normalColor, highlightColor, downColor;
        public ActionButton() {
            normalColor = Colors.Black;
            highlightColor = Colors.Coral;
            downColor = Colors.Red;
            brush = new SolidColorBrush(normalColor);

            FocusVisualStyle = null;
            Background = Brushes.Transparent;
            Width = Height = 18;
            VerticalAlignment = VerticalAlignment.Center;
            Child = new Path() {
                Fill = brush,
                Stretch = Stretch.Uniform
            };
            anim = new ColorAnimation() {
                Duration = TimeSpan.FromSeconds(0.5),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
        }
        protected void animateBrush(Color color) {
            anim.To = color;
            brush.BeginAnimation(SolidColorBrush.ColorProperty, anim);
        }
        protected override void OnMouseEnter(MouseEventArgs e) => animateBrush(highlightColor);
        protected override void OnMouseLeave(MouseEventArgs e) => animateBrush(normalColor);
        protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e) => Command.Invoke();
        protected override void OnMouseDown(MouseButtonEventArgs e) => animateBrush(downColor);
    }
}
