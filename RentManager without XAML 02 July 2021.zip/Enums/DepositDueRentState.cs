﻿namespace RentManager.Enums
{
    enum DepositDueRentState
    {
        Rent,
        Deposit,
        Due
    }
}
