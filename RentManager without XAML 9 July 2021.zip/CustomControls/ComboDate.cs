﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;

namespace RentManager.CustomControls
{
    class ComboDate : Grid
    {
        DayPicker day;
        TextBlock block;
        Run text;

        public string Hint { get; set; }
        public string Error { get; set; }
        public string Editable { get; set; }
        public string NonEditable { get; set; }
        public bool IsRequired { get; set; }

        public ComboDate() {
            day = new DayPicker() {
                DateFormat = "dd/MM/yyyy",
                Visibility = Visibility.Hidden 
            };
            text = new Run() { FontSize = 12 };
            block = new TextBlock();
            Children.Add(day);
            Children.Add(block);
            Loaded += onLoaded;
            Unloaded += onUnloaded;
        }

        void onUnloaded(object sender, RoutedEventArgs e) {
            Loaded -= onLoaded;
            Unloaded -= onUnloaded;
        }
        void onLoaded(object sender, RoutedEventArgs e) {
            text.SetBinding(Run.TextProperty, new Binding(NonEditable) { StringFormat = "dd MMMM yyyy"});
            block.Inlines.Add(new Run() {
                Foreground = Brushes.Gray,
                FontStyle = FontStyles.Italic,
                FontSize = 11,
                Text = Hint
            });
            block.Inlines.Add(new LineBreak());
            block.Inlines.Add(text);

            day.Hint = Hint;
            day.SetBinding(DayPicker.SelectedDateProperty, new Binding(Editable));
            if (IsRequired) {
                day.IsRequired = true;
                day.SetBinding(DayPicker.ErrorProperty, new Binding(Error));
            }
        }

        public bool IsOnEdit {
            get { return (bool)GetValue(IsOnEditProperty); }
            set { SetValue(IsOnEditProperty, value); }
        }
        public static readonly DependencyProperty IsOnEditProperty =
            DependencyProperty.Register("IsOnEdit", typeof(bool), typeof(ComboDate), new PropertyMetadata() {
                DefaultValue = false,
                PropertyChangedCallback = (s, e) => {
                    var o = (ComboDate)s;
                    if ((bool)e.NewValue) {
                        o.day.Visibility = Visibility.Visible;
                        o.block.Visibility = Visibility.Hidden;
                    }
                    else {
                        o.day.Visibility = Visibility.Hidden;
                        o.block.Visibility = Visibility.Visible;
                    }
                }
            });
    }
}
