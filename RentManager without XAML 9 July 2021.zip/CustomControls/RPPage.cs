﻿using RentManager.Helpers;
using RentManager.Models;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;

namespace RentManager.CustomControls
{
    class RPPage
    {
        double margin, remainingHeight;
        StackPanel header;
        Grid content;
        Border footer, columnNames;
        TextBlock title, period, footNoteBlock;
        ItemsControl entries;
        Run currentPage, totalPage;

        public FixedPage Page { get; set; }
        public Size PageSize { get; set; }
        public int PageNo { get; set; }
        public string Title { get; set; }
        public string Period { get; set; }
        string footNote;
        public string FootNote {
            get { return footNote; }
            set { footNote = value; footNoteBlock.Text = value; measure(); }
        }
        int numberOfPage;
        public int NumberOfPage {
            get { return numberOfPage; }
            set { numberOfPage = value; totalPage.Text = value.ToString(); }
        }
        bool isComplete;
        public bool IsComplete {
            get { return isComplete; }
            set { isComplete = value; entries.UpdateLayout(); }
        }
        public RPPage(Size pageSize) {
            margin = 96d * 0.7;
            initializeHeader();
            initializeContent();
            initializeFooter();
            PageSize = pageSize;
            PageNo = 1;
            Page = new FixedPage() {
                Width = PageSize.Width,
                Height = PageSize.Height,
                Margin = new Thickness(margin),
                Children = { header, content, footer }
            };
        }
        public RPPage(RPPage previousPage) : this(previousPage.PageSize) {
            Title = previousPage.Title;
            Period = previousPage.Period;
            PageNo = previousPage.PageNo + 1;
            FootNote = previousPage.FootNote;
        }
        void initializeHeader() {
            title = new TextBlock() { FontSize = 16, TextAlignment = TextAlignment.Center };
            period = new TextBlock() { FontSize = 12, TextAlignment = TextAlignment.Center };

            var colParticulars = new TextBlock() { Text = "Particulars", HorizontalAlignment = HorizontalAlignment.Left };
            var colReceivable = new TextBlock() { Text = "Cash", HorizontalAlignment = HorizontalAlignment.Right };
            var colReceipt = new TextBlock() { Text = "Kind", HorizontalAlignment = HorizontalAlignment.Right };
            var colBalance = new TextBlock() { Text = "Total", HorizontalAlignment = HorizontalAlignment.Right };
            
            Grid.SetColumn(colReceivable, 1);
            Grid.SetColumn(colReceipt, 2);
            Grid.SetColumn(colBalance, 3);
            var columnGrid = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) }
                },
                Children = { colParticulars, colReceivable, colReceipt, colBalance }
            };
            columnNames = new Border() {
                BorderThickness = new Thickness(0, .5, 0, .5),
                BorderBrush = Brushes.Black,
                Child = columnGrid
            };
            header = new StackPanel() {
                Resources = {
                    {
                        typeof(TextBlock),
                        new Style() {
                            Setters = {
                                new Setter(TextBlock.FontWeightProperty, FontWeights.Bold)
                            }
                        }
                    }
                },
                Children = { title, period, columnNames }
            };
        }
        void initializeContent() {
            entries = new ItemsControl() { HorizontalContentAlignment = HorizontalAlignment.Stretch };
            content = new Grid() { Children = { entries} };
        }
        void initializeFooter() {
            footNoteBlock = new TextBlock();
            currentPage = new Run();
            totalPage = new Run();
            var pageNo = new TextBlock() {
                Inlines = {
                    currentPage,
                    new Run(){Text = "/" },
                    totalPage
                }
            };
            Grid.SetColumn(pageNo, 1);
            var grid = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto }
                },
                Children = { footNoteBlock, pageNo }
            };
            footer = new Border() {
                BorderThickness = new Thickness(0, .5, 0, 0),
                BorderBrush = Brushes.Black,
                Child = grid
            };
        }
        void measure() {
            var availableSize = new Size(PageSize.Width - 2 * margin, PageSize.Height - 2 * margin);           
            title.Text = Title;
            period.Text = Period;
            currentPage.Text = "Page: " + PageNo;

            double y = 0;
            foreach (FrameworkElement item in Page.Children) {
                item.Width = availableSize.Width;
                item.Measure(availableSize);
                FixedPage.SetTop(item, y);
                y += item.DesiredSize.Height;
            }
            var contentHeight = availableSize.Height - header.DesiredSize.Height - footer.DesiredSize.Height;
            content.Height = contentHeight;
            remainingHeight = contentHeight;
            FixedPage.SetTop(footer, header.DesiredSize.Height + contentHeight);
        }
        public bool AddEntry(object entry) {
            ContentControl content;
            if (entry is Tuple<int, string>) content = new RPHeaderItem((Tuple<int, string>)entry);
            else if (entry is Tuple<int, ReceiptPayment>) content = new RPEntryItem((Tuple<int, ReceiptPayment>)entry);
            else content = new RPFooterItem((Tuple<int, string, int, int, int>)entry);
            content.Measure(PageSize);
            content.UpdateLayout();
            remainingHeight -= content.DesiredSize.Height;
            if (remainingHeight < 0) return false;
            entries.Items.Add(content);
            return true;
        }
    }

    class RPHeaderItem : ContentControl
    {
        public RPHeaderItem(Tuple<int, string> header) {
            Content = new TextBlock() {
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(10 * header.Item1, 0, 0, 0),
                Text = header.Item2
            };
        }
    }
    class RPEntryItem : ContentControl
    {
        public RPEntryItem(Tuple<int, ReceiptPayment> entry) {
            var text = new TextBlock() {
                Margin = new Thickness(10 * entry.Item1, 0, 0, 0),
                HorizontalAlignment = HorizontalAlignment.Left
            };
            var cash = new TextBlock() { Text = entry.Item2.Cash.ToString(Constants.NumberFormat) };
            var kind = new TextBlock() { Text = entry.Item2.Kind.ToString(Constants.NumberFormat) };
            var total = new TextBlock() { Text = entry.Item2.Total.ToString(Constants.NumberFormat) };

            if (entry.Item1 == 3) {
                var tenant = new Run() { Text = entry.Item2.Tenant };
                var space = new Run() { Text = " - " + entry.Item2.Space };
                text.Inlines.Add(tenant);
                text.Inlines.Add(space);
            }
            else text.Text = entry.Item2.Space;

            Grid.SetColumn(cash, 1);
            Grid.SetColumn(kind, 2);
            Grid.SetColumn(total, 3);
            Content = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) }
                },
                Resources = {
                    {
                        typeof(TextBlock),
                        new Style() {
                            Setters = {
                                new Setter(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right)
                            }
                        }
                    }
                },
                Children = { text, cash, kind, total }
            };
        }
    }
    class RPFooterItem : ContentControl
    {
        public RPFooterItem(Tuple<int, string, int, int, int> footer) {
            var text = new TextBlock() {
                Margin = new Thickness(10 * footer.Item1, 0, 0, 0),
                Text = "Total " + footer.Item2,
                HorizontalAlignment = HorizontalAlignment.Left,

            };
            var cash = new TextBlock() { Text = footer.Item3.ToString(Constants.NumberFormat) };
            var kind = new TextBlock() { Text = footer.Item4.ToString(Constants.NumberFormat) };
            var total = new TextBlock() { Text = footer.Item5.ToString(Constants.NumberFormat) };
            var separator = new Separator() { Background = Brushes.Black, Height = 0.5 };
            Grid.SetColumn(cash, 1);
            Grid.SetColumn(kind, 2);
            Grid.SetColumn(total, 3);
            Grid.SetColumn(separator, 1);
            Grid.SetColumnSpan(separator, 3);
            Content = new Grid() {
                RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition()
                },
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) }
                },
                Resources = {
                    {
                        typeof(TextBlock),
                        new Style() {
                            Setters = {
                                new Setter(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right),
                                new Setter(Grid.RowProperty, 1)
                            }
                        }
                    }
                },
                Children = { separator, text, cash, kind, total }
            };
        }
    }
}
