﻿namespace RentManager.Enums
{
    enum CalendarState
    {
        Day,
        Month,
        Year
    }
}
