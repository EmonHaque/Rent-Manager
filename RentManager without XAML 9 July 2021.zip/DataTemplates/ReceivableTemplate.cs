﻿using RentManager.CustomControls;
using RentManager.Helpers;
using RentManager.Models;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace RentManager.DataTemplates
{
    class ReceivableTemplate : DataTemplate
    {
        public ReceivableTemplate() {
            var grid = new FrameworkElementFactory(typeof(Grid));
            var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var head = new FrameworkElementFactory(typeof(TextBlock));
            var amount = new FrameworkElementFactory(typeof(TextBlock));
            col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(1, GridUnitType.Auto));
            amount.SetValue(Grid.ColumnProperty, 1);
            amount.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
            head.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
            head.SetBinding(TextBlock.TextProperty, new Binding(nameof(Receivable.HeadId)) { Converter = Converters.headId2headName });
            amount.SetBinding(TextBlock.TextProperty, new Binding(nameof(Receivable.Amount)) { StringFormat = "N0" });
            grid.AppendChild(col1);
            grid.AppendChild(col2);
            grid.AppendChild(head);
            grid.AppendChild(amount);
            VisualTree = grid;
        }

        public ReceivableTemplate(Binding command) {
            var grid = new FrameworkElementFactory(typeof(Grid));
            var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var head = new FrameworkElementFactory(typeof(TextBlock));
            var amount = new FrameworkElementFactory(typeof(TextBlock));
            var button = new FrameworkElementFactory(typeof(DependencyButton<Receivable>));
            col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(1, GridUnitType.Auto));
            col3.SetValue(ColumnDefinition.WidthProperty, new GridLength(1, GridUnitType.Auto));
            amount.SetValue(Grid.ColumnProperty, 1);
            amount.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
            head.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
            button.SetValue(Grid.ColumnProperty, 2);
            button.SetValue(FrameworkElement.WidthProperty, 16d);
            button.SetValue(FrameworkElement.HeightProperty, 16d);
            button.SetValue(FrameworkElement.MarginProperty, new Thickness(10, 2, 0, 2));
            button.SetValue(DependencyButton<Receivable>.IconProperty, Icons.Minus);
            button.SetBinding(DependencyButton<Receivable>.CommandProperty, command);
            button.SetBinding(DependencyButton<Receivable>.ParameterProperty, new Binding("."));
            head.SetBinding(TextBlock.TextProperty, new Binding(nameof(Receivable.HeadId)) { Converter = Converters.headId2headName });
            amount.SetBinding(TextBlock.TextProperty, new Binding(nameof(Receivable.Amount)) { StringFormat = "N0" });
            grid.AppendChild(col1);
            grid.AppendChild(col2);
            grid.AppendChild(col3);
            grid.AppendChild(head);
            grid.AppendChild(amount);
            grid.AppendChild(button);
            VisualTree = grid;
        }
    }
}
