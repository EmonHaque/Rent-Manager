﻿using System.Windows.Controls;

namespace Rent.View
{
    /// <summary>
    /// Interaction logic for TransactView.xaml
    /// </summary>
    public partial class TransactView : UserControl
    {
        public TransactView()
        {
            InitializeComponent();
        }
    }
}
