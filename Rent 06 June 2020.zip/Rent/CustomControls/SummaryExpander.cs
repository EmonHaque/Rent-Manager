﻿using System.Windows;
using System.Windows.Controls;

namespace Rent.CustomControls
{
    public class SummaryExpander : Expander
    {
        static SummaryExpander()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(SummaryExpander), new FrameworkPropertyMetadata(typeof(SummaryExpander)));
        }
    }
}
