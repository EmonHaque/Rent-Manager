﻿using System.Windows;
using System.Windows.Controls;

namespace Rent.CustomControls
{
    public class EditText : Control
    {
        static EditText()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(EditText), new FrameworkPropertyMetadata(typeof(EditText)));
        }

        public string Label
        {
            get { return (string)GetValue(LabelProperty); }
            set { SetValue(LabelProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Label.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty LabelProperty =
            DependencyProperty.Register("Label", typeof(string), typeof(EditText), new PropertyMetadata(null));


        public string NonEditable
        {
            get { return (string)GetValue(NonEditableProperty); }
            set { SetValue(NonEditableProperty, value); }
        }

        // Using a DependencyProperty as the backing store for NonEditable.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty NonEditableProperty =
            DependencyProperty.Register("NonEditable", typeof(string), typeof(EditText), new PropertyMetadata(null));


        public string Editable
        {
            get { return (string)GetValue(EditableProperty); }
            set { SetValue(EditableProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Editable.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty EditableProperty =
            DependencyProperty.Register("Editable", typeof(string), typeof(EditText), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));


        public bool IsOnEdit
        {
            get { return (bool)GetValue(IsOnEditProperty); }
            set { SetValue(IsOnEditProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsOnEdit.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsOnEditProperty =
            DependencyProperty.Register("IsOnEdit", typeof(bool), typeof(EditText), new PropertyMetadata(false, OnIsOnEditChanged));

        static void OnIsOnEditChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if ((bool)e.NewValue) (d as EditText).IsNotOnEdit = false;
            else (d as EditText).IsNotOnEdit = true;
        }

        public bool IsNotOnEdit
        {
            get { return (bool)GetValue(IsNotOnEditProperty); }
            set { SetValue(IsNotOnEditProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsNotOnEdit.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsNotOnEditProperty =
            DependencyProperty.Register("IsNotOnEdit", typeof(bool), typeof(EditText), new PropertyMetadata(true));


        public bool AcceptReturn
        {
            get { return (bool)GetValue(AcceptReturnProperty); }
            set { SetValue(AcceptReturnProperty, value); }
        }

        // Using a DependencyProperty as the backing store for AcceptReturn.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty AcceptReturnProperty =
            DependencyProperty.Register("AcceptReturn", typeof(bool), typeof(EditText), new PropertyMetadata(false, OnAcceptReturnChanged));

        static void OnAcceptReturnChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if ((bool)e.NewValue)
            {
                (d as EditText).TextWrap = TextWrapping.Wrap;
                (d as EditText).MinimumHeight = 60;
            }
        }

        public TextWrapping TextWrap
        {
            get { return (TextWrapping)GetValue(TextWrapProperty); }
            set { SetValue(TextWrapProperty, value); }
        }

        // Using a DependencyProperty as the backing store for TextWrap.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TextWrapProperty =
            DependencyProperty.Register("TextWrap", typeof(TextWrapping), typeof(EditText), new PropertyMetadata(TextWrapping.NoWrap));


        public double MinimumHeight
        {
            get { return (double)GetValue(MinimumHeightProperty); }
            set { SetValue(MinimumHeightProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MinimumHeight.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MinimumHeightProperty =
            DependencyProperty.Register("MinimumHeight", typeof(double), typeof(EditText), new PropertyMetadata(0d));
    }
}
