﻿using System.Windows;
using System.Windows.Controls;

namespace Rent.CustomControls
{
    public class SummaryList : ListBox
    {
        static SummaryList()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(SummaryList), new FrameworkPropertyMetadata(typeof(SummaryList)));
        }
    }
}
