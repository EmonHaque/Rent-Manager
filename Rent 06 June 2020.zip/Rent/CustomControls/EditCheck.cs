﻿using System.Windows;
using System.Windows.Controls;

namespace Rent.CustomControls
{
    public class EditCheck : Control
    {
        static EditCheck()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(EditCheck), new FrameworkPropertyMetadata(typeof(EditCheck)));
        }

        public object Label
        {
            get { return (object)GetValue(LabelProperty); }
            set { SetValue(LabelProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Label.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty LabelProperty =
            DependencyProperty.Register("Label", typeof(object), typeof(EditCheck), new PropertyMetadata(null));


        public bool NonEditable
        {
            get { return (bool)GetValue(NonEditableProperty); }
            set { SetValue(NonEditableProperty, value); }
        }

        // Using a DependencyProperty as the backing store for NonEditable.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty NonEditableProperty =
            DependencyProperty.Register("NonEditable", typeof(bool), typeof(EditCheck), new PropertyMetadata(false));


        public bool Editable
        {
            get { return (bool)GetValue(EditableProperty); }
            set { SetValue(EditableProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Editable.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty EditableProperty =
            DependencyProperty.Register("Editable", typeof(bool), typeof(EditCheck), new FrameworkPropertyMetadata(false, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));

        public bool Enabled
        {
            get { return (bool)GetValue(EnabledProperty); }
            set { SetValue(EnabledProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Enabled.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty EnabledProperty =
            DependencyProperty.Register("Enabled", typeof(bool), typeof(EditCheck), new PropertyMetadata(true));



        public bool IsOnEdit
        {
            get { return (bool)GetValue(IsOnEditProperty); }
            set { SetValue(IsOnEditProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsOnEdit.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsOnEditProperty =
            DependencyProperty.Register("IsOnEdit", typeof(bool), typeof(EditCheck), new PropertyMetadata(false, OnIsOnEditChanged));

        static void OnIsOnEditChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if ((bool)e.NewValue) (d as EditCheck).IsNotOnEdit = false;
            else (d as EditCheck).IsNotOnEdit = true;
        }

        public bool IsNotOnEdit
        {
            get { return (bool)GetValue(IsNotOnEditProperty); }
            set { SetValue(IsNotOnEditProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsNotOnEdit.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsNotOnEditProperty =
            DependencyProperty.Register("IsNotOnEdit", typeof(bool), typeof(EditCheck), new PropertyMetadata(true));
    }
}
