﻿using Rent.Model;
using Rent.VM;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Rent.CustomControls
{
    public class FilterListBox : Control
    {
        IEnumerable<Tenant> OriginalSource, NewSource;
        ItemsSource CurrentSource;

        static FilterListBox()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(FilterListBox), new FrameworkPropertyMetadata(typeof(FilterListBox)));
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            EditVM.OnTenantLeft += TenantLeft;
            EditVM.OnTenantReturn += TenantReturned;
        }

        void TenantReturned(Tenant obj)
        {
            if (CurrentSource == ItemsSource.Filtered)
                NewSource.First(x => x.Id == obj.Id).HasLeft = false;
        }

        void TenantLeft(Tenant obj)
        {
            if (CurrentSource == ItemsSource.Filtered)
                NewSource.First(x => x.Id == obj.Id).HasLeft = true;
        }

        public string FilterText
        {
            get { return (string)GetValue(FilterTextProperty); }
            set { SetValue(FilterTextProperty, value); }
        }

        // Using a DependencyProperty as the backing store for FilterText.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty FilterTextProperty =
            DependencyProperty.Register("FilterText", typeof(string), typeof(FilterListBox), new PropertyMetadata(null, onTextChanged));

        static void onTextChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var o = (d as FilterListBox);
            o.OriginalSource ??= o.Source as IEnumerable<Tenant>;
            var text = o.FilterText.Trim().ToLower();

            if (!string.IsNullOrWhiteSpace(text))
            {
                o.NewSource = o.OriginalSource.Where(x => x.Name.ToLower().Contains(text));
                o.Source = o.NewSource;
                o.CurrentSource = ItemsSource.Filtered;
            }
            else
            {
                o.Source = o.OriginalSource;
                o.CurrentSource = ItemsSource.Original;
            }
        }

        public IEnumerable Source
        {
            get { return (IEnumerable)GetValue(SourceProperty); }
            set { SetValue(SourceProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Source.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SourceProperty =
            DependencyProperty.Register("Source", typeof(IEnumerable), typeof(FilterListBox), new PropertyMetadata(null));


        public object Selected
        {
            get { return (object)GetValue(SelectedProperty); }
            set { SetValue(SelectedProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Selected.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SelectedProperty =
            DependencyProperty.Register("Selected", typeof(object), typeof(FilterListBox), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));
    }

    public enum ItemsSource
    {
        Original,
        Filtered
    }
}
