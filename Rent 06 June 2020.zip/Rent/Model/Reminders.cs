﻿using System.Collections.Generic;

namespace Rent.Model
{
    class Reminders
    {
        public List<string> GetReminders()
        {
            return new List<string>()
            {
                "If you've to pass entries under the Head \"Receivables\" manually in \"Pass Entry\" section, make sure to put either the Long Month Name, Year (eg. \"December, 3030\") or \"period from 15 January, 3030 to 31 January, 3030\", for example, in Narration since that's been used as Period for Invoice.",
                "Choose only a \"From\" date on which you've \"Receivable\" entries before printing Invoice.",
                "No chance for deleting any kind of record, to some extent you can edit.",
                "No chance for editing or deleting Transaction, pass necessary rectification entry, if required."
            };
        }
    }
}
