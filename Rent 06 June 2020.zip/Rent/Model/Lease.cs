﻿using Rent.VM;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Rent.Model
{
    [Serializable]
	public class Lease : INotifyPropertyChanged
	{

		int id;
		public int Id { get => id; set { id = value; OnPropertyChanged(); } }

		int plotId;
		public int PlotId { get => plotId; set { plotId = value; OnPropertyChanged(); } }

		int spaceId;
		public int SpaceId { get => spaceId; set { spaceId = value; OnPropertyChanged(); } }

		int tenantId;
		public int TenantId { get => tenantId; set { tenantId = value; OnPropertyChanged(); } }

		DateTime date;
		public DateTime Date { get => date; set { date = value; OnPropertyChanged(); } }

		string business;
		public string Business { get => business; set { business = value; OnPropertyChanged(); } }

		bool isExpired;
		public bool IsExpired { get => isExpired; set { isExpired = value; OnPropertyChanged(); } }

		ObservableCollection<Receivable> fixedReceivables;
		public ObservableCollection<Receivable> FixedReceivables { get => fixedReceivables; set { fixedReceivables = value; OnPropertyChanged(); } }

		public Lease()
		{
			App.Current.Dispatcher.Invoke(() => FixedReceivables = new ObservableCollection<Receivable>());
		}

		public bool IsValid()
		{
			return !MainVM.LeaseBusy && 
				Id > 0 &&
				PlotId > 0 &&
				SpaceId > 0 &&
				TenantId > 0 &&
				!string.IsNullOrWhiteSpace(business) && 
				FixedReceivables.Count > 0;
		}

		#region Notify Property Changed Members
		[field: NonSerialized]
		public event PropertyChangedEventHandler PropertyChanged;
		void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
		#endregion
	}

}
