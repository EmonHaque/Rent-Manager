﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Rent.Model
{
    [Serializable]
	public class Receivable : INotifyPropertyChanged
	{

		int leaseId;
		public int LeaseId { get => leaseId; set { leaseId = value; OnPropertyChanged(); } }

		int headId;
		public int HeadId { get => headId; set { headId = value; OnPropertyChanged(); } }

		int amount;
		public int Amount { get => amount; set { amount = value; OnPropertyChanged(); } }

		public bool IsValid()
		{
			return LeaseId > 0 &&
				HeadId > 0 &&
				Amount > 0;
		}

		#region Notify Property Changed Members
		[field: NonSerialized]
		public event PropertyChangedEventHandler PropertyChanged;
		void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
		#endregion
	}
}
