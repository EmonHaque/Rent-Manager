﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Rent.Model
{
    public class ReportDates : INotifyPropertyChanged
	{

        DateTime start;
        public DateTime Start { get => start; set { start = value; OnPropertyChanged(); } }

        DateTime end;
        public DateTime End { get => end; set { end = value; OnPropertyChanged(); } }

        DateTime from;
		public DateTime From { get => from; set { from = value; OnPropertyChanged(); } }

		DateTime to;
		public DateTime To { get => to; set { to = value; OnPropertyChanged(); } }

		public ReportDates()
		{
			From = DateTime.Now;
			To = DateTime.Now;
		}
		#region Notify Property Changed Members
		public event PropertyChangedEventHandler PropertyChanged;
		void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
		#endregion
	}

}
