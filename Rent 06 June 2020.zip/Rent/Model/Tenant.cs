﻿using Rent.VM;
using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Rent.Model
{
    [Serializable]
	public class Tenant : INotifyPropertyChanged
	{

		int id;
		public int Id { get => id; set { id = value; OnPropertyChanged(); } }

		string name;
		public string Name { get => name; set { name = value; OnPropertyChanged(); } }

		string father;
		public string Father { get => father; set { father = value; OnPropertyChanged(); } }

		string mother;
		public string Mother { get => mother; set { mother = value; OnPropertyChanged(); } }

		string husband;
		public string Husband { get => husband; set { husband = value; OnPropertyChanged(); } }

		string address;
		public string Address { get => address; set { address = value; OnPropertyChanged(); } }

		string nid;
		public string NID { get => nid; set { nid = value; OnPropertyChanged(); } }

		string contactNo;
		public string ContactNo { get => contactNo; set { contactNo = value; OnPropertyChanged(); } }

		bool hasLeft;
		public bool HasLeft { get => hasLeft; set { hasLeft = value; OnPropertyChanged(); } }

		public bool IsValid()
		{
			return !MainVM.TenantBusy && 
				Id > 0 &&
				!string.IsNullOrWhiteSpace(Name) &&
				!string.IsNullOrWhiteSpace(Father) &&
				!string.IsNullOrWhiteSpace(Address) &&
				!string.IsNullOrWhiteSpace(ContactNo);
		}

		#region Notify Property Changed Members
		[field: NonSerialized]
		public event PropertyChangedEventHandler PropertyChanged;
		void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
		#endregion
	}

}
