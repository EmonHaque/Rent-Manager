﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Rent.Model
{

    public class CommonNarration : INotifyPropertyChanged
    {

        DateTime date;
        public DateTime Date { get => date; set { date = value; OnPropertyChanged(); } }

        string narration;
        public string Narration { get => narration; set { narration = value; OnPropertyChanged(); } }

        public CommonNarration()
        {
            Date = DateTime.Now;
        }

        public bool IsValid() => !string.IsNullOrWhiteSpace(Narration);

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }
}
