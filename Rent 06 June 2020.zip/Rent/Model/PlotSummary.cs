﻿using System.Collections.Generic;

namespace Rent.Model
{
    public class PlotSummary
    {
        public string Name { get; set; }
        public int Spaces { get; set; }
        public int Leases { get; set; }
        public int Receivables { get; set; }
        public List<Lease> ListLeases { get; set; }
        public int LeaseReceivable { get; set; }
    }
}
