﻿using Microsoft.Data.Sqlite;
using Rent.Common;
using Rent.Model;
using Rent.View.Edit;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace Rent.VM
{
    public class EditVM : INotifyPropertyChanged
    {
        Plot editedPlot;
        Space editedSpace;
        Tenant editedTenant, occupiedBy;
        Lease editedLease, spaceLease;
        Head editedHead;
        Receivable newReceivable;
        Tab selectedTab;
        bool isOnEdit;
        OCollection<Space> filteredSpaces;
        OCollection<Lease> filteredLeases;
        List<Lease> tenantsLease;

        public Plot EditedPlot { get => editedPlot; set { editedPlot = value; OnPropertyChanged(); } }
        public Space EditedSpace { get => editedSpace; set { editedSpace = value; OnPropertyChanged(); } }
        public Tenant EditedTenant { get => editedTenant; set { editedTenant = value; OnPropertyChanged(); } }
        public Tenant OccupiedBy { get => occupiedBy; set { occupiedBy = value; OnPropertyChanged(); } }
        public Lease EditedLease { get => editedLease; set { editedLease = value; OnPropertyChanged(); } }
        public Lease SpaceLease { get => spaceLease; set { spaceLease = value; OnPropertyChanged(); } }
        public Head EditedHead { get => editedHead; set { editedHead = value; OnPropertyChanged(); } }
        public Receivable NewReceivable { get => newReceivable; set { newReceivable = value; OnPropertyChanged(); } }
        public Tab SelectedTab { get => selectedTab; set { selectedTab = value; OnPropertyChanged(); if (value != null) IsOnEdit = false; OnTabChanged?.Invoke(value); } }
        public bool IsOnEdit { get => isOnEdit; set { isOnEdit = value; OnPropertyChanged(); } }
        public OCollection<Space> FilteredSpaces { get => filteredSpaces; set { filteredSpaces = value; OnPropertyChanged(); } }
        public OCollection<Lease> FilteredLeases { get => filteredLeases; set { filteredLeases = value; OnPropertyChanged(); } }
        public List<Lease> TenantsLease { get => tenantsLease; set { tenantsLease = value; OnPropertyChanged(); } }

        public List<Tab> Tabs { get; set; }

        public Command SetIsOnEdit { get; set; }
        public Command ResetIsOnEdit { get; set; }
        public Command SavePlot { get; set; }
        public Command SaveSpace { get; set; }
        public Command SaveTenant { get; set; }
        public Command SaveLease { get; set; }
        public Command SaveHead { get; set; }
        public Command AddReceivable { get; set; }
        public Command RemoveReceivable { get; set; }

        public static event Action<Space> OnSpaceVacated, OnVacantSpaceEdited;
        public static event Action<Tenant> OnTenantLeft, OnTenantReturn, OnAvailableTenantEdited;
        public event Action<Tab> OnTabChanged;

        public EditVM()
        {
            initializeProperties();
            initializeICommands();
            initializeTabs();
            MainVM.DataLoaded += initializeCollections;
            MainVM.OnSelectedPlotChanged += filter;
            MainVM.OnSelectedReceivableHeadChanged += headId => NewReceivable.HeadId = headId;
            MainVM.OnSelectedLeaseChanged += leaseId => { NewReceivable.LeaseId = leaseId; IsOnEdit = false; };
            MainVM.OnSelectedSpaceChanged += spaceId =>
            {
                
                IsOnEdit = false;
                if (SelectedTab.Type == ViewType.Space)
                    updateSpaceLeaseInfo(spaceId);
            };
            MainVM.OnSelectedTenantChanged += tenantId =>
            {
                IsOnEdit = false;
                if (SelectedTab.Type == ViewType.Tenant)
                    updateTenantsLeaseInfo(tenantId);

            };
            MainVM.OnSelectedIconChanged += icon => IsOnEdit = false;

            AddVM.OnSpaceAdded += space => FilteredSpaces.Add(space);
            AddVM.OnLeaseAdded += lease => FilteredLeases.Add(lease);
        }

        void updateSpaceLeaseInfo(int spaceId)
        {
            SpaceLease = MainVM.Leases.FirstOrDefault(x => x.SpaceId == spaceId);
            OccupiedBy = MainVM.Tenants.FirstOrDefault(x => x.Id == SpaceLease?.TenantId);
        }

        void updateTenantsLeaseInfo(int tenantId)
        {
            TenantsLease = MainVM.Leases.Where(x => x.TenantId == tenantId).ToList();
        }

        void filter(int plotId)
        {
            if (IsOnEdit) IsOnEdit = false;
            App.Current.Dispatcher.Invoke(() =>
            {
                FilteredSpaces = new OCollection<Space>(MainVM.Spaces.Where(x => x.PlotId == plotId));
                FilteredLeases = new OCollection<Lease>(MainVM.Leases.Where(x => x.PlotId == MainVM.SelectedPlot.Id));
            });
        }

        void initializeCollections()
        {
            if(MainVM.SelectedPlot != null)
            {
                FilteredSpaces = new OCollection<Space>(MainVM.Spaces.Where(x => x.PlotId == MainVM.SelectedPlot.Id));
                FilteredLeases = new OCollection<Lease>(MainVM.Leases.Where(x => x.PlotId == MainVM.SelectedPlot.Id));
            }
            if (MainVM.SelectedReceivableHead != null)
                NewReceivable.HeadId = MainVM.SelectedReceivableHead.Id;
        }

        void initializeProperties()
        {
            EditedPlot = new Plot();
            EditedSpace = new Space();
            EditedTenant = new Tenant();
            EditedLease = new Lease();
            EditedHead = new Head();
            NewReceivable = new Receivable();
        }

        void initializeICommands()
        {
            SetIsOnEdit = new Command(setIsOnEdit, isEditValid);
            ResetIsOnEdit = new Command(resetIsOnEdit, (o) => true);
            SavePlot = new Command(savePlot, (o) => EditedPlot.IsValid());
            SaveSpace = new Command(saveSpace, (o) => EditedSpace.IsValid());
            SaveTenant = new Command(saveTenant, (o) => EditedTenant.IsValid());
            SaveLease = new Command(saveLease, (o) => EditedLease.IsValid());
            SaveHead = new Command(saveHead, (o) => EditedHead.IsValid());
            AddReceivable = new Command(addReceivable, (o) => NewReceivable.IsValid());
            RemoveReceivable = new Command(removeReceivable, (o) => true);
        }

        void initializeTabs()
        {
            Tabs = new List<Tab>()
            {
                new Tab("Plot", ViewType.Plot, new PlotView() { DataContext = this }, Constants.PlotIcon),
                new Tab("Space", ViewType.Space, new SpaceView() { DataContext = this }, Constants.SpaceIcon),
                new Tab("Tenant", ViewType.Tenant, new TenantView() { DataContext = this }, Constants.TenantIcon),
                new Tab("Lease", ViewType.Lease, new LeaseView() { DataContext = this }, Constants.LeaseIcon),
                new Tab("Head", ViewType.Head, new HeadView() { DataContext = this }, Constants.HeadIcon)
            };
            SelectedTab = Tabs.First();
            OnTabChanged += upDateLeaseInfo;
        }

        void upDateLeaseInfo(Tab t)
        {
            switch (SelectedTab.Type)
            {
                case ViewType.Space:
                    if(MainVM.SelectedSpace != null) updateSpaceLeaseInfo(MainVM.SelectedSpace.Id);
                    break;
                case ViewType.Tenant:
                    if (MainVM.SelectedTenant != null) updateTenantsLeaseInfo(MainVM.SelectedTenant.Id);
                    break;
            }
        }

        void setIsOnEdit(object o)
        {
            switch (SelectedTab.Type)
            {
                case ViewType.Plot: EditedPlot = MainVM.SelectedPlot.DeepClone(); break;
                case ViewType.Space: EditedSpace = MainVM.SelectedSpace.DeepClone(); break;
                case ViewType.Tenant: EditedTenant = MainVM.SelectedTenant.DeepClone(); break;
                case ViewType.Lease: EditedLease = MainVM.SelectedLease.DeepClone(); break;
                case ViewType.Head: EditedHead = MainVM.SelectedHead.DeepClone(); break;
            }
            IsOnEdit = true;
        }

        bool isEditValid(object o)
        {
            return SelectedTab.Type switch
            {
                ViewType.Plot => MainVM.SelectedPlot != null,
                ViewType.Space => MainVM.SelectedSpace != null,
                ViewType.Tenant => MainVM.SelectedTenant != null,
                ViewType.Lease => MainVM.SelectedLease != null,
                ViewType.Head => MainVM.SelectedHead != null
            };
        }

        void resetIsOnEdit(object o) => IsOnEdit = false;

        void savePlot(object o)
        {
            MainVM.DoAsynchronously(ViewType.Plot, () =>
            {
                if (!EditedPlot.IsEqualTo(MainVM.SelectedPlot))
                {
                    using var cmd = SQLHelper.connection.CreateCommand();
                    cmd.CommandText = "UPDATE Plots SET Name = @Name, Description = @Description WHERE Id = @Id";
                    cmd.Parameters.AddWithValue("@Name", EditedPlot.Name);
                    cmd.Parameters.AddWithValue("@Description", EditedPlot.Description);
                    cmd.Parameters.AddWithValue("@Id", EditedPlot.Id);
                    SQLHelper.NonQuery(cmd);

                    var index = MainVM.Plots.IndexOf(MainVM.SelectedPlot);
                    MainVM.Plots[index] = EditedPlot;
                    MainVM.SelectedPlot = EditedPlot;

                    //to Update Transact View (Fixed Monthly receivable Part)
                    MainVM.Leases.RaiseCollectionChanged();
                }
            });
        }

        void saveSpace(object o)
        {
            MainVM.DoAsynchronously(ViewType.Space, () =>
            {
                if (!EditedSpace.IsEqualTo(MainVM.SelectedSpace))
                {
                    string tenantName, spaceName;
                    tenantName = spaceName = string.Empty;

                    var commands = new List<SqliteCommand>();
                    if (EditedSpace.IsVacant && !MainVM.SelectedSpace.IsVacant)
                    {
                        var lease = MainVM.Leases.FirstOrDefault(x => x.SpaceId == EditedSpace.Id);
                        if (lease != null)
                        {
                            tenantName = MainVM.Tenants.First(x => x.Id == lease.TenantId).Name;
                            spaceName = MainVM.Spaces.First(x => x.Id == lease.SpaceId).Name;

                            commands.Add(new SqliteCommand($"UPDATE Leases SET IsExpired = 1 WHERE Id = {lease.Id}"));
                            foreach (var item in lease.FixedReceivables)
                                commands.Add(new SqliteCommand($"DELETE FROM Receivables WHERE LeaseId = {lease.Id}"));

                            MainVM.Leases.Remove(lease);
                            FilteredLeases.Remove(lease);
                        }
                        FilteredSpaces.First(x => x.Id == EditedSpace.Id).IsVacant = true;
                        OnSpaceVacated?.Invoke(EditedSpace);
                    }

                    var cmd = new SqliteCommand("UPDATE Spaces SET Name = @Name, Description = @Description, IsVacant = @IsVacant WHERE Id = @Id");
                    cmd.Parameters.AddWithValue("@Name", EditedSpace.Name);
                    cmd.Parameters.AddWithValue("@Description", EditedSpace.Description);
                    cmd.Parameters.AddWithValue("@IsVacant", EditedSpace.IsVacant);
                    cmd.Parameters.AddWithValue("@Id", EditedSpace.Id);
                    commands.Add(cmd);
                    SQLHelper.Transaction(commands);

                    var oldSpace = MainVM.SelectedSpace;
                    FilteredSpaces[FilteredSpaces.IndexOf(oldSpace)] = EditedSpace;
                    MainVM.Spaces[MainVM.Spaces.IndexOf(oldSpace)] = EditedSpace;

                    if (oldSpace.IsVacant) OnVacantSpaceEdited?.Invoke(EditedSpace);

                    MainVM.SelectedSpace = EditedSpace;

                    foreach (var command in commands) command.Dispose();

                    if (!string.IsNullOrEmpty(tenantName))
                    {
                        MainVM.Message = $"{spaceName} was let out to {tenantName}\r\nand is vacant now";
                        MainVM.PopUp();
                    }

                    //to Update Transact View (Fixed Monthly receivable Part)
                    MainVM.Leases.RaiseCollectionChanged();
                }
            });
        }

        void saveTenant(object o)
        {
            MainVM.DoAsynchronously(ViewType.Tenant, () =>
            {
                if (!EditedTenant.IsEqualTo(MainVM.SelectedTenant))
                {
                    var spaces = new Dictionary<string, string>();
                    var tenantName = string.Empty;

                    var commands = new List<SqliteCommand>();
                    if (EditedTenant.HasLeft && !MainVM.SelectedTenant.HasLeft)
                    {
                        var leases = MainVM.Leases.Where(x => x.TenantId == EditedTenant.Id).ToList();
                        var count = leases.Count;

                        if (count > 0)
                        {
                            tenantName = EditedTenant.Name;
                            foreach (var lease in leases)
                            {
                                var space = MainVM.Spaces.FirstOrDefault(x => x.Id == lease.SpaceId);
                                spaces.Add(space.Name, MainVM.Plots.First(x => x.Id == space.PlotId).Name);

                                commands.Add(new SqliteCommand($"UPDATE Leases SET IsExpired = 1 WHERE Id = {lease.Id}"));
                                commands.Add(new SqliteCommand($"UPDATE Spaces SET IsVacant = 1 WHERE Id = {space.Id}"));

                                foreach (var item in lease.FixedReceivables)
                                    commands.Add(new SqliteCommand($"DELETE FROM Receivables WHERE LeaseId = {lease.Id}"));

                                space.IsVacant = true;
                                OnSpaceVacated?.Invoke(space);
                            }
                        }

                        for (int i = 0; i < count; i++)
                        {
                            MainVM.Leases.Remove(leases[i]);
                            FilteredLeases.Remove(leases[i]);
                        }

                        OnTenantLeft?.Invoke(MainVM.SelectedTenant);
                    }
                    else if (!EditedTenant.HasLeft && MainVM.SelectedTenant.HasLeft)
                        OnTenantReturn?.Invoke(EditedTenant);
                    else if(!EditedTenant.HasLeft && !MainVM.SelectedTenant.HasLeft)
                        OnAvailableTenantEdited?.Invoke(EditedTenant);

                    var cmd = new SqliteCommand(@"UPDATE Tenants SET Name = @Name, Father = @Father, Mother = @Mother, Husband = @Husband,
                                            Address = @Address, NID = @NID, ContactNo = @ContactNo, HasLeft = @HasLeft WHERE Id = @Id");

                    cmd.Parameters.AddWithValue("@Name", EditedTenant.Name);
                    cmd.Parameters.AddWithValue("@Father", EditedTenant.Father);
                    cmd.Parameters.AddWithValue("@Mother", string.IsNullOrWhiteSpace(EditedTenant.Mother) ? (object)DBNull.Value : EditedTenant.Mother);
                    cmd.Parameters.AddWithValue("@Husband", string.IsNullOrWhiteSpace(EditedTenant.Husband) ? (object)DBNull.Value : EditedTenant.Husband);
                    cmd.Parameters.AddWithValue("@Address", EditedTenant.Address);
                    cmd.Parameters.AddWithValue("@NID", string.IsNullOrWhiteSpace(EditedTenant.NID) ? (object)DBNull.Value : EditedTenant.NID);
                    cmd.Parameters.AddWithValue("@ContactNo", EditedTenant.ContactNo);
                    cmd.Parameters.AddWithValue("@HasLeft", EditedTenant.HasLeft);
                    cmd.Parameters.AddWithValue("@Id", EditedTenant.Id);

                    commands.Add(cmd);
                    SQLHelper.Transaction(commands);

                    var oldTEnant = MainVM.SelectedTenant;
                    MainVM.Tenants[MainVM.Tenants.IndexOf(oldTEnant)] = EditedTenant;

                    MainVM.SelectedTenant = EditedTenant;

                    foreach (var command in commands) command.Dispose();

                    if (!string.IsNullOrEmpty(tenantName) && spaces.Count > 0)
                    {
                        MainVM.Message = "Space(s) occupied:";
                        foreach (var item in spaces)
                            MainVM.Message += $"\r\n\t{item.Key} of {item.Value}";

                        MainVM.Message += $"\r\n\r\nby {tenantName} now available to let out";
                        MainVM.PopUp();
                    }

                    //to Update Transact View (Fixed Monthly receivable Part)
                    MainVM.Leases.RaiseCollectionChanged();
                }
            });
        }

        void saveLease(object o)
        {
            MainVM.DoAsynchronously(ViewType.Lease, () =>
            {
                if (!EditedLease.IsEqualTo(MainVM.SelectedLease))
                {
                    var spaceName = string.Empty;

                    var commands = new List<SqliteCommand>();
                    commands.Add(new SqliteCommand($"DELETE FROM Receivables WHERE LeaseId = {EditedLease.Id}"));

                    if (EditedLease.IsExpired && !MainVM.SelectedLease.IsExpired)
                    {
                        commands.Add(new SqliteCommand($"UPDATE Spaces SET IsVacant = 1 WHERE Id = {EditedLease.SpaceId}"));

                        var space = MainVM.Spaces.FirstOrDefault(x => x.Id == EditedLease.SpaceId);
                        space.IsVacant = true;
                        spaceName = space.Name;
                        OnSpaceVacated?.Invoke(space);
                    }
                    else
                    {
                        foreach (var item in editedLease.FixedReceivables)
                            commands.Add(new SqliteCommand($"INSERT INTO Receivables VALUES({item.LeaseId}, {item.HeadId}, {item.Amount})"));
                    }

                    var cmd = new SqliteCommand("UPDATE Leases SET Date = @Date, Business = @Business, IsExpired = @IsExpired WHERE Id = @Id");
                    cmd.Parameters.AddWithValue("@Date", EditedLease.Date.ToString("yyyy-MM-dd"));
                    cmd.Parameters.AddWithValue("@Business", EditedLease.Business);
                    cmd.Parameters.AddWithValue("@IsExpired", EditedLease.IsExpired);
                    cmd.Parameters.AddWithValue("@Id", EditedLease.Id);
                    commands.Add(cmd);
                    SQLHelper.Transaction(commands);

                    var index = MainVM.Leases.IndexOf(MainVM.SelectedLease);
                    var index1 = FilteredLeases.IndexOf(MainVM.SelectedLease);

                    if (EditedLease.IsExpired)
                    {
                        MainVM.Leases.RemoveAt(index);
                        FilteredLeases.Remove(MainVM.SelectedLease);
                        MainVM.SelectedSpace = MainVM.Spaces.First(x => x.Id == EditedLease.SpaceId);
                    }
                    else
                    {
                        MainVM.Leases[index] = EditedLease;
                        FilteredLeases[index1] = EditedLease;
                        MainVM.SelectedLease = EditedLease;
                    }

                    foreach (var command in commands) command.Dispose();

                    if (!string.IsNullOrEmpty(spaceName))
                    {
                        MainVM.Message = $"{spaceName} is available to let out";
                        MainVM.PopUp();
                    }
                }
            });
        }

        void saveHead(object o)
        {
            MainVM.DoAsynchronously(ViewType.Head, () =>
            {
                if (!EditedHead.IsEqualTo(MainVM.SelectedHead))
                {
                    using var cmd = SQLHelper.connection.CreateCommand();
                    cmd.CommandText = "UPDATE Heads SET Name = @Name, Description = @Description WHERE Id = @Id";
                    cmd.Parameters.AddWithValue("@Name", EditedHead.Name);
                    cmd.Parameters.AddWithValue("@Description", EditedHead.Description);
                    cmd.Parameters.AddWithValue("@Id", EditedHead.Id);
                    SQLHelper.NonQuery(cmd);

                    var index1 = MainVM.Heads.IndexOf(MainVM.SelectedHead);
                    var index2 = MainVM.FilteredHeads.IndexOf(MainVM.SelectedHead);

                    if (EditedHead.ControlId == MainVM.ControlIdOfReceivable)
                    {
                        var index3 = MainVM.ReceivableHeads.IndexOf(MainVM.SelectedHead);
                        MainVM.ReceivableHeads[index3] = EditedHead;
                        MainVM.SelectedReceivableHead = EditedHead;
                    }
                    MainVM.Heads[index1] = EditedHead;
                    MainVM.FilteredHeads[index2] = EditedHead;
                    MainVM.SelectedHead = EditedHead;

                    IsOnEdit = false;
                }
            });
        }

        void addReceivable(object o)
        {
            EditedLease.FixedReceivables.Add(NewReceivable);
            NewReceivable = new Receivable()
            {
                LeaseId = MainVM.SelectedLease.Id,
                HeadId = MainVM.SelectedReceivableHead.Id
            };
        }

        void removeReceivable(object o) => EditedLease.FixedReceivables.Remove(o as Receivable);

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }
}
