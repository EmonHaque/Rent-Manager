﻿using Rent.VM;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;

namespace Rent.Common
{
    public class FlowPaginator : DocumentPaginator
    {
        public static double PageWodth, PageHeight;
        public const double Margin = 96.0;
        DocumentPaginator paginator;

        public FlowPaginator(FlowDocument document)
        {
            paginator = ((IDocumentPaginatorSource)document).DocumentPaginator;
        }
        public override bool IsPageCountValid => paginator.IsPageCountValid;
        public override int PageCount => paginator.PageCount;
        public override Size PageSize { get => paginator.PageSize; set => paginator.PageSize = value; }
        public override IDocumentPaginatorSource Source => paginator.Source;
        public override DocumentPage GetPage(int pageNumber)
        {
            return new DocumentPage(new ContainerVisual() 
            { 
                Children =
                {
                    LedgerVM.Header(PageSize),
                    paginator.GetPage(pageNumber).Visual,
                    Footer(++pageNumber)
                }
            });
        }

        public static UIElement Footer(int pageNo)
        {
            var footer = new Grid()
            {
                Width = PageWodth - 2.0 * Margin,
                Margin = new Thickness(Margin, PageHeight - Margin, 0, 0),
                RowDefinitions =
                {
                    new RowDefinition(),
                    new RowDefinition()
                },
                Children =
                {
                    new Separator(),
                    new TextBlock(){ Text = "Auto generated ledger" },
                    new TextBlock(){ Text = "Page No.: " + pageNo, HorizontalAlignment = HorizontalAlignment.Right }
                }
            };

            for (int i = 0; i < footer.Children.Count; i++)
                Grid.SetRow(footer.Children[i], i == 2 ? i - 1 : i);

            footer.Measure(new Size(PageWodth, PageHeight));
            footer.Arrange(new Rect(footer.DesiredSize));
            return footer;
        }
    }
}
