﻿using Rent.Model;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows.Data;

namespace Rent.Common
{
    public class Int2StringConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if ((int)value > 0)
            {
                return parameter switch
                {
                    IEnumerable<Plot> p => p.First(x => x.Id == (int)value).Name,
                    IEnumerable<Space> s => s.First(x => x.Id == (int)value).Name,
                    IEnumerable<Tenant> t => t.First(x => x.Id == (int)value).Name,
                    IEnumerable<ControlHead> c => c.First(x => x.Id == (int)value).Name,
                    IEnumerable<Head> h => h.First(x => x.Id == (int)value).Name,
                };
            }
            else return string.Empty;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
