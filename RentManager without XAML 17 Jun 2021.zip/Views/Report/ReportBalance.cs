﻿using RentManager.Abstracts;
using RentManager.CustomControls;
using RentManager.Helpers;
using System.Windows;
using System.Windows.Controls;
using RentManager.ViewModels.Report;
using RentManager.Models;
using System.Windows.Data;

namespace RentManager.Views.Report
{
    class ReportBalance : CardView
    {
        public override string Icon => Icons.Balance;
        public override string Header => "Balance";

        SelectItem plot;
        BiState hasLeft;
        CommandButton refresh, exportCSV, print;
        BalanceView balances;
        EditText search;
        ReportBalanceVM viewModel;

        public ReportBalance() : base() {
            viewModel = new ReportBalanceVM();
            DataContext = viewModel;
            initializeUI();
            bind();
        }

        void initializeUI() {
            plot = new SelectItem() {
                Hint = "Plot",
                IsRequired = true,
                Icon = Icons.Plot,
                SelectedValuePath = nameof(Plot.Id),
                DisplayPath = nameof(Plot.Name)
            };
            search = new EditText() {
                Hint = "Tenant",
                Icon = Icons.SearchTenant,
                IsTrimBottomRequested = true,
                VerticalAlignment = VerticalAlignment.Center
            };
            Grid.SetColumn(search, 1);
            var plotGrid = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(){ Width = new GridLength(2, GridUnitType.Star)},
                    new ColumnDefinition()
                },
                Children = { plot, search }
            };
            hasLeft = new BiState() {
                Text = "Tenants who left?",
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Right
            };
            refresh = new CommandButton() {
                Icon = Icons.Refresh,
                Command = viewModel.Refresh,
                Margin = new Thickness(5, 0, 5, 0),
                ToolTip = "Refresh"
            };
            exportCSV = new CommandButton() {
                Icon = Icons.CSV,
                Command = viewModel.ExportCSV,
                ToolTip = "Export CSV"
            };
            print = new CommandButton() {
                Icon = Icons.Print,
                Command = viewModel.PrintReport,
                ToolTip = "Print"
            };
            balances = new BalanceView(viewModel);
            Grid.SetColumn(hasLeft, 1);
            Grid.SetColumn(refresh, 2);
            Grid.SetColumn(exportCSV, 3);
            Grid.SetColumn(print, 4);
            Grid.SetRow(balances, 1);
            Grid.SetColumnSpan(balances, 5);
            var grid = new Grid() {
                RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(),
                },
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto }
                },
                Children = { plotGrid, hasLeft, print, refresh, exportCSV, balances }
            };
            setContent(grid);
        }

        void bind() {
            plot.SetBinding(SelectItem.SelectedvalueProperty, new Binding(nameof(viewModel.PlotId)));
            plot.SetBinding(SelectItem.ErrorProperty, new Binding(nameof(viewModel.ErrorPlotId)));
            plot.SetBinding(SelectItem.ItemsSourceProperty, new Binding(nameof(viewModel.Plots)));
            plot.SetBinding(SelectItem.QueryProperty, new Binding(nameof(viewModel.PlotQuery)) { Mode = BindingMode.OneWayToSource });

            search.SetBinding(EditText.TextProperty, new Binding(nameof(viewModel.TenantQuery)) { Mode = BindingMode.OneWayToSource});

            hasLeft.SetBinding(BiState.IsTrueProperty, new Binding(nameof(viewModel.HasLeft)));
            balances.SetBinding(BalanceView.ItemsSourceProperty, new Binding(nameof(viewModel.Balances)));
            balances.SetBinding(BalanceView.SummaryProperty, new Binding(nameof(viewModel.Totals)));

            var binding = new Binding(nameof(viewModel.IsPrintOrExportValid));
            exportCSV.SetBinding(CommandButton.IsEnabledProperty, binding);
            print.SetBinding(CommandButton.IsEnabledProperty, binding);
            refresh.SetBinding(CommandButton.IsEnabledProperty, new Binding(nameof(viewModel.IsRefreshValid)));
        }
    }
}
