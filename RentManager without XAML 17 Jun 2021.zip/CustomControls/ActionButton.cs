﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace RentManager.CustomControls
{
    class ActionButton : FrameworkElement
    {
        Border border;
        string icon;
        public string Icon {
            get { return icon; }
            set { icon = value; ((Path)border.Child).Data = Geometry.Parse(value); }
        }
        public Action Command { get; set; }
        protected SolidColorBrush brush;
        protected ColorAnimation anim;
        protected Color normalColor, highlightColor, downColor;       
        public ActionButton() {
            Width = Height = 18;
            VerticalAlignment = VerticalAlignment.Center;
            normalColor = Colors.Black;
            highlightColor = Colors.Coral;
            downColor = Colors.Red;
            brush = new SolidColorBrush(normalColor);
            border = new Border() {
                Background = Brushes.Transparent,
                Child = new Path() {
                    Fill = brush,
                    Stretch = Stretch.Uniform
                }
            };
            anim = new ColorAnimation() {
                Duration = TimeSpan.FromSeconds(0.5),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
            FocusVisualStyle = null;
            AddVisualChild(border);
        }
        protected void animateBrush(Color color) {
            anim.To = color;
            brush.BeginAnimation(SolidColorBrush.ColorProperty, anim);
        }
        protected override Size MeasureOverride(Size availableSize) {
            border.Measure(new Size(Width, Height));
            border.Arrange(new Rect(border.DesiredSize));
            return border.DesiredSize;
        }
        protected override Size ArrangeOverride(Size finalSize) => new Size(Width, Height);
        protected override void OnMouseEnter(MouseEventArgs e) => animateBrush(highlightColor);
        protected override void OnMouseLeave(MouseEventArgs e) => animateBrush(normalColor);
        protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e) => Command.Invoke();
        protected override void OnMouseDown(MouseButtonEventArgs e) => animateBrush(downColor);
        protected override Visual GetVisualChild(int index) => border;
        protected override int VisualChildrenCount => 1;
    }
}
