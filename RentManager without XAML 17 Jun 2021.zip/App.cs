﻿using System;
using System.Windows;
using RentManager.Views;
using RentManager.CustomControls;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using RentManager.Helpers;
using System.Threading;
using System.Windows.Threading;

namespace RentManager
{
    class App : Application
    {
        #region static properties
        public static Style scrollBarStyle;
        public static Style multilineTextScrollStyle;
        public static Style editableItemContainerStyle;
        public static Converter convert;
        #endregion

        [STAThread]
        static void Main() => new App().Run();
        protected override void OnStartup(StartupEventArgs e) {
            LoadingWindow loading = null;
            var thread = new Thread(() => {
                loading = new LoadingWindow();
                loading.Show();
                Dispatcher.Run();
            });
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
            Thread.Sleep(1000);
            setResourceAndStyles();
            new AppData();
            convert = new Converter();
            Current.MainWindow = new RootWindow() {
                Content = new RootPanel() {
                    Children = { 
                        new HomeView(), 
                        new AddView(), 
                        new EditView(), 
                        new TransactionView(), 
                        new ReportView() 
                    }
                }
            };
            Current.DispatcherUnhandledException += unhandledHandler;
            Current.MainWindow.Show();
            Current.MainWindow.Activate();
            loading.Dispatcher.Invoke(loading.Close);
            loading.Dispatcher.InvokeShutdown();
        }
        protected override void OnExit(ExitEventArgs e) {
            if (BusyWindow.IsOpened) BusyWindow.Terminate();
        }
        void unhandledHandler(object sender, DispatcherUnhandledExceptionEventArgs e) {
            if (BusyWindow.IsOpened) BusyWindow.Terminate();
            InfoWindow.Activate("Exception", e.Exception.StackTrace);
            e.Handled = true;
        }
        void setResourceAndStyles() {
            Current.Resources.Add(SystemParameters.VerticalScrollBarWidthKey, Constants.ScrollBarThickness);
            Current.Resources.Add(SystemParameters.HorizontalScrollBarHeightKey, Constants.ScrollBarThickness);
            scrollBarStyle = new Style() {
                TargetType = typeof(ScrollBar),
                Setters = { new Setter(ScrollBar.TemplateProperty, new VScrollTemplate()) },
                Triggers = {
                    new Trigger() {
                        Property = ScrollBar.OrientationProperty,
                        Value = Orientation.Horizontal,
                        Setters = { new Setter(ScrollBar.TemplateProperty, new HScrollTemplate()) }
                    }
                }
            };
            Control.StyleProperty.OverrideMetadata(typeof(ScrollBar), new FrameworkPropertyMetadata() { DefaultValue = scrollBarStyle });
            multilineTextScrollStyle = new Style(typeof(ScrollBar), scrollBarStyle) {
                Setters = { new Setter(ScrollBar.MarginProperty, new Thickness(0, 20, -26, 0)) }
            };
            editableItemContainerStyle = new Style() {
                TargetType = typeof(ListBoxItem),
                Setters = {
                    new Setter(ListBoxItem.MarginProperty, new Thickness(0,0,10,0)),
                    new Setter(ListBoxItem.FocusVisualStyleProperty, null)
                }
            };
        }
    }
}
