﻿class ReportBalanceVM : Notifiable
    {
        List<Balance> summary;
        public ICollectionView Plots { get; set; }
        public ICollectionView Balances { get; set; }
        public Tuple<int, int, int> Totals { get; set; }
        public bool IsPrintOrExportValid { get; set; }
        public bool IsRefreshValid { get; set; }
        public Action Refresh { get; set; }
        public Action PrintReport { get; set; }
        public Action ExportCSV { get; set; }
        public string ErrorPlotId { get; set; }
        bool hasLeft;
        public bool HasLeft {
            get { return hasLeft; }
            set {
                if (hasLeft != value) {
                    hasLeft = value;
                    getData();
                }
            }
        }
        int? plotId;
        public int? PlotId {
            get { return plotId; }
            set {
                if (plotId != value) {
                    plotId = value;
                    validate();
                    IsRefreshValid = value == null ? false : true;
                    OnPropertyChanged(nameof(IsRefreshValid));
                }
            }
        }
        string plotQuery;
        public string PlotQuery {
            get { return plotQuery; }
            set {
                if (plotQuery != value) {
                    plotQuery = value?.Trim().ToLower();
                    Plots.Refresh();
                }
            }
        }
        string tenantQuery;
        public string TenantQuery {
            get { return tenantQuery; }
            set {
                if (tenantQuery != value) {
                    tenantQuery = value?.Trim().ToLower();
                    Balances.Refresh();
                }
            }
        }

        public ReportBalanceVM() {
            Refresh = refresh;
            PrintReport = printReport;
            ExportCSV = exportCSV;
            Plots = new CollectionViewSource() { Source = AppData.plots }.View;
            Plots.Filter = filterPlots;
        }

        bool filterPlots(object o) {
            if (string.IsNullOrWhiteSpace(PlotQuery)) return true;
            return ((Plot)o).Name.ToLower().Contains(PlotQuery);
        }
        bool filterTenants(object o) {
            if (string.IsNullOrWhiteSpace(TenantQuery)) return true;
            return ((Balance)o).Tenant.ToLower().Contains(TenantQuery);
        }

        void validate() {
            ErrorPlotId = string.Empty;
            if (PlotId == null) {
                ErrorPlotId = " is required";
                summary = null;
                Balances = null;
                Totals = new Tuple<int, int, int>(0, 0, 0);
                IsPrintOrExportValid = false;
                OnPropertyChanged(nameof(Balances));
                OnPropertyChanged(nameof(Totals));
                OnPropertyChanged(nameof(IsPrintOrExportValid));
            }
            else getData();
            OnPropertyChanged(nameof(ErrorPlotId));
        }

        #region Command
        void refresh() {
            BusyWindow.Activate("Refreshing ...");
            getData();
            BusyWindow.Terminate();
        }
        void printReport() {
            var dialog = new PrintDialog();
            if (dialog.ShowDialog() != true) return;
            BusyWindow.Activate("Printing ...");
            var size = new Size(dialog.PrintableAreaWidth, dialog.PrintableAreaHeight);
            var document = new FixedDocument();
            document.DocumentPaginator.PageSize = size;

            List<object> list = new();
            int totalSecurity, totalRent, totalDue, index;
            totalSecurity = totalRent = totalDue = 0;
            for (int i = 0; i < summary.Count; i += index) {
                int sumSecurity, sumRent, sumDue;
                sumSecurity = sumRent = sumDue = 0;
                var indexIncrement = summary[i].Count;
                if (summary[i].Count > 1) {
                    #region include all entries even if there's no outstanding for expired lease
                    //list.Add(summary[i].Tenant);
                    //for (int j = i; j < i + summary[i].Count; j++) {
                    //    list.Add(summary[j]);
                    //    sumSecurity += summary[j].Security;
                    //    sumRent += summary[j].Rent;
                    //    sumDue += summary[j].Due;
                    //}
                    //list.Add(new Tuple<int, int, int>(sumSecurity, sumRent, sumDue));
                    //totalSecurity += sumSecurity;
                    //totalRent += sumRent;
                    //totalDue += sumDue;
                    #endregion

                    #region eliminate entries where there's no outstanding for expired lease
                    var internalList = new List<Balance>();
                    for (int j = i; j < i + summary[i].Count; j++) {
                        if (!summary[j].IsExpired) internalList.Add(summary[j]);
                        else if (summary[j].Security != summary[j].Due)
                            internalList.Add(summary[j]);
                    }
                    if (internalList.Count > 1) {
                        list.Add(summary[i].Tenant);
                        foreach (var item in internalList) {
                            list.Add(item);
                            sumSecurity += item.Security;
                            sumRent += item.Rent;
                            sumDue += item.Due;
                        }
                        list.Add(new Tuple<int, int, int>(sumSecurity, sumRent, sumDue));
                        totalSecurity += sumSecurity;
                        totalRent += sumRent;
                        totalDue += sumDue;
                    }
                    else {
                        var item = internalList.First();
                        item.Count = 1;
                        list.Add(item);
                        totalSecurity += item.Security;
                        totalRent += item.Rent;
                        totalDue += item.Due;
                    }
                    #endregion
                }
                else {
                    list.Add(summary[i]);
                    totalSecurity += summary[i].Security;
                    totalRent += summary[i].Rent;
                    totalDue += summary[i].Due;
                }
                index = indexIncrement;
            }
            var pages = new List<BalancePage>();
            var page = getPage(document, null);
            pages.Add(page);
            for (int i = 0; i < list.Count; i++) {
                if (!page.AddEntry(list[i])) {
                    page.IsComplete = true;
                    page = getPage(document, page);
                    page.AddEntry(list[i]);
                    pages.Add(page);
                }
            }
            page.IsComplete = true;
            foreach (var p in pages) {
                p.NumberOfPage = document.Pages.Count;
            }
            dialog.PrintDocument(document.DocumentPaginator, "");
            BusyWindow.Terminate();
        }
        void exportCSV() {
            var dialog = new SaveFileDialog() {
                FileName = "Balance",
                Filter = "CSV files (.csv)|*.csv"
            };
            if (dialog.ShowDialog() != true) return;
            BusyWindow.Activate("Exporting ....");
            var builder = new StringBuilder();
            builder.Append("Name and Space, Date, Security, Rent, Due").AppendLine();
            foreach (var item in summary) {
                var nameAndSpace = item.Count > 1 ? item.Tenant + " - " + item.Space : item.Space;
                builder
                    .Append("\"").Append(nameAndSpace).Append("\"").Append(",")
                    .Append(item.DateStart.Value.ToString("MM/dd/yyyy")).Append(",")
                    .Append(item.Security).Append(",")
                    .Append(item.Rent).Append(",")
                    .Append(item.Due).AppendLine();
            }
            System.IO.File.WriteAllText(System.IO.Path.GetFullPath(dialog.FileName), builder.ToString());
            BusyWindow.Terminate();
        }
        BalancePage getPage(FixedDocument doc, BalancePage previousPage) {
            BalancePage page;
            if (previousPage == null) {
                var plot = AppData.plots.First(x => x.Id == PlotId);
                var date = DateTime.Now;
                page = new BalancePage(doc.DocumentPaginator.PageSize) {
                    Title = plot.Name,
                    SubTitle = plot.Description,
                    AsAt = "as at " + date.ToString("dd MMMM yyyy"),
                    FootNote = $"Generated on {date.ToString("dd MMMM, yyyy | hh:mm:ss tt")}",
                };
            }
            else page = new BalancePage(previousPage);
            doc.Pages.Add(new PageContent() { Child = page.Page });
            return page;
        }
        #endregion

        void getData() {
            lock (SQLHelper.key) {
                SQLHelper.connection.Open();
                var cmd = SQLHelper.connection.CreateCommand();
                cmd.CommandText = $@"WITH t0(Space, Tenant, Amount, ControlId, HeadId, TenantId, SpaceId) AS(
									SELECT s.Name, t.Name, SUM(tn.Amount), tn.ControlId, tn.HeadId, tn.TenantId, tn.SpaceId FROM Transactions tn
									LEFT JOIN Plots p ON p.Id = tn.PlotId
									LEFT JOIN Spaces s ON s.Id = tn.SpaceId
									LEFT JOIN Tenants t ON t.Id = tn.TenantId
									WHERE tn.PlotId = {PlotId} AND TenantId IN (SELECT Id FROM Tenants WHERE HasLeft = {Convert.ToInt32(HasLeft)})
									GROUP BY t.Name, s.Name, tn.HeadId
									ORDER BY s.Name
								),
								t1(Space, Tenant, Security, Receivable, Receipt, TenantId, SpaceId) AS(
									SELECT Space, Tenant, 
									SUM(CASE HeadId WHEN 4 THEN 1 WHEN 6 THEN -1 ELSE 0 END * Amount) Security,
									SUM(CASE ControlId WHEN 1 THEN Amount ELSE 0 END) Receivable,
									SUM(CASE WHEN HeadId=5 THEN Amount ELSE 0 END) Receipt,
									TenantId, SpaceId FROM t0
									GROUP BY Tenant, Space
								),
								t2 (Space, Tenant, Security, Due, TenantId, SpaceId) AS (
									SELECT Space, Tenant, Security, (Receivable - Receipt) Due, TenantId, SpaceId FROM t1
								),
								t3(Space, Tenant, Security, Due, LeaseId, DateStart, DateEnd, IsExpired) AS(
									SELECT Space, Tenant, Security, Due, l.Id, l.DateStart, l.DateEnd, l.IsExpired FROM t2 tn
									LEFT JOIN Leases l ON l.TenantId = tn.TenantId AND l.SpaceId = tn.SpaceId
								),
								t4(Space, Tenant, Security, Rent, Due, DateStart, DateEnd, IsExpired) AS(
									SELECT Space, Tenant, Security, COALESCE(SUM(r.Amount), 0), Due, DateStart, DateEnd, IsExpired FROM t3 tn
									LEFT JOIN Receivables r ON r.LeaseId = tn.LeaseId
									GROUP BY tn.Tenant, tn.LeaseId
								),
								t5(Space, Tenant, Security, Rent, Due, DateStart, DateEnd, IsExpired, Counts) AS (
                                	SELECT *, COUNT(Tenant)
                                	FROM t4 GROUP BY Tenant
                                ),
                                t6(Space, Tenant, Security, Rent, Due, DateStart, DateEnd, IsExpired, Counts, SCount) AS(
                                    SELECT t1.Space, t1.Tenant, t1.Security, t1.Rent, t1.Due, t1.DateStart, t1.DateEnd, t1.IsExpired, t2.Counts,
                                    COUNT(t1.Space) OVER(PARTITION BY t1.Tenant, t1.Space) SCount FROM t4 t1
                                    LEFT JOIN t5 t2 ON t1.Tenant = t2.Tenant
                                    ORDER BY t2.Counts DESC, t1.Tenant ASC
                                )
                                SELECT Space, Tenant, Security, Rent, 
                                CASE WHEN SCount > 1 AND IsExpired = 1 THEN 0 ELSE Due END AS Due,
                                DateStart, DateEnd, IsExpired, Counts FROM t6";
                var reader = cmd.ExecuteReader();
                summary = new List<Balance>();
                while (reader.Read()) {
                    summary.Add(new Balance() {
                        Space = reader.GetString(0),
                        Tenant = reader.GetString(1),
                        Security = reader.GetInt32(2),
                        Rent = reader.GetInt32(3),
                        Due = reader.GetInt32(4),
                        DateStart = reader.IsDBNull(5) ? (DateTime?)null : reader.GetDateTime(5),
                        DateEnd = reader.IsDBNull(6) ? (DateTime?)null : reader.GetDateTime(6),
                        IsExpired = reader.IsDBNull(7) ? false : reader.GetBoolean(7),
                        Count = reader.GetInt32(8)
                    });
                }
                cmd.Dispose();
                SQLHelper.connection.Close();
            }
            Balances = new CollectionViewSource() {
                Source = summary,
                GroupDescriptions = {
                    new PropertyGroupDescription(nameof(Balance.Tenant))
                }
            }.View;
            Balances.Filter = filterTenants;
            int totalSecurity, totalRent, totalDue;
            totalSecurity = totalRent = totalDue = 0;
            for (int i = 0; i < summary.Count; i++) {
                totalSecurity += summary[i].Security;
                totalRent += summary[i].Rent;
                totalDue += summary[i].Due;
            }
            Totals = new Tuple<int, int, int>(totalSecurity, totalRent, totalDue);
            IsPrintOrExportValid = summary.Count > 0;

            OnPropertyChanged(nameof(Balances));
            OnPropertyChanged(nameof(Totals));
            OnPropertyChanged(nameof(IsPrintOrExportValid));
        }
    }
