﻿class BarChart : Panel
    {
        public IEnumerable ItemSource {
            get { return (IEnumerable)GetValue(ItemSourceProperty); }
            set { SetValue(ItemSourceProperty, value); }
        }
        public static readonly DependencyProperty ItemSourceProperty =
            DependencyProperty.Register("ItemSource", typeof(IEnumerable), typeof(BarChart), new FrameworkPropertyMetadata() {
                DefaultValue = null,
                PropertyChangedCallback = onSourceChanged,
                AffectsArrange = true
            });

        static void onSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
            var o = d as BarChart;
            o.Children.Clear();
            if (e.NewValue != null) {
                var list = ((IEnumerable<PlotWiseDue>)e.NewValue).ToList();
                o.hasData = list.Count > 0;
                if (o.hasData) o.generateChart(list);
                else o.Children.Add(o.noInfoBlock);
            }
            else {
                o.hasData = false;
                o.Children.Add(o.noInfoBlock);
            }
        }

        double x1Max, x1Min, x2Max;
        Size bottomLabelDesired, sideLabelDesired;
        bool hasData;
        TextBlock noInfoBlock;

        public BarChart() {
            LayoutTransform = new ScaleTransform() { ScaleY = -1 };
            noInfoBlock = new TextBlock() {
                TextAlignment = TextAlignment.Center,
                FontSize = 18,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Gray,
                Inlines = {
                    new Run(){ Text = "No data"},
                    new LineBreak(),
                    new Run(){ Text = "available" }
                },
                LayoutTransform = new ScaleTransform() { ScaleY = -1 }
            };
        }
        void addLabel(string date) {
            var label = new TextBlock() {
                Tag = "Label",
                Text = date,
                IsHitTestVisible = false,
                TextAlignment = TextAlignment.Right,
                Padding = new Thickness(0, 0, 5, 0),
                RenderTransform = new TransformGroup() {
                    Children = {
                            new ScaleTransform() { ScaleY = -1 },
                            new RotateTransform() { Angle = 90 }
                        }
                }
            };
            label.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
            if (bottomLabelDesired.Width < label.DesiredSize.Width)
                bottomLabelDesired = label.DesiredSize;
            Children.Add(label);
            //label.Loaded += animateLabels;
        }
        void addLine() {
            var line = new Line() {
                StrokeThickness = 1,
                Stroke = Brushes.LightBlue,
                IsHitTestVisible = false
            };
            Children.Add(line);
            SetZIndex(line, 1);
            //line.Loaded += animateLines;
        }
        void addSideLables() {
            var x1Label = new TextBlock() {
                Tag = "x1Label",
                Text = "Outstanding",
                FontSize = 14,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Gray,
                Padding = new Thickness(0, 0, 0, 5),
                RenderTransform = new RotateTransform(90),
                LayoutTransform = new ScaleTransform() { ScaleY = -1 },
                TextAlignment = TextAlignment.Center

            };
            var x2Label = new TextBlock() {
                Tag = "x2Label",
                Text = "Number of Tenant",
                FontSize = 14,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Gray,
                Padding = new Thickness(0, 0, 0, 5),
                RenderTransform = new RotateTransform(-90),
                LayoutTransform = new ScaleTransform() { ScaleY = -1 },
                TextAlignment = TextAlignment.Center
            };
            Children.Add(x1Label);
            Children.Add(x2Label);
            x1Label.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
            x2Label.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
            sideLabelDesired.Width = x1Label.DesiredSize.Width > x2Label.DesiredSize.Width ? x1Label.DesiredSize.Width : x2Label.DesiredSize.Width;
            sideLabelDesired.Height = x1Label.DesiredSize.Height > x2Label.DesiredSize.Height ? x1Label.DesiredSize.Height : x2Label.DesiredSize.Height;
        }
        void addX1Tick(double value) {
            var tick = new TextBlock() {
                Tag = "x1Tick",
                Text = value.ToString("N0"),
                HorizontalAlignment = HorizontalAlignment.Left,
                RenderTransform = new TransformGroup() {
                    Children = {
                            new ScaleTransform() { ScaleY = - 1 },
                            new TranslateTransform()
                        }
                },
                IsHitTestVisible = false
            };
            if (value < 0) tick.Foreground = Brushes.Coral;
            Children.Add(tick);
            //tick.Loaded += animateTicks;
        }
        void addX2Tick(double value) {
            var tick = new TextBlock() {
                Tag = "x2Tick",
                Text = value.ToString("N1"),
                HorizontalAlignment = HorizontalAlignment.Right,
                RenderTransform = new TransformGroup() {
                    Children = {
                            new ScaleTransform() { ScaleY = - 1 },
                            new TranslateTransform()
                        }
                },
                IsHitTestVisible = false
            };
            Children.Add(tick);
            //tick.Loaded += animateTicks;
        }
        void generateChart(List<PlotWiseDue> list) {
            bottomLabelDesired = new Size(0, 0);
            x1Min = x1Max = x2Max = 0;
            var months = list.Select(x => x.Month).Distinct();
            foreach (var month in months) {
                var tenants = list.Where(x => string.Equals(x.Month, month)).ToList();
                Bar bar = new(tenants);
                Children.Add(bar);
                SetZIndex(bar, 3);
                addLabel(month);
                var dueTotal = tenants.Sum(x => x.Due);
                var numTenants = tenants.Count;
                if (dueTotal > x1Max) x1Max = dueTotal;
                if (dueTotal < x1Min) x1Min = dueTotal;
                if (numTenants > x2Max) x2Max = numTenants;
            }
            var minX1 = x1Min < 0 ? x1Min : 0;
            double x1Step = minX1 < 0 ? (x1Max + Math.Abs(x1Min)) / 9 : x1Max / 9;
            double x2Step = x2Max / 9;
            var x1Current = minX1;
            var x2Current = 0d;
            for (int i = 0; i < 10; i++) {
                addLine();
                addX1Tick(x1Current);
                addX2Tick(x2Current);
                x1Current += x1Step;
                x2Current += x2Step;
            }
            addSideLables();
        }

        protected override Size ArrangeOverride(Size finalSize) {
            if (finalSize.Width == 0 || finalSize.Height == 0) return finalSize;
            if (!hasData) {
                noInfoBlock.Measure(finalSize);
                var center = new Point(finalSize.Width / 2, finalSize.Height / 2);
                var point = new Point(center.X - noInfoBlock.DesiredSize.Width / 2, center.Y - noInfoBlock.DesiredSize.Height / 2);
                noInfoBlock.Arrange(new Rect(point, noInfoBlock.DesiredSize));
                return finalSize;
            }
            var x1Tick = new TextBlock() { Text = x1Max.ToString("N0") };
            var x2Tick = new TextBlock() { Text = x2Max.ToString("N1") };
            x1Tick.Measure(finalSize);
            x2Tick.Measure(finalSize);

            var labelHeight = bottomLabelDesired.Width;
            var bars = Children.OfType<Bar>().Count();
            var x1TickSpace = x1Tick.DesiredSize.Width + sideLabelDesired.Height;
            var x2TickSpace = x2Tick.DesiredSize.Width + sideLabelDesired.Height;
            var barWidth = (finalSize.Width - x1TickSpace - x2TickSpace) / bars;

            var remainingHeight = finalSize.Height - labelHeight;
            var lineSpace = remainingHeight / 10;
            var availableHeight = remainingHeight / 10 * 9;
            var barSpace = x1TickSpace;
            var labelSpace = x1TickSpace + barWidth / 2 - bottomLabelDesired.Height / 2;
            var y = labelHeight;
            var x1TickY = labelHeight;
            var x2TickY = labelHeight;
            var upperBound = x1Max;
            var lowerBound = x1Min < 0 ? Math.Abs(x1Min) : 0;

            var posHeight = availableHeight / (lowerBound + upperBound) * upperBound;
            var negHeight = availableHeight - posHeight;

            if (barWidth < 1 || availableHeight < 5) return finalSize;
            foreach (UIElement item in Children) {
                if (item is Bar) {
                    var rect = (Bar)item;
                    rect.SetParameters(lowerBound, upperBound, posHeight, negHeight, x2Max);
                    rect.Measure(new Size(barWidth, availableHeight));
                    rect.Arrange(new Rect(new Point(barSpace, labelHeight), rect.DesiredSize));
                    barSpace += barWidth;
                }
                else if (item is Line) {
                    var line = (Line)item;
                    line.X1 = sideLabelDesired.Height;
                    line.X2 = finalSize.Width - sideLabelDesired.Height;
                    line.Y1 = line.Y2 = y;
                    item.Measure(finalSize);
                    item.Arrange(new Rect(item.DesiredSize));
                    y += lineSpace;
                }
                else if (item is TextBlock) {
                    var block = (TextBlock)item;
                    if (string.Equals(block.Tag.ToString(), "x1Tick")) {
                        block.Measure(finalSize);
                        block.Arrange(new Rect(new Point(sideLabelDesired.Height, x1TickY + block.DesiredSize.Height), block.DesiredSize));
                        x1TickY += lineSpace;
                    }
                    else if (string.Equals(block.Tag.ToString(), "x2Tick")) {
                        block.Measure(finalSize);
                        block.Arrange(new Rect(new Point(finalSize.Width - block.DesiredSize.Width - sideLabelDesired.Height, x2TickY + block.DesiredSize.Height), block.DesiredSize));
                        x2TickY += lineSpace;
                    }
                    else if (string.Equals(block.Tag.ToString(), "Label")) {
                        block.Width = bottomLabelDesired.Width;
                        block.Measure(finalSize);
                        block.Arrange(new Rect(new Point(labelSpace, 0), block.DesiredSize));
                        labelSpace += barWidth;
                    }
                    else if (string.Equals(block.Tag.ToString(), "x1Label")) {
                        block.Width = remainingHeight;
                        block.Measure(finalSize);
                        block.Arrange(new Rect(new Point(block.DesiredSize.Height, labelHeight), block.DesiredSize));
                    }
                    else if (string.Equals(block.Tag.ToString(), "x2Label")) {
                        block.Width = remainingHeight;
                        block.Measure(finalSize);
                        block.Arrange(new Rect(new Point(finalSize.Width - block.DesiredSize.Height, labelHeight + remainingHeight), block.DesiredSize));
                    }
                }
            }

            return finalSize;
        }
    }
