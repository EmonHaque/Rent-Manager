﻿class Bar : FrameworkElement
    {
        Border dueBorder;
        Line tenantLine;
        EllipseGeometry circleGeo;
        Path circle;
        Color durNormal, dueHilight, tenantNormal, tenantHilight;
        SolidColorBrush dueBrush, tenantBrush;
        ColorAnimation dueBrushAnim, tenantBrushAnim;
        DoubleAnimation tenantThicknessAnim;
        HomePlotDueTip tip;
        VisualCollection children;
        double x1LowerBound, x1UpperBound, x2UpperBound, posHeight, negHeight, radius;
        int dueTotal, tenantTotal;
        Size available;
        bool isClicked;

        public Bar(List<PlotWiseDue> dues) {
            Margin = new Thickness(2.5, 0, 2.5, 0);
            dueTotal = dues.Sum(x => x.Due);
            tenantTotal = dues.Count;
            radius = 3;
            durNormal = Colors.Gray;
            tenantNormal = Colors.CornflowerBlue;
            dueHilight = Colors.LightGray;
            tenantHilight = Colors.Coral;
            dueBrush = new SolidColorBrush(durNormal);
            tenantBrush = new SolidColorBrush(tenantNormal);
            dueBorder = new Border() {
                Background = dueBrush,
                CornerRadius = new CornerRadius(0,0,10,10),
                RenderTransform = new ScaleTransform(0, 0)
            };
            tenantLine = new Line() {
                Stroke = tenantBrush,
                StrokeThickness = 1
            };
            circleGeo = new EllipseGeometry() { RadiusX = radius, RadiusY = radius };
            circle = new Path() {
                Fill = tenantBrush,
                Data = circleGeo,
                RenderTransform = new TransformGroup() {
                    Children = {
                        new TranslateTransform(),
                        new ScaleTransform(0.25,0.25)
                    }
                }
            };
            children = new VisualCollection(this) { dueBorder, tenantLine, circle };

            dueBrushAnim = new ColorAnimation() {
                Duration = TimeSpan.FromSeconds(0.5),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
            tenantBrushAnim = new ColorAnimation() {
                Duration = TimeSpan.FromSeconds(0.5),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
            tenantThicknessAnim = new DoubleAnimation() {
                Duration = TimeSpan.FromSeconds(0.5),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
            Loaded += onLoaded;
            Unloaded += onUnloaded;
            tip = new HomePlotDueTip(dues);
        }

        void onUnloaded(object sender, RoutedEventArgs e) {
            Loaded -= onLoaded;
            Unloaded -= onUnloaded;
        }

        void onLoaded(object sender, RoutedEventArgs e) {
            ((TranslateTransform)((TransformGroup)circle.RenderTransform).Children[0]).Y = available.Height - tenantLine.Y2;
            ((ScaleTransform)((TransformGroup)circle.RenderTransform).Children[1]).CenterY = available.Height;
            ((ScaleTransform)((TransformGroup)circle.RenderTransform).Children[1]).CenterX = available.Width / 2;

            tenantLine.RenderTransform = new ScaleTransform(1, 0);
            var borderScaleAnim = new DoubleAnimation() {
                To = 1,
                Duration = TimeSpan.FromSeconds(1),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
            var lineScaleAnim = new DoubleAnimation() {
                BeginTime = TimeSpan.FromSeconds(0.5),
                To = 1,
                Duration = TimeSpan.FromSeconds(1),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
            dueBorder.RenderTransform.BeginAnimation(ScaleTransform.ScaleXProperty, borderScaleAnim);
            dueBorder.RenderTransform.BeginAnimation(ScaleTransform.ScaleYProperty, borderScaleAnim);
            tenantLine.RenderTransform.BeginAnimation(ScaleTransform.ScaleYProperty, lineScaleAnim);

            ((TransformGroup)circle.RenderTransform).Children[0].BeginAnimation(TranslateTransform.YProperty, lineScaleAnim);
            ((TransformGroup)circle.RenderTransform).Children[1].BeginAnimation(ScaleTransform.ScaleXProperty, lineScaleAnim);
            ((TransformGroup)circle.RenderTransform).Children[1].BeginAnimation(ScaleTransform.ScaleYProperty, lineScaleAnim);
        }

        public void SetParameters(double x1Lower, double x1Upper, double posHeight, double negHeight, double x2Upper) {
            x1LowerBound = x1Lower;
            x1UpperBound = x1Upper;
            x2UpperBound = x2Upper;
            this.posHeight = posHeight;
            this.negHeight = negHeight;
        }
        protected override Size MeasureOverride(Size availableSize) {
            available = availableSize;
            dueBorder.Width = availableSize.Width;
            if(dueTotal >= 0) dueBorder.Height = dueTotal / x1UpperBound * posHeight;
            else {
                dueBorder.Height = Math.Abs(dueTotal) / x1LowerBound * negHeight;
                dueBorder.CornerRadius = new CornerRadius(10, 10, 0, 0);
            }
            tenantLine.Y2 = tenantTotal / x2UpperBound * availableSize.Height;
            var centerX = availableSize.Width / 2;
            tenantLine.X1 = tenantLine.X2 = centerX;
            ((ScaleTransform)dueBorder.RenderTransform).CenterX = centerX;
            circleGeo.Center = new Point(centerX, tenantLine.Y2 - radius);
            foreach (UIElement child in children)
                child.Measure(availableSize);
            return availableSize;
        }
        protected override Size ArrangeOverride(Size finalSize) {
            if (dueTotal > 0) dueBorder.Arrange(new Rect(new Point(0, negHeight), dueBorder.DesiredSize));
            else dueBorder.Arrange(new Rect(new Point(0, negHeight - dueBorder.DesiredSize.Height), dueBorder.DesiredSize));
            tenantLine.Arrange(new Rect(tenantLine.DesiredSize));
            circle.Arrange(new Rect(circle.DesiredSize));
            return finalSize;
        }
        protected override void OnMouseEnter(MouseEventArgs e) {
            dueBrushAnim.To = dueHilight;
            tenantBrushAnim.To = tenantHilight;
            tenantThicknessAnim.To = 2;
            dueBrush.BeginAnimation(SolidColorBrush.ColorProperty, dueBrushAnim);
            tenantBrush.BeginAnimation(SolidColorBrush.ColorProperty, tenantBrushAnim);
            tenantLine.BeginAnimation(Line.StrokeThicknessProperty, tenantThicknessAnim);
            tip.IsOpen = true;
        }
        protected override void OnMouseLeave(MouseEventArgs e) {
            if (!isClicked) {
                dueBrushAnim.To = durNormal;
                tenantBrushAnim.To = tenantNormal;
                tenantThicknessAnim.To = 1;
                dueBrush.BeginAnimation(SolidColorBrush.ColorProperty, dueBrushAnim);
                tenantBrush.BeginAnimation(SolidColorBrush.ColorProperty, tenantBrushAnim);
                tenantLine.BeginAnimation(Line.StrokeThicknessProperty, tenantThicknessAnim);
                tip.IsOpen = false;
            }
        }
        protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e) => isClicked = !isClicked;
        protected override Visual GetVisualChild(int index) => children[index];
        protected override int VisualChildrenCount => children.Count;
    }
