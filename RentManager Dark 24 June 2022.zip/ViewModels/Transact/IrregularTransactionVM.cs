﻿class IrregularTransactionVM : TransactionBaseVM
{
    public IrregularTransactionVM() : base() { }
    protected override void validatePlotId() {
        base.validatePlotId();
        Entry.SpaceId = (Spaces.CurrentItem as Space)?.Id;
    }
    protected override bool filterPlots(object o) {
        //if (Entry.TenantId == null) return false;
        if (string.IsNullOrWhiteSpace(PlotQuery)) return true;
        return ((Plot)o).Name.ToLower().Contains(PlotQuery);
    }
    protected override bool filterSpaces(object o) {
        //if (Entry.TenantId == null) return false;
        var space = (Space)o;
        var result = space.PlotId == Entry.PlotId;
        if (string.IsNullOrWhiteSpace(SpaceQuery)) return result;
        return result && space.Name.ToLower().Contains(SpaceQuery);
    }
    protected override void initializePlotAndSpace() {
        Plots = CollectionViewSource.GetDefaultView(AppData.plots);
        Spaces = CollectionViewSource.GetDefaultView(AppData.spaces);
    }
}
