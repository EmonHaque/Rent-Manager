﻿class AddSpaceVM : AddBase<Space>
{
    CollectionViewSource plots;
    public string ErrorPlotId { get; set; }
    public string ErrorName { get; set; }
    public string ErrorDescription { get; set; }
    public bool IsValid { get; set; }
    public ICollectionView Plots { get; set; }
    string query;
    public string Query {
        get { return query; }
        set {
            if (query != value) {
                query = value?.Trim().ToLower();
                Plots.Refresh();
            }
        }
    }

    public AddSpaceVM() : base() {
        plots = new CollectionViewSource() { Source = AppData.plots };
        Plots = plots.View;
        Plots.Filter = filterPlot;
        TObject.Id = AppData.GetId(AppData.spaces);
        TObject.IsVacant = true;
        ErrorPlotId = " is required";
        TObject.PropertyChanged += validate;
        initializeValidationProperties();
        validatePlotId();
    }
    void initializeValidationProperties() {
        IsValid = false;
        ErrorName = "Name is required";
        ErrorDescription = "Description is required";

        OnPropertyChanged(nameof(ErrorName));
        OnPropertyChanged(nameof(ErrorDescription));
        OnPropertyChanged(nameof(IsValid));
    }

    bool filterPlot(object o) {
        var plot = o as Plot;
        if (string.IsNullOrWhiteSpace(Query)) return true;
        return plot.Name.ToLower().Contains(Query);
    }

    #region validation rules
    void validate(object sender, PropertyChangedEventArgs e) {
        switch (e.PropertyName) {
            case nameof(Space.PlotId): validatePlotId(); break;
            case nameof(Space.Name): validateName(); break;
            case nameof(Space.Description): validateDescription(); break;
        }
        IsValid =
            ErrorPlotId == string.Empty &&
            ErrorName == string.Empty &&
            ErrorDescription == string.Empty
            ? true : false;
        OnPropertyChanged(nameof(IsValid));
    }
    void validatePlotId() {
        ErrorPlotId = string.Empty;
        if (TObject.PlotId == null)
            ErrorPlotId = " is required";
        OnPropertyChanged(nameof(ErrorPlotId));
    }
    void validateName() {
        ErrorName = string.Empty;
        if (string.IsNullOrWhiteSpace(TObject.Name)) ErrorName = "Name is required";
        else {
            if (TObject.PlotId != null) {
                for (int i = 0; i < AppData.spaces.Count; i++) {
                    if (AppData.spaces[i].PlotId == TObject.PlotId) {
                        if (string.Equals(AppData.spaces[i].Name, TObject.Name.Trim(), StringComparison.OrdinalIgnoreCase)) {
                            ErrorName = "Name exists";
                            break;
                        }
                    }
                }
            }
        }
        OnPropertyChanged(nameof(ErrorName));
    }
    void validateDescription() {
        ErrorDescription = string.Empty;
        if (string.IsNullOrWhiteSpace(TObject.Description)) ErrorDescription = "Description is required";
        OnPropertyChanged(nameof(ErrorDescription));
    }
    #endregion

    #region base implementation
    protected override ObservableCollection<Space> collection => AppData.spaces;
    protected override void insertInDatabase() {
        lock (SQL.key) {
            SQL.command.CommandText = "INSERT INTO Spaces (PlotId, Name, Description, IsVacant) VALUES(@PlotId, @Name, @Description, 1)";
            SQL.command.Parameters.AddWithValue("@PlotId", TObject.PlotId);
            SQL.command.Parameters.AddWithValue("@Name", TObject.Name);
            SQL.command.Parameters.AddWithValue("@Description", TObject.Description);
            SQL.command.ExecuteNonQuery();
            SQL.command.Parameters.Clear();
        }
    }
    protected override void renewTObject() {
        TObject.PropertyChanged -= validate;
        TObject.PlotName = AppData.plots.First(x => x.Id == TObject.PlotId).Name;
        TObject = new Space() {
            Id = TObject.Id + 1,
            PlotId = TObject.PlotId,
            IsVacant = true
        };
        OnPropertyChanged(nameof(TObject));
        TObject.PropertyChanged += validate;
        initializeValidationProperties();
    }
    #endregion
}
