﻿class Counts : CardView
{
    public override string Header => "Space, Lease & Tenants";
    PieChart pie;
    MultiState state, selectionState;
    ActionButton refresh;
    CountsVM viewModel;

    public Counts() {
        viewModel = new CountsVM();
        DataContext = viewModel;
        initializeUI();
        bind();
    }

    void refreshCommand() {
        if (BusyWindow.IsOpened) return;
        var position = PointToScreen(new Point(0, 0));
        var dpi = VisualTreeHelper.GetDpi(this);
        position.X /= dpi.DpiScaleX;
        position.Y /= dpi.DpiScaleY;
        position.X += Constants.CardMargin.Left;
        position.Y += Constants.CardMargin.Top;
        var width = ActualWidth - Constants.CardMargin.Left - Constants.CardMargin.Right;
        var height = ActualHeight - Constants.CardMargin.Top - Constants.CardMargin.Bottom;
        BusyWindow.Activate(position.X, position.Y, width, height, "Reloading ...");
        viewModel.Refresh.Invoke();
        BusyWindow.Terminate();
    }

    void initializeUI() {
        state = new MultiState() {
            Icons = new string[] {Icons.Existing, Icons.LeftOrExpired, Icons.All }
        };
        selectionState = new MultiState() {
            Icons = new string[] { Icons.Space, Icons.Lease, Icons.Tenant },
            Texts = new string[] {"Space", "Lease", "Tenant"},
            IsIconInfront = true
        };
        pie = new PieChart() { SelectedValuePath = nameof(PlotSummary.Id) };
        refresh = new ActionButton() {
            Command = refreshCommand,
            Icon = Icons.Refresh,
            ToolTip = "Reload",
            HorizontalAlignment = HorizontalAlignment.Right,
            Margin = new Thickness(0, -45, 0, 0)
        };
        Grid.SetColumn(refresh, 1);
        Grid.SetColumn(state, 1);
        Grid.SetRow(pie, 1);
        Grid.SetColumnSpan(pie, 2);
        var grid = new Grid() {
            RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(),
                },
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto },
                },
            Children = { selectionState, state, pie, refresh }
        };
        setContent(grid);
    }

    void bind() {
        pie.SetBinding(PieChart.ItemsSourceProperty, new Binding(nameof(viewModel.Summary)));
        pie.SetBinding(PieChart.SelectedValueProperty, new Binding(nameof(viewModel.Selected)));
        selectionState.SetBinding(MultiState.StateProperty, new Binding(nameof(viewModel.SelectionState)));
        state.SetBinding(MultiState.StateProperty, new Binding(nameof(viewModel.State)));
        state.SetBinding(MultiState.TextsProperty, new Binding(nameof(viewModel.StateTexts)));
    }
}
