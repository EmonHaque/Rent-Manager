﻿class RPTemplate : DataTemplate
{
    public RPTemplate(string queryProperty, object viewModel) {
        var grid = new FrameworkElementFactory(typeof(Grid)) { Name = "grid"};
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col4 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col5 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var tenant = new FrameworkElementFactory(typeof(HiBlock)) { Name = "tenant" };
        var space = new FrameworkElementFactory(typeof(HiBlock)) { Name = "space" };
        var cash = new FrameworkElementFactory(typeof(TextBlock));
        var electronic = new FrameworkElementFactory(typeof(TextBlock));
        var kind = new FrameworkElementFactory(typeof(TextBlock));
        var total = new FrameworkElementFactory(typeof(TextBlock));
        var name = new FrameworkElementFactory(typeof(Run));
        var colon = new FrameworkElementFactory(typeof(Run));
        var tenantSpace = new FrameworkElementFactory(typeof(Run));
        Resources.Add(typeof(TextBlock), new Style() {
            Setters = {
                    new Setter(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right)
                }
        });
        grid.SetValue(Grid.MarginProperty, new Thickness(0, 0, 5, 0));
        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
        col3.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
        col4.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
        col5.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));

        name.SetValue(Run.FontWeightProperty, FontWeights.Bold);
        colon.SetValue(Run.TextProperty, " : ");
        tenantSpace.SetValue(Run.FontStyleProperty, FontStyles.Italic);
        tenant.SetValue(HiBlock.VisibilityProperty, Visibility.Hidden);
        space.SetValue(HiBlock.HorizontalAlignmentProperty, HorizontalAlignment.Left);
        cash.SetValue(Grid.ColumnProperty, 1);
        electronic.SetValue(Grid.ColumnProperty, 2);
        kind.SetValue(Grid.ColumnProperty, 3);
        total.SetValue(Grid.ColumnProperty, 4);

        name.SetBinding(Run.TextProperty, new Binding(nameof(ReceiptPayment.Tenant)));
        tenant.SetBinding(HiBlock.QueryProperty, new Binding(queryProperty) { Source = viewModel, IsAsync = true });
        space.SetBinding(HiBlock.QueryProperty, new Binding(queryProperty) { Source = viewModel, IsAsync = true });

        tenantSpace.SetBinding(Run.TextProperty, new Binding(nameof(ReceiptPayment.Space)));
        space.SetBinding(HiBlock.TextProperty, new Binding(nameof(ReceiptPayment.Space)));
        cash.SetBinding(TextBlock.TextProperty, new Binding(nameof(ReceiptPayment.Cash)) { StringFormat = Constants.NumberFormat });
        electronic.SetBinding(TextBlock.TextProperty, new Binding(nameof(ReceiptPayment.Mobile)) { StringFormat = Constants.NumberFormat });
        kind.SetBinding(TextBlock.TextProperty, new Binding(nameof(ReceiptPayment.Kind)) { StringFormat = Constants.NumberFormat });
        total.SetBinding(TextBlock.TextProperty, new Binding(nameof(ReceiptPayment.Total)) { StringFormat = Constants.NumberFormat });

        tenant.AppendChild(name);
        tenant.AppendChild(colon);
        tenant.AppendChild(tenantSpace);

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(col3);
        grid.AppendChild(col4);
        grid.AppendChild(col5);
        grid.AppendChild(tenant);
        grid.AppendChild(space);
        grid.AppendChild(cash);
        grid.AppendChild(electronic);
        grid.AppendChild(kind);
        grid.AppendChild(total);
        Triggers.Add(new MultiDataTrigger() {
            Conditions = {
                    new Condition(new Binding("DataContext.IsBottomLevel"){
                        RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(ItemsPresenter), 1)
                    }, true),
                    new Condition(new Binding("DataContext.ItemCount"){
                        RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(ItemsPresenter), 1)
                    }, 1),
                },
            Setters = {
                    new Setter(TextBlock.VisibilityProperty, Visibility.Hidden, "space"),
                    new Setter(TextBlock.VisibilityProperty, Visibility.Visible, "tenant"),
                    new Setter(Grid.MarginProperty, new Thickness(0), "grid")
            }
        });
        VisualTree = grid;
    }
}
