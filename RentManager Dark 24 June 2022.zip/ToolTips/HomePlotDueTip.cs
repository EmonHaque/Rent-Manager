﻿class HomePlotDueTip : PopupDraggable
{
    ICollectionView view;
    EditText search;
    string query;
    public string Query {
        get { return query; }
        set {
            if (query != value) {
                query = value;
                view.Refresh();
            }
        }
    }
    public HomePlotDueTip(List<PlotWiseDue> list) {
        AllowsTransparency = true;
        Placement = PlacementMode.Mouse;
        HorizontalOffset = 20;
        view = new CollectionViewSource() { Source = list }.View;
        view.Filter = filter;
        var topDivider = new Separator() { Background = Brushes.LightGray };
        var bottomDivider = new Separator() { Background = Brushes.LightGray };
        var monthYear = list.First().Month.Split('-');
        var month = new DateTime(Convert.ToInt32(monthYear[1].Trim()), Convert.ToInt32(monthYear[0].Trim()), 1);
        var header = new TextBlock() {
            FontSize = 16,
            FontWeight = FontWeights.Bold,
            Foreground = Brushes.Gray,
            Text = month.ToString("MMMM yyyy"),
            VerticalAlignment = VerticalAlignment.Center
        };
        search = new EditText() {
            Width = 200,
            Hint = "Tenant",
            Icon = Icons.SearchTenant,
            IsTrimBottomRequested = true,
            Margin = new Thickness(10, 10, 0, 0),
            VerticalAlignment = VerticalAlignment.Center
        };
        search.SetBinding(EditText.TextProperty, new Binding(nameof(Query)) {
            Mode = BindingMode.OneWayToSource,
            UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged,
            Source = this
        });
        Grid.SetColumn(search, 1);
        var headerGrid = new Grid() {
            ColumnDefinitions = {
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition()
                },
            Children = { header, search }
        };
        HomeDueTemplate itemTemplate = new(this);
        var dues = new ItemsControl() {
            Margin = new Thickness(10, 0, 2, 0),
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            ItemsSource = view,
            ItemTemplate = itemTemplate,
            AlternationCount = 2
        };
        var scrollViewer = new ScrollViewer() {
            OverridesDefaultStyle = true,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            Template = new LedgerScrollTemplate(),
            Content = dues
        };
        var total = new PlotWiseDue() {
            Tenant = "Toal of " + list.Count,
            Due = list.Sum(x => x.Due)
        };
        var footer = new ContentControl() {
            Content = total,
            ContentTemplate = itemTemplate,
            Margin = new Thickness(2, 0, 3 + Constants.ScrollBarThickness, 0)
        };
        Grid.SetRow(topDivider, 1);
        Grid.SetRow(scrollViewer, 2);
        Grid.SetRow(bottomDivider, 3);
        Grid.SetRow(footer, 4);
        Child = new Border() {
            MinWidth = 250,
            MaxHeight = 500,
            Background = Constants.Background,
            BorderBrush = Brushes.White,
            BorderThickness = new Thickness(1),
            //Effect = new DropShadowEffect() { BlurRadius = 50, ShadowDepth = 10 },
            Margin = new Thickness(2),
            Padding = new Thickness(5),
            CornerRadius = new CornerRadius(5),
            Child = new Grid() {
                RowDefinitions = {
                        new RowDefinition(){ Height = GridLength.Auto },
                        new RowDefinition(){ Height = GridLength.Auto },
                        new RowDefinition(),
                        new RowDefinition(){ Height = GridLength.Auto },
                        new RowDefinition(){ Height = GridLength.Auto },
                    },
                Children = { headerGrid, topDivider, scrollViewer, bottomDivider, footer }
            }
        };
    }
    bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return true;
        return ((PlotWiseDue)o).Tenant.ToLower().Contains(Query.Trim().ToLower());
    }
}
