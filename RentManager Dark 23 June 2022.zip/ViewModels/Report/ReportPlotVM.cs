﻿class ReportPlotVM : ReportBase
{
    protected override string particulars => "s.Name ||' -> '|| t.Name";
    protected override string where => "PlotId";
    public override ICollectionView selectionView => plots.View;

    CollectionViewSource plots;
    public ReportPlotVM() : base() {
        plots = new CollectionViewSource() { Source = AppData.plots };
        selectionView.Filter = filterPlots;
    }

    bool filterPlots(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return true;
        return ((Plot)o).Name.ToLower().Contains(Query);
    }

    protected override void setTitleAndSubTitle() {
        var plot = AppData.plots.First(x => x.Id == base.Id);
        base.Title = plot.Name;
        base.SubTitle = plot.Description;
    }
}
