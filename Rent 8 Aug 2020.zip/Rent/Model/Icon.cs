﻿using System.Windows.Controls;

namespace Rent.Model
{
    public class Icon
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string Geometry { get; set; }
        public UserControl View { get; set; }

        public Icon(string name, string description, UserControl view, string geometry)
        {
            Name = name;
            Description = description;
            View = view;
            Geometry = geometry;
        }
    }
}
