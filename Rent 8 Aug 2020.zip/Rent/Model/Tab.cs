﻿using System.Windows.Controls;

namespace Rent.Model
{
    public class Tab
    {
        public string Name { get; set; }
        public ViewType Type { get; set; }
        public UserControl View { get; set; }
        public string Geometry { get; set; }

        public Tab(string name, ViewType type, UserControl view, string geometry)
        {
            Name = name;
            Type = type;
            View = view;
            Geometry = geometry;
        }
    }
}
