﻿using Rent.Common;
using Rent.Model;
using Rent.View;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Input;

namespace Rent.VM
{
    public class MainVM : INotifyPropertyChanged
	{
		public List<Icon> Icons { get; set; }
		public static int MaxLeaseId { get; set; }
		public static int ControlIdOfReceivable { get; set; }

		static string message;
		static bool isPopupOpen;
		static Timer popupTimer;
		string maxRestoreIcon, maxRestoreTip;
		public static string Message { get => message; set { message = value; OnStaticPropertyChanged(); } }
		public static bool IsPopupOpen { get => isPopupOpen; set { isPopupOpen = value; OnStaticPropertyChanged(); } }
		
		public string MaxRestoreIcon { get => maxRestoreIcon; set { maxRestoreIcon = value; OnPropertyChanged(); } }
		public string MaxRestoreTip { get => maxRestoreTip; set { maxRestoreTip = value; OnPropertyChanged(); } }

		static Plot selectedPlot;
		static Space selectedSpace;
		static Tenant selectedTenant;
		static Lease selectedLease;
		static ControlHead selectedControlHead;
		static Head selectedHead, selectedReceivableHead;
		static OCollection<Head> filteredHeads;
		static Icon selectedIcon;

		public static Plot SelectedPlot
		{
			get => selectedPlot;
			set
			{
				selectedPlot = value;
				OnStaticPropertyChanged();
				if (value != null)
				{
					SelectedSpace = Spaces.FirstOrDefault(x => x.PlotId == value.Id);
					OnSelectedPlotChanged?.Invoke(value.Id);
				}
			}
		}
		public static Space SelectedSpace
		{
			get => selectedSpace;
			set
			{
				selectedSpace = value; OnStaticPropertyChanged();
				if (value != null)
					OnSelectedSpaceChanged?.Invoke(value.Id);
			}
		}
		public static Tenant SelectedTenant
		{
			get => selectedTenant;
			set
			{
				selectedTenant = value;
				OnStaticPropertyChanged();
				if (value != null) OnSelectedTenantChanged?.Invoke(value.Id);
			}
		}
		public static Lease SelectedLease
		{
			get => selectedLease;
			set
			{
				selectedLease = value;
				OnStaticPropertyChanged();
				if (value != null) OnSelectedLeaseChanged?.Invoke(value.Id);
			}
		}
		public static ControlHead SelectedControlHead
		{
			get => selectedControlHead;
			set
			{
				selectedControlHead = value;
				OnStaticPropertyChanged();
				if (value != null)
				{
					OnSelectedControlHeadChanged?.Invoke(value.Id);
					filterHeads(value.Id);
				}
			}
		}
		public static Icon SelectedIcon
		{
			get => selectedIcon;
			set
			{
				selectedIcon = value;
				OnStaticPropertyChanged();
				if (value != null) OnSelectedIconChanged?.Invoke(value);
			}
		}
		public static Head SelectedHead { get => selectedHead; 
			set 
			{ 
				selectedHead = value; 
				OnStaticPropertyChanged();
				OnSelectedHeadChanged?.Invoke(value);
			} 
		}
		public static Head SelectedReceivableHead
		{
			get => selectedReceivableHead;
			set
			{
				selectedReceivableHead = value;
				OnStaticPropertyChanged();
				if (value != null) OnSelectedReceivableHeadChanged?.Invoke(value.Id);
			}
		}
		public static OCollection<Head> FilteredHeads { get => filteredHeads; set { filteredHeads = value; OnStaticPropertyChanged(); } }

		public static OCollection<Plot> Plots { get; set; }
		public static OCollection<Space> Spaces { get; set; }
		public static OCollection<Tenant> Tenants { get; set; }
		public static OCollection<Lease> Leases { get; set; }
		public static OCollection<ControlHead> ControlHeads { get; set; }
		public static OCollection<Head> Heads { get; set; }
		public static OCollection<Head> ReceivableHeads { get; set; }

		public static event Action DataLoaded;
		public static event Action<int> OnSelectedPlotChanged;
		public static event Action<int> OnSelectedSpaceChanged;
		public static event Action<int> OnSelectedControlHeadChanged;
		public static event Action<Head> OnSelectedHeadChanged;
		public static event Action<int> OnSelectedReceivableHeadChanged;
		public static event Action<int> OnSelectedLeaseChanged;
		public static event Action<int> OnSelectedTenantChanged;
		public static event Action<Icon> OnSelectedIconChanged;


		static bool plotBusy, spaceBusy, tenantBusy, leaseBusy, headBusy;
		public static bool PlotBusy { get => plotBusy; set { plotBusy = value; OnStaticPropertyChanged(); } }
		public static bool SpaceBusy { get => spaceBusy; set { spaceBusy = value; OnStaticPropertyChanged(); } }
		public static bool TenantBusy { get => tenantBusy; set { tenantBusy = value; OnStaticPropertyChanged(); } }
		public static bool LeaseBusy { get => leaseBusy; set { leaseBusy = value; OnStaticPropertyChanged(); } }
		public static bool HeadBusy { get => headBusy; set { headBusy = value; OnStaticPropertyChanged(); } }

		public Command Close { get; set; }
		public Command Minimize { get; set; }
		public Command MaxRestore { get; set; }

		public MainVM()
		{
			initializeCollections();
			checkDatabase();
			initializeStaticProperties();
			initializeIcons();
			popupTimer = new Timer(30000);
			popupTimer.Elapsed += (o, e) => { IsPopupOpen = false; popupTimer.Stop(); };
			DataLoaded?.Invoke();

			App.Current.MainWindow.MouseDown += move;
			MaxRestoreTip = "Maximize";
			MaxRestoreIcon = Constants.MaximizeIcon;
			initializeCommands();
		}

		void initializeCommands()
		{
			Close = new Command(close, (o) => true);
			Minimize = new Command(minimize, (o) => true);
			MaxRestore = new Command(maxRestore, (o) => true);
		}

		void close(object o) => App.Current.Shutdown();

		void minimize(object o) => App.Current.MainWindow.WindowState = System.Windows.WindowState.Minimized;

		void maxRestore(object o)
		{
			switch (App.Current.MainWindow.WindowState)
			{
				case System.Windows.WindowState.Normal:
					App.Current.MainWindow.WindowState = System.Windows.WindowState.Maximized;
					MaxRestoreIcon = Constants.RestoreIcon;
					MaxRestoreTip = "Restore";
					break;
				case System.Windows.WindowState.Maximized:
					App.Current.MainWindow.WindowState = System.Windows.WindowState.Normal;
					MaxRestoreIcon = Constants.MaximizeIcon;
					MaxRestoreTip = "Maximize";
					break;
			}
		}

		void move(object sender, System.Windows.Input.MouseButtonEventArgs e)
		{
			if (e.ChangedButton == System.Windows.Input.MouseButton.Left)
				App.Current.MainWindow.DragMove();
		}

		void initializeStaticProperties()
		{
			SelectedPlot = Plots.FirstOrDefault();
			SelectedSpace = SelectedPlot == null ? null : Spaces.FirstOrDefault(x => x.PlotId == SelectedPlot.Id);
			SelectedTenant = Tenants.FirstOrDefault();
			SelectedControlHead = ControlHeads.First();

			ReceivableHeads = new OCollection<Head>(Heads.Where(x => x.ControlId == ControlHeads.First(x => x.Name == "Receivable").Id));
			SelectedReceivableHead = ReceivableHeads.FirstOrDefault();
		}

		void initializeIcons()
		{
			Icons = new List<Icon>()
			{
				new Icon(Constants.Home, Constants.HomeDescription, new HomeView(), Constants.HomeIcon),
				new Icon(Constants.Add, Constants.AddDescription, new AddView(), Constants.AddIcon),
				new Icon(Constants.Edit, Constants.EditDescription, new EditView(), Constants.EditIcon),
				new Icon(Constants.Transact, Constants.TransactDescription, new TransactView(), Constants.TransactIcon),
				new Icon(Constants.Ledger, Constants.LedgerDescription, new LedgerView(), Constants.LedgerIcon)
			};
			SelectedIcon = Icons.First();
		}

		void checkDatabase()
		{
			if (!File.Exists(Constants.DBName)) createDatabase();
			else populateCollections();
		}

		void createDatabase()
		{
			using var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("Rent.SQL.init.sql");
			using var sReader = new StreamReader(stream);
			SQLHelper.NonQuery(sReader.ReadToEnd());

			using var cmd = SQLHelper.connection.CreateCommand();
			cmd.CommandText = @"SELECT * FROM ControlHeads;
								SELECT * FROM Heads";
			SQLHelper.connection.Open();
			var reader = cmd.ExecuteReader();
			while (reader.Read())
			{
				ControlHeads.Add(new ControlHead()
				{
					Id = reader.GetInt32(0),
					Name = reader.GetString(1)
				});
			}

			reader.NextResult();
			while (reader.Read())
			{
				Heads.Add(new Head()
				{
					Id = reader.GetInt32(0),
					ControlId = reader.GetInt32(1),
					Name = reader.GetString(2),
					Description = reader.GetString(3)
				});
			}
			SQLHelper.connection.Close();
			ControlIdOfReceivable = ControlHeads.First(x => x.Name == "Receivable").Id;
		}

		void populateCollections()
		{
			using var cmd = SQLHelper.connection.CreateCommand();
			cmd.CommandText = @"SELECT * FROM Plots ORDER BY Name;
								SELECT * FROM Spaces ORDER BY PlotId, Name;
								SELECT * FROM ControlHeads ORDER BY Name;
								SELECT * FROM Heads ORDER BY ControlId, Name;
								SELECT * FROM Tenants ORDER BY Name;
								SELECT * FROM Leases WHERE IsExpired = 0 ORDER BY PlotId, SpaceId;
								SELECT * FROM Receivables;
								SELECT MAX(Id) FROM Leases;";

			SQLHelper.connection.Open();
			var reader = cmd.ExecuteReader();
			while (reader.Read())
			{
				Plots.Add(new Plot()
				{
					Id = reader.GetInt32(0),
					Name = reader.GetString(1),
					Description = reader.GetString(2)
				});
			}

			reader.NextResult();
			while (reader.Read())
			{
				Spaces.Add(new Space()
				{
					Id = reader.GetInt32(0),
					PlotId = reader.GetInt32(1),
					Name = reader.GetString(2),
					Description = reader.GetString(3),
					IsVacant = reader.GetBoolean(4)
				});
			}

			reader.NextResult();
			while (reader.Read())
			{
				ControlHeads.Add(new ControlHead()
				{
					Id = reader.GetInt32(0),
					Name = reader.GetString(1)
				});
			}

			reader.NextResult();
			while (reader.Read())
			{
				Heads.Add(new Head()
				{
					Id = reader.GetInt32(0),
					ControlId = reader.GetInt32(1),
					Name = reader.GetString(2),
					Description = reader.GetString(3)
				});
			}

			reader.NextResult();
			while (reader.Read())
			{
				Tenants.Add(new Tenant()
				{
					Id = reader.GetInt32(0),
					Name = reader.GetString(1),
					Father = reader.GetString(2),
					Mother = reader.IsDBNull(3) ? null : reader.GetString(3),
					Husband = reader.IsDBNull(4) ? null : reader.GetString(4),
					Address = reader.GetString(5),
					NID = reader.IsDBNull(6) ? null : reader.GetString(6),
					ContactNo = reader.GetString(7),
					HasLeft = reader.GetBoolean(8)
				});
			}

			reader.NextResult();
			while (reader.Read())
			{
				Leases.Add(new Lease()
				{
					Id = reader.GetInt32(0),
					PlotId = reader.GetInt32(1),
					SpaceId = reader.GetInt32(2),
					TenantId = reader.GetInt32(3),
					Date = reader.GetDateTime(4),
					Business = reader.GetString(5),
					IsExpired = reader.GetBoolean(6)
				});
			}

			var list = new List<Receivable>();
			reader.NextResult();
			while (reader.Read())
			{
				list.Add(new Receivable()
				{
					LeaseId = reader.GetInt32(0),
					HeadId = reader.GetInt32(1),
					Amount = reader.GetInt32(2)
				});
			}

			reader.NextResult();
			reader.Read();
			MaxLeaseId = reader.IsDBNull(0) ? 0 : reader.GetInt32(0);

			SQLHelper.connection.Close();

			if (list.Count > 0)
			{
				foreach (var item in Leases)
					item.FixedReceivables = new ObservableCollection<Receivable>(list.Where(x => x.LeaseId == item.Id));
			}

			ControlIdOfReceivable = ControlHeads.First(x => x.Name == "Receivable").Id;
		}

		void initializeCollections()
		{
			Plots = new OCollection<Plot>();
			Spaces = new OCollection<Space>();
			Tenants = new OCollection<Tenant>();
			Leases = new OCollection<Lease>();
			ControlHeads = new OCollection<ControlHead>();
			Heads = new OCollection<Head>();
		}

		static void filterHeads(int controlId)
		{
			FilteredHeads = new OCollection<Head>(Heads.Where(x => x.ControlId == controlId));
			SelectedHead = FilteredHeads.FirstOrDefault();
		}

		public static void PopUp()
		{
			IsPopupOpen = true;
			popupTimer.Start();
		}

		public static async void DoAsynchronously(ViewType type, Action task)
		{
			switch (type)
			{
				case ViewType.Plot: PlotBusy = true; break;
				case ViewType.Space: SpaceBusy = true; break;
				case ViewType.Tenant: TenantBusy = true; break;
				case ViewType.Lease: LeaseBusy = true; break;
				case ViewType.Head: HeadBusy = true; break;
			}
			await Task.Delay(250);
			await Task.Run(task);
			await Task.Delay(250);
			switch (type)
			{
				case ViewType.Plot: PlotBusy = false; break;
				case ViewType.Space: SpaceBusy = false; break;
				case ViewType.Tenant: TenantBusy = false; break;
				case ViewType.Lease: LeaseBusy = false; break;
				case ViewType.Head: HeadBusy = false; break;
			}
			CommandManager.InvalidateRequerySuggested();
		}

		#region Notify Property Changed Members
		public event PropertyChangedEventHandler PropertyChanged;
		public static event PropertyChangedEventHandler StaticPropertyChanged;
		void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
		static void OnStaticPropertyChanged([CallerMemberName] string name = "") => StaticPropertyChanged?.Invoke(null, new PropertyChangedEventArgs(name));
		#endregion
	}
}
