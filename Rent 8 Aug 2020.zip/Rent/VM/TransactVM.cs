﻿using Microsoft.Data.Sqlite;
using Rent.Common;
using Rent.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace Rent.VM
{
    public class TransactVM : INotifyPropertyChanged
    {
        List<Lease> leases, relevantPlots, relevantSpaces;
        OCollection<Transaction> entries;

        Transaction entry;
        Lease selectedRelevantPlot;
        Lease selectedRelevantSpace;
        CommonNarration monthlyNarration;
        int totalAmount;

        public int TotalAmount { get => totalAmount; set { totalAmount = value; OnPropertyChanged(); } }
        public List<Lease> RelevantPlots { get => relevantPlots; set { relevantPlots = value; OnPropertyChanged(); } }
        public List<Lease> RelevantSpaces { get => relevantSpaces; set { relevantSpaces = value; OnPropertyChanged(); } }
        public OCollection<Transaction> Entries { get => entries; set { entries = value; OnPropertyChanged(); } }
        public Lease SelectedRelevantPlot
        {
            get => selectedRelevantPlot;
            set
            {
                selectedRelevantPlot = value;
                OnPropertyChanged();
                if (value != null)
                {
                    Entry.PlotId = value.PlotId;
                    setRelevantSpaces();
                }
                else Entry.PlotId = 0;
            }
        }
        public Lease SelectedRelevantSpace
        {
            get => selectedRelevantSpace;
            set
            {
                selectedRelevantSpace = value;
                OnPropertyChanged();
                if (value != null) Entry.SpaceId = value.SpaceId;
                else Entry.SpaceId = 0;
            }
        }
        public Transaction Entry { get => entry; set { entry = value; OnPropertyChanged(); } }
        public CommonNarration MonthlyNarration { get => monthlyNarration; set { monthlyNarration = value; OnPropertyChanged(); } }

        public Command AddEntry { get; set; }
        public Command RemoveEntry { get; set; }
        public Command PassEntry { get; set; }
        public Command ChargeFixedReceivables { get; set; }

        public TransactVM()
        {
            MainVM.OnSelectedIconChanged += read;
            MainVM.OnSelectedTenantChanged += checkBeforeRead;
            MainVM.OnSelectedControlHeadChanged += controlId => Entry.ControlId = controlId;
            MainVM.OnSelectedHeadChanged += head => Entry.HeadId = head == null ? 0 : head.Id;
            AddVM.OnLeaseAdded += setRelevants4Once;

            Entry = new Transaction();
            Entries = new OCollection<Transaction>();
            MonthlyNarration = new CommonNarration();

            initializeCommands();
        }

        void setRelevants4Once(Lease lease)
        {
            if (SelectedRelevantPlot == null)
            {
                SelectedRelevantPlot = lease;
                SelectedRelevantSpace = lease;
            }
        }

        void initializeCommands()
        {
            AddEntry = new Command(addEntry, (o) => Entry.IsValid());
            RemoveEntry = new Command(removeEntry, (o) => true);
            PassEntry = new Command(passEntry, isPassEntryValid);
            ChargeFixedReceivables = new Command(chargeFixedReceivables, isMonthlyChargeValid);
        }

        void addEntry(object o)
        {
            var date = Entry.Date;
            var narration = Entry.Narration;
            Entries.Add(Entry);
            TotalAmount += Entry.Amount;

            Entry = new Transaction()
            {
                PlotId = SelectedRelevantPlot.PlotId,
                SpaceId = SelectedRelevantSpace.SpaceId,
                TenantId = MainVM.SelectedTenant.Id,
                ControlId = MainVM.SelectedControlHead.Id,
                HeadId = MainVM.SelectedHead.Id,
                Narration = narration,
                Date = date
            };
        }

        void removeEntry(object o)
        {
            var tran = o as Transaction;
            TotalAmount -= tran.Amount;
            Entries.Remove(tran);
        }

        void passEntry(object o)
        {
            MainVM.DoAsynchronously(ViewType.Tenant, () =>
            {
                var commands = new List<SqliteCommand>(Entries.Count);
                foreach (var entry in Entries)
                {
                    var narrattion = string.IsNullOrWhiteSpace(entry.Narration) ? (object)DBNull.Value : entry.Narration;
                    var cmd = new SqliteCommand(@$"INSERT INTO Transactions (Date, PlotId, SpaceId, TenantId, ControlId, HeadId, Amount, Narration) 
                                                VALUES(@Date, @PlotId, @SpaceId, @TenantId, @ControlId, @HeadId, @Amount, @Narration)");
                    cmd.Parameters.AddWithValue("@Date", entry.Date.ToString("yyyy-MM-dd"));
                    cmd.Parameters.AddWithValue("@PlotId", entry.PlotId);
                    cmd.Parameters.AddWithValue("@SpaceId", entry.SpaceId);
                    cmd.Parameters.AddWithValue("@TenantId", entry.TenantId);
                    cmd.Parameters.AddWithValue("@ControlId", entry.ControlId);
                    cmd.Parameters.AddWithValue("@HeadId", entry.HeadId);
                    cmd.Parameters.AddWithValue("@Amount", entry.Amount);
                    cmd.Parameters.AddWithValue("@Narration", narrattion);
                    commands.Add(cmd);
                }
                SQLHelper.Transaction(commands);
                var num = Entries.Count;
                App.Current.Dispatcher.Invoke(() => Entries = new OCollection<Transaction>());
                foreach (var command in commands) command.Dispose();

                MainVM.Message = $"{num} transaction(s) recorded";
                MainVM.PopUp();
            });
            TotalAmount = 0;
        }

        void chargeFixedReceivables(object o)
        {
            MainVM.DoAsynchronously(ViewType.Lease, () =>
            {
                var excluded = o as IEnumerable<object>;
                var commands = new List<SqliteCommand>();
                IEnumerable<Lease> eligibles;

                if (excluded.Count() > 0)
                    eligibles = MainVM.Leases.Except(excluded.Cast<Lease>());
                else
                    eligibles = MainVM.Leases;

                var count = eligibles.Count();
                if (count > 0)
                {
                    foreach (var lease in eligibles)
                        foreach (var receivable in lease.FixedReceivables)
                            commands.Add(monthlyCommand(lease, receivable));

                    SQLHelper.Transaction(commands);
                    MonthlyNarration = new CommonNarration();
                    foreach (var command in commands) command.Dispose();

                    MainVM.Message = $"Fixed monthly receivables\r\ncharged for {count} lease(s)";
                    MainVM.PopUp();
                }
            });
        }

        SqliteCommand monthlyCommand(Lease lease, Receivable receivable)
        {
            var cmd = new SqliteCommand(@$"INSERT INTO Transactions (Date, PlotId, SpaceId, TenantId, ControlId, HeadId, Amount, Narration) 
                                        VALUES('{MonthlyNarration.Date.ToString("yyyy-MM-dd")}', {lease.PlotId}, {lease.SpaceId}, {lease.TenantId}, 
                                        {MainVM.ControlIdOfReceivable}, {receivable.HeadId}, {receivable.Amount}, @Narration)");
            cmd.Parameters.AddWithValue("@Narration", MonthlyNarration.Narration);
            return cmd;
        }

        bool isPassEntryValid(object o) => !MainVM.TenantBusy && Entries.Count > 0;

        bool isMonthlyChargeValid(object o)
        {
            return !MainVM.LeaseBusy && 
                MainVM.Leases.Count > 0 &&
                MonthlyNarration.IsValid();
        }

        void read(Icon icon)
        {
            if (icon.Name == Constants.Transact)
                
                if (MainVM.SelectedTenant != null)
                {
                    setRelevantPlotAndSpaces(MainVM.SelectedTenant.Id);
                    Entry.TenantId = MainVM.SelectedTenant.Id;
                    Entry.ControlId = MainVM.SelectedControlHead.Id;

                    if (MainVM.SelectedHead != null)
                        Entry.HeadId = MainVM.SelectedHead.Id;
                }
        }

        void checkBeforeRead(int tenantId)
        {
            if (MainVM.SelectedIcon.Name == Constants.Transact)
            {
                setRelevantPlotAndSpaces(tenantId);
                Entry.TenantId = MainVM.SelectedTenant.Id;
            }
        }

        void setRelevantPlotAndSpaces(int tenantId)
        {
            leases = new List<Lease>();
            using var cmd = SQLHelper.connection.CreateCommand();
            cmd.CommandText = $"SELECT Date, PlotId, SpaceId, IsExpired FROM Leases WHERE TenantId = {tenantId}";
            SQLHelper.connection.Open();
            var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                leases.Add(new Lease()
                {
                    Date = reader.GetDateTime(0),
                    PlotId = reader.GetInt32(1),
                    SpaceId = reader.GetInt32(2),
                    IsExpired = reader.GetBoolean(3)
                });
            }
            SQLHelper.connection.Close();

            if (leases.Count > 0)
            {
                RelevantPlots = leases.DistinctBy(x => x.PlotId).ToList();
                SelectedRelevantPlot = RelevantPlots.First();

                setRelevantSpaces();
            }
            else
            {
                RelevantPlots = null;
                RelevantSpaces = null;
                SelectedRelevantPlot = null;
                SelectedRelevantSpace = null;
            }
        }

        void setRelevantSpaces()
        {
            if (leases != null)
            {
                RelevantSpaces = leases.Where(x => x.PlotId == SelectedRelevantPlot.PlotId).ToList();
                SelectedRelevantSpace = RelevantSpaces.FirstOrDefault();
            }
        }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

}
