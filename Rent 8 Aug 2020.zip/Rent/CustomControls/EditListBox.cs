﻿using System.Windows;
using System.Windows.Controls;

namespace Rent.CustomControls
{
    public class EditListBox : ListBox
    {
        static EditListBox()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(EditListBox), new FrameworkPropertyMetadata(typeof(EditListBox)));
        }
    }
}
