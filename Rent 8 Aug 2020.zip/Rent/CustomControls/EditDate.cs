﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace Rent.CustomControls
{
    public class EditDate : Control
    {
        static EditDate()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(EditDate), new FrameworkPropertyMetadata(typeof(EditDate)));
        }

        public string Label
        {
            get { return (string)GetValue(LabelProperty); }
            set { SetValue(LabelProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Label.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty LabelProperty =
            DependencyProperty.Register("Label", typeof(string), typeof(EditDate), new PropertyMetadata(null));

        public DateTime NonEditable
        {
            get { return (DateTime)GetValue(NonEditableProperty); }
            set { SetValue(NonEditableProperty, value); }
        }

        // Using a DependencyProperty as the backing store for NonEditable.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty NonEditableProperty =
            DependencyProperty.Register("NonEditable", typeof(DateTime), typeof(EditDate), new PropertyMetadata(DateTime.Now));


        public DateTime Editable
        {
            get { return (DateTime)GetValue(EditableProperty); }
            set { SetValue(EditableProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Editable.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty EditableProperty =
            DependencyProperty.Register("Editable", typeof(DateTime), typeof(EditDate), new FrameworkPropertyMetadata(DateTime.Now, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));


        public bool IsOnEdit
        {
            get { return (bool)GetValue(IsOnEditProperty); }
            set { SetValue(IsOnEditProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsOnEdit.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsOnEditProperty =
            DependencyProperty.Register("IsOnEdit", typeof(bool), typeof(EditDate), new PropertyMetadata(false, OnIsOnEditChanged));

        static void OnIsOnEditChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if ((bool)e.NewValue) (d as EditDate).IsNotOnEdit = false;
            else (d as EditDate).IsNotOnEdit = true;
        }

        public bool IsNotOnEdit
        {
            get { return (bool)GetValue(IsNotOnEditProperty); }
            set { SetValue(IsNotOnEditProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsNotOnEdit.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsNotOnEditProperty =
            DependencyProperty.Register("IsNotOnEdit", typeof(bool), typeof(EditDate), new PropertyMetadata(true));
    }
}
