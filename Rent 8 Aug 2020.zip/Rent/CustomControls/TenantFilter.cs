﻿using System.Windows;
using System.Windows.Controls;

namespace Rent.CustomControls
{

    public class TenantFilter : CheckBox
    {
        static TenantFilter()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(TenantFilter), new FrameworkPropertyMetadata(typeof(TenantFilter)));
        }
    }
}
