﻿using System.Windows.Controls;

namespace Rent.View.Edit
{
    /// <summary>
    /// Interaction logic for LeaseView.xaml
    /// </summary>
    public partial class LeaseView : UserControl
    {
        public LeaseView()
        {
            InitializeComponent();
        }
    }
}
