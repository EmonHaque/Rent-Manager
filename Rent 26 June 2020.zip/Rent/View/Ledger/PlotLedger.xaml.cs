﻿using System.Windows.Controls;

namespace Rent.View.Ledger
{
    /// <summary>
    /// Interaction logic for PlotLedger.xaml
    /// </summary>
    public partial class PlotLedger : UserControl
    {
        public PlotLedger()
        {
            InitializeComponent();
        }
    }
}
