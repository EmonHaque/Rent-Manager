﻿namespace Rent.Model
{
    public enum ViewType
    {
        Plot,
        Space,
        Tenant,
        Lease,
        Head
    }
}
