﻿using System.Collections.Generic;

namespace Rent.Model
{
    public class PrimarySummary
    {
        public string Plot { get; set; }
        public string Space { get; set; }
        public string TenantName { get; set; }
        public int TenantId { get; set; }
        public int ControlId { get; set; }
        public int HeadId { get; set; }
        public int Amount { get; set; }
    }

    public class SecondarySummary
    {
        public string Space { get; set; }
        public string Tenant { get; set; }
        public int SecurityDeposit { get; set; }
        public int Receivables { get; set; }
        public int Receipts { get; set; }
        public int Adjustments { get; set; }
        public int Dues { get; set; }
        public bool IsExpired { get; set; }
    }

    public class TenantSummary
    {
        public string Plot { get; set; }
        public List<SecondarySummary> Summary { get; set; }
    }
}
