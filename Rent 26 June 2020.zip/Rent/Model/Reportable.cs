﻿using System;

namespace Rent.Model
{
    public class Reportable
	{
		public DateTime Date { get; set; }
		public string PlotName { get; set; }
		public string SpaceName { get; set; }
		public string TenantName { get; set; }
		public string HeadName { get; set; }
		public int Receivable { get; set; }
		public int Receipt { get; set; }
		public int Balance { get; set; }
        public int ControlId { get; set; }
        public int TenantId { get; set; }
        public string Narration { get; set; }
	}
}
