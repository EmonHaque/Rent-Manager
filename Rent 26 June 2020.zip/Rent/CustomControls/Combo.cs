﻿using System.Windows;
using System.Windows.Controls;

namespace Rent.CustomControls
{
    public class Combo : ComboBox
    {
        static Combo()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(Combo), new FrameworkPropertyMetadata(typeof(Combo)));
        }
    }
}
