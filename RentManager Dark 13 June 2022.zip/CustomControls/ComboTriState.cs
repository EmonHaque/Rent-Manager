﻿class ComboTriState : Grid
{
    TriState editableState, nonEditableState;
    public string Text { get; set; }
    public string Editable { get; set; }
    public string NonEditable { get; set; }
    public ComboTriState() {
        editableState = new TriState() { 
            Text = "Cash",
            Visibility = Visibility.Hidden,
            CheckedIcon = Icons.Cash,
            UncheckedIcon = Icons.Noncash,
            UndefinedIcon = Icons.Phone
        };
        nonEditableState = new TriState() {
            Text = "Cash",
            IsEnabled = false,
            CheckedIcon = Icons.Cash,
            UncheckedIcon = Icons.Noncash,
            UndefinedIcon = Icons.Phone
        };
        var dd = DependencyPropertyDescriptor.FromProperty(TriState.StateProperty, typeof(TriState));
        dd.AddValueChanged(editableState, stateChangedHandler);
        dd.AddValueChanged(nonEditableState, stateChangedHandler);
        
        Children.Add(editableState);
        Children.Add(nonEditableState);
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }
    void stateChangedHandler(object s, EventArgs e) {
        var state = (TriState)s;
        switch (state.State) {
            case true: state.Text = "Cash"; break;
            case false: state.Text = "Noncash"; break;
            default: state.Text = "Mobile"; break;
        }
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
    }
    void onLoaded(object sender, RoutedEventArgs e) {
        editableState.SetBinding(TriState.StateProperty, new Binding(Editable));
        nonEditableState.SetBinding(TriState.StateProperty, new Binding(NonEditable));
    }

    public bool IsOnEdit {
        get { return (bool)GetValue(IsOnEditProperty); }
        set { SetValue(IsOnEditProperty, value); }
    }
    public static readonly DependencyProperty IsOnEditProperty =
        DependencyProperty.Register("IsOnEdit", typeof(bool), typeof(ComboTriState), new PropertyMetadata() {
            DefaultValue = false,
            PropertyChangedCallback = (s, e) => {
                var o = (ComboTriState)s;
                if ((bool)e.NewValue) {
                    o.editableState.Visibility = Visibility.Visible;
                    o.nonEditableState.Visibility = Visibility.Hidden;
                }
                else {
                    o.editableState.Visibility = Visibility.Hidden;
                    o.nonEditableState.Visibility = Visibility.Visible;
                }
            }
        });
}
