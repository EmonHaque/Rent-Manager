﻿public class SQLHelper
    {
        public static SqliteConnection connection = new(Constants.ConnectionString);
        public static object key = new();
        
        public static void NonQuery(string command){
            using var cmd = connection.CreateCommand();
            cmd.CommandText = command;
            connection.Open();
            cmd.ExecuteNonQuery();
            connection.Close();
        }

        public static void NonQuery(SqliteCommand command){
            connection.Open();
            command.ExecuteNonQuery();
            connection.Close();
        }

        public static void Transaction(IEnumerable<SqliteCommand> commands){
            connection.Open();
            using var transaction = connection.BeginTransaction();
            try{
                foreach (var command in commands){
                    command.Connection = connection;
                    command.Transaction = transaction;
                    command.ExecuteNonQuery();
                }
                transaction.Commit();
            }
            catch (Exception){
                transaction.Rollback();
            }
            connection.Close();
        }
    }
