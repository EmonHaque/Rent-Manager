﻿abstract class LedgerView : CardView
    {
        SelectItem items;
        DayPicker startDate, endDate;
        CommandButton refresh, exportCSV, print;
        Ledger report;
        TextBlock title;
        EditText search;
        protected virtual string display { get; }
        protected virtual DataTemplate template { get; }
        protected virtual ControlTemplate groupTemplate { get; }
        protected abstract ReportBase viewModel { get; }
        public LedgerView() : base() {
            DataContext = viewModel;
            initializeUI();
            if (display == null) items.ItemTemplate = template;
            else items.DisplayPath = display;
            if (groupTemplate != null) items.GroupTemplate = groupTemplate;
            bind();
        }

        void initializeUI() {
            items = new SelectItem() {
                Hint = Header,
                Icon = Icon,
                IsRequired = true,
                SelectedValuePath = "Id"
            };
            startDate = new DayPicker() {
                Hint = "From",
                DateFormat = "dd/MM/yyyy",
                IsRequired = true
            };
            endDate = new DayPicker() {
                Hint = "To",
                DateFormat = "dd/MM/yyyy",
                IsRequired = true
            };
            refresh = new CommandButton() {
                Icon = Icons.Refresh,
                Margin = new Thickness(0,5,0,0),
                VerticalAlignment = VerticalAlignment.Center,
                Command = viewModel.RefreshReport
            };
            exportCSV = new CommandButton() {
                Icon = Icons.CSV,
                Command = viewModel.ExportCSV
            };
            print = new CommandButton() {
                Icon = Icons.Print,
                Margin = new Thickness(5,0,0,0),
                Command = viewModel.PrintReport
            };
            report = new Ledger(viewModel, nameof(viewModel.ParticularsQuery));
            title = new TextBlock() { 
                FontSize = 18, 
                Margin = new Thickness(5, 0, 0, 0),
                VerticalAlignment = VerticalAlignment.Center
            };
            search = new EditText() {
                Hint = "Particulars",
                Icon = Icons.Search,
                IsTrimBottomRequested = true
            };
            Grid.SetColumn(search, 1);
            Grid.SetColumn(exportCSV, 2);
            Grid.SetColumn(print, 3);
            var titleGrid = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = new GridLength(400)},
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto }
                },
                Children = { title, search, exportCSV, print}
            };

            Grid.SetColumn(startDate, 1);
            Grid.SetColumn(endDate, 2);
            Grid.SetColumn(refresh, 3);
            Grid.SetRow(titleGrid, 1);
            Grid.SetColumnSpan(titleGrid, 4);
            Grid.SetRow(report, 2);
            Grid.SetColumnSpan(report, 4);
            var grid = new Grid() {
                RowDefinitions = {
                    new RowDefinition(){ Height = new GridLength(48) },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(),
                },
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto }
                },
                Children = { items, startDate, endDate, refresh, titleGrid, report }
            };
            setContent(grid);
        }
        void bind() {
            items.SetBinding(SelectItem.SelectedvalueProperty, new Binding(nameof(viewModel.Id)));
            items.SetBinding(SelectItem.ItemsSourceProperty, new Binding(nameof(viewModel.selectionView)));
            items.SetBinding(SelectItem.QueryProperty, new Binding(nameof(viewModel.Query)) { Mode = BindingMode.OneWayToSource });
           
            report.SetBinding(Ledger.ItemsSourceProperty, new Binding(nameof(viewModel.Reportables)));
            report.SetBinding(Ledger.SummaryProperty, new Binding(nameof(viewModel.Summary)));

            startDate.SetBinding(DayPicker.StartDateProperty, new Binding($"{nameof(viewModel.Dates)}.{nameof(ReportDates.Start)}"));
            startDate.SetBinding(DayPicker.EndDateProperty, new Binding($"{nameof(viewModel.Dates)}.{nameof(ReportDates.End)}"));
            startDate.SetBinding(DayPicker.SelectedDateProperty, new Binding($"{nameof(viewModel.Dates)}.{nameof(ReportDates.From)}"));

            endDate.SetBinding(DayPicker.StartDateProperty, new Binding($"{nameof(viewModel.Dates)}.{nameof(ReportDates.Start)}"));
            endDate.SetBinding(DayPicker.EndDateProperty, new Binding($"{nameof(viewModel.Dates)}.{nameof(ReportDates.End)}"));
            endDate.SetBinding(DayPicker.SelectedDateProperty, new Binding($"{nameof(viewModel.Dates)}.{nameof(ReportDates.To)}"));

            var binding = new Binding(nameof(viewModel.IsPrintOrExportValid));
            print.SetBinding(CommandButton.IsEnabledProperty, binding);
            exportCSV.SetBinding(CommandButton.IsEnabledProperty, binding);
            refresh.SetBinding(CommandButton.IsEnabledProperty, new Binding(nameof(viewModel.IsRefreshValid)));

            title.SetBinding(TextBlock.TextProperty, new Binding($"{nameof(viewModel.Summary)}.{nameof(ReportSummary.Heading)}"));
            search.SetBinding(EditText.TextProperty, new Binding(nameof(viewModel.ParticularsQuery)) { Mode = BindingMode.OneWayToSource });
        }
    }
