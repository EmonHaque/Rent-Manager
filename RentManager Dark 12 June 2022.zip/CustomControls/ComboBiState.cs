﻿class ComboBiState : Grid
{
    BiState editableState, nonEditableState;
    public string Text { get; set; }
    public string Editable { get; set; }
    public string NonEditable { get; set; }
    public ComboBiState() {
        editableState = new BiState() { Visibility = Visibility.Hidden };
        nonEditableState = new BiState() { IsEnabled = false };
        Children.Add(editableState);
        Children.Add(nonEditableState);
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }

    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
    }
    void onLoaded(object sender, RoutedEventArgs e) {
        editableState.Text = nonEditableState.Text = Text;
        editableState.SetBinding(BiState.IsTrueProperty, new Binding(Editable));
        nonEditableState.SetBinding(BiState.IsTrueProperty, new Binding(NonEditable));
    }

    public bool IsOnEdit {
        get { return (bool)GetValue(IsOnEditProperty); }
        set { SetValue(IsOnEditProperty, value); }
    }
    public static readonly DependencyProperty IsOnEditProperty =
        DependencyProperty.Register("IsOnEdit", typeof(bool), typeof(ComboBiState), new PropertyMetadata() {
            DefaultValue = false,
            PropertyChangedCallback = (s, e) => {
                var o = (ComboBiState)s;
                if ((bool)e.NewValue) {
                    o.editableState.Visibility = Visibility.Visible;
                    o.nonEditableState.Visibility = Visibility.Hidden;
                }
                else {
                    o.editableState.Visibility = Visibility.Hidden;
                    o.nonEditableState.Visibility = Visibility.Visible;
                }
            }
        });
}

