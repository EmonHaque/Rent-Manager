﻿class Card : Border
{
    Grid container, headerContainer;
    TextBlock headerBlock;
    Separator divider;
    UIElement content;
    StackPanel tools;
    public UIElement Content {
        get { return content; }
        set {
            content = value;
            Grid.SetRow(value, 2);
            container.Children.Add(value);
        }
    }
    string header;
    public string Header {
        get { return header; }
        set {
            header = value;
            headerBlock.Text = value;
            headerContainer.Visibility = Visibility.Visible;
        }
    }

    public Card() {
        headerBlock = new TextBlock() { FontSize = 16 };
        tools = new StackPanel() { Orientation = Orientation.Horizontal };
        Grid.SetColumn(tools, 1);
        headerContainer = new Grid() {
            Visibility = Visibility.Collapsed,
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { headerBlock, tools }
        };
        divider = new Separator() {
            Margin = new Thickness(0, 0, 0, 5),
            Background = Brushes.LightGray
        };
        Grid.SetRow(divider, 1);
        container = new Grid() {
            RowDefinitions = {
                    new RowDefinition(){Height = GridLength.Auto},
                    new RowDefinition(){Height = GridLength.Auto},
                    new RowDefinition()
                },
            Children = { headerContainer, divider }
        };
        Margin = Constants.CardMargin;
        Padding = new Thickness(5);
        CornerRadius = new CornerRadius(5);
        Background = Constants.Background;
        Effect = new DropShadowEffect() { BlurRadius = 10, ShadowDepth = 0, Color = Color.FromRgb(60, 60, 60) };
        Child = container;
    }
    public void AddActions(ActionButton action) {
        tools.Children.Add(action);
    }
    protected override Size MeasureOverride(Size constraint) {
        container.Width = constraint.Width - Padding.Left - Padding.Right;
        container.Height = constraint.Height - Padding.Top - Padding.Bottom;
        return constraint;
    }
}