﻿class MultiBar : FrameworkElement
{
    SolidColorBrush cashBrush, mobileBrush, kindBrush, dueBrush;
    Color cashNormal, cashHilight, mobileNormal, mobileHighlight, kindNormal, kindHilight, dueNormal, dueHilight;
    Border cashBorder, mobileBorder, kindBorder, dueBorder;
    ColorAnimation cashBrushAnim, mobileBrushAnim, kindBrushAnim, dueBrushAnim;
    ScaleTransform transform;
    HomeBarTip tip;
    VisualCollection children;
    int cashTotal, mobileTotal, kindTotal, dueTotal;
    double upperBound, lowerBound, posHeight, negHeight;

    public MultiBar(List<RentPayment> payment) {
        Margin = new Thickness(5, 0, 0, 0);
        children = new VisualCollection(this);
        tip = new HomeBarTip(payment);
        cashNormal = Colors.Gray;
        cashHilight = Colors.Coral;
        mobileNormal = Colors.Green;
        mobileHighlight = Colors.Red;
        kindNormal = Colors.CadetBlue;
        kindHilight = Colors.LightGreen;
        
        dueNormal = Colors.DarkCyan;
        dueHilight = Colors.LightCoral;
        cashBrush = new SolidColorBrush(cashNormal);
        mobileBrush = new SolidColorBrush(mobileNormal);
        kindBrush = new SolidColorBrush(kindNormal);
        dueBrush = new SolidColorBrush(dueNormal);
        transform = new ScaleTransform(0, 0);
        foreach (var item in payment) {
            cashTotal += item.Cash;
            mobileTotal += item.Mobile;
            kindTotal += item.Kind;
        }
        dueTotal = payment.First().Due;
        cashBorder = new Border() { Background = cashBrush };

        dueBorder = new Border() {
            Background = dueBrush,
            CornerRadius = new CornerRadius(0, 0, 10, 10)
        };
        children.Add(cashBorder);
        children.Add(dueBorder);

        //if(mobileTotal > 0) {
       

        if (kindTotal > 0) {
            mobileBorder = new Border() { Background = mobileBrush };
        }
        else {
            mobileBorder = new Border() {
                Background = mobileBrush,
                CornerRadius = new CornerRadius(0, 0, 10, 10)
            };
        }
        children.Add(mobileBorder);
        mobileBrushAnim = new ColorAnimation() {
            Duration = TimeSpan.FromSeconds(1),
            EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
        };
        //}

        //if (kindTotal > 0) {
        
        kindBorder = new Border() {
            Background = kindBrush,
            CornerRadius = new CornerRadius(0, 0, 10, 10)
        };
        children.Add(kindBorder);
        kindBrushAnim = new ColorAnimation() {
            Duration = TimeSpan.FromSeconds(1),
            EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
        };
        //}
        cashBrushAnim = new ColorAnimation() {
            Duration = TimeSpan.FromSeconds(1),
            EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
        };
        dueBrushAnim = new ColorAnimation() {
            Duration = TimeSpan.FromSeconds(1),
            EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
        };
        RenderTransform = transform;
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }

    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
    }

    void onLoaded(object sender, RoutedEventArgs e) {
        var borderScaleAnim = new DoubleAnimation() {
            BeginTime = TimeSpan.FromSeconds(0.75),
            To = 1,
            Duration = TimeSpan.FromSeconds(1),
            EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
        };
        transform.BeginAnimation(ScaleTransform.ScaleXProperty, borderScaleAnim);
        transform.BeginAnimation(ScaleTransform.ScaleYProperty, borderScaleAnim);
    }
    public void SetParameters(double lower, double upper, double posHeight, double negHeight) {
        lowerBound = lower;
        upperBound = upper;
        this.posHeight = posHeight;
        this.negHeight = negHeight;
    }
    protected override Size MeasureOverride(Size availableSize) {
        if (availableSize.Width <= Margin.Left) return availableSize;
        var width = availableSize.Width - Margin.Left;
        cashBorder.Width = dueBorder.Width = transform.CenterX = width / 2;
        transform.CenterY = negHeight;
        cashBorder.Height = cashTotal / upperBound * posHeight;
        if (dueTotal >= 0) dueBorder.Height = dueTotal / upperBound * posHeight;
        else {
            dueBorder.Height = Math.Abs(dueTotal) / lowerBound * negHeight;
            dueBorder.CornerRadius = new CornerRadius(10, 10, 0, 0);
        }
        //if (kindBorder != null) {

        mobileBorder.Width = cashBorder.Width;
        mobileBorder.Height = mobileTotal / upperBound * posHeight;

        kindBorder.Width = cashBorder.Width;
        kindBorder.Height = kindTotal / upperBound * posHeight;

        if (mobileTotal == 0 && kindTotal == 0) {
            cashBorder.CornerRadius = new CornerRadius(0, 0, 10, 10);
        }
        //}
        //else cashBorder.CornerRadius = new CornerRadius(0, 0, 10, 10);
        foreach (UIElement item in children)
            item.Measure(availableSize);
        return availableSize;
    }
    protected override Size ArrangeOverride(Size finalSize) {
        if (finalSize.Width <= Margin.Left) return finalSize;
        if (dueTotal > 0) dueBorder.Arrange(new Rect(new Point(Margin.Left, negHeight), dueBorder.DesiredSize));
        else dueBorder.Arrange(new Rect(new Point(Margin.Left, negHeight - dueBorder.DesiredSize.Height), dueBorder.DesiredSize));

        cashBorder.Arrange(new Rect(new Point(Margin.Left + dueBorder.DesiredSize.Width, negHeight), cashBorder.DesiredSize));
        mobileBorder.Arrange(new Rect(new Point(Margin.Left + dueBorder.DesiredSize.Width, negHeight + cashBorder.DesiredSize.Height), mobileBorder.DesiredSize));
        //if (kindBorder != null)
        kindBorder.Arrange(new Rect(new Point(Margin.Left + dueBorder.DesiredSize.Width, negHeight + cashBorder.DesiredSize.Height + mobileBorder.DesiredSize.Height), kindBorder.DesiredSize));
        return finalSize;
    }
    protected override void OnMouseEnter(MouseEventArgs e) {
        cashBrushAnim.To = cashHilight;
        dueBrushAnim.To = dueHilight;
        cashBrush.BeginAnimation(SolidColorBrush.ColorProperty, cashBrushAnim);
        dueBrush.BeginAnimation(SolidColorBrush.ColorProperty, dueBrushAnim);
        //if (kindTotal > 0) {

        mobileBrushAnim.To = mobileHighlight;
        mobileBrush.BeginAnimation(SolidColorBrush.ColorProperty, mobileBrushAnim);

        kindBrushAnim.To = kindHilight;
        kindBrush.BeginAnimation(SolidColorBrush.ColorProperty, kindBrushAnim);
        //}
        tip.IsOpen = true;
    }
    protected override void OnMouseLeave(MouseEventArgs e) {
        cashBrushAnim.To = cashNormal;
        dueBrushAnim.To = dueNormal;
        cashBrush.BeginAnimation(SolidColorBrush.ColorProperty, cashBrushAnim);
        dueBrush.BeginAnimation(SolidColorBrush.ColorProperty, dueBrushAnim);

        //if (kindTotal > 0) {
        mobileBrushAnim.To = mobileNormal;
        mobileBrush.BeginAnimation(SolidColorBrush.ColorProperty, mobileBrushAnim);

        kindBrushAnim.To = kindNormal;
        kindBrush.BeginAnimation(SolidColorBrush.ColorProperty, kindBrushAnim);
        //}
        tip.IsOpen = false;
    }
    protected override Visual GetVisualChild(int index) => children[index];
    protected override int VisualChildrenCount => children.Count;
}
