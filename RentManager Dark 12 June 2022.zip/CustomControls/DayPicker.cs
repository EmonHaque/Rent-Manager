﻿class DayPicker : Border
{
    Grid dayMonthYearContainer, dayNameContainer, headerContainer, rootGrid;
    Border dayNameBorder, headerBorder, selectedBorder, popContent;
    Popup pop;
    StackPanel popContentPanel;
    TextBlock headerBlock, hintBlock;
    ContentControl selectedContent;
    TextBox inputBox;
    Path leftIcon;
    CommandButton popOpener, back, forward;
    SolidColorBrush brush;
    Run errorText, formatText;
    TranslateTransform translateHint;
    ScaleTransform scaleHint;
    DoubleAnimation translateHintAnim, scaleHintAnim;
    ColorAnimation brushAnim;
    DateTime currentDate;
    CalendarState currentState;
    bool isHintMoved;
    int floorYear, capYear;

    string hint;
    public string Hint {
        get { return hint; }
        set { hint = value; hintBlock.Inlines.Add(value); }
    }
    string dateFormat;
    public string DateFormat {
        get { return dateFormat; }
        set {
            dateFormat = value;
            formatText = new Run() {
                Text = $" [{value}]",
                FontStyle = FontStyles.Italic,
                Foreground = Brushes.Gray
            };
            hintBlock.Inlines.Add(formatText);
        }
    }
    bool isRequired;
    public bool IsRequired {
        get { return isRequired; }
        set { isRequired = value; }
    }
    public DayPicker() {
        Margin = new Thickness(5, 10, 5, 5);
        VerticalAlignment = VerticalAlignment.Center;
        brush = new SolidColorBrush(Colors.LightGray);
        errorText = new Run() {
            Foreground = Brushes.Coral,
            FontStyle = FontStyles.Italic
        };
        initializeSelectedItemControls();
        initializeAnimations();
        initializeControls();

        rootGrid = new Grid() {
            ColumnDefinitions = {
                    new ColumnDefinition(){Width = GridLength.Auto},
                    new ColumnDefinition(),
                    new ColumnDefinition(){Width = GridLength.Auto}
                },
            Children = { leftIcon, inputBox, hintBlock, selectedBorder, popOpener }
        };
        BorderThickness = new Thickness(0, 0, 0, 1);
        BorderBrush = brush;
        Child = rootGrid;

        initializeDayContainer();
        addHeader();

        popContentPanel = new StackPanel() { Children = { headerContainer, dayNameBorder, dayMonthYearContainer } };
        currentState = CalendarState.Day;
        popContent.Child = popContentPanel;
        pop = new Popup() {
            AllowsTransparency = true,
            StaysOpen = false,
            Placement = PlacementMode.Bottom,
            PlacementTarget = this,
            Child = popContent
        };
        pop.Opened += setIcon;
        pop.Closed += resetIcon;
        dayMonthYearContainer.MouseLeftButtonUp += onDayMonthYearClicked;
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
        dayMonthYearContainer.MouseLeftButtonUp -= onDayMonthYearClicked;
        pop.Opened -= setIcon;
        pop.Closed -= resetIcon;
        selectedContent.MouseLeftButtonUp -= onClickOnSlectedContent;
        inputBox.KeyUp -= setDate;
        headerBorder.MouseUp -= resetState;
    }
    void onLoaded(object sender, RoutedEventArgs e) => checkDateValidity();
    void onDayMonthYearClicked(object sender, MouseButtonEventArgs e) {
        if (e.Source is Day) {
            var element = e.Source as Day;
            currentDate = new DateTime(currentDate.Year, currentDate.Month, element.day);
            foreach (Day item in dayMonthYearContainer.Children) {
                if (item.IsSelected) {
                    item.IsSelected = false;
                    break;
                }
            }
            SelectedDate = currentDate;
            element.IsSelected = true;
            setSelectedItem();
            checkDateValidity();
        }
        else if (e.Source is MonthYear) {
            foreach (MonthYear item in dayMonthYearContainer.Children) {
                if (item.IsSelected) {
                    item.IsSelected = false;
                    break;
                }
            }
            var element = e.Source as MonthYear;
            if (element.state == CalendarState.Month) {
                currentDate = new DateTime(currentDate.Year, element.number, 1);
                dayNameBorder.Visibility = Visibility.Visible;
                addDays(currentDate);
            }
            else {
                currentDate = new DateTime(element.number, 1, 1);
                addMonths();
            }
            element.IsSelected = true;
            checkDateValidity();
        }
    }
    void setIcon(object sender, EventArgs e) => popOpener.Icon = Icons.CalendarSearch;
    void resetIcon(object sender, EventArgs e) {
        popOpener.Icon = Icons.CalendarEdit;
        currentDate = SelectedDate == null ? DateTime.Today : SelectedDate.Value;
        dayNameBorder.Visibility = Visibility.Visible;
    }
    void initializeAnimations() {
        var duration = TimeSpan.FromMilliseconds(250);
        var ease = new CubicEase { EasingMode = EasingMode.EaseInOut };
        scaleHintAnim = new DoubleAnimation {
            Duration = duration,
            EasingFunction = ease
        };
        translateHintAnim = new DoubleAnimation {
            Duration = duration,
            EasingFunction = ease
        };
        brushAnim = new ColorAnimation {
            Duration = duration,
            EasingFunction = ease
        };
    }
    void initializeSelectedItemControls() {
        selectedContent = new ContentControl() {
            Margin = new Thickness(10, 0, 0, 0),
            VerticalAlignment = VerticalAlignment.Center,
            FocusVisualStyle = null,
        };
        var close = new CommandButton() {
            Width = 12,
            Height = 12,
            Margin = new Thickness(5, 0, 0, 0),
            Icon = Icons.CloseCircle,
            Command = removeSelected
        };
        Grid.SetColumn(close, 1);
        selectedBorder = new Border() {
            Background = new SolidColorBrush(Color.FromRgb(60, 60, 60)),
            Margin = new Thickness(5, 0, 5, 0),
            CornerRadius = new CornerRadius(5),
            Padding = new Thickness(5, 0, 5, 0),
            Visibility = Visibility.Hidden,
            Child = new Grid() {
                ColumnDefinitions = {
                        new ColumnDefinition(),
                        new ColumnDefinition(){Width = GridLength.Auto}
                    },
                Children = { selectedContent, close }
            }
        };
        Grid.SetColumn(selectedBorder, 1);
        selectedContent.MouseLeftButtonUp += onClickOnSlectedContent;
    }
    void onClickOnSlectedContent(object sender, MouseButtonEventArgs e) => showCalendar();
    void initializeControls() {
        leftIcon = new Path() {
            Fill = brush,
            Data = Geometry.Parse(Icons.Calendar),
            Stretch = Stretch.Uniform,
            Width = 12,
            Height = 12
        };
        translateHint = new TranslateTransform();
        scaleHint = new ScaleTransform();

        hintBlock = new TextBlock {
            Padding = new Thickness(5, 0, 5, 0),
            //Foreground = Brushes.Gray,
            //Background = Brushes.White,
            HorizontalAlignment = HorizontalAlignment.Left,
            VerticalAlignment = VerticalAlignment.Center,
            RenderTransform = new TransformGroup {
                Children = { scaleHint, translateHint }
            }
        };
        Grid.SetColumn(hintBlock, 1);
        inputBox = new TextBox() {
            Margin = new Thickness(5),
            BorderThickness = new Thickness(0)
        };
        Grid.SetColumn(inputBox, 1);
        popOpener = new CommandButton() {
            Width = 12,
            Height = 12,
            Icon = Icons.CalendarEdit,
            Command = showCalendar
        };
        Grid.SetColumn(popOpener, 2);
        inputBox.KeyUp += setDate;
    }
    void initializeDayContainer() {
        string[] days = { "Sat", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri" };
        dayMonthYearContainer = new Grid();
        dayNameContainer = new Grid();

        for (int i = 0; i < 7; i++) {
            dayNameContainer.ColumnDefinitions.Add(new ColumnDefinition());

            var dayName = new TextBlock() {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                FontWeight = FontWeights.Bold,
                Text = days[i]
            };
            Grid.SetColumn(dayName, i);
            dayNameContainer.Children.Add(dayName);
        }

        dayNameBorder = new Border() {
            BorderThickness = new Thickness(0, 1, 0, 1),
            Padding = new Thickness(0, 5, 0, 5),
            Margin = new Thickness(0, 5, 0, 5),
            BorderBrush = Brushes.LightGray,
            Child = dayNameContainer
        };

        currentDate = DateTime.Today;
        popContent = new Border() {
            Width = 350,
            Margin = new Thickness(5),
            Padding = new Thickness(5),
            CornerRadius = new CornerRadius(5),
            Background = Constants.Background,
            Effect = new DropShadowEffect() { BlurRadius = 5, ShadowDepth = 0 }
        };
    }
    void setDate(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;
        DateTime input;
        if (DateTime.TryParseExact(inputBox.Text, DateFormat, null, DateTimeStyles.None, out input)) {
            currentDate = input;
            SelectedDate = input;
        }
    }
    void setSelectedItem() {
        if (!isHintMoved) moveHintUp();
        inputBox.IsEnabled = false;
        selectedContent.Content = SelectedDate.Value.ToString("dd MMMM yyyy");
        selectedBorder.Visibility = Visibility.Visible;
        hintBlock.Inlines.Remove(formatText);
        if (IsRequired && string.IsNullOrWhiteSpace(Error)) hintBlock.Inlines.Remove(errorText);
        if(currentState == CalendarState.Day) {
            foreach (Day item in dayMonthYearContainer.Children) {
                if (item.IsSelected) {
                    item.IsSelected = false;
                    break;
                }
            }
        }
        //addDays(currentDate);
        pop.IsOpen = false;
        Keyboard.Focus(selectedContent);
    }
    void removeSelected() {
        selectedBorder.Visibility = Visibility.Hidden;
        inputBox.Text = string.Empty;
        inputBox.IsEnabled = true;
        SelectedDate = null;
        hintBlock.Inlines.Add(formatText);
        if (IsRequired) hintBlock.Inlines.Add(errorText);
        currentDate = DateTime.Today;
        if (isHintMoved) moveHintDown();
        addDays(currentDate);
    }
    void animateHint() {
        translateHint.BeginAnimation(TranslateTransform.YProperty, translateHintAnim);
        scaleHint.BeginAnimation(ScaleTransform.ScaleYProperty, scaleHintAnim);
        scaleHint.BeginAnimation(ScaleTransform.ScaleXProperty, scaleHintAnim);
    }
    void showCalendar() {
        addDays(currentDate);
        checkDateValidity();
        pop.IsOpen = true;
    }
    void resetState(object sender, MouseButtonEventArgs e) {
        switch (currentState) {
            case CalendarState.Day:
                dayNameBorder.Visibility = Visibility.Collapsed;
                addMonths();
                break;
            case CalendarState.Month:
                addYears();
                break;
            case CalendarState.Year:
                dayNameBorder.Visibility = Visibility.Visible;
                currentDate = SelectedDate == null ? DateTime.Today : SelectedDate.Value;
                addDays(currentDate);
                break;
        }
        checkDateValidity();
    }
    void increase() {
        switch (currentState) {
            case CalendarState.Day:
                currentDate = currentDate.AddMonths(1);
                currentDate = new DateTime(currentDate.Year, currentDate.Month, DateTime.DaysInMonth(currentDate.Year, currentDate.Month));
                addDays(currentDate);
                break;
            case CalendarState.Month:
                currentDate = currentDate.AddYears(1);
                currentDate = new DateTime(currentDate.Year, 12, 31);
                addMonths();
                break;
            case CalendarState.Year:
                floorYear = currentDate.Year;
                currentDate = currentDate.AddYears(12);
                capYear = currentDate.Year;
                addYears();
                break;
        }
        checkDateValidity();
    }
    void decrease() {
        switch (currentState) {
            case CalendarState.Day:
                currentDate = currentDate.AddMonths(-1);
                currentDate = new DateTime(currentDate.Year, currentDate.Month, 1);
                addDays(currentDate);
                break;
            case CalendarState.Month:
                currentDate = currentDate.AddYears(-1);
                currentDate = new DateTime(currentDate.Year, 1, 31);
                addMonths();
                break;
            case CalendarState.Year:
                capYear = currentDate.Year;
                currentDate = currentDate.AddYears(-12);
                floorYear = currentDate.Year;
                addYears();
                break;
        }
        checkDateValidity();
    }
    void checkDateValidity() {
        if (EndDate == null && StartDate == null) return;
        if (currentState == CalendarState.Day) {
            if (DateTime.Compare(EndDate.Value, currentDate) > 0) forward.IsEnabled = true;
            else forward.IsEnabled = false;

            if (DateTime.Compare(StartDate.Value, currentDate) < 0) back.IsEnabled = true;
            else back.IsEnabled = false;
        }
        else if (currentState == CalendarState.Month) {
            if (currentDate.Year < EndDate.Value.Year) forward.IsEnabled = true;
            else forward.IsEnabled = false;

            if (currentDate.Year > StartDate.Value.Year) back.IsEnabled = true;
            else back.IsEnabled = false;
        }
        else {
            if (capYear < EndDate.Value.Year) forward.IsEnabled = true;
            else forward.IsEnabled = false;

            if (floorYear > StartDate.Value.Year) back.IsEnabled = true;
            else back.IsEnabled = false;
        }
    }
    void addDays(DateTime currentDate) {
        currentState = CalendarState.Day;
        headerBlock.Text = currentDate.ToString("MMMM, yyyy");

        dayMonthYearContainer.Children.Clear();
        dayMonthYearContainer.RowDefinitions.Clear();
        dayMonthYearContainer.ColumnDefinitions.Clear();
        for (int i = 0; i < 7; i++)
            dayMonthYearContainer.ColumnDefinitions.Add(new ColumnDefinition());

        var numberOfDays = DateTime.DaysInMonth(currentDate.Year, currentDate.Month);
        var currentDay = 1;
        var dayOfWeek = (int)new DateTime(currentDate.Year, currentDate.Month, currentDay).DayOfWeek;
        var newDayOfWeek = dayOfWeek == 6 ? 0 : dayOfWeek + 1;

        int requiredRows = 1;
        var remainingDays = numberOfDays - 7 + newDayOfWeek;
        requiredRows += remainingDays / 7;
        var remainder = remainingDays % 7;
        if (remainder != 0) requiredRows++;

        var today = DateTime.Today;
        var isInSelectedMonth = SelectedDate.HasValue ?
            (SelectedDate.Value.Month == currentDate.Month && SelectedDate.Value.Year == currentDate.Year)
            : false;
        for (int i = 0; i < requiredRows; i++) {
            dayMonthYearContainer.RowDefinitions.Add(new RowDefinition());
            int k = currentDay == 1 ? newDayOfWeek : 0;
            for (int j = k; j < 7; j++) {
                if (currentDay < numberOfDays + 1) {
                    var day = new Day(currentDay);
                    if (isInSelectedMonth) {
                        if (currentDay == SelectedDate.Value.Day)
                            day.IsSelected = true;
                    }
                    if (currentDay == today.Day && currentDate.Month == today.Month && currentDate.Year == today.Year)
                        day.IsToday = true;

                    if (StartDate != null && EndDate != null) {
                        if (currentDate.Month == StartDate.Value.Month && currentDate.Year == StartDate.Value.Year) {
                            if (currentDay < StartDate.Value.Day)
                                day.Visibility = Visibility.Hidden;
                        }
                        if (currentDate.Month == EndDate.Value.Month && currentDate.Year == EndDate.Value.Year) {
                            if (currentDay > EndDate.Value.Day)
                                day.Visibility = Visibility.Hidden;
                        }
                    }
                    Grid.SetRow(day, i);
                    Grid.SetColumn(day, j);
                    dayMonthYearContainer.Children.Add(day);
                    currentDay++;
                }
            }
        }
    }
    void addMonths() {
        currentState = CalendarState.Month;
        headerBlock.Text = currentDate.ToString("yyyy");
        dayMonthYearContainer.Children.Clear();
        dayMonthYearContainer.RowDefinitions.Clear();
        dayMonthYearContainer.ColumnDefinitions.Clear();
        for (int i = 0; i < 3; i++)
            dayMonthYearContainer.ColumnDefinitions.Add(new ColumnDefinition());

        var today = DateTime.Today;
        int currentMonth = 1;
        for (int i = 0; i < 4; i++) {
            dayMonthYearContainer.RowDefinitions.Add(new RowDefinition());
            for (int j = 0; j < 3; j++) {
                var month = new MonthYear(currentMonth, currentState);
                if (SelectedDate.HasValue) {
                    if (currentMonth == SelectedDate.Value.Month && currentDate.Year == SelectedDate.Value.Year)
                        month.IsSelected = true;
                }
                if (currentMonth == today.Month && currentDate.Year == today.Year)
                    month.IsThisMonthOrYear = true;
                if (StartDate != null && EndDate != null) {
                    if (currentDate.Year == StartDate.Value.Year) {
                        if (currentMonth < StartDate.Value.Month)
                            month.Visibility = Visibility.Hidden;
                    }
                    if (currentDate.Year == EndDate.Value.Year) {
                        if (currentMonth > EndDate.Value.Month)
                            month.Visibility = Visibility.Hidden;
                    }
                }
                Grid.SetRow(month, i);
                Grid.SetColumn(month, j);
                dayMonthYearContainer.Children.Add(month);
                currentMonth++;
            }
        }
    }
    void addYears() {
        currentState = CalendarState.Year;
        capYear = currentDate.Year;
        int currentYear = currentDate.Year - 11;
        floorYear = currentYear;
        headerBlock.Text = currentYear + " - " + currentDate.Year;
        var today = DateTime.Today;
        dayMonthYearContainer.Children.Clear();
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 3; j++) {
                var year = new MonthYear(currentYear, currentState);
                if (SelectedDate.HasValue) {
                    if (currentYear == SelectedDate.Value.Year)
                        year.IsSelected = true;
                }
                if (currentYear == today.Year) year.IsThisMonthOrYear = true;
                if (StartDate != null && EndDate != null) {
                    if (currentYear < StartDate.Value.Year) year.Visibility = Visibility.Hidden;
                    if (currentYear > EndDate.Value.Year) year.Visibility = Visibility.Hidden;
                }
                Grid.SetRow(year, i);
                Grid.SetColumn(year, j);
                dayMonthYearContainer.Children.Add(year);
                currentYear++;
            }
        }
    }
    void addHeader() {
        headerBlock = new TextBlock() {
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center,
            FontWeight = FontWeights.Bold,
            FontSize = 16,
            Text = currentDate.ToString("MMMM, yyyy")
        };
        headerBorder = new Border() {
            Background = Brushes.Transparent,
            Child = headerBlock,
        };
        Grid.SetColumn(headerBorder, 1);
        back = new CommandButton() {
            Width = 16,
            Height = 16,
            Icon = Icons.ScrollLeft,
            Command = decrease,
            Margin = new Thickness(5, 0, 0, 0)
        };
        forward = new CommandButton() {
            Width = 16,
            Height = 16,
            Icon = Icons.ScrollRight,
            Command = increase,
            Margin = new Thickness(0, 0, 5, 0)
        };
        Grid.SetColumn(forward, 2);
        headerContainer = new Grid() {
            ColumnDefinitions = {
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto }
                },
            Children = { back, headerBorder, forward }
        };
        headerBorder.MouseUp += resetState;
    }
    void moveHintUp() {
        isHintMoved = true;
        scaleHintAnim.To = 0.9;
        translateHintAnim.To = -20;
        animateHint();
    }
    void moveHintDown() {
        isHintMoved = false;
        scaleHintAnim.To = 1;
        translateHintAnim.To = 0;
        animateHint();
    }

    protected override void OnMouseEnter(MouseEventArgs e) {
        if (string.IsNullOrWhiteSpace(inputBox.Text)) {
            inputBox.Focus();
            brushAnim.To = Colors.CornflowerBlue;
            brush.BeginAnimation(SolidColorBrush.ColorProperty, brushAnim);
        }
    }
    protected override void OnMouseLeave(MouseEventArgs e) {
        brushAnim.To = Colors.LightGray;
        brush.BeginAnimation(SolidColorBrush.ColorProperty, brushAnim);
    }
    protected override void OnGotKeyboardFocus(KeyboardFocusChangedEventArgs e) {
        if (!isHintMoved) moveHintUp();
        brushAnim.To = Colors.CornflowerBlue;
        brush.BeginAnimation(SolidColorBrush.ColorProperty, brushAnim);
    }
    protected override void OnPreviewLostKeyboardFocus(KeyboardFocusChangedEventArgs e) {
        if (inputBox.IsEnabled && string.IsNullOrWhiteSpace(inputBox.Text) && !pop.IsOpen)
            moveHintDown();
        if (!pop.IsOpen) {
            brushAnim.To = Colors.LightGray;
            brush.BeginAnimation(SolidColorBrush.ColorProperty, brushAnim);
        }
    }

    #region mess
    public DateTime? SelectedDate {
        get { return (DateTime?)GetValue(SelectedDateProperty); }
        set { SetValue(SelectedDateProperty, value); }
    }
    public string Error {
        get { return (string)GetValue(ErrorProperty); }
        set { SetValue(ErrorProperty, value); }
    }
    public DateTime? StartDate {
        get { return (DateTime?)GetValue(StartDateProperty); }
        set { SetValue(StartDateProperty, value); }
    }
    public DateTime? EndDate {
        get { return (DateTime?)GetValue(EndDateProperty); }
        set { SetValue(EndDateProperty, value); }
    }

    public static readonly DependencyProperty EndDateProperty =
        DependencyProperty.Register("EndDate", typeof(DateTime?), typeof(DayPicker), new PropertyMetadata(null));

    public static readonly DependencyProperty StartDateProperty =
        DependencyProperty.Register("StartDate", typeof(DateTime?), typeof(DayPicker), new PropertyMetadata(null));

    public static readonly DependencyProperty ErrorProperty =
        DependencyProperty.Register("Error", typeof(string), typeof(DayPicker), new PropertyMetadata(null, onErrorChanged));

    public static readonly DependencyProperty SelectedDateProperty =
        DependencyProperty.Register("SelectedDate", typeof(DateTime?), typeof(DayPicker), new FrameworkPropertyMetadata() {
            DefaultValue = null,
            BindsTwoWayByDefault = true,
            PropertyChangedCallback = onDateChanged
        });

    static void onDateChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
        var o = d as DayPicker;
        if (e.NewValue == null) o.removeSelected();
        else {
            o.setSelectedItem();
            var date = ((DateTime?)e.NewValue).Value;
            if (o.currentDate != date) {
                o.currentDate = date;
                //o.addDays(o.currentDate);
            }
        }
    }

    static void onErrorChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
        var o = d as DayPicker;
        if (e.NewValue != null) {
            o.errorText.Text = e.NewValue.ToString();
            if (o.IsRequired) o.hintBlock.Inlines.Add(o.errorText);
        }
    }
    #endregion
}

class Day : FrameworkElement
{
    Size size;
    Border border;
    TextBlock text;
    SolidColorBrush textBrush, borderBrush;
    ColorAnimation textAnim, borderBrushAnim;
    ThicknessAnimation borderThicknessAnim;
    Color todayColor, normalColor, highlightColor;
    public int day;
    bool isSelected, isToday;
    public bool IsSelected {
        get { return isSelected; }
        set {
            isSelected = value;
            if (isSelected) {
                borderBrushAnim.To = Colors.Black;
                borderThicknessAnim.To = new Thickness(4);
            }
            else {
                borderBrushAnim.To = IsToday ? Colors.LightSeaGreen : Colors.Coral;
                borderThicknessAnim.To = new Thickness(0);
            }
            borderBrush.BeginAnimation(SolidColorBrush.ColorProperty, borderBrushAnim);
            border.BeginAnimation(Border.BorderThicknessProperty, borderThicknessAnim);
        }
    }
    public bool IsToday {
        get { return isToday; }
        set {
            isToday = value;
            borderBrushAnim.To = todayColor;
            borderBrush.BeginAnimation(SolidColorBrush.ColorProperty, borderBrushAnim);
        }
    }

    public Day(int day) {
        Margin = new Thickness(2);
        this.day = day;
        size = new Size(40, 40);
        todayColor = Color.FromRgb(40, 40, 40);
        normalColor = Color.FromRgb(60, 60, 60);
        highlightColor = Colors.Black;
        textBrush = new SolidColorBrush(Colors.LightGray);
        borderBrush = new SolidColorBrush(normalColor);
        text = new TextBlock() {
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center,
            Foreground = textBrush,
            FontSize = 15,
            Text = day.ToString()
        };
        border = new Border() {
            CornerRadius = new CornerRadius(20),
            Background = borderBrush,
            BorderBrush = Brushes.Coral,
            Child = text
        };
        AddVisualChild(border);

        var duration = TimeSpan.FromSeconds(1);
        var ease = new CubicEase() { EasingMode = EasingMode.EaseInOut };
        textAnim = new ColorAnimation() {
            Duration = duration,
            EasingFunction = ease
        };
        borderBrushAnim = new ColorAnimation() {
            Duration = duration,
            EasingFunction = ease
        };
        borderThicknessAnim = new ThicknessAnimation() {
            Duration = duration,
            EasingFunction = ease
        };
        Loaded += scaleUp;
        Unloaded += onUnloaded;
    }

    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= scaleUp;
        Unloaded -= onUnloaded;
    }
    void scaleUp(object sender, RoutedEventArgs e) {
        RenderTransform = new ScaleTransform(1, 1, ActualWidth / 2, ActualHeight / 2);
        var anim = new DoubleAnimation() {
            From = 0,
            Duration = TimeSpan.FromSeconds(0.5),
            EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseIn }
        };
        RenderTransform.BeginAnimation(ScaleTransform.ScaleXProperty, anim);
        RenderTransform.BeginAnimation(ScaleTransform.ScaleYProperty, anim);
    }
    void animate() {
        textBrush.BeginAnimation(SolidColorBrush.ColorProperty, textAnim);
        borderBrush.BeginAnimation(SolidColorBrush.ColorProperty, borderBrushAnim);
        border.BeginAnimation(Border.BorderThicknessProperty, borderThicknessAnim);
    }

    protected override void OnMouseEnter(MouseEventArgs e) {
        textAnim.To = Colors.White;
        borderBrushAnim.To = highlightColor;
        borderThicknessAnim.To = new Thickness(2);
        animate();
        text.FontWeight = FontWeights.Bold;
    }
    protected override void OnMouseLeave(MouseEventArgs e) {
        textAnim.To = Colors.LightGray;
        if (IsSelected) {
            borderBrushAnim.To = Colors.Black;
            borderThicknessAnim.To = new Thickness(4);
        }
        else {
            borderBrushAnim.To = IsToday ? todayColor : normalColor;
            borderThicknessAnim.To = new Thickness(0);
        }
        animate();
        text.FontWeight = FontWeights.Normal;
    }
    protected override Size MeasureOverride(Size availableSize) {
        border.Width = size.Width;
        border.Height = size.Height;
        border.Measure(size);
        return size;
    }
    protected override Size ArrangeOverride(Size finalSize) {
        border.Arrange(new Rect(size));
        return size;
    }
    protected override Visual GetVisualChild(int index) => border;
    protected override int VisualChildrenCount => 1;
}

class MonthYear : FrameworkElement
{
    Size size;
    Border border;
    TextBlock text;
    SolidColorBrush textBrush, borderBrush;
    ColorAnimation textAnim, borderBrushAnim;
    ThicknessAnimation borderThicknessAnim;
    Color thisMonthColor, normalColor, highlightColor;
    public int number;
    public CalendarState state;
    bool isSelected, isThisMonthOrYear;
    public bool IsSelected {
        get { return isSelected; }
        set {
            isSelected = value;
            if (isSelected) {
                borderBrushAnim.To = Colors.Black;
                borderThicknessAnim.To = new Thickness(4);
            }
            else {
                borderBrushAnim.To = isThisMonthOrYear ? Colors.LightSeaGreen : Colors.Coral;
                borderThicknessAnim.To = new Thickness(0);
            }
            borderBrush.BeginAnimation(SolidColorBrush.ColorProperty, borderBrushAnim);
            border.BeginAnimation(Border.BorderThicknessProperty, borderThicknessAnim);
        }
    }
    public bool IsThisMonthOrYear {
        get { return isThisMonthOrYear; }
        set {
            isThisMonthOrYear = value;
            borderBrushAnim.To = thisMonthColor;
            borderBrush.BeginAnimation(SolidColorBrush.ColorProperty, borderBrushAnim);
        }
    }
    public MonthYear(int number, CalendarState state) {
        Margin = new Thickness(5);
        this.number = number;
        this.state = state;
        size = new Size(80, 40);
        normalColor = Color.FromRgb(60, 60, 60);
        highlightColor = Colors.Black;
        thisMonthColor = Colors.Black;
        textBrush = new SolidColorBrush(Colors.LightGray);
        borderBrush = new SolidColorBrush(normalColor);
        text = new TextBlock() {
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center,
            Foreground = textBrush,
            FontSize = 15,
            Text = state == CalendarState.Month ?
                CultureInfo.CurrentCulture.DateTimeFormat.GetAbbreviatedMonthName(number) :
                number.ToString()
        };
        border = new Border() {
            CornerRadius = new CornerRadius(20),
            Background = borderBrush,
            BorderBrush = Brushes.Coral,
            Child = text
        };
        AddVisualChild(border);

        var duration = TimeSpan.FromSeconds(1);
        var ease = new CubicEase() { EasingMode = EasingMode.EaseInOut };
        textAnim = new ColorAnimation() {
            Duration = duration,
            EasingFunction = ease
        };
        borderBrushAnim = new ColorAnimation() {
            Duration = duration,
            EasingFunction = ease
        };
        borderThicknessAnim = new ThicknessAnimation() {
            Duration = duration,
            EasingFunction = ease
        };

        Loaded += scaleUp;
        Unloaded += onUnloaded;
    }

    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= scaleUp;
        Unloaded -= onUnloaded;
    }
    void scaleUp(object sender, RoutedEventArgs e) {
        RenderTransform = new ScaleTransform(1, 1, ActualWidth / 2, ActualHeight / 2);
        var anim = new DoubleAnimation() {
            From = 0,
            Duration = TimeSpan.FromSeconds(0.5),
            EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseIn }
        };
        RenderTransform.BeginAnimation(ScaleTransform.ScaleXProperty, anim);
        RenderTransform.BeginAnimation(ScaleTransform.ScaleYProperty, anim);
    }
    void animate() {
        textBrush.BeginAnimation(SolidColorBrush.ColorProperty, textAnim);
        borderBrush.BeginAnimation(SolidColorBrush.ColorProperty, borderBrushAnim);
        border.BeginAnimation(Border.BorderThicknessProperty, borderThicknessAnim);
    }

    protected override void OnMouseEnter(MouseEventArgs e) {
        textAnim.To = Colors.White;
        borderBrushAnim.To = highlightColor;
        borderThicknessAnim.To = new Thickness(2);
        animate();
        text.FontWeight = FontWeights.Bold;
    }
    protected override void OnMouseLeave(MouseEventArgs e) {
        textAnim.To = Colors.LightGray;
        if (IsSelected) {
            borderBrushAnim.To = Colors.LightGray;
            borderThicknessAnim.To = new Thickness(4);
        }
        else {
            borderBrushAnim.To = IsThisMonthOrYear ? thisMonthColor : normalColor;
            borderThicknessAnim.To = new Thickness(0);
        }
        animate();
        text.FontWeight = FontWeights.Normal;
    }
    protected override Size MeasureOverride(Size availableSize) {
        border.Width = size.Width;
        border.Height = size.Height;
        border.Measure(size);
        return size;
    }
    protected override Size ArrangeOverride(Size finalSize) {
        border.Arrange(new Rect(size));
        return size;
    }
    protected override Visual GetVisualChild(int index) => border;
    protected override int VisualChildrenCount => 1;
}