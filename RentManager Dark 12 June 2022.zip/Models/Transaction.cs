﻿ class Transaction : Notifiable
    {
        public int Id { get; set; }
        int? plotId;
        public int? PlotId {
            get { return plotId; }
            set {
                if (plotId != value) {
                    plotId = value;
                    OnPropertyChanged(nameof(PlotId));
                }
            }
        }
        int? spaceId;
        public int? SpaceId {
            get { return spaceId; }
            set {
                if (spaceId != value) {
                    spaceId = value;
                    OnPropertyChanged(nameof(SpaceId));
                }
            }
        }
        int? tenantId;
        public int? TenantId {
            get { return tenantId; }
            set { if (tenantId != value) {
                    tenantId = value; 
                    OnPropertyChanged(nameof(TenantId));
                }
            }
        }
        int? controlId;
        public int? ControlId {
            get { return controlId; }
            set {
                if (controlId != value) {
                    controlId = value;
                    OnPropertyChanged(nameof(ControlId));
                }
            }
        }
        int? headId;
        public int? HeadId {
            get { return headId; }
            set {
                if (headId != value) {
                    headId = value;
                    OnPropertyChanged(nameof(HeadId));
                }
            }
        }
        DateTime? date;
        public DateTime? Date {
            get { return date; }
            set {
                if (date != value) {
                    date = value;
                    OnPropertyChanged(nameof(Date));
                }
            }
        }
        int amount;
        public int Amount {
            get { return amount; }
            set {
                if (amount != value) {
                    amount = value;
                    OnPropertyChanged(nameof(Amount));
                }
            }
        }
        bool? isCash;
        public bool? IsCash {
            get { return isCash; }
            set {
                if (isCash != value) {
                    isCash = value;
                    OnPropertyChanged(nameof(IsCash));
                }
            }
        }
        string narration;
        public string Narration {
            get { return narration; }
            set { 
                if (narration != value) {
                    narration = value; 
                    OnPropertyChanged(nameof(Narration));
                }
            }
        }
        string tenantName;
        public string TenantName {
            get { return tenantName; }
            set {
                if (tenantName != value) {
                    tenantName = value;
                    OnPropertyChanged(nameof(TenantName));
                }
            }
        }

        public Transaction() {
            Date = DateTime.Now;
            IsCash = true;
        }
    }
