﻿class RentDetail : CardView
    {
        public override string Header => "Detail Rent Deposit & Dues";

        LineChart line;
        RentDetailVM viewModel;
        public RentDetail() {
            viewModel = new RentDetailVM();
            DataContext = viewModel;
            initializeUI();
            bind();
        }
        void initializeUI() {
            line = new LineChart();
            var grid = new Grid() {
                Children = { line }
            };
            setContent(grid);
        }
        void bind() {
            line.SetBinding(LineChart.ItemSourceProperty, new Binding(nameof(viewModel.Data)));
            line.SetBinding(LineChart.SelectedValueProperty, new Binding(nameof(viewModel.SelectedTenant)));
        }
    }
