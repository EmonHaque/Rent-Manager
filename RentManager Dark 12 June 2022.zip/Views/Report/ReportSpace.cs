﻿class ReportSpace : LedgerView
    {
        public override string Icon => Icons.Space;
        public override string Header => "Space";
        ReportSpaceVM vm = new();
        protected override ReportBase viewModel => vm;
        protected override string display => "Name";
        protected override ControlTemplate groupTemplate => new GroupedSpaceTemplate(nameof(vm.Query), vm);
        public ReportSpace() : base() {
        }
    }
