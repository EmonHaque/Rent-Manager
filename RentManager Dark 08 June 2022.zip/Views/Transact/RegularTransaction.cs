﻿class RegularTransaction : CardView
    {
        public override string Header => "Regular";
        public override string Icon => Icons.RegularTransaction;

        SelectItem tenant, plot, space, control, head;
        EditText amount, narration;
        DayPicker date;
        BiState isCash;
        ItemsControl entries;
        Run cashReceipt, kindReceipt, cashPayment, kindPayment, receivable;
        CommandButton addEntry, passEntry;
        RegularTransactionVM viewModel;

        public RegularTransaction() {
            viewModel = new RegularTransactionVM();
            DataContext = viewModel;
            initializeUI();
            bind();
        }

        void initializeUI() {
            tenant = new SelectItem() {
                Hint = "Tenant",
                IsRequired = true,
                Icon = Icons.Tenant,
                SelectedValuePath = nameof(Tenant.Id),
                ItemTemplate = new TenantTemplate(nameof(viewModel.TenantQuery), viewModel, true),
                FilterParameter = SelectQuery.Tenant,
                FilterCommand = viewModel.FilterCommand
            };
            plot = new SelectItem() {
                Hint = "Plot",
                IsRequired = true,
                Icon = Icons.Plot,
                SelectedValuePath = nameof(Lease.PlotId),
                DisplayPath = nameof(Lease.PlotName),
                FilterParameter = SelectQuery.Plot,
                FilterCommand = viewModel.FilterCommand
            };
            space = new SelectItem() {
                Hint = "Space",
                IsRequired = true,
                Icon = Icons.Space,
                SelectedValuePath = nameof(Lease.SpaceId),
                ItemTemplate = new TransactionSpaceTemplate(nameof(viewModel.SpaceQuery), viewModel),
                FilterParameter = SelectQuery.Space,
                FilterCommand = viewModel.FilterCommand
            };
            control = new SelectItem() {
                Hint = "Control",
                IsRequired = true,
                Icon = Icons.ControlHead,
                SelectedValuePath = nameof(ControlHead.Id),
                DisplayPath = nameof(ControlHead.Name),
                FilterParameter = SelectQuery.ControlHead,
                FilterCommand = viewModel.FilterCommand
            };
            head = new SelectItem() {
                Hint = "Head",
                IsRequired = true,
                Icon = Icons.Head,
                SelectedValuePath = nameof(Head.Id),
                DisplayPath = nameof(Head.Name),
                FilterParameter = SelectQuery.Head,
                FilterCommand = viewModel.FilterCommand
            };
            date = new DayPicker() {
                Hint = "Date",
                DateFormat = "dd/MM/yyyy",
                IsRequired = true
            };
            amount = new EditText() {
                Hint = "Amount",
                IsRequired = true,
                Icon = Icons.Amount
            };
            isCash = new BiState() {
                IsTrue = true,
                Text = "Is cash?",
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(5,0,5,0)
            };
            Grid.SetColumn(isCash, 1);
            addEntry = new CommandButton() {
                Width = 14,
                Height = 14,
                Icon = Icons.Plus,
                Command = viewModel.AddEntry,
                Margin = new Thickness(5,0,5,0)
            };
            Grid.SetColumn(addEntry, 2);
            var amountGrid = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto }
                },
                Children = { amount, isCash, addEntry }
            };
            narration = new EditText() {
                IsRequired = true,
                IsMultiline = true,
                Hint = "Narration",
                Icon = Icons.Description
            };
            entries = new ItemsControl() { 
                HorizontalContentAlignment = HorizontalAlignment.Stretch,
                Template = new ScrollableItemsControlTemplate(),
                ItemTemplate = new EntryTemplate(new Binding(nameof(viewModel.RemoveEntry)) { Source = viewModel }),
                GroupStyle = {
                    new GroupStyle() {
                        ContainerStyle = new Style(typeof(GroupItem)) {
                            Setters = {
                                new Setter(GroupItem.TemplateProperty, new GroupedEntryTemplate())
                            }
                        }
                    }
                }
            };
            cashReceipt = new Run() { FontWeight = FontWeights.DemiBold, Foreground = Brushes.Green };
            kindReceipt = new Run() { FontWeight = FontWeights.DemiBold, Foreground = Brushes.Coral };
            cashPayment = new Run() { FontWeight = FontWeights.DemiBold, Foreground = Brushes.Green };
            kindPayment = new Run() { FontWeight = FontWeights.DemiBold, Foreground = Brushes.Coral };
            receivable = new Run()  { FontWeight = FontWeights.DemiBold };
            var summaryBlock = new TextBlock() {
                VerticalAlignment = VerticalAlignment.Bottom,
                HorizontalAlignment = HorizontalAlignment.Left,
                Margin = new Thickness(5,0,0,0),
                Inlines = {
                    new Run("Receipt:"){ FontWeight = FontWeights.Bold, Foreground = Brushes.Green },
                    new Run(" cash "),
                    cashReceipt,
                    new Run(" kind "),
                    kindReceipt,
                    new Run(" | "){ FontWeight = FontWeights.Black },
                    new Run("Payment:"){ FontWeight = FontWeights.Bold, Foreground = Brushes.Coral },
                    new Run(" cash "),
                    cashPayment,
                    new Run(" kind "),
                    kindPayment,
                    new Run(" | "){ FontWeight = FontWeights.Black },
                    new Run("Receivable: "){ FontWeight = FontWeights.Bold },
                    receivable
                }
            };

            passEntry = new CommandButton() {
                Width = 16,
                Height = 16,
                Icon = Icons.Add,
                Command = viewModel.PassEntries,
                HorizontalAlignment = HorizontalAlignment.Right
            };
            Grid.SetColumnSpan(tenant, 2);
            Grid.SetRow(plot, 1);
            Grid.SetRow(space, 1);
            Grid.SetColumn(space, 1);
            Grid.SetRow(control, 2);
            Grid.SetRow(head, 2);
            Grid.SetColumn(head, 1);
            Grid.SetRow(date, 3);
            Grid.SetRow(amountGrid, 3);
            Grid.SetColumn(amountGrid, 1);
            Grid.SetRow(narration, 4);
            Grid.SetColumnSpan(narration, 2);
            Grid.SetRow(entries, 5);
            Grid.SetColumnSpan(entries, 2);
            Grid.SetRow(summaryBlock, 6);
            Grid.SetColumnSpan(summaryBlock, 2);
            Grid.SetRow(passEntry, 6);
            Grid.SetColumn(passEntry, 1);
            var grid = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(),
                },
                RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(),
                    new RowDefinition(){ Height = GridLength.Auto }
                },
                Children = { tenant, plot, space, control, head, date, amountGrid, narration, entries, summaryBlock, passEntry }
            };
            setContent(grid);
        }

        void bind() {
            tenant.SetBinding(SelectItem.SelectedvalueProperty, new Binding($"{nameof(viewModel.Entry)}.{nameof(Transaction.TenantId)}"));
            tenant.SetBinding(SelectItem.ErrorProperty, new Binding(nameof(viewModel.ErrorTenant)));
            tenant.SetBinding(SelectItem.ItemsSourceProperty, new Binding(nameof(viewModel.Tenants)));
            tenant.SetBinding(SelectItem.QueryProperty, new Binding(nameof(viewModel.TenantQuery)) { Mode = BindingMode.OneWayToSource});
            
            plot.SetBinding(SelectItem.SelectedvalueProperty, new Binding($"{nameof(viewModel.Entry)}.{nameof(Transaction.PlotId)}"));
            plot.SetBinding(SelectItem.ErrorProperty, new Binding(nameof(viewModel.ErrorPlot)));
            plot.SetBinding(SelectItem.ItemsSourceProperty, new Binding(nameof(viewModel.Plots)));
            plot.SetBinding(SelectItem.QueryProperty, new Binding(nameof(viewModel.PlotQuery)) { Mode = BindingMode.OneWayToSource });
            
            space.SetBinding(SelectItem.SelectedvalueProperty, new Binding($"{nameof(viewModel.Entry)}.{nameof(Transaction.SpaceId)}"));
            space.SetBinding(SelectItem.ErrorProperty, new Binding(nameof(viewModel.ErrorSpace)));
            space.SetBinding(SelectItem.ItemsSourceProperty, new Binding(nameof(viewModel.Spaces)));
            space.SetBinding(SelectItem.QueryProperty, new Binding(nameof(viewModel.SpaceQuery)) { Mode = BindingMode.OneWayToSource });
            
            control.SetBinding(SelectItem.SelectedvalueProperty, new Binding($"{nameof(viewModel.Entry)}.{nameof(Transaction.ControlId)}"));
            control.SetBinding(SelectItem.ErrorProperty, new Binding(nameof(viewModel.ErrorControl)));
            control.SetBinding(SelectItem.ItemsSourceProperty, new Binding(nameof(viewModel.ControlHeads)));
            control.SetBinding(SelectItem.QueryProperty, new Binding(nameof(viewModel.ControlQuery)) { Mode = BindingMode.OneWayToSource });
            
            head.SetBinding(SelectItem.SelectedvalueProperty, new Binding($"{nameof(viewModel.Entry)}.{nameof(Transaction.HeadId)}"));
            head.SetBinding(SelectItem.ErrorProperty, new Binding(nameof(viewModel.ErrorHead)));
            head.SetBinding(SelectItem.ItemsSourceProperty, new Binding(nameof(viewModel.Heads)));
            head.SetBinding(SelectItem.QueryProperty, new Binding(nameof(viewModel.HeadQuery)) { Mode = BindingMode.OneWayToSource });
            
            date.SetBinding(DayPicker.SelectedDateProperty, new Binding($"{nameof(viewModel.Entry)}.{nameof(Transaction.Date)}"));
            date.SetBinding(DayPicker.ErrorProperty, new Binding(nameof(viewModel.ErrorDate)));

            amount.SetBinding(EditText.TextProperty, new Binding(nameof(viewModel.Amount)));
            amount.SetBinding(EditText.ErrorProperty, new Binding(nameof(viewModel.ErrorAmount)));

            narration.SetBinding(EditText.TextProperty, new Binding($"{nameof(viewModel.Entry)}.{nameof(Transaction.Narration)}"));
            narration.SetBinding(EditText.ErrorProperty, new Binding(nameof(viewModel.ErrorNarration)));

            isCash.SetBinding(BiState.IsTrueProperty, new Binding($"{nameof(viewModel.Entry)}.{nameof(Transaction.IsCash)}"));
            addEntry.SetBinding(IsEnabledProperty, new Binding(nameof(viewModel.IsValid)));
            passEntry.SetBinding(CommandButton.IsEnabledProperty, new Binding(nameof(viewModel.CanClickInsert)));
            entries.SetBinding(ItemsControl.ItemsSourceProperty, new Binding(nameof(viewModel.Entries)));

            cashReceipt.SetBinding(Run.TextProperty, new Binding(($"{nameof(viewModel.Summary)}.{nameof(TransactionSummary.CashReceipt)}")) { StringFormat = "N0"});
            kindReceipt.SetBinding(Run.TextProperty, new Binding(($"{nameof(viewModel.Summary)}.{nameof(TransactionSummary.KindReceipt)}")) { StringFormat = "N0" });
            cashPayment.SetBinding(Run.TextProperty, new Binding(($"{nameof(viewModel.Summary)}.{nameof(TransactionSummary.CashPayment)}")) { StringFormat = "N0" });
            kindPayment.SetBinding(Run.TextProperty, new Binding(($"{nameof(viewModel.Summary)}.{nameof(TransactionSummary.KindPayment)}")) { StringFormat = "N0" });
            receivable.SetBinding(Run.TextProperty, new Binding(($"{nameof(viewModel.Summary)}.{nameof(TransactionSummary.Receivable)}")) { StringFormat = "N0" });

            isCash.Style = new Style() {
                Triggers = {
                    new DataTrigger() {
                        Binding = new Binding(nameof(SelectItem.Selectedvalue)) { Source = control },
                        Value = AppData.controlIdOfReceivable,
                        Setters = {
                            new Setter(BiState.IsEnabledProperty, false)
                        }
                    }
                }
            };
        }
    }
