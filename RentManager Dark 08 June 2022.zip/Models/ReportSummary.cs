﻿ class ReportSummary : Notifiable
    {
        int totalReceivable;
        public int TotalReceivable {
            get { return totalReceivable; }
            set {
                if (totalReceivable != value) {
                    totalReceivable = value;
                    OnPropertyChanged(nameof(TotalReceivable));
                }
            }
        }
        int totalReceipt;
        public int TotalReceipt {
            get { return totalReceipt; }
            set {
                if (totalReceipt != value) {
                    totalReceipt = value;
                    OnPropertyChanged(nameof(TotalReceipt));
                }
            }
        }
        string heading;
        public string Heading {
            get { return heading; }
            set {
                if (heading != value) {
                    heading = value;
                    OnPropertyChanged(nameof(Heading));
                }
            }
        }
    }
