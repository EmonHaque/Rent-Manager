﻿class ListBoxEx : ListBox
{
    public ListBoxEx() {
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }

    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
    }

    void onLoaded(object sender, RoutedEventArgs e) {
        var border = (Border)VisualTreeHelper.GetChild(this, 0);
        var scroll = (ScrollViewer)VisualTreeHelper.GetChild(border, 0);
        ((Rectangle)scroll.Template.FindName("Corner", scroll)).Fill = Constants.Background;
    }
}
