﻿class VScrollTemplate : ControlTemplate
{
    public VScrollTemplate() {
        TargetType = typeof(ScrollBar);

        var vGrid = new FrameworkElementFactory(typeof(Grid));
        var row1 = new FrameworkElementFactory(typeof(RowDefinition));
        var row2 = new FrameworkElementFactory(typeof(RowDefinition));
        var row3 = new FrameworkElementFactory(typeof(RowDefinition));
        var upButton = new FrameworkElementFactory(typeof(ScrollButton));
        var track = new FrameworkElementFactory(typeof(VTrack)) { Name = "PART_Track" };
        var downButton = new FrameworkElementFactory(typeof(ScrollButton));
        row1.SetValue(RowDefinition.HeightProperty, GridLength.Auto);
        row3.SetValue(RowDefinition.HeightProperty, GridLength.Auto);
        upButton.SetValue(ScrollButton.IconProperty, Icons.ScrollUp);
        upButton.SetValue(RepeatButton.CommandProperty, ScrollBar.LineUpCommand);
        track.SetValue(Grid.RowProperty, 1);
        track.SetValue(Track.IsDirectionReversedProperty, true);

        downButton.SetValue(Grid.RowProperty, 2);
        downButton.SetValue(ScrollButton.IconProperty, Icons.ScrollDown);
        downButton.SetValue(RepeatButton.CommandProperty, ScrollBar.LineDownCommand);

        vGrid.AppendChild(row1);
        vGrid.AppendChild(row2);
        vGrid.AppendChild(row3);
        vGrid.AppendChild(upButton);
        vGrid.AppendChild(track);
        vGrid.AppendChild(downButton);
        VisualTree = vGrid;
    }
}

class HScrollTemplate : ControlTemplate
{
    public HScrollTemplate() {
        TargetType = typeof(ScrollBar);
        var hGrid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var leftButton = new FrameworkElementFactory(typeof(ScrollButton));
        var track = new FrameworkElementFactory(typeof(HTrack)) { Name = "PART_Track" };
        var rightButton = new FrameworkElementFactory(typeof(ScrollButton));
        col1.SetValue(ColumnDefinition.WidthProperty, GridLength.Auto);
        col3.SetValue(ColumnDefinition.WidthProperty, GridLength.Auto);
        leftButton.SetValue(ScrollButton.IconProperty, Icons.ScrollLeft);
        leftButton.SetValue(RepeatButton.CommandProperty, ScrollBar.LineLeftCommand);
        track.SetValue(Grid.ColumnProperty, 1);
        track.SetValue(Track.IsDirectionReversedProperty, false);
        rightButton.SetValue(Grid.ColumnProperty, 2);
        rightButton.SetValue(ScrollButton.IconProperty, Icons.ScrollRight);
        rightButton.SetValue(RepeatButton.CommandProperty, ScrollBar.LineRightCommand);

        hGrid.AppendChild(col1);
        hGrid.AppendChild(col2);
        hGrid.AppendChild(col3);
        hGrid.AppendChild(leftButton);
        hGrid.AppendChild(track);
        hGrid.AppendChild(rightButton);
        VisualTree = hGrid;
    }
}

class ScrollButton : RepeatButton
{
    static ScrollButton() {
        DefaultStyleKeyProperty.OverrideMetadata(typeof(ScrollButton), new FrameworkPropertyMetadata(typeof(ScrollButton)));
    }
    public string Icon {
        get { return (string)GetValue(IconProperty); }
        set { SetValue(IconProperty, value); }
    }

    public static readonly DependencyProperty IconProperty =
        DependencyProperty.Register("Icon", typeof(string), typeof(ScrollButton), new PropertyMetadata() {
            DefaultValue = null,
            PropertyChangedCallback = (s, e) => (s as ScrollButton).setTemplate()
        });

    void setTemplate() {
        var border = new FrameworkElementFactory(typeof(Border));
        var path = new FrameworkElementFactory(typeof(Path)) { Name = "path" };
        path.SetValue(Path.StretchProperty, Stretch.Uniform);
        path.SetValue(Path.FillProperty, Brushes.LightGray);
        path.SetValue(Path.DataProperty, Geometry.Parse(Icon));
        border.SetValue(Border.BackgroundProperty, Brushes.Transparent);
        border.AppendChild(path);
        Template = new ControlTemplate(typeof(RepeatButton)) {
            VisualTree = border,
            Triggers = {
                    new Trigger() {
                        Property = IsMouseOverProperty,
                        Value = true,
                        Setters = {
                            new Setter() {
                                Property = Path.FillProperty,
                                Value = Brushes.CornflowerBlue,
                                TargetName = "path"
                            },
                        }
                    }
                }
        };
    }
}

class ScrollThumb : ControlTemplate
{
    public ScrollThumb(Thickness margin) {
        TargetType = typeof(Thumb);
        var rect = new FrameworkElementFactory(typeof(Rectangle)) { Name = "rect" };
        rect.SetValue(Rectangle.RadiusXProperty, 10d);
        rect.SetValue(Rectangle.RadiusYProperty, 10d);
        rect.SetValue(Rectangle.OpacityProperty, 0.5d);
        rect.SetValue(Rectangle.FillProperty, Brushes.Gray);
        rect.SetValue(Rectangle.MarginProperty, margin);
        Triggers.Add(new Trigger() {
            Property = Thumb.IsMouseOverProperty,
            Value = true,
            Setters = {
                    new Setter() {
                        Property = Rectangle.FillProperty,
                        Value = Brushes.LightGray,
                        TargetName = "rect"
                    }
                }
        });
        Triggers.Add(new Trigger() {
            Property = Thumb.IsDraggingProperty,
            Value = true,
            Setters = {
                    new Setter() {
                        Property = Rectangle.FillProperty,
                        Value = Brushes.LightGray,
                        TargetName = "rect"
                    }
                }
        });
        VisualTree = rect;
    }
}

class VTrack : Track
{
    public VTrack() {
        IncreaseRepeatButton = new ScrollButton() { Command = ScrollBar.PageUpCommand };
        DecreaseRepeatButton = new ScrollButton() { Command = ScrollBar.PageDownCommand };
        Thumb = new Thumb() { Template = new ScrollThumb(new Thickness(2.5, 0, 2.5, 0)) };
    }
}

class HTrack : Track
{
    public HTrack() {
        IncreaseRepeatButton = new ScrollButton() { Command = ScrollBar.PageLeftCommand };
        DecreaseRepeatButton = new ScrollButton() { Command = ScrollBar.PageRightCommand };
        Thumb = new Thumb() { Template = new ScrollThumb(new Thickness(0, 2.5, 0, 2.5)) };
    }
}
