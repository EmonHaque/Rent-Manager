﻿class PolyLineStream : FrameworkElement
    {
        List<int> values;
        double spacing, height, lower, upper;
        Pen pen;
        StreamGeometry geometry, polygon;
        Path polyPath;
        LinearGradientBrush fillBrush;
        DoubleAnimation gradientAnim;

        public PolyLineStream(List<int> values) {
            Clip = new RectangleGeometry();
            this.values = values;
            geometry = new StreamGeometry();
            polygon = new StreamGeometry();
            fillBrush = new LinearGradientBrush() {
                StartPoint = new Point(0.5, 0),
                EndPoint = new Point(0.5, 1),
                GradientStops = {
                    new GradientStop(){Offset = 0, Color = Color.FromArgb(75, 0, 0, 100)},
                    new GradientStop() { Offset = 0, Color = Colors.Transparent }
                }
            };
            polyPath = new Path() { Fill = fillBrush, Data = polygon };
            gradientAnim = new DoubleAnimation(1, TimeSpan.FromSeconds(1)) {
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseIn }
            };
            pen = new Pen(Brushes.CornflowerBlue, 2);
            Loaded += animateLine;
            Unloaded += onUnloaded;
        }

        void onUnloaded(object sender, RoutedEventArgs e) {
            Loaded -= animateLine;
        }

        void animateLine(object sender, RoutedEventArgs e) {
            var anim = new RectAnimation() {
                From = new Rect(0, 0, 0, height),
                Duration = TimeSpan.FromSeconds(1),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
            Clip.BeginAnimation(RectangleGeometry.RectProperty, anim);
            fillBrush.GradientStops[0].BeginAnimation(GradientStop.OffsetProperty, gradientAnim);
            fillBrush.GradientStops[1].BeginAnimation(GradientStop.OffsetProperty, gradientAnim);
        }
        public void SetParameters(double width, double height, double lower, double upper, double spacing) {
            this.height = height;
            this.lower = lower;
            this.upper = upper;
            this.spacing = spacing;
            ((RectangleGeometry)Clip).Rect = new Rect(0, 0, width, height + 10);
            geometry.Clear();
            polygon.Clear();
            InvalidateVisual();
        }
        protected override void OnRender(DrawingContext drawingContext) {
            var posHeight = height / (lower + upper) * upper;
            var negHeight = height - posHeight;            
            var poly = polygon.Open();
            using (var geo = geometry.Open()) {
                double x = 0;
                double y = values[0] < 0 ? negHeight - Math.Abs(values[0]) / lower * negHeight : values[0] / upper * posHeight + negHeight;
                Point point = new(x, y);
                geo.BeginFigure(point, true, false);
                poly.BeginFigure(new Point(x, negHeight), true, true);
                poly.LineTo(point, true, true);
                for (int i = 1; i < values.Count; i++) {
                    x += spacing;
                    y = values[i] < 0 ? negHeight - Math.Abs(values[i]) / lower * negHeight : values[i] / upper * posHeight + negHeight;
                    point = new Point(x, y);
                    geo.LineTo(point, true, true);
                    poly.LineTo(point, true, true);
                }
                poly.LineTo(new Point(x, negHeight), true, true);
            }
            poly.Close();
            polyPath.Data = polygon;
            drawingContext.DrawGeometry(null, pen, geometry);
            drawingContext.DrawGeometry(fillBrush, null, polygon);
        }
    }
