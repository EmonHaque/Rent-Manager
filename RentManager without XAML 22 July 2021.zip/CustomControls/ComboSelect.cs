﻿using RentManager.Enums;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;

namespace RentManager.CustomControls
{
    class ComboSelect : Grid
    {
        public SelectItem selectItem;
        TextBlock block;
        Run text;

        public string Hint { get; set; }
        public string Icon { get; set; }
        public Binding NonEditable { get; set; }
        public string Error { get; set; }
        public string DisplayPath { get; set; }
        public string SelectedValuePath { get; set; }
        public string SelectedValue { get; set; }
        public string Query { get; set; }
        public string ItemsSource { get; set; }
        public SelectQuery FilterParameter { get; set; }
        public Action<SelectQuery, string> FilterCommand { get; set; }
        public bool IsRequired { get; set; }
        public DataTemplate ItemTemplate { get; set; }

        public ComboSelect() {
            text = new Run() { FontSize = 12 };
            block = new TextBlock();
            selectItem = new SelectItem() { Visibility = Visibility.Hidden };
            Children.Add(selectItem);
            Children.Add(block);
            IsOnEdit = false;
            Loaded += onLoaded;
            Unloaded += onUnloaded;
        }

        void onUnloaded(object sender, RoutedEventArgs e) {
            Loaded -= onLoaded;
            Unloaded -= onUnloaded;
        }
        void onLoaded(object sender, RoutedEventArgs e) {
            text.SetBinding(Run.TextProperty, NonEditable);
            block.Inlines.Add(new Run() {
                Foreground = Brushes.Gray,
                FontStyle = FontStyles.Italic,
                FontSize = 11,
                Text = Hint
            });
            block.Inlines.Add(new LineBreak());
            block.Inlines.Add(text);
            selectItem.Hint = Hint;
            selectItem.Icon = Icon;
            selectItem.SelectedValuePath = SelectedValuePath;
            if (DisplayPath == null) selectItem.ItemTemplate = ItemTemplate;
            else selectItem.DisplayPath = DisplayPath;

            if (IsRequired) {
                selectItem.IsRequired = true;
                selectItem.SetBinding(SelectItem.ErrorProperty, new Binding(Error));
            }
            selectItem.SetBinding(SelectItem.SelectedvalueProperty, new Binding(SelectedValue) { Mode = BindingMode.TwoWay });
            selectItem.SetBinding(SelectItem.ItemsSourceProperty, new Binding(ItemsSource));
            if (Query != null)
                selectItem.SetBinding(SelectItem.QueryProperty, new Binding(Query) { Mode = BindingMode.OneWayToSource });
            if (FilterCommand != null) {
                selectItem.FilterParameter = FilterParameter;
                selectItem.FilterCommand = FilterCommand;
                //selectItem.SetBinding(SelectItem.FilterCommandProperty, new Binding(FilterCommand));
            }
        }

        public bool IsOnEdit {
            get { return (bool)GetValue(IsOnEditProperty); }
            set { SetValue(IsOnEditProperty, value); }
        }
        public static readonly DependencyProperty IsOnEditProperty =
            DependencyProperty.Register("IsOnEdit", typeof(bool), typeof(ComboSelect), new PropertyMetadata() {
                DefaultValue = false,
                PropertyChangedCallback = (s, e) => {
                    var o = (ComboSelect)s;
                    if ((bool)e.NewValue) {
                        o.selectItem.Visibility = Visibility.Visible;
                        o.block.Visibility = Visibility.Hidden;
                    }
                    else {
                        o.selectItem.Visibility = Visibility.Hidden;
                        o.block.Visibility = Visibility.Visible;
                    }
                }
            });
    }
}
