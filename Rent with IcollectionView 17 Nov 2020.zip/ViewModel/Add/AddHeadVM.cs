﻿using RentManager.Common;
using RentManager.Model;
using System.Collections.ObjectModel;

namespace RentManager.ViewModel.Add
{
    public class AddHeadVM : AddBase<Head>
    {
        public AddHeadVM() : base() => NewObject.Id = MainVM.GetId(MainVM.heads);

        #region base Implementation
        protected override ViewType type => ViewType.Head;
        protected override ObservableCollection<Head> collection => MainVM.heads;
        protected override void insertInDatabase()
        {
            using var cmd = SQLHelper.connection.CreateCommand();
            cmd.CommandText = "INSERT INTO Heads (ControlId, Name, Description) VALUES(@ControlId, @Name, @Description)";
            cmd.Parameters.AddWithValue("@ControlId", NewObject.ControlId);
            cmd.Parameters.AddWithValue("@Name", NewObject.Name);
            cmd.Parameters.AddWithValue("@Description", NewObject.Description);
            SQLHelper.NonQuery(cmd);
        }
        protected override void renewNewObject()
        {
            NewObject = new Head()
            {
                Id = NewObject.Id + 1,
                ControlId = NewObject.ControlId
            };
        }
        #endregion
    }
}
