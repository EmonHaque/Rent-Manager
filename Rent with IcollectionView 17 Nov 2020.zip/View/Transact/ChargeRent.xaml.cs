﻿using System.Windows.Controls;

namespace RentManager.View.Transact
{
    /// <summary>
    /// Interaction logic for BulkEntry.xaml
    /// </summary>
    public partial class ChargeRent : UserControl
    {
        public ChargeRent()
        {
            InitializeComponent();
        }
    }
}
