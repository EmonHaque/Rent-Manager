﻿using System.Windows.Controls;

namespace RentManager.View.Add
{
    /// <summary>
    /// Interaction logic for AddTenantView.xaml
    /// </summary>
    public partial class AddTenantView : UserControl
    {
        public AddTenantView()
        {
            InitializeComponent();
        }
    }
}
