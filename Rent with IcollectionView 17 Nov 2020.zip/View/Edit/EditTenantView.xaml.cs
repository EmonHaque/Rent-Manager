﻿using System.Windows.Controls;

namespace RentManager.View.Edit
{
    /// <summary>
    /// Interaction logic for TenantView.xaml
    /// </summary>
    public partial class EditTenantView : UserControl
    {
        public EditTenantView()
        {
            InitializeComponent();
        }
    }
}
