﻿using RentManager.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace RentManager.Interface
{
    public interface IEditable<T> 
    {
       T Clone();
       bool IsEqualTo(T source);
       bool IsValid();
       void Update(T Edited);
    }
}
