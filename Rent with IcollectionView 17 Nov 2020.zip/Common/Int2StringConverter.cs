﻿using RentManager.Model;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows.Data;

namespace RentManager.Common
{
    public class Int2StringConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is int && (value as int?) > 0)
            {
                var id = (int)value;
                return parameter switch
                {
                    IEnumerable<Plot> p => p.First(x => x.Id == id).Name,
                    IEnumerable<Space> s => s.First(x => x.Id == id).Name,
                    IEnumerable<Tenant> t => t.First(x => x.Id == id).Name,
                    IEnumerable<ControlHead> c => c.First(x => x.Id == id).Name,
                    IEnumerable<Head> h => h.First(x => x.Id == id).Name
                };
            }
            else return string.Empty;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
