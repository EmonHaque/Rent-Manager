﻿using System.Collections.Specialized;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;

namespace RentManager.CustomControl
{
    public class Combo : ComboBox
    {
        static Combo()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(Combo), new FrameworkPropertyMetadata(typeof(Combo)));
        }
        protected override void OnItemsChanged(NotifyCollectionChangedEventArgs e)
        {
            switch (e.Action)
            {
                case NotifyCollectionChangedAction.Add:
                    if (SelectedItem != e.NewItems[0])
                        SelectedItem = e.NewItems[0];
                    break;
                case NotifyCollectionChangedAction.Remove:
                case NotifyCollectionChangedAction.Reset:
                    if (e.NewItems == null && !Items.IsEmpty)
                        Items.MoveCurrentToFirst();
                    break;
            }
        }
    }
}
