﻿using RentManager.Model;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;

namespace RentManager.CustomControl
{
    public class LedgerPage : Control
    { 
        ItemsControl content { get; set; }
        public double AvailableHeight { get; set; }
        public FixedPage Page { get; set; }
        public ReportEntry LastEntry { get; set; }

        static LedgerPage()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(LedgerPage), new FrameworkPropertyMetadata(typeof(LedgerPage)));
        }
        public LedgerPage() { }
        public LedgerPage(LedgerPage page)
        {
            Width = page.Width;
            Height = page.Height;
            Title = page.Title;
            SubTitle = page.SubTitle;
            Date = page.Date;
            FootNote = page.FootNote;
            PageNo = page.PageNo + 1;
            IsFinished = false;

            var grid = new Grid() { Children = { this } };
            grid.Measure(new Size(this.Width, this.Height));
            grid.Arrange(new Rect(grid.DesiredSize));

            AddItem(new ReportEntry()
            {
                Date = page.LastEntry.Date,
                Particulars = "balance b/d",
                Narration = string.Empty,
                Receivable = page.TotalReceivable,
                Receipt = page.TotalReceipt,
                Balance = page.LastEntry.Balance
            }) ;
        }
        public override void OnApplyTemplate()
        {
            Page = GetTemplateChild("page") as FixedPage;
            content = GetTemplateChild("content") as ItemsControl;
            var header = GetTemplateChild("header") as StackPanel;
            var contentGrid = GetTemplateChild("contentGrid") as Grid;
            var subTotal = GetTemplateChild("subTotal") as Border;
            var footer = GetTemplateChild("footer") as Border;

            double margin = 96d * .7;
            Page.Margin = new Thickness(margin);
            contentGrid.Height = Height - 2 * margin - heightOf(header) - heightOf(footer);
            AvailableHeight = contentGrid.Height - heightOf(subTotal);
            contentGrid.Width = Width - 2 * margin;
        }

        double heightOf(UIElement element)
        {
            element.Measure(new Size(Width, Height));
            element.Arrange(new Rect(element.DesiredSize));
            return element.DesiredSize.Height;
        }
        public double AddItem(ReportEntry entry)
        {
            content.Items.Add(entry);
            content.UpdateLayout();
            TotalReceivable += entry.Receivable;
            TotalReceipt += entry.Receipt;
            return content.DesiredSize.Height;
        }
        public void RemoveItem(ReportEntry entry)
        {
            content.Items.Remove(entry);
            content.UpdateLayout();
            TotalReceivable -= entry.Receivable;
            TotalReceipt -= entry.Receipt;
        }

        public void RaiseFinished() => IsFinished = true;

        public string Title
        {
            get { return (string)GetValue(TitleProperty); }
            set { SetValue(TitleProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Title.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TitleProperty =
            DependencyProperty.Register("Title", typeof(string), typeof(LedgerPage), new PropertyMetadata(null));


        public string SubTitle
        {
            get { return (string)GetValue(SubTitleProperty); }
            set { SetValue(SubTitleProperty, value); }
        }

        // Using a DependencyProperty as the backing store for SubTitle.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SubTitleProperty =
            DependencyProperty.Register("SubTitle", typeof(string), typeof(LedgerPage), new PropertyMetadata(null));


        public string Date
        {
            get { return (string)GetValue(DateProperty); }
            set { SetValue(DateProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Date.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty DateProperty =
            DependencyProperty.Register("Date", typeof(string), typeof(LedgerPage), new PropertyMetadata(null));


        public int TotalReceivable
        {
            get { return (int)GetValue(TotalReceivableProperty); }
            set { SetValue(TotalReceivableProperty, value); }
        }

        // Using a DependencyProperty as the backing store for TotalReceivable.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TotalReceivableProperty =
            DependencyProperty.Register("TotalReceivable", typeof(int), typeof(LedgerPage), new PropertyMetadata(null));


        public int TotalReceipt
        {
            get { return (int)GetValue(TotalReceiptProperty); }
            set { SetValue(TotalReceiptProperty, value); }
        }

        // Using a DependencyProperty as the backing store for TotalReceipt.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TotalReceiptProperty =
            DependencyProperty.Register("TotalReceipt", typeof(int), typeof(LedgerPage), new PropertyMetadata(null));


        public string FootNote
        {
            get { return (string)GetValue(FootNoteProperty); }
            set { SetValue(FootNoteProperty, value); }
        }

        // Using a DependencyProperty as the backing store for FootNote.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty FootNoteProperty =
            DependencyProperty.Register("FootNote", typeof(string), typeof(LedgerPage), new PropertyMetadata(null));


        public int PageNo
        {
            get { return (int)GetValue(PageNoProperty); }
            set { SetValue(PageNoProperty, value); }
        }

        // Using a DependencyProperty as the backing store for PageNo.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty PageNoProperty =
            DependencyProperty.Register("PageNo", typeof(int), typeof(LedgerPage), new PropertyMetadata(0));


        public bool IsFinished
        {
            get { return (bool)GetValue(IsFinishedProperty); }
            set { SetValue(IsFinishedProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsFinished.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsFinishedProperty =
            DependencyProperty.Register("IsFinished", typeof(bool), typeof(LedgerPage), new PropertyMetadata(false));


    }
}
