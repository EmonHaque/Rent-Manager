﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentManager.Models
{
    class PlotWiseDue
    {
        public string Month { get; set; }
        public string Tenant { get; set; }
        public int Due { get; set; }
    }
}
