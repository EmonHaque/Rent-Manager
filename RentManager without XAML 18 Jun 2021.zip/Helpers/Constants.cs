﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace RentManager.Helpers
{
    class Constants
    {
        public const string DBName = "data.db";
        public const string ConnectionString = "data source = " + DBName;
        public const double ScrollBarThickness = 12;
        public const string NumberFormat = "#,##0;(#,##0);-    ";
        public static Thickness CardMargin = new Thickness(7);
    }
}
