﻿using RentManager.Abstracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace RentManager.Views.Transact
{
    class NormalTransaction : View
    {
        NormalTransactionContainer views;
        public NormalTransaction() {
            views = new NormalTransactionContainer();
            AddVisualChild(views);
        }
        public override FrameworkElement container => views;
    }

    class NormalTransactionContainer : ViewContainer
    {
        public NormalTransactionContainer() {
            Children.Add(new RegularTransaction());
            Children.Add(new IrregularTransaction());
        }
    }
}
