﻿using Microsoft.Data.Sqlite;
using RentManager.CustomControls;
using RentManager.Enums;
using RentManager.Helpers;
using RentManager.Models;
using RentManager.ViewModels;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows.Data;

namespace RentManager.ViewModel.Edit
{
    public class EditLeaseVM : EditBase<Lease>
    {
        bool isEqual;
        CollectionViewSource editablePlots, spaces, tenants;
        int? selectedPlot;
        public int? SelectedPlot {
            get { return selectedPlot; }
            set {
                if (selectedPlot != value) {
                    selectedPlot = value;
                    reset();
                }
            }
        }
        string editableQuery;
        public string EditableQuery {
            get { return editableQuery; }
            set {
                if (editableQuery != value) {
                    editableQuery = value?.Trim().ToLower();
                    Editables.Refresh();
                }
            }
        }
        bool? filterState;
        public bool? FilterState {
            get { return filterState; }
            set {
                if (filterState != value) {
                    filterState = value;
                    Editables.Refresh();
                }
            }
        }
        string amount;
        public string Amount {
            get { return amount; }
            set {
                if (amount != value) {
                    amount = value;
                    OnPropertyChanged(nameof(Amount));
                    validateAmount();
                }
            }
        }
        public string ErrorPlotId { get; set; }
        public string ErrorSpaceId { get; set; }
        public string ErrorTenantId { get; set; }
        public string ErrorBusiness { get; set; }
        public string ErrorStartDate { get; set; }
        public string ErrorEndDate { get; set; }
        public string ErrorCharge { get; set; }
        public string ErrorAmount { get; set; }
        public string ErrorHeadId { get; set; }
        public bool IsValid { get; set; }
        public bool IsReceivableValid { get; set; }      
        public string NonEditablePlotQuery { get; set; }
        public string PlotQuery { get; set; }
        public string SpaceQuery { get; set; }
        public string TenantQuery { get; set; }
        public string HeadQuery { get; set; }
        public ICollectionView NonEditablePlots { get; set; }
        public ICollectionView Plots { get; set; }
        public ICollectionView Spaces { get; set; }
        public ICollectionView Tenants { get; set; }
        public ICollectionView ReceivableHeads { get; set; }
        public Receivable NewReceivable { get; set; }
        public Action AddReceivable { get; set; }
        public Action<Receivable> RemoveReceivable { get; set; }
        public Action<SelectQuery, string> FilterCommand { get; set; }

        public EditLeaseVM() : base() {
            NewReceivable = new Receivable();
            initializeCollections();
            initializeFilters();
            AddReceivable = addReceivable;
            RemoveReceivable = removeReceivable;
            NewReceivable.PropertyChanged += validateReceivable;
            FilterState = true;
            FilterCommand = filterCommand;
        }

        void filterCommand(SelectQuery parameter, string query) {
            switch (parameter) {
                case SelectQuery.Plot: PlotQuery = query; Plots.Refresh(); break;
                case SelectQuery.Space: SpaceQuery = query; Spaces.Refresh(); break;
                case SelectQuery.Tenant: TenantQuery = query; Tenants.Refresh(); break;
                case SelectQuery.Head: HeadQuery = query; ReceivableHeads.Refresh(); break;
                case SelectQuery.NonEditable: NonEditablePlotQuery = query; NonEditablePlots.Refresh(); break;
            }
        }

        void reset() {
            if (IsOnEdit) base.resetIsOnEdit();
            Editables.Refresh();
        }
        #region validation rules
        void validateReceivable(object sender, PropertyChangedEventArgs e) {
            switch (e.PropertyName) {
                case nameof(Receivable.Amount):
                case nameof(Receivable.HeadId): validateHead(); break;
            }
            IsReceivableValid =
                ErrorHeadId == string.Empty &&
                ErrorAmount == string.Empty
                ? true : false;
            OnPropertyChanged(nameof(IsReceivableValid));
        }
        void validatePlotId() {
            ErrorPlotId = string.Empty;
            if (Edited.PlotId == null)
                ErrorPlotId = " is required";
            OnPropertyChanged(nameof(ErrorPlotId));
            Spaces.Refresh();
            Edited.SpaceId = (Spaces.CurrentItem as Space)?.Id;         
        }
        void validateSpaceId() {
            ErrorSpaceId = string.Empty;
            if (Edited.SpaceId == null)
                ErrorSpaceId = " is required";
            OnPropertyChanged(nameof(ErrorSpaceId));
        }
        void validateTenantId() {
            ErrorTenantId = string.Empty;
            if (Edited.TenantId == null)
                ErrorTenantId = " is required";
            OnPropertyChanged(nameof(ErrorTenantId));
        }
        void validateBusiness() {
            ErrorBusiness = string.Empty;
            if (string.IsNullOrWhiteSpace(Edited.Business))
                ErrorBusiness = "Business is required";
            OnPropertyChanged(nameof(ErrorBusiness));
        }
        void validateStartDate() {
            ErrorStartDate = string.Empty;
            if (Edited.DateStart == null)
                ErrorStartDate = " is required";
            OnPropertyChanged(nameof(ErrorStartDate));
        }
        void validateIsExpired() {
            if ((Edited.IsExpired && !Selected.IsExpired) &&
                (Edited.SpaceId != Selected.SpaceId)) {
                ErrorSpaceId = " are you sure?";
                OnPropertyChanged(nameof(ErrorSpaceId));
            }
            else {
                if(Edited.SpaceId == null) {
                    ErrorSpaceId = " is required";
                    OnPropertyChanged(nameof(ErrorSpaceId));
                }
                else {
                    ErrorSpaceId = string.Empty;
                    OnPropertyChanged(nameof(ErrorSpaceId));
                }
            }
            validateEndDate();
        }
        void validateEndDate() {
            ErrorEndDate = string.Empty;
            if (Edited.IsExpired) {
                if (Edited.DateEnd == null)
                    ErrorEndDate = " is required";
                else {
                    if (Nullable.Compare(Edited.DateEnd, Edited.DateStart) <= 0) {
                        ErrorEndDate = " must be later than Lease start date";
                    }
                }
            }
            OnPropertyChanged(nameof(ErrorEndDate));
            checkValidity();
        }
        void validateAmount() {
            ErrorAmount = string.Empty;
            if (string.IsNullOrWhiteSpace(Amount))
                ErrorAmount = "Amount in required";
            else {
                int x;
                if (int.TryParse(Amount, out x)) {
                    if (x > 0) {
                        NewReceivable.Amount = x;
                        ErrorAmount = string.Empty;
                    }
                    else ErrorAmount = "Positive integers only";
                }
                else ErrorAmount = "Integer only";
            }
            OnPropertyChanged(nameof(ErrorAmount));

            IsReceivableValid =
                ErrorHeadId == string.Empty &&
                ErrorAmount == string.Empty
                ? true : false;
            OnPropertyChanged(nameof(IsReceivableValid));
        }
        void validateHead() {
            ErrorHeadId = string.Empty;
            if (NewReceivable.HeadId == null)
                ErrorHeadId = " is required";
            OnPropertyChanged(nameof(ErrorHeadId));
        }
        void checkValidity() {
            isEqual = isBothEqual();
            IsValid =
                !isEqual &&
                ErrorPlotId == string.Empty &&
                ErrorSpaceId == string.Empty &&
                ErrorTenantId == string.Empty &&
                ErrorStartDate == string.Empty &&
                ErrorEndDate == string.Empty &&
                ErrorBusiness == string.Empty &&
                ErrorCharge == string.Empty;
            OnPropertyChanged(nameof(IsValid));
        }

        public bool isBothEqual() {
            return
                Selected.PlotId == Edited.PlotId &&
                Selected.SpaceId == Edited.SpaceId &&
                Selected.TenantId == Edited.TenantId &&
                Nullable.Compare(Selected.DateStart, Edited.DateStart) == 0 &&
                Nullable.Compare(Selected.DateEnd, Edited.DateEnd) == 0 &&
                string.Equals(Selected.Business, Edited.Business) &&
                Selected.IsExpired == Edited.IsExpired &&
                isFixedReceivablesEqual();
        }
        bool isFixedReceivablesEqual() {
            if (Selected.FixedReceivables.Count != Edited.FixedReceivables.Count) return false;
            bool isEqual = false;
            for (int i = 0; i < Edited.FixedReceivables.Count; i++)
                isEqual = isEqualTo(Edited.FixedReceivables[i], Selected.FixedReceivables[i]);
            return isEqual;
        }
        public bool isEqualTo(Receivable edited, Receivable selected) {
            return
                selected.LeaseId == edited.LeaseId &&
                selected.HeadId == edited.HeadId &&
                selected.Amount == edited.Amount;
        }
        #endregion

        #region for Constructor
        void initializeCollections() {
            ReceivableHeads = new CollectionViewSource() { Source = AppData.heads }.View;
            NonEditablePlots = new CollectionViewSource() { Source = AppData.plots }.View;
            editablePlots = new CollectionViewSource() { Source = AppData.plots };
            spaces = new CollectionViewSource() { Source = AppData.spaces };
            tenants = new CollectionViewSource() {
                Source = AppData.tenants,
                IsLiveFilteringRequested = true,
                LiveFilteringProperties = { nameof(Tenant.HasLeft) }
            };
            Plots = editablePlots.View;
            Spaces = spaces.View;
            Tenants = tenants.View;
            Editables = new CollectionViewSource() {
                Source = AppData.leases,
                IsLiveFilteringRequested = true,
                LiveFilteringProperties = { nameof(Lease.IsExpired), nameof(Lease.PlotId) }
            }.View;
        }
        void initializeFilters() {
            NonEditablePlots.Filter = filterPlots;
            Plots.Filter = filterEditablePlots;
            Editables.Filter = filterLeases;
            ReceivableHeads.Filter = filterReceivableHeads;
            Spaces.Filter = filterSpaces;
            Tenants.Filter = filterTenants;
        }
        #endregion

        #region Commands
        void addReceivable() {
            NewReceivable.PropertyChanged -= validateReceivable;
            Edited.FixedReceivables.Add(NewReceivable);
            var head = ReceivableHeads.CurrentItem as Head;
            NewReceivable = new Receivable() {
                LeaseId = Selected.Id,
                HeadId = head == null ? 0 : head.Id,
            };
            NewReceivable.PropertyChanged += validateReceivable;
            OnPropertyChanged(nameof(NewReceivable));

            Amount = null;
            if (ErrorCharge != string.Empty) {
                ErrorCharge = string.Empty;
                OnPropertyChanged(nameof(ErrorCharge));

            }
            ReceivableHeads.Refresh();
            checkValidity();
        }
        void removeReceivable(Receivable receivable) {
            Edited.FixedReceivables.Remove(receivable);
            ReceivableHeads.Refresh();
            if (ReceivableHeads.CurrentItem == null)
                ReceivableHeads.MoveCurrentToFirst();
            if (Edited.FixedReceivables.Count == 0) {
                ErrorCharge = " is required";
                OnPropertyChanged(nameof(ErrorCharge));
            }
            checkValidity();
        }
        #endregion

        #region filters
        bool filterPlots(object o) {
            if (string.IsNullOrWhiteSpace(NonEditablePlotQuery)) return true;
            return ((Plot)o).Name.ToLower().Contains(NonEditablePlotQuery);
        }
        bool filterEditablePlots(object o) {
            if (string.IsNullOrWhiteSpace(PlotQuery)) return true;
            return ((Plot)o).Name.ToLower().Contains(PlotQuery);
        }
        bool filterSpaces(object o) {
            if (Edited == null) return false;
            if (string.IsNullOrWhiteSpace(SpaceQuery))
                return (o as Space).PlotId == Edited.PlotId;
            var space = (Space)o;
            return space.PlotId == Edited.PlotId && space.Name.ToLower().Contains(SpaceQuery);
        }
        bool filterTenants(object o) {
            if (string.IsNullOrWhiteSpace(TenantQuery)) return true;
            return ((Tenant)o).Name.ToLower().Contains(TenantQuery);
        }
        bool filterLeases(object o) {
            if (SelectedPlot == null) return false;
            if (AppData.leases.Count > 0) {
                if (((Lease)o).PlotId == selectedPlot) {
                    var lease = (Lease)o;
                    bool isEmpty, nameContains;
                    isEmpty = nameContains = false;
                    isEmpty = string.IsNullOrWhiteSpace(EditableQuery);
                    if(!isEmpty) {
                        nameContains = lease.TenantName.ToLower().Contains(EditableQuery) || lease.SpaceName.ToLower().Contains(EditableQuery);
                    }
                    switch (FilterState) {
                        case true: return isEmpty ? true && !lease.IsExpired : nameContains && !lease.IsExpired;
                        case false: return isEmpty ? true && lease.IsExpired : nameContains && lease.IsExpired;
                        default: return isEmpty ? true : nameContains;
                    }
                }
                return false;
            }
            return false;
        }
        bool filterReceivableHeads(object o) {
            if (Edited == null) return false;
            var head = o as Head;
            var result = head.ControlId == AppData.controlIdOfReceivable
                && Edited.FixedReceivables.FirstOrDefault(x => x.HeadId == head.Id) == null;
            if (string.IsNullOrWhiteSpace(HeadQuery)) return result;
            return head.Name.ToLower().Contains(HeadQuery) && result;
        }
        #endregion

        #region base implementation
        protected override void setStatesOnClone() {
            Spaces.Refresh();
            Edited.SpaceId = Selected.SpaceId;
            ReceivableHeads.Refresh();
            NewReceivable.HeadId = (ReceivableHeads.CurrentItem as Head)?.Id;
        }
        protected override Lease clone() {
            NewReceivable.LeaseId = Selected.Id;
            var lease = new Lease() {
                Id = Selected.Id,
                PlotId = Selected.PlotId,
                SpaceId = Selected.SpaceId,
                TenantId = Selected.TenantId,
                DateStart = Selected.DateStart,
                DateEnd = Selected.DateEnd,
                Business = Selected.Business,
                IsExpired = Selected.IsExpired,
                FixedReceivables = new ObservableCollection<Receivable>()
            };
            foreach (var receivable in Selected.FixedReceivables)
                lease.FixedReceivables.Add(new Receivable(receivable));
            return lease;
        }
        protected override void validate(object sender, PropertyChangedEventArgs e) {
            switch (e.PropertyName) {
                case nameof(Lease.PlotId):
                    validatePlotId();
                    Spaces.Refresh();
                    break;
                case nameof(Lease.SpaceId): validateSpaceId(); break;
                case nameof(Lease.TenantId): validateTenantId(); break;
                case nameof(Lease.Business): validateBusiness(); break;
                case nameof(Lease.DateStart): validateStartDate(); break;
                case nameof(Lease.IsExpired): validateIsExpired(); break;
                case nameof(Lease.DateEnd): validateEndDate(); break;
            }
            checkValidity();
        }
        protected override void setValidationProperties() {
            isEqual = true;
            IsValid = false;
            IsReceivableValid = false;
            ErrorPlotId =
            ErrorSpaceId =
            ErrorTenantId =
            ErrorBusiness =
            ErrorStartDate =
            ErrorEndDate =
            ErrorCharge = string.Empty;

            OnPropertyChanged(nameof(ErrorPlotId));
            OnPropertyChanged(nameof(ErrorSpaceId));
            OnPropertyChanged(nameof(ErrorTenantId));
            OnPropertyChanged(nameof(ErrorBusiness));
            OnPropertyChanged(nameof(ErrorStartDate));
            OnPropertyChanged(nameof(ErrorEndDate));
            OnPropertyChanged(nameof(ErrorCharge));
            OnPropertyChanged(nameof(IsReceivableValid));
            OnPropertyChanged(nameof(IsValid));
        }
        protected override void save() {
            var spaceName = string.Empty;
            object dateExpired = DBNull.Value;
            var commands = new List<SqliteCommand>();

            if (Edited.IsExpired && !Selected.IsExpired) {
                commands.Add(new SqliteCommand($"UPDATE Spaces SET IsVacant = 1 WHERE Id = {Edited.SpaceId}"));
                var space = AppData.spaces.FirstOrDefault(x => x.Id == Edited.SpaceId);
                space.IsVacant = true;
                spaceName = space.Name;
                dateExpired = DateTime.Now.ToString("yyyy-MM-dd");
                space.OnPropertyChanged(nameof(Space.IsVacant));
            }
            else {
                if (Edited.IsExpired && Selected.IsExpired)
                    dateExpired = Edited.DateEnd.Value.ToString("yyyy-MM-dd");
                commands.Add(new SqliteCommand($"DELETE FROM Receivables WHERE LeaseId = {Edited.Id}"));
                foreach (var item in Edited.FixedReceivables)
                    commands.Add(new SqliteCommand($"INSERT INTO Receivables VALUES({item.LeaseId}, {item.HeadId}, {item.Amount})"));
            }

            if (Edited.SpaceId != Selected.SpaceId) {
                commands.Add(new SqliteCommand($"UPDATE Spaces SET IsVacant = 1 WHERE Id = {Selected.SpaceId}"));
                commands.Add(new SqliteCommand($"UPDATE Spaces SET IsVacant = 0 WHERE Id = {Edited.SpaceId}"));

                var space = AppData.spaces.FirstOrDefault(x => x.Id == Selected.SpaceId);
                space.IsVacant = true;
                space.OnPropertyChanged(nameof(Space.IsVacant));

                space = AppData.spaces.FirstOrDefault(x => x.Id == Edited.SpaceId);
                space.IsVacant = false;
                space.OnPropertyChanged(nameof(Space.IsVacant));
            }
            var cmd = new SqliteCommand(@"UPDATE Leases SET PlotId = @PlotId, SpaceId = @SpaceId, TenantId = @TenantId, 
                                            DateStart = @DateStart, DateEnd = @DateEnd, Business = @Business, IsExpired = @IsExpired WHERE Id = @Id");
            cmd.Parameters.AddWithValue("@PlotId", Edited.PlotId);
            cmd.Parameters.AddWithValue("@SpaceId", Edited.SpaceId);
            cmd.Parameters.AddWithValue("@TenantId", Edited.TenantId);
            cmd.Parameters.AddWithValue("@DateStart", Edited.DateStart.Value.ToString("yyyy-MM-dd"));
            cmd.Parameters.AddWithValue("@DateEnd", dateExpired);
            cmd.Parameters.AddWithValue("@Business", Edited.Business);
            cmd.Parameters.AddWithValue("@IsExpired", Edited.IsExpired);
            cmd.Parameters.AddWithValue("@Id", Edited.Id);
            commands.Add(cmd);
            lock (SQLHelper.key) {
                SQLHelper.Transaction(commands);
            }
            foreach (var command in commands) command.Dispose();

            if (!string.IsNullOrEmpty(spaceName)) {
                InfoWindow.Activate("Lease", $"{spaceName} is now available to let out");
            }
        }
        protected override void update() {
            if (Edited.PlotId != Selected.PlotId) Selected.PlotName = AppData.plots.First(x => x.Id == Edited.PlotId).Name;
            if (Edited.SpaceId != Selected.SpaceId) Selected.SpaceName = AppData.spaces.First(x => x.Id == Edited.SpaceId).Name;
            if (Edited.TenantId != Selected.TenantId) Selected.TenantName = AppData.tenants.First(x => x.Id == Edited.TenantId).Name;
            
            Selected.PlotId = Edited.PlotId;
            Selected.SpaceId = Edited.SpaceId;
            Selected.TenantId = Edited.TenantId;
            Selected.DateStart = Edited.DateStart;
            Selected.DateEnd = Edited.DateEnd;
            Selected.Business = Edited.Business;
            Selected.IsExpired = Edited.IsExpired;
            Selected.FixedReceivables = Edited.FixedReceivables;
        }
        #endregion
    }
}