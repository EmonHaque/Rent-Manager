﻿using RentManager.CustomControls;
using RentManager.Helpers;
using RentManager.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace RentManager.DataTemplates
{
    class RentReceiptTemplate : DataTemplate
    {
        public RentReceiptTemplate() {
            var grid = new FrameworkElementFactory(typeof(Grid));
            var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var col4 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var space = new FrameworkElementFactory(typeof(TextBlock));
            var cash = new FrameworkElementFactory(typeof(TextBlock));
            var kind = new FrameworkElementFactory(typeof(TextBlock));
            var total = new FrameworkElementFactory(typeof(TextBlock));

            Resources.Add(typeof(TextBlock), new Style() {
                Setters = {
                    new Setter(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center)
                }
            });
            col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
            col3.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
            col4.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
            cash.SetValue(Grid.ColumnProperty, 1);
            kind.SetValue(Grid.ColumnProperty, 2);
            total.SetValue(Grid.ColumnProperty, 3);

            cash.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
            kind.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
            total.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);

            space.SetBinding(TextBlock.TextProperty, new Binding(nameof(RentPayment.Space)));
            cash.SetBinding(TextBlock.TextProperty, new Binding(nameof(RentPayment.Cash)) { StringFormat = Constants.NumberFormat });
            kind.SetBinding(TextBlock.TextProperty, new Binding(nameof(RentPayment.Kind)) { StringFormat = Constants.NumberFormat });
            total.SetBinding(TextBlock.TextProperty, new Binding(nameof(RentPayment.TotalPaid)) { StringFormat = Constants.NumberFormat });

            grid.AppendChild(col1);
            grid.AppendChild(col2);
            grid.AppendChild(col3);
            grid.AppendChild(col4);
            grid.AppendChild(space);
            grid.AppendChild(cash);
            grid.AppendChild(kind);
            grid.AppendChild(total);

            VisualTree = grid;
        }
    }
}
