﻿class PlotDue : CardView
    {
        public override string Header => "Due & Tenants";

        BarChart chart;
        ActionButton refresh;
        BiState state;
        TextBlock info;
        PlotDueVM viewModel;
        public PlotDue() {
            viewModel = new PlotDueVM();
            DataContext = viewModel;
            initializeUI();
            bind();
        }
        void refreshCommand() {
            if (BusyWindow.IsOpened) return;
            var position = PointToScreen(new Point(0, 0));
            var dpi = VisualTreeHelper.GetDpi(this);
            position.X /= dpi.DpiScaleX;
            position.Y /= dpi.DpiScaleY;
            position.X += Constants.CardMargin.Left;
            position.Y += Constants.CardMargin.Top;
            var width = ActualWidth - Constants.CardMargin.Left - Constants.CardMargin.Right;
            var height = ActualHeight - Constants.CardMargin.Top - Constants.CardMargin.Bottom;

            BusyWindow.Activate(position.X, position.Y, width, height, "Reloading ...");
            viewModel.Refresh.Invoke();
            BusyWindow.Terminate();
        }
        void initializeUI() {
            chart = new BarChart();
            refresh = new ActionButton() {
                Command = refreshCommand,
                Icon = Icons.Refresh,
                ToolTip = "Reload",
                VerticalAlignment = VerticalAlignment.Center
            };
            state = new BiState() {
                IsTrue = true,
                Text = "All",
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 5, 0)
            };
            var buttonStack = new StackPanel() {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(0, -50, 0, 0),
                Children = { state, refresh }
            };
            info = new TextBlock() {
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(0,0,10,0),
                FontWeight = FontWeights.Bold
            };
            Grid.SetRow(chart, 1);
            var grid = new Grid() {
                RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition()
                },
                Children = { chart, buttonStack, info }
            };
            setContent(grid);
        }
        void bind() {
            chart.SetBinding(BarChart.ItemSourceProperty, new Binding(nameof(viewModel.Data)));
            state.SetBinding(BiState.IsTrueProperty, new Binding(nameof(viewModel.State)));
            info.SetBinding(TextBlock.TextProperty, new Binding(nameof(viewModel.Name)));
        }
    }
