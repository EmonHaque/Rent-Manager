﻿class EditPlotVM : EditBase<Plot>
{
    bool isEqual;
    public string ErrorName { get; set; }
    public string ErrorDescription { get; set; }
    public bool IsValid { get; set; }
    string filterName;
    public string FilterName {
        get { return filterName; }
        set {
            if (filterName != value) {
                filterName = value?.Trim().ToLower();
                Editables.Refresh();
            }
        }
    }
    public static event Action<Plot> NameChanged;
    public EditPlotVM() {
        Editables = new CollectionViewSource() { Source = AppData.plots }.View;
        Editables.Filter = filterPlot;
    }
    bool filterPlot(object o) {
        if (string.IsNullOrWhiteSpace(FilterName)) return true;
        return ((Plot)o).Name.ToLower().Contains(FilterName);
    }

    #region validation rules
    void validateName() {
        ErrorName = string.Empty;
        if (string.IsNullOrWhiteSpace(Edited.Name))
            ErrorName = "Name is required";
        else {
            if (!string.Equals(Edited.Name, Selected.Name, StringComparison.OrdinalIgnoreCase)) {
                for (int i = 0; i < AppData.plots.Count; i++) {
                    if (string.Equals(Edited.Name, AppData.plots[i].Name, StringComparison.OrdinalIgnoreCase))
                        ErrorName = "Name exists";
                }
            }
        }
        OnPropertyChanged(nameof(ErrorName));
    }
    void validateDescription() {
        ErrorDescription = string.Empty;
        if (string.IsNullOrWhiteSpace(Edited.Description))
            ErrorDescription = "Description is required";
        OnPropertyChanged(nameof(ErrorDescription));
    }
    #endregion

    #region base implementation
    protected override Plot clone() {
        return new Plot() {
            Id = Selected.Id,
            Name = Selected.Name,
            Description = Selected.Description
        };
    }
    protected override void setValidationProperties() {
        isEqual = true;
        IsValid = false;
        ErrorName = string.Empty;
        ErrorDescription = string.Empty;
        OnPropertyChanged(nameof(IsValid));
        OnPropertyChanged(nameof(ErrorName));
        OnPropertyChanged(nameof(ErrorDescription));
    }
    protected override void validate(object sender, PropertyChangedEventArgs e) {
        switch (e.PropertyName) {
            case nameof(Plot.Name): validateName(); break;
            case nameof(Plot.Description): validateDescription(); break;
        }
        isEqual =
            string.Equals(Edited.Name, Selected.Name, StringComparison.OrdinalIgnoreCase) &&
            string.Equals(Edited.Description, Selected.Description, StringComparison.OrdinalIgnoreCase);
        IsValid =
            !isEqual &&
            ErrorName == string.Empty &&
            ErrorDescription == string.Empty;
        OnPropertyChanged(nameof(IsValid));
    }
    protected override void save() {
        lock (SQLHelper.key) {
            SQLHelper.command.CommandText = "UPDATE Plots SET Name = @Name, Description = @Description WHERE Id = @Id";
            SQLHelper.command.Parameters.AddWithValue("@Name", Edited.Name);
            SQLHelper.command.Parameters.AddWithValue("@Description", Edited.Description);
            SQLHelper.command.Parameters.AddWithValue("@Id", Edited.Id);
            SQLHelper.command.ExecuteNonQuery();
            SQLHelper.command.Parameters.Clear();
        }
    }
    protected override void update() {
        if (!string.Equals(Selected.Name, Edited.Name)) {
            foreach (var lease in AppData.leases) {
                if (lease.PlotId == Selected.Id)
                    lease.PlotName = Edited.Name;
            }
            foreach (var space in AppData.spaces) {
                if (space.PlotId == Selected.Id) {
                    space.PlotName = Edited.Name;
                }
            }
            NameChanged?.Invoke(Edited);
        }
        Selected.Name = Edited.Name;
        Selected.Description = Edited.Description;
    }
    #endregion
}
