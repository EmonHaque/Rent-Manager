﻿class EditTenantVM : EditBase<Tenant>
{
    bool isEqual;
    string filterName;
    public string FilterName {
        get { return filterName; }
        set {
            if (filterName != value) {
                filterName = value?.Trim().ToLower();
                Editables.Refresh();
            }
        }
    }
    bool? filterState;
    public bool? FilterState {
        get { return filterState; }
        set {
            if (filterState != value) {
                filterState = value;
                Editables.Refresh();
            }
        }
    }
    DateTime? leftOn;
    public DateTime? LeftOn {
        get { return leftOn; }
        set {
            if (leftOn != value) {
                leftOn = value;
                validateLeftOn();
            }
        }
    }

    public string ErrorName { get; set; }
    public string ErrorFather { get; set; }
    public string ErrorAddress { get; set; }
    public string ErrorContactNo { get; set; }
    public string ErrorLeftOn { get; set; }
    public bool IsValid { get; set; }
    public ICollectionView Leases { get; set; }
    public static event Action<Tenant> NameChanged;
    public EditTenantVM() {
        Editables = new CollectionViewSource() {
            Source = AppData.tenants,
            IsLiveFilteringRequested = true,
            LiveFilteringProperties = { nameof(Tenant.HasLeft) },
            IsLiveSortingRequested = true,
            LiveSortingProperties = { nameof(Tenant.Name) }
        }.View;
        Leases = new CollectionViewSource() { Source = AppData.leases }.View;
        Editables.SortDescriptions.Add(new SortDescription(nameof(Tenant.Name), ListSortDirection.Ascending));
        Editables.Filter = filterTenants;
        Leases.Filter = (o) => Selected == null ? false : (o as Lease).TenantId == Selected.Id;
        FilterState = true;
    }

    #region validation rules
    void validateName() {
        ErrorName = string.Empty;
        if (string.IsNullOrWhiteSpace(Edited.Name))
            ErrorName = "Name is required";
        else {
            if (!string.Equals(Selected.Name, Edited.Name, StringComparison.OrdinalIgnoreCase)) {
                for (int i = 0; i < AppData.tenants.Count; i++) {
                    if (string.Equals(AppData.tenants[i].Name, Edited.Name, StringComparison.OrdinalIgnoreCase))
                        ErrorName = "Name exists";
                }
            }
        }
        OnPropertyChanged(nameof(ErrorName));
    }
    void validateFather() {
        ErrorFather = string.Empty;
        if (string.IsNullOrWhiteSpace(Edited.Father))
            ErrorFather = "Father is required";
        OnPropertyChanged(nameof(ErrorFather));
    }
    void validateAddress() {
        ErrorAddress = string.Empty;
        if (string.IsNullOrWhiteSpace(Edited.Address))
            ErrorAddress = "Address is required";
        OnPropertyChanged(nameof(ErrorAddress));
    }
    void validateContactNo() {
        ErrorContactNo = string.Empty;
        if (string.IsNullOrWhiteSpace(Edited.ContactNo))
            ErrorContactNo = "phone is required";
        OnPropertyChanged(nameof(ErrorContactNo));
    }
    void validateLeftOn() {
        ErrorLeftOn = string.Empty;
        if (Edited.HasLeft) {
            if (LeftOn == null)
                ErrorLeftOn = " is required";
            else {
                var leases = AppData.leases.Where(x => x.TenantId == Edited.Id && !x.IsExpired).ToList();
                if (leases.Count > 0) {
                    foreach (var lease in leases) {
                        if (Nullable.Compare(LeftOn, lease.DateStart) <= 0) {
                            ErrorLeftOn = " must be later than Lease start date";
                        }
                    }
                }
            }
        }
        OnPropertyChanged(nameof(ErrorLeftOn));
        checkValidity();
    }
    void checkValidity() {
        IsValid =
            !isEqual &&
            ErrorName == string.Empty &&
            ErrorFather == string.Empty &&
            ErrorAddress == string.Empty &&
            ErrorContactNo == string.Empty &&
            ErrorLeftOn == string.Empty;
        OnPropertyChanged(nameof(IsValid));
    }
    #endregion

    bool filterTenants(object o) {
        if (AppData.tenants.Count > 0) {
            var tenant = (o as Tenant);
            switch (FilterState) {
                case true:
                    return string.IsNullOrWhiteSpace(FilterName) ? true && !tenant.HasLeft : tenant.Name.ToLower().Contains(FilterName) && !tenant.HasLeft;
                case false:
                    return string.IsNullOrWhiteSpace(FilterName) ? true && tenant.HasLeft : tenant.Name.ToLower().Contains(FilterName) && tenant.HasLeft;
                default:
                    return string.IsNullOrWhiteSpace(FilterName) ? true : tenant.Name.ToLower().Contains(FilterName);
            }
        }
        return false;
    }

    #region base implementation  
    protected override void save() {
        var spaces = new Dictionary<string, string>();
        var tenantName = string.Empty;
        var commands = new List<KeyValuePair<string, List<SqliteParameter>>>();
        if (Edited.HasLeft && !Selected.HasLeft) {
            var leases = AppData.leases.Where(x => !x.IsExpired && x.TenantId == Edited.Id).ToList();
            if (leases.Count > 0) {
                tenantName = Edited.Name;
                foreach (var lease in leases) {
                    var space = AppData.spaces.FirstOrDefault(x => x.Id == lease.SpaceId);
                    spaces.Add(space.Name, AppData.plots.First(x => x.Id == space.PlotId).Name);

                    var leaseCommand = $"UPDATE Leases SET DateEnd = '{LeftOn.Value.ToString("yyyy-MM-dd")}', IsExpired = 1 WHERE Id = {lease.Id}";
                    var spaceCommand = $"UPDATE Spaces SET IsVacant = 1 WHERE Id = {space.Id}";

                    commands.Add(new KeyValuePair<string, List<SqliteParameter>>(leaseCommand, null));
                    commands.Add(new KeyValuePair<string, List<SqliteParameter>>(spaceCommand, null));

                    space.IsVacant = true;
                    lease.IsExpired = true;
                    lease.DateEnd = LeftOn.Value;

                    space.OnPropertyChanged(nameof(Space.IsVacant));
                    lease.OnPropertyChanged(nameof(Lease.IsExpired));
                }
            }
        }
        var tenantCommand = @"UPDATE Tenants SET Name = @Name, Father = @Father, Mother = @Mother, Husband = @Husband,
                            Address = @Address, NID = @NID, ContactNo = @ContactNo, HasLeft = @HasLeft WHERE Id = @Id";
        var paras = new List<SqliteParameter>() {
            new SqliteParameter("@Name", Edited.Name),
            new SqliteParameter("@Father", Edited.Father),
            new SqliteParameter("@Mother", string.IsNullOrWhiteSpace(Edited.Mother) ? (object)DBNull.Value : Edited.Mother),
            new SqliteParameter("@Husband", string.IsNullOrWhiteSpace(Edited.Husband) ? (object)DBNull.Value : Edited.Husband),
            new SqliteParameter("@Address", Edited.Address),
            new SqliteParameter("@NID", string.IsNullOrWhiteSpace(Edited.NID) ? (object)DBNull.Value : Edited.NID),
            new SqliteParameter("@ContactNo", Edited.ContactNo),
            new SqliteParameter("@HasLeft", Edited.HasLeft),
            new SqliteParameter("@Id", Edited.Id)
        };
        commands.Add(new KeyValuePair<string, List<SqliteParameter>>(tenantCommand, paras));

        lock (SQLHelper.key) SQLHelper.Transaction(commands);
        
        if (!string.IsNullOrEmpty(tenantName) && spaces.Count > 0) {
            var msg = "Space(s) occupied:";
            foreach (var item in spaces) {
                msg += $"\r\n\t{item.Key} of {item.Value}";
            }
            msg += $"\r\n\r\nby {tenantName} now available to let out";
            InfoWindow.Activate("Tenant", msg);
        }
    }
    protected override Tenant clone() {
        return new Tenant() {
            Id = Selected.Id,
            Name = Selected.Name,
            Father = Selected.Father,
            Mother = Selected.Mother,
            Husband = Selected.Husband,
            Address = Selected.Address,
            NID = Selected.NID,
            ContactNo = Selected.ContactNo,
            HasLeft = Selected.HasLeft
        };
    }
    protected override void validate(object sender, PropertyChangedEventArgs e) {
        switch (e.PropertyName) {
            case nameof(Tenant.Name): validateName(); break;
            case nameof(Tenant.Father): validateFather(); break;
            case nameof(Tenant.Address): validateAddress(); break;
            case nameof(Tenant.ContactNo): validateContactNo(); break;
            case nameof(Tenant.HasLeft): validateLeftOn(); break;
        }
        isEqual =
            string.Equals(Selected.Name, Edited.Name, StringComparison.OrdinalIgnoreCase) &&
            string.Equals(Selected.Father, Edited.Father, StringComparison.OrdinalIgnoreCase) &&
            string.Equals(Selected.Mother, Edited.Mother, StringComparison.OrdinalIgnoreCase) &&
            string.Equals(Selected.Husband, Edited.Husband, StringComparison.OrdinalIgnoreCase) &&
            string.Equals(Selected.Address, Edited.Address, StringComparison.OrdinalIgnoreCase) &&
            string.Equals(Selected.NID, Edited.NID, StringComparison.OrdinalIgnoreCase) &&
            string.Equals(Selected.ContactNo, Edited.ContactNo, StringComparison.OrdinalIgnoreCase) &&
            Selected.HasLeft == Edited.HasLeft;
        checkValidity();
    }
    protected override void setValidationProperties() {
        isEqual = true;
        IsValid = false;
        ErrorName =
        ErrorFather =
        ErrorAddress =
        ErrorContactNo =
        ErrorLeftOn = string.Empty;
        OnPropertyChanged(nameof(ErrorName));
        OnPropertyChanged(nameof(ErrorFather));
        OnPropertyChanged(nameof(ErrorAddress));
        OnPropertyChanged(nameof(ErrorContactNo));
        OnPropertyChanged(nameof(ErrorLeftOn));
        OnPropertyChanged(nameof(IsValid));
    }
    protected override void update() {
        if (!string.Equals(Selected.Name, Edited.Name)) {
            foreach (var lease in AppData.leases) {
                if (lease.TenantId == Edited.Id)
                    lease.TenantName = Edited.Name;
            }
            NameChanged?.Invoke(Edited);
        }
        Selected.Name = Edited.Name;
        Selected.Father = Edited.Father;
        Selected.Mother = Edited.Mother;
        Selected.Husband = Edited.Husband;
        Selected.Address = Edited.Address;
        Selected.NID = Edited.NID;
        Selected.ContactNo = Edited.ContactNo;
        Selected.HasLeft = Edited.HasLeft;
    }
    #endregion
}
