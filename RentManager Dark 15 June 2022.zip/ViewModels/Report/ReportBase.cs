﻿abstract class ReportBase : Notifiable
{
    List<ReportEntry> reserved, reportables;
    int? id;
    public int? Id {
        get { return id; }
        set {
            if (id != value) {
                id = value;
                updateReportables();
                IsRefreshValid = value == null ? false : true;
                OnPropertyChanged(nameof(IsRefreshValid));
            }
        }
    }
    string query;
    public string Query {
        get { return query; }
        set {
            if (query != value) {
                query = value?.Trim().ToLower();
                selectionView.Refresh();
            }
        }
    }
    string particularsQuery;
    public string ParticularsQuery {
        get { return particularsQuery; }
        set {
            if (particularsQuery != value) {
                particularsQuery = value?.Trim().ToLower();
                Reportables.Refresh();
            }
        }
    }
    public ICollectionView Reportables { get; set; }

    public ReportDates Dates { get; set; }
    public ReportSummary Summary { get; set; }
    public Action RefreshReport { get; set; }
    public Action ExportCSV { get; set; }
    public Action PrintReport { get; set; }
    public bool IsPrintOrExportValid { get; set; }
    public bool IsRefreshValid { get; set; }
    protected string Title { get; set; }
    protected string SubTitle { get; set; }
    public abstract ICollectionView selectionView { get; }
    protected abstract string particulars { get; }
    protected abstract string where { get; }
    protected abstract void setTitleAndSubTitle();

    public ReportBase() {
        initializeProperties();
        initializeCommands();
    }

    #region for Constructor
    void initializeProperties() {
        Dates = new ReportDates();
        Summary = new ReportSummary();
        OnPropertyChanged(nameof(Dates));
        OnPropertyChanged(nameof(Summary));
    }
    void initializeCommands() {
        RefreshReport = refreshReport;
        ExportCSV = exportCSV;
        PrintReport = printReport;
    }
    #endregion

    #region Commands
    void refreshReport() {
        BusyWindow.Activate("Refreshing ...");
        if (reserved == null) {
            updateReportables();
            BusyWindow.Terminate();
            return;
        }
        else if (reserved.First().Date == Dates.From && reserved.Last().Date == Dates.To) {
            updateReportables();
            BusyWindow.Terminate();
            return;
        }
        var lastEntry = reserved.LastOrDefault(x => x.Date < Dates.From);
        var newReportables = new List<ReportEntry>();
        if (lastEntry != null) {
            newReportables.Add(new ReportEntry() {
                Date = Dates.From,
                Balance = lastEntry.Balance,
                Particulars = "balance b/d",
                Narration = string.Empty
            });
        }
        var entries = reserved.Where(x => x.Date >= Dates.From && x.Date <= Dates.To).ToList();
        var receivable = entries.Sum(x => x.Receivable);
        var receipt = entries.Sum(x => x.Receipt);
        newReportables.AddRange(entries);

        reportables = newReportables;
        Reportables = CollectionViewSource.GetDefaultView(reportables);
        Reportables.Filter = filter;
        Summary.TotalReceivable = receivable;
        Summary.TotalReceipt = receipt;
        OnPropertyChanged(nameof(Summary));
        OnPropertyChanged(nameof(Reportables));
        BusyWindow.Terminate();
    }
    void exportCSV() {
        var dialog = new SaveFileDialog() {
            FileName = "Report",
            Filter = "CSV files (.csv)|*.csv"
        };
        if (dialog.ShowDialog() != true) return;
        BusyWindow.Activate("Exporting ...");

        var builder = new StringBuilder();
        builder.Append("Date, Particulars, Receivable/Payment, Receipt, Balance").AppendLine();
        foreach (var item in reportables) {
            builder
                .Append(item.Date.ToShortDateString()).Append(",")
                .Append("\"").Append(item.Particulars).Append(item.Narration).Append("\"").Append(",")
                .Append(item.Receivable).Append(",")
                .Append(item.Receipt).Append(",")
                .Append(item.Balance).AppendLine();
        }
        System.IO.File.WriteAllText(System.IO.Path.GetFullPath(dialog.FileName), builder.ToString());
        BusyWindow.Terminate();
    }
    void printReport() {
        var dialog = new PrintDialog();
        if (dialog.ShowDialog() != true) return;
        BusyWindow.Activate("Printing ...");
        var size = new Size(dialog.PrintableAreaWidth, dialog.PrintableAreaHeight);
        var document = new FixedDocument();
        var pages = new List<LedgerPage>();
        var page = getPage(document, null);
        pages.Add(page);
        for (int i = 0; i < reportables.Count; i++) {
            if (!page.AddEntry(reportables[i])) {
                page.IsComplete = true;
                page.LastEntry = reportables[i - 1];
                page = getPage(document, page);
                page.AddEntry(reportables[i]);
                pages.Add(page);
            }
        }
        page.IsComplete = true;
        foreach (var p in pages) {
            p.NumberOfPage = document.Pages.Count;
        }
        document.DocumentPaginator.PageSize = size;
        dialog.PrintDocument(document.DocumentPaginator, "");
        BusyWindow.Terminate();
    }
    #endregion

    void updateReportables() {
        if (Id == null) {
            clearReportables();
            IsRefreshValid = IsPrintOrExportValid = false;
            OnPropertyChanged(nameof(IsPrintOrExportValid));
            OnPropertyChanged(nameof(IsRefreshValid));
            return;
        }
        reserved = new List<ReportEntry>();
        int receivable, receipt, balance;
        receivable = receipt = balance = 0;

        lock (SQLHelper.key) {
            SQLHelper.command.CommandText = $@"SELECT tn.Date, {particulars} ||' -> '|| c.Name ||' - '|| h.Name, tn.Narration, 
                                                tn.ControlId, tn.TenantId, tn.Amount FROM Transactions tn
                                        LEFT JOIN Plots p ON p.Id = tn.PlotId
                                        LEFT JOIN Spaces s ON s.Id = tn.SpaceId
                                        LEFT JOIN Tenants t ON t.Id = tn.TenantId
                                        LEFT JOIN Heads h ON h.Id = tn.HeadId
                                        LEFT JOIN ControlHeads c ON c.Id = tn.ControlId
                                        WHERE tn.{where}={Id} ORDER by tn.Date";

            var reader = SQLHelper.command.ExecuteReader();
            while (reader.Read()) {
                var entry = new ReportEntry() {
                    Date = reader.GetDateTime(0),
                    Particulars = reader.GetString(1),
                    Narration = reader.IsDBNull(2) ? " | No explanation" : " | " + reader.GetString(2),
                    ControlId = reader.GetInt32(3),
                    TenantId = reader.GetInt32(4)
                };
                var amount = reader.GetInt32(5);

                if (entry.ControlId == AppData.controlIdOfReceivable || entry.ControlId == AppData.controlIdOfPayment) {
                    receivable += amount;
                    balance -= amount;
                    entry.Receivable = amount;
                }
                else {
                    receipt += amount;
                    balance += amount;
                    entry.Receipt = amount;
                }

                entry.Balance = balance;
                reserved.Add(entry);
            }
            reader.Close();
            reader.DisposeAsync();
        }

        if (reserved.Count > 0) {
            Dates.Start = reserved.First().Date;
            Dates.End = reserved.Last().Date;

            Dates.From = reserved.First().Date;
            Dates.To = reserved.Last().Date;
            OnPropertyChanged(nameof(Dates));

            Summary.Heading = $"available from {Dates.From.ToString("dd MMMM, yyyy")} to {Dates.To.ToString("dd MMMM, yyyy")}";
            Summary.TotalReceipt = receipt;
            Summary.TotalReceivable = receivable;
            OnPropertyChanged(nameof(Summary));

            reportables = reserved;
            Reportables = CollectionViewSource.GetDefaultView(reserved);
            Reportables.Filter = filter;

            IsPrintOrExportValid = true;
            OnPropertyChanged(nameof(Reportables));
            OnPropertyChanged(nameof(IsPrintOrExportValid));
        }
        else {
            clearReportables();
            IsPrintOrExportValid = false;
            OnPropertyChanged(nameof(IsPrintOrExportValid));
        }

    }
    bool filter(object o) {
        if (string.IsNullOrWhiteSpace(ParticularsQuery)) return true;
        var entry = (ReportEntry)o;
        return entry.Particulars.ToLower().Contains(ParticularsQuery) || entry.Narration.ToLower().Contains(ParticularsQuery);
    }
    void clearReportables() {
        Dates.Start = Dates.End = Dates.From = Dates.To = DateTime.Today;
        Summary.TotalReceipt = Summary.TotalReceivable = 0;
        Summary.Heading = string.Empty;

        reserved = null;
        reportables = null;
        Reportables = null;
        OnPropertyChanged(nameof(Dates));
        OnPropertyChanged(nameof(Summary));
        OnPropertyChanged(nameof(Reportables));
    }
    LedgerPage getPage(FixedDocument doc, LedgerPage previousPage) {
        LedgerPage page;
        if (previousPage == null) {
            setTitleAndSubTitle();
            page = new LedgerPage(doc.DocumentPaginator.PageSize) {
                Title = Title,
                SubTitle = SubTitle,
                Period = $"period from {Dates.From.ToString("dd MMMM, yyyy")} to {Dates.To.ToString("dd MMMM, yyyy")}",
                FootNote = $"Generated on {DateTime.Now.ToString("dd MMMM, yyyy | hh:mm:ss tt")}",
            };
        }
        else page = new LedgerPage(previousPage);
        doc.Pages.Add(new PageContent() { Child = page.Page });
        return page;
    }
}
