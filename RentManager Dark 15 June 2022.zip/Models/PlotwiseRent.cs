﻿class PlotwiseRent
{
    public int? PlotId { get; set; }
    public string Plot { get; set; }
    public string Tenant { get; set; }
    public string Month { get; set; }
    public int Rent { get; set; }
    public int Cash { get; set; }
    public int Mobile { get; set; }
    public int Kind { get; set; }
    public int Total { get; set; }
}
