﻿using System;

namespace RentManager.Models
{
    public class ReportEntry
	{
		public DateTime Date { get; set; }
        public string Particulars { get; set; }
        public string Narration { get; set; }
        public int Receivable { get; set; }
		public int Receipt { get; set; }
		public int Balance { get; set; }
        public int ControlId { get; set; }
        public int TenantId { get; set; }       
	}
}
