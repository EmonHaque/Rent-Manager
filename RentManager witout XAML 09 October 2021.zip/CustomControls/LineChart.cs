﻿using RentManager.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace RentManager.CustomControls
{
    class LineChart : Panel
    {
        public IEnumerable ItemSource {
            get { return (IEnumerable)GetValue(ItemSourceProperty); }
            set { SetValue(ItemSourceProperty, value); }
        }
        public int? SelectedValue {
            get { return (int?)GetValue(SelectedValueProperty); }
            set { SetValue(SelectedValueProperty, value); }
        }

        public static readonly DependencyProperty SelectedValueProperty =
            DependencyProperty.Register("SelectedValue", typeof(int?), typeof(LineChart), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));

        public static readonly DependencyProperty ItemSourceProperty =
            DependencyProperty.Register("ItemSource", typeof(IEnumerable), typeof(LineChart), new PropertyMetadata(null, onSourceChanged));

        static void onSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
            var o = d as LineChart;
            if (e.OldValue != null) o.Children.Clear();
            var values = ((IEnumerable)e.NewValue).Cast<DepositDueRent>().ToList();
            o.hasData = o.IsHitTestVisible = values.Count > 0;
            if (o.hasData) o.generateChart(values);
            else o.Children.Add(o.noInfoBlock);
            o.InvalidateArrange();
        }

        int numPoints;
        bool hasData;
        Pointer pointer;
        TextBlock infoBlock, noInfoBlock;
        double minValue, maxValue, horizontalOffset;
        Size labelDesired, tickDesired;
        public LineChart() {
            ClipToBounds = true;
            noInfoBlock = new TextBlock() {
                TextAlignment = TextAlignment.Center,
                FontSize = 18,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Gray,
                Inlines = {
                    new Run(){ Text = "No data"},
                    new LineBreak(),
                    new Run(){ Text = "available" }
                },
                LayoutTransform = new ScaleTransform() { ScaleY = -1 }
            };
            infoBlock = new TextBlock() {
                Foreground = Brushes.Gray,
                Tag = "Info",
                FontSize = 14,
                IsHitTestVisible = false,
                LayoutTransform = new ScaleTransform() { ScaleY = -1 }
            };
            LayoutTransform = new ScaleTransform() { ScaleY = -1 };
        }

        void addLine() {
            var line = new Line() {
                StrokeThickness = 1,
                Stroke = Brushes.LightBlue,
                StrokeDashCap = PenLineCap.Flat,
                StrokeDashArray = new DoubleCollection(new List<double> { 3, 3 }),
                IsHitTestVisible = false
            };
            Children.Add(line);
            SetZIndex(line, 1);
            line.Loaded += animateLine;
        }
        void addTick(double current) {
            var tick = new TextBlock() {
                Tag = "Tick",
                Text = current.ToString("N0"),
                HorizontalAlignment = HorizontalAlignment.Right,
                RenderTransform = new TransformGroup() {
                    Children = {
                            new ScaleTransform() { ScaleY = - 1 },
                            new TranslateTransform()
                        }
                },
                IsHitTestVisible = false
            };
            if (current < 0) tick.Foreground = Brushes.Coral;
            Children.Add(tick);
            tick.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
            tickDesired.Width = tick.DesiredSize.Width > tickDesired.Width ? tick.DesiredSize.Width : tickDesired.Width;
            tickDesired.Height = tick.DesiredSize.Height > tickDesired.Height ? tick.DesiredSize.Height : tickDesired.Height;
            tick.Loaded += animateTicks;
        }
        void addLabel(string value) {
            var label = new TextBlock() {
                Text = value,
                IsHitTestVisible = false,
                TextAlignment = TextAlignment.Right,
                Padding = new Thickness(0, 0, 5, 0),
                RenderTransform = new TransformGroup() {
                    Children = {
                            new ScaleTransform() { ScaleY = -1 },
                            new RotateTransform() { Angle = 90 }
                        }
                }
            };
            Children.Add(label);
            label.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
            if (label.DesiredSize.Width > labelDesired.Width)
                labelDesired = label.DesiredSize;
            label.Loaded += animateLabels;
        }
        void generateChart(List<DepositDueRent> values) {
            labelDesired = tickDesired = new Size(0, 0);
            Children.Add(new Border() { Background = Brushes.Transparent });
            infoBlock.Inlines.Clear();
            infoBlock.Inlines.Add(new Run() {
                Text = values.Select(x => x.TenantId).Distinct().Count() + " tenants, " + values.Count + " space",
                FontStyle = FontStyles.Italic
            });
            infoBlock.Inlines.Add(new Run() {
                Text = " in " + AppData.plots.First(x => x.Id == values.First().PlotId).Name,
                FontWeight = FontWeights.Bold
            });
            Children.Add(infoBlock);
            infoBlock.Loaded += animateInfoBlock;
            var line = new PolyLineStream(values.Select(x => x.Amount).ToList());
            SetZIndex(line, 2);
            Children.Add(line);
            maxValue = minValue = 0;
            foreach (var value in values) {
                Circle c = new(value);
                Children.Add(c);
                SetZIndex(c, 3);
                addLabel(AppData.spaces.First(x => x.Id == value.SpaceId).Name);
                if (value.Amount > maxValue) maxValue = value.Amount;
                if (value.Amount < minValue) minValue = value.Amount;
            }
            var min = minValue < 0 ? minValue : 0;
            double step = 0d;
            var current = min;
            step = min < 0 ? (maxValue + Math.Abs(min)) / 9 : maxValue / 9;
            for (int i = 0; i < 10; i++) {
                addLine();
                addTick(current);
                current += step;
            }
            numPoints = values.Count;
            pointer = new Pointer() { Visibility = Visibility.Hidden };
            Children.Add(pointer);
        }

        void animateLine(object sender, RoutedEventArgs e) {
            var line = (Line)sender;
            line.Loaded -= animateLine;
            var translateAnim = new DoubleAnimation() {
                BeginTime = TimeSpan.FromSeconds(0.5),
                To = 0,
                Duration = TimeSpan.FromSeconds(0.5),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
            var scaleAnim = new DoubleAnimation() {
                From = 0,
                Duration = TimeSpan.FromSeconds(1),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
            var translate = new TranslateTransform(0, ActualHeight / 2 - line.Y1);
            var scale = new ScaleTransform(1, 1) { CenterX = ActualWidth / 2 };
            line.RenderTransform = new TransformGroup() { Children = { translate, scale } };
            translate.BeginAnimation(TranslateTransform.YProperty, translateAnim);
            scale.BeginAnimation(ScaleTransform.ScaleXProperty, scaleAnim);
        }
        void animateTicks(object sender, RoutedEventArgs e) {
            var tick = (TextBlock)sender;
            tick.Loaded -= animateTicks;
            var anim = new DoubleAnimationUsingKeyFrames() {
                KeyFrames = {
                    new LinearDoubleKeyFrame(-30 - horizontalOffset, TimeSpan.FromSeconds(0)),
                    new LinearDoubleKeyFrame(-30 - horizontalOffset, TimeSpan.FromSeconds(0.5)),
                    new LinearDoubleKeyFrame(0, TimeSpan.FromSeconds(1)),
                }
            };
            var transform = (tick.RenderTransform as TransformGroup).Children[1];
            transform.BeginAnimation(TranslateTransform.XProperty, anim);
        }
        void animateLabels(object sender, RoutedEventArgs e) {
            var label = (TextBlock)sender;
            label.Loaded -= animateLabels;
            var anim = new DoubleAnimationUsingKeyFrames() {
                AccelerationRatio = 0.9,
                DecelerationRatio = 0.1,
                KeyFrames = {
                    new LinearDoubleKeyFrame(0, TimeSpan.FromSeconds(0)),
                    new LinearDoubleKeyFrame(45, TimeSpan.FromSeconds(0.5)),
                    new LinearDoubleKeyFrame(90, TimeSpan.FromSeconds(1))
                }
            };
            var transform = (label.RenderTransform as TransformGroup).Children[1];
            transform.BeginAnimation(RotateTransform.AngleProperty, anim);
        }
        void animateInfoBlock(object sender, RoutedEventArgs e) {
            infoBlock.Loaded -= animateInfoBlock;
            infoBlock.RenderTransform = new ScaleTransform(0, 1);
            var anim = new DoubleAnimation() {
                BeginTime = TimeSpan.FromSeconds(0.5),
                Duration = TimeSpan.FromSeconds(0.5),
                To = 1,
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseIn }
            };
            infoBlock.RenderTransform.BeginAnimation(ScaleTransform.ScaleXProperty, anim);
        }

        protected override Size ArrangeOverride(Size finalSize) {
            if (finalSize.Width == 0 || finalSize.Height == 0) return finalSize;
            if (!hasData) {
                noInfoBlock.Measure(finalSize);
                var center = new Point(finalSize.Width / 2, finalSize.Height / 2);
                var point = new Point(center.X - noInfoBlock.DesiredSize.Width / 2, center.Y - noInfoBlock.DesiredSize.Height / 2);
                noInfoBlock.Arrange(new Rect(point, noInfoBlock.DesiredSize));
                return finalSize;
            }
            var tickWidth = horizontalOffset = tickDesired.Width;
            var labelHeight = labelDesired.Width;
            var upperBound = maxValue;
            var lowerBound = minValue < 0 ? Math.Abs(minValue) : 0;

            double margin = 10;
            var availableWidth = finalSize.Width - tickWidth - 2 * margin;
            var availableHeight = (finalSize.Height - labelHeight - margin) / 10 * 9;
            var posHeight = availableHeight / (lowerBound + upperBound) * upperBound;
            var negHeight = availableHeight - posHeight;
            var horizontalSpacing = (finalSize.Width - tickWidth - 2 * margin) / (numPoints - 1);
            double verticalSpacing = (finalSize.Height - labelHeight - margin) / 10;

            double lineY, tickY, labelX, circleX;
            lineY = tickY = 0;
            labelX = circleX = tickWidth + margin;

            if (availableWidth < 5 || availableHeight < 5) return finalSize;
            foreach (var item in Children) {
                if (item is PolyLineStream) {
                    var path = (PolyLineStream)item;
                    path.SetParameters(availableWidth, availableHeight, lowerBound, upperBound, horizontalSpacing);
                    path.Arrange(new Rect(new Point(tickWidth + margin, labelHeight), path.DesiredSize));
                }
                else if (item is Pointer) {
                    var pointer = (Pointer)item;
                    pointer.SetPoint(0, finalSize.Height, labelHeight);
                    pointer.Arrange(new Rect(pointer.DesiredSize));
                }
                else if (item is Circle) {
                    var circle = (Circle)item;
                    double y = 0;
                    if (circle.value is DepositDueRent) {
                        var c = (DepositDueRent)circle.value;
                        y = c.Amount < 0 ? negHeight - Math.Abs(c.Amount) / lowerBound * negHeight : c.Amount / upperBound * posHeight + negHeight;
                    }
                    circle.SetCenter(new Point(circleX, y + labelHeight));
                    circle.Arrange(new Rect(circle.DesiredSize));
                    circleX += horizontalSpacing;
                }
                else if (item is Line) {
                    var line = (Line)item;
                    line.X2 = finalSize.Width - margin;
                    line.Y1 = line.Y2 = lineY + labelHeight;
                    line.Measure(finalSize);
                    line.Arrange(new Rect(line.DesiredSize));
                    lineY += verticalSpacing;
                }
                else if (item is TextBlock) {
                    var block = (TextBlock)item;
                    block.Measure(finalSize);
                    if (block.Tag != null) {
                        if (string.Equals(block.Tag.ToString(), "Tick")) {
                            block.Arrange(new Rect(new Point(0, tickY + block.DesiredSize.Height + labelHeight), block.DesiredSize));
                            tickY += verticalSpacing;
                        }
                        else {
                            var xPos = finalSize.Width - infoBlock.DesiredSize.Width - margin;
                            var yPos = finalSize.Height - infoBlock.DesiredSize.Height;
                            block.Arrange(new Rect(new Point(xPos, yPos), infoBlock.DesiredSize));
                        }
                    }
                    else {
                        block.Width = labelDesired.Width;
                        block.Height = labelDesired.Height;
                        block.Arrange(new Rect(new Point(labelX - labelDesired.Height / 2, 0), block.DesiredSize));
                        labelX += horizontalSpacing;
                    }
                }
                else if (item is Border) {
                    var border = (Border)item;
                    border.Width = finalSize.Width - tickWidth;
                    border.Height = finalSize.Height - labelHeight;
                    border.Measure(finalSize);
                    border.Arrange(new Rect(new Point(tickWidth, labelHeight), border.DesiredSize));
                }
            }
            return finalSize;
        }
        protected override void OnMouseEnter(MouseEventArgs e) => pointer.Visibility = Visibility.Visible;
        protected override void OnMouseMove(MouseEventArgs e) => pointer.SetPoint(e.GetPosition(this).X, ActualHeight, labelDesired.Width);
        protected override void OnMouseLeave(MouseEventArgs e) {
            pointer.Visibility = Visibility.Hidden;
            pointer.SetPoint(-1, ActualHeight, labelDesired.Width);
        }
        protected override void OnPreviewMouseLeftButtonUp(MouseButtonEventArgs e) {
            if (e.OriginalSource is Circle) {
                var circle = (Circle)e.OriginalSource;
                foreach (var c in Children.OfType<Circle>()) {
                    if (c.IsSelected) {
                        c.IsSelected = false;
                        break;
                    }
                }
                circle.IsSelected = true;
                SelectedValue = circle.value.TenantId;
            }
        }
    }
}
