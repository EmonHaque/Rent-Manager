﻿using RentManager.ControlTemplates;
using RentManager.DataTemplates;
using RentManager.Models;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Media.Effects;

namespace RentManager.ToolTips
{
    class HomeBarTip : ToolTip
    {
        public HomeBarTip(List<RentPayment> payments) {
            BorderBrush = null;
            Effect = null;
            Background = null;
            HasDropShadow = false;

            var cashBlock = new TextBlock() { Text = "Cash" };
            var kindBlock = new TextBlock() { Text = "Kind" };
            var totalBlock = new TextBlock() { Text = "Total" };
            Grid.SetColumn(cashBlock, 1);
            Grid.SetColumn(kindBlock, 2);
            Grid.SetColumn(totalBlock, 3);
            var headerGrid = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) }
                },
                Children = { cashBlock , kindBlock, totalBlock },
                Resources = {
                    {
                        typeof(TextBlock),
                        new Style() {
                            Setters = {
                                new Setter(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right),
                                new Setter(TextBlock.FontWeightProperty, FontWeights.Bold)
                            }
                        }
                    } 
                }
            };
            var receipts = new ItemsControl() {
                Margin = new Thickness(2, 0, 2, 0),
                HorizontalContentAlignment = HorizontalAlignment.Stretch,
                ItemTemplate = new RentReceiptTemplate(),
                GroupStyle = {
                    new GroupStyle() {
                        ContainerStyle = new Style(typeof(GroupItem)) {
                            Setters = {
                                new Setter(GroupItem.TemplateProperty, new GroupedRentReceiptTemplate())
                            }
                        }
                    }
                },
                ItemsSource = new CollectionViewSource() {
                    Source = payments,
                    GroupDescriptions = {
                        new PropertyGroupDescription(nameof(RentPayment.Plot))
                    }
                }.View
            };
            Grid.SetRow(receipts, 1);
            Content = new Border() {
                MinWidth = 250,
                Background = Brushes.White,
                Effect = new DropShadowEffect() { BlurRadius = 5, ShadowDepth = 0 },
                Padding = new Thickness(5),
                CornerRadius = new CornerRadius(5),
                Child = new Grid() {
                    RowDefinitions = {
                        new RowDefinition(){ Height = GridLength.Auto },
                        new RowDefinition(),
                        new RowDefinition(){ Height = GridLength.Auto }
                    },
                    Children = { headerGrid, receipts }
                }
            };

            int cash, kind, total;
            cash = kind = total = 0;
            foreach (var item in payments) {
                cash += item.Cash;
                kind += item.Kind;
                total += item.TotalPaid;
            }
            RentPayment r = new RentPayment() {
                Space = "Total " + payments.First().Due.ToString("N0") + " due",
                Cash = cash,
                Kind = kind,
                TotalPaid = total
            };
            var summary = new Border() {
                BorderThickness = new Thickness(0, 1, 0, 0),
                BorderBrush = Brushes.LightBlue,
                Child = new ContentControl() {
                    ContentTemplate = new RentReceiptTemplate(),
                    Content = r,
                    Margin = new Thickness(3, 0, 3, 0)
                }
            };
            Grid.SetRow(summary, 2);
            var grid = (Grid)((Border)Content).Child;
            grid.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
            grid.Children.Add(summary);

        }
    }
}
