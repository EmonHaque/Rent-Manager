﻿using RentManager.Models;
using RentManager.ToolTips;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace RentManager.CustomControls
{
    class Pin : FrameworkElement
    {
        Line cashLine, kindLine;
        EllipseGeometry circleGeo;
        Path circle;
        DoubleAnimation onLoadAnim, thicknessAnim;
        ColorAnimation cashColorAnim, kindColorAnim, circleColorAnim;
        SolidColorBrush cashBrush, kindBrush, circleBrush;
        HomePinTip tip;
        VisualCollection children;
        Size available;
        Color cashNormal, kindNormal, circleNormal, cashHighlight, kindHilight, circleHighlight;
        int cashTotal, kindTotal;
        double radius = 3.0;
        public double upperBound;
        bool isClicked;

        public Pin(List<PlotwiseRent> values) {            
            cashNormal = Colors.CadetBlue;
            kindNormal = Colors.Coral;
            circleNormal = Colors.CornflowerBlue;
            cashHighlight = Colors.Green;
            kindHilight = Colors.Red;
            circleHighlight = Colors.Black;
            cashBrush = new SolidColorBrush(cashNormal);
            kindBrush = new SolidColorBrush(kindNormal);
            circleBrush = new SolidColorBrush(circleNormal);
            for (int i = 0; i < values.Count; i++) {
                cashTotal += values[i].Cash;
                kindTotal += values[i].Kind;
            }
            if (cashTotal > 0 || kindTotal > 0) {
                tip = new HomePinTip(values);
            }
            cashLine = new Line() {
                Stroke = cashBrush,
                StrokeThickness = 2,
                RenderTransform = new ScaleTransform(1, 0)
            };
            kindLine = new Line() {
                Stroke = kindBrush,
                StrokeThickness = 2,
                RenderTransform = new ScaleTransform(1, 0)
            };
            circleGeo = new EllipseGeometry() { RadiusX = radius, RadiusY = radius };
            circle = new Path() {
                Fill = circleBrush,
                Data = circleGeo,
                RenderTransform = new TransformGroup() {
                    Children = {
                        new TranslateTransform(),
                        new ScaleTransform(0.25,0.25)
                    }
                }
            };
            children = new VisualCollection(this) { cashLine, kindLine, circle };
            initializaAnimations();
            Loaded += onLoaded;
            Unloaded += onUnloaded;
        }
        void onUnloaded(object sender, RoutedEventArgs e) {
            Loaded -= onLoaded;
            Unloaded -= onUnloaded;
        }
        void onLoaded(object sender, RoutedEventArgs e) {
            ((TranslateTransform)((TransformGroup)circle.RenderTransform).Children[0]).Y = available.Height - kindLine.Y2;
            ((ScaleTransform)((TransformGroup)circle.RenderTransform).Children[1]).CenterY = available.Height;
            ((ScaleTransform)((TransformGroup)circle.RenderTransform).Children[1]).CenterX = available.Width / 2;
            cashLine.RenderTransform.BeginAnimation(ScaleTransform.ScaleYProperty, onLoadAnim);
            kindLine.RenderTransform.BeginAnimation(ScaleTransform.ScaleYProperty, onLoadAnim);
            ((TransformGroup)circle.RenderTransform).Children[0].BeginAnimation(TranslateTransform.YProperty, onLoadAnim);
            ((TransformGroup)circle.RenderTransform).Children[1].BeginAnimation(ScaleTransform.ScaleXProperty, onLoadAnim);
            ((TransformGroup)circle.RenderTransform).Children[1].BeginAnimation(ScaleTransform.ScaleYProperty, onLoadAnim);
        }
        void initializaAnimations() {
            var ease = new CubicEase() { EasingMode = EasingMode.EaseIn };
            var duration = TimeSpan.FromSeconds(0.5);
            onLoadAnim = new DoubleAnimation() {
                To = 1,
                Duration = TimeSpan.FromSeconds(1),
                EasingFunction = ease
            };
            cashColorAnim = new ColorAnimation() {
                Duration = duration,
                EasingFunction = ease
            };
            circleColorAnim = new ColorAnimation() {
                Duration = duration,
                EasingFunction = ease
            };
            kindColorAnim = new ColorAnimation() {
                Duration = duration,
                EasingFunction = ease
            };
            thicknessAnim = new DoubleAnimation() {
                Duration = duration,
                EasingFunction = ease
            };
        }
        void animate() {
            cashLine.BeginAnimation(Line.StrokeThicknessProperty, thicknessAnim);
            kindLine.BeginAnimation(Line.StrokeThicknessProperty, thicknessAnim);
            cashBrush.BeginAnimation(SolidColorBrush.ColorProperty, cashColorAnim);
            kindBrush.BeginAnimation(SolidColorBrush.ColorProperty, kindColorAnim);
            circleBrush.BeginAnimation(SolidColorBrush.ColorProperty, circleColorAnim);
        }
        protected override Size MeasureOverride(Size availableSize) {
            available = availableSize;
            if (cashTotal > 0 || kindTotal > 0) {
                var newBound = upperBound / available.Height * radius + upperBound;
                cashLine.Y2 = cashTotal / newBound * available.Height;
                kindLine.Y1 = cashLine.Y2;
                kindLine.Y2 = cashLine.Y2 + kindTotal / newBound * available.Height;
                cashLine.X1 = cashLine.X2 = kindLine.X1 = kindLine.X2 = available.Width / 2;
                circleGeo.Center = new Point(cashLine.X1, kindLine.Y2);
                foreach (UIElement child in children) 
                    child.Measure(availableSize);
            }
            return availableSize;
        }
        protected override Size ArrangeOverride(Size finalSize) {
            if (cashTotal > 0 || kindTotal > 0) {
                foreach (UIElement child in children) 
                    child.Arrange(new Rect(child.DesiredSize));
            }
            return finalSize;
        }
        protected override void OnMouseEnter(MouseEventArgs e) {
            circleColorAnim.To = circleHighlight;
            cashColorAnim.To = cashHighlight;
            kindColorAnim.To = kindHilight;
            thicknessAnim.To = 3;
            animate();
            tip.IsOpen = true;
        }
        protected override void OnMouseLeave(MouseEventArgs e) {
            if (!isClicked) {
                circleColorAnim.To = circleNormal;
                cashColorAnim.To = cashNormal;
                kindColorAnim.To = kindNormal;
                thicknessAnim.To = 2;
                animate();
                tip.IsOpen = false;
            }
        }
        protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e) => isClicked = !isClicked;
        protected override Visual GetVisualChild(int index) => children[index];
        protected override int VisualChildrenCount => children.Count;
    }
}
