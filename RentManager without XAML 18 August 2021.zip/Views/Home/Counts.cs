﻿using RentManager.Abstracts;
using RentManager.CustomControls;
using RentManager.Helpers;
using RentManager.Models;
using RentManager.ViewModels.Home;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;

namespace RentManager.Views.Home
{
    class Counts : CardView
    {
        public override string Header => "Space, Lease & Tenants";
        PieChart pie;
        TriState state, selectionState;
        CommandButton refresh;
        CountsVM viewModel;

        public Counts() {
            viewModel = new CountsVM();
            DataContext = viewModel;
            initializeUI();
            bind();
        }

        void refreshCommand() {
            if (BusyWindow.IsOpened) return; 
            var position = PointToScreen(new Point(0, 0));
            var dpi = VisualTreeHelper.GetDpi(this);
            position.X /= dpi.DpiScaleX;
            position.Y /= dpi.DpiScaleY;
            position.X += Constants.CardMargin.Left;
            position.Y += Constants.CardMargin.Top;
            var width = ActualWidth - Constants.CardMargin.Left - Constants.CardMargin.Right;
            var height = ActualHeight - Constants.CardMargin.Top - Constants.CardMargin.Bottom;       
            BusyWindow.Activate(position.X, position.Y, width, height, "Reloading ...");
            viewModel.Refresh.Invoke();
            BusyWindow.Terminate();
        }

        void initializeUI() {
            state = new TriState();
            selectionState = new TriState() { 
                CheckedIcon = Icons.Space,
                UncheckedIcon = Icons.Lease,
                UndefinedIcon = Icons.Tenant,
                IsIconInfront = true
            };
            pie = new PieChart() { SelectedValuePath = nameof(PlotSummary.Id) };
            refresh = new CommandButton() {
                Command = refreshCommand,
                Icon = Icons.Refresh,
                ToolTip = "Reload",
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(0,-55,0,0)
            };
            Grid.SetColumn(refresh, 1);
            Grid.SetColumn(state, 1);
            Grid.SetRow(pie, 1);
            Grid.SetColumnSpan(pie, 2);
            var grid = new Grid() {
                RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(),
                },
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto },
                },
                Children = { selectionState, state, pie, refresh }
            };
            setContent(grid);
        }

        void bind() {
            pie.SetBinding(PieChart.ItemsSourceProperty, new Binding(nameof(viewModel.Summary)));
            pie.SetBinding(PieChart.SelectedValueProperty, new Binding(nameof(viewModel.Selected)));
            selectionState.SetBinding(TriState.StateProperty, new Binding(nameof(viewModel.SelectionState)));
            selectionState.SetBinding(TriState.TextProperty, new Binding(nameof(viewModel.SelectionStateText)));
            state.SetBinding(TriState.StateProperty, new Binding(nameof(viewModel.State)));
            state.SetBinding(TriState.TextProperty, new Binding(nameof(viewModel.StateText)));
        }
    }
}
