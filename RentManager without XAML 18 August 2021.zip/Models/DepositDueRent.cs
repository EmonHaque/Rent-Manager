﻿using RentManager.Enums;

namespace RentManager.Models
{
    class DepositDueRent
    {
        public DepositDueRentState State { get; set; }
        public int? PlotId { get; set; }
        public int? SpaceId { get; set; }
        public int? TenantId { get; set; }
        public int Amount { get; set; }
    }
}
