﻿using RentManager.Helpers;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace RentManager.CustomControls
{
    class BiState : Grid
    {
        Path icon;
        TextBlock block;
        SolidColorBrush brush;
        Color trueColor, falseColor, highlightColor, downColor, disabledColor;
        ColorAnimation anim;
        Geometry trueGeo, falseGeo;
        public string Text { get; set; }
        public string TrueIcon { get; set; }
        public string FalseIcon { get; set; }

        public BiState() {
            trueColor = Colors.Green;
            falseColor = Colors.Coral;
            highlightColor = Colors.CornflowerBlue;
            downColor = Colors.Red;
            disabledColor = Colors.LightGray;
            brush = new SolidColorBrush(falseColor);
            block = new TextBlock() { VerticalAlignment = VerticalAlignment.Center };
            icon = new Path() {
                Height = 16,
                Width = 16,
                Stretch = Stretch.Uniform,
                Fill = brush,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(5,0,0,0)
            };
            SetColumn(icon, 1);
            Background = Brushes.Transparent;
            ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
            ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
            Children.Add(block);
            Children.Add(icon);
            anim = new ColorAnimation() {
                Duration = TimeSpan.FromMilliseconds(250),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
            IsEnabledChanged += onEnabledChanged;
            Loaded += onLoaded;
            Unloaded += onUnloaded;
        }

        void onUnloaded(object sender, RoutedEventArgs e) {
            IsEnabledChanged -= onEnabledChanged;
            Loaded -= onLoaded;
            Unloaded -= onUnloaded;
        }
        void onLoaded(object sender, RoutedEventArgs e) {
            if (TrueIcon == null) TrueIcon = Icons.Checked;
            if (FalseIcon == null) FalseIcon = Icons.CloseCircle;
            if(Text != null) block.Text = Text;
            trueGeo = Geometry.Parse(TrueIcon);
            falseGeo = Geometry.Parse(FalseIcon);
            if (IsTrue) {
                icon.Data = trueGeo;
                animateBrush(trueColor);
            }
            else {
                icon.Data = falseGeo;
                animateBrush(falseColor);
            }
        }
        void animateBrush(Color c) {
            anim.To = c;
            brush.BeginAnimation(SolidColorBrush.ColorProperty, anim);
        }
        void onEnabledChanged(object sender, DependencyPropertyChangedEventArgs e) {
            if (IsEnabled) animateBrush(IsTrue ? trueColor : falseColor);
            else animateBrush(disabledColor);
        }
        protected override void OnMouseEnter(MouseEventArgs e) => animateBrush(highlightColor);       
        protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e) => IsTrue = !IsTrue;
        protected override void OnMouseDown(MouseButtonEventArgs e) => animateBrush(downColor);
        protected override void OnMouseLeave(MouseEventArgs e) {
            if (IsEnabled) animateBrush(IsTrue ? trueColor : falseColor);
        }

        public bool IsTrue {
            get { return (bool)GetValue(IsTrueProperty); }
            set { SetValue(IsTrueProperty, value); }
        }
        public static readonly DependencyProperty IsTrueProperty =
            DependencyProperty.Register("IsTrue", typeof(bool), typeof(BiState), new FrameworkPropertyMetadata() { 
                DefaultValue = false,
                BindsTwoWayByDefault = true,
                PropertyChangedCallback = (s,e) => {
                    var o = (BiState)s;
                    if ((bool)e.NewValue) {
                        o.icon.Data = o.trueGeo;
                        o.animateBrush(o.trueColor);
                    }
                    else {
                        o.icon.Data = o.falseGeo;
                        o.animateBrush(o.falseColor);
                    }
                }
            });
    }
}
