﻿using RentManager.CustomControls;
using RentManager.DataTemplates;
using RentManager.Helpers;
using RentManager.ViewModels.Report;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace RentManager.ControlTemplates
{
    class GroupedRPTemplate : ControlTemplate
    {
        RPSummaryTemplate groupSummary = new();
        public GroupedRPTemplate(string queryProperty, object viewModel, double margin = 5) {
            TargetType = typeof(GroupItem);
            var grid = new FrameworkElementFactory(typeof(Grid));
            var row1 = new FrameworkElementFactory(typeof(RowDefinition));
            var row2 = new FrameworkElementFactory(typeof(RowDefinition));
            var row3 = new FrameworkElementFactory(typeof(RowDefinition));
            var header = new FrameworkElementFactory(typeof(HiBlock)) { Name = "header"};
            var items = new FrameworkElementFactory(typeof(ItemsPresenter)) { Name = "presenter" };
            var footer = new FrameworkElementFactory(typeof(ContentControl)) { Name = "footer" };

            row1.SetValue(RowDefinition.HeightProperty, GridLength.Auto);
            row3.SetValue(RowDefinition.HeightProperty, GridLength.Auto);
            items.SetValue(Grid.RowProperty, 1);
            items.SetValue(ItemsPresenter.MarginProperty, new Thickness(10, 0, 0, 0));
            header.SetValue(HiBlock.FontWeightProperty, FontWeights.Bold);
            footer.SetValue(Grid.RowProperty, 2);
            footer.SetValue(ContentControl.ContentTemplateProperty, groupSummary);
            footer.SetValue(ContentControl.MarginProperty, new Thickness(0, 0, margin, 0));

            header.SetBinding(HiBlock.TextProperty, new Binding(nameof(GroupItem.Name)));
            header.SetBinding(HiBlock.QueryProperty, new Binding(queryProperty) { Source = viewModel, IsAsync = true });

            IValueConverter converter = viewModel is ReportBalanceVM ? Converters.balanceGroup2Summary : Converters.rpGroup2Summary;
            footer.SetBinding(ContentControl.ContentProperty, new Binding() { Converter = converter });

            grid.AppendChild(row1);
            grid.AppendChild(row2);
            grid.AppendChild(row3);
            grid.AppendChild(header);
            grid.AppendChild(items);
            grid.AppendChild(footer);
            Triggers.Add(new MultiDataTrigger() {
                Conditions = {
                    new Condition(new Binding(nameof(CollectionViewGroup.IsBottomLevel)), true),
                    new Condition(new Binding(nameof(CollectionViewGroup.ItemCount)), 1),
                },
                Setters = { 
                    new Setter(TextBlock.VisibilityProperty, Visibility.Collapsed, "header"),
                    new Setter(ItemsPresenter.MarginProperty, new Thickness(-5,0,0,0), "presenter"),
                    new Setter(ContentControl.VisibilityProperty, Visibility.Collapsed, "footer")
                }
            });      
            VisualTree = grid;
        }
    }
}
