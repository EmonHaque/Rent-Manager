﻿using System.Windows.Controls;

namespace Rent.View.Ledger
{
    /// <summary>
    /// Interaction logic for SpaceLedger.xaml
    /// </summary>
    public partial class SpaceLedger : UserControl
    {
        public SpaceLedger()
        {
            InitializeComponent();
        }
    }
}
