﻿using System.Windows.Controls;

namespace Rent.View
{
    /// <summary>
    /// Interaction logic for LedgerView.xaml
    /// </summary>
    public partial class LedgerView : UserControl
    {
        public LedgerView()
        {
            InitializeComponent();
        }
    }
}
