﻿using Microsoft.Win32;
using Rent.Common;
using Rent.CustomControls;
using Rent.Model;
using Rent.View.Ledger;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;

namespace Rent.VM
{
    public class LedgerVM : INotifyPropertyChanged
    {
        public static object _lock = new object();
        Tab selectedTab;
        ReportDates dates;
        string heading;
        int totalReceivable, totalReceipt, controlIdOfPayment;
        List<Reportable> reportables, reserved;

        #region for Report
        static ViewType reportType;
        static ReportDates staticDates;
        static string title, description, period;
        static double columnWidth;
        FlowDocument document;

        public static string Title { get => title; set { title = value; OnStaticPropertyChanged(); } }
        public static string Description { get => description; set { description = value; OnStaticPropertyChanged(); } }
        public static string Period { get => period; set { period = value; OnStaticPropertyChanged(); } }
        public static double ColumnWidth { get => columnWidth; set { columnWidth = value; OnStaticPropertyChanged(); } }
        #endregion

        public List<Tab> Tabs { get; set; }
        public List<Reportable> Reportables { get => reportables; set { reportables = value; OnPropertyChanged(); } }
        public int TotalReceipt { get => totalReceipt; set { totalReceipt = value; OnPropertyChanged(); } }
        public int TotalReceivable { get => totalReceivable; set { totalReceivable = value; OnPropertyChanged(); } }
        public string Heading { get => heading; set { heading = value; OnPropertyChanged(); } }
        public Tab SelectedTab
        {
            get => selectedTab;
            set
            {
                selectedTab = value;
                reportType = value.Type;
                OnPropertyChanged();
                if (value != null) read(null);
            }
        }
        public ReportDates Dates { get => dates; set { dates = value; OnPropertyChanged(); } }

        public Command Generate { get; set; }
        public Command ExportCSV { get; set; }
        public Command PrintReport { get; set; }
        public Command PrintInvoice { get; set; }

        public LedgerVM()
        {
            ColumnWidth = 80.0;
            MainVM.DataLoaded += initializeAndSubscribe;
            Dates = new ReportDates();
            initializeCommands();
            initializeTabs();
        }

        void initializeAndSubscribe()
        {
            controlIdOfPayment = MainVM.ControlHeads.First(x => x.Name == "Payment").Id;
            SelectedTab = Tabs.First();
            MainVM.OnSelectedIconChanged += read;
            MainVM.OnSelectedPlotChanged += readPlotData;
            MainVM.OnSelectedSpaceChanged += readSpaceData;
            MainVM.OnSelectedTenantChanged += readTenantData;
        }

        void initializeCommands()
        {
            Generate = new Command(generate, isGenerationValid);
            ExportCSV = new Command(exportCSV, isPrintOrExportValid);
            PrintReport = new Command(printReport, isPrintOrExportValid);
            PrintInvoice = new Command(printInvoice, isPrintInvoiceValid);
        }

        void exportCSV(object o)
        {
            var dialog = new SaveFileDialog()
            {
                FileName = "Report",
                Filter = "CSV files (.csv)|*.csv"
            };

            if (dialog.ShowDialog() == true)
            {
                var builder = new StringBuilder();
                builder.Append("Date, Particulars, Receivable/Payment, Receipt, Balance").AppendLine();

                foreach (var item in Reportables)
                {
                    string particulars = string.Empty;
                    switch (SelectedTab.Type)
                    {
                        case ViewType.Plot: particulars = $"{item.SpaceName} : {item.TenantName} -> {item.HeadName} | {item.Narration}"; break;
                        case ViewType.Space: particulars = $"{item.PlotName} : {item.TenantName} -> {item.HeadName} | {item.Narration}"; break;
                        case ViewType.Tenant: particulars = $"{item.PlotName} : {item.SpaceName} -> {item.HeadName} | {item.Narration}"; break;
                    }
                    builder.Append(item.Date.ToShortDateString()).Append(",")
                        .Append("\"").Append(particulars).Append("\"").Append(",")
                        .Append(item.Receivable).Append(",")
                        .Append(item.Receipt).Append(",")
                        .Append(item.Balance).AppendLine();
                }
                File.WriteAllText(System.IO.Path.GetFullPath(dialog.FileName), builder.ToString());
            }
        }

        void printReport(object o)
        {
            staticDates = new ReportDates()
            {
                From = Dates.From,
                To = Dates.To
            };

            var dialog = new PrintDialog()
            {
                CurrentPageEnabled = true,
                UserPageRangeEnabled = true
            };

            if (dialog.ShowDialog() == true)
            {
                var width = dialog.PrintableAreaWidth;
                var height = dialog.PrintableAreaHeight;
                FlowPaginator.PageWodth = width;
                FlowPaginator.PageHeight = height;
                CreateReport(new Size(width, height));
                dialog.PrintDocument(new FlowPaginator(document) { PageSize = new Size(width, height) }, string.Empty);
            }
        }

        void CreateReport(Size pageSize)
        {
            document = new FlowDocument()
            {
                PageWidth = pageSize.Width,
                PageHeight = pageSize.Height,
                PagePadding = new Thickness(FlowPaginator.Margin,
                                            Header(pageSize).DesiredSize.Height,
                                            FlowPaginator.Margin,
                                            FlowPaginator.Margin)
            };

            var table = new Table()
            {
                FontFamily = SystemFonts.MessageFontFamily,
                FontStyle = SystemFonts.MessageFontStyle,
                FontSize = 11.0,
                CellSpacing = 0,
                Columns =
                {
                    new TableColumn(){ Width = new GridLength(ColumnWidth) },
                    new TableColumn(){ Width = new GridLength(pageSize.Width - (2.0 * FlowPaginator.Margin) - (4 * ColumnWidth)) },
                    new TableColumn(){ Width = new GridLength(ColumnWidth) },
                    new TableColumn(){ Width = new GridLength(ColumnWidth) },
                    new TableColumn(){ Width = new GridLength(ColumnWidth) },
                }
            };

            var rowNum = 1;

            foreach (var item in Reportables)
            {
                var rowGroup = new TableRowGroup();
                var row = new TableRow();

                string particulars = string.Empty;
                switch (SelectedTab.Type)
                {
                    case ViewType.Plot: particulars = $"{item.SpaceName} : {item.TenantName} -> {item.HeadName} | {item.Narration}"; break;
                    case ViewType.Space: particulars = $"{item.PlotName} : {item.TenantName} -> {item.HeadName} | {item.Narration}"; break;
                    case ViewType.Tenant: particulars = $"{item.PlotName} : {item.SpaceName} -> {item.HeadName} | {item.Narration}"; break;
                }

                row.Cells.Add(new TableCell(new Paragraph(new Run(item.Date.ToString("dd/MM/yyyy")))));
                row.Cells.Add(new TableCell(new Paragraph(new Run(particulars))));
                row.Cells.Add(new TableCell(new Paragraph(new Run(item.Receivable.ToString("#,##0;(#,##0);-    ")))) { TextAlignment = TextAlignment.Right });
                row.Cells.Add(new TableCell(new Paragraph(new Run(item.Receipt.ToString("#,##0;(#,##0);-    ")))) { TextAlignment = TextAlignment.Right });
                row.Cells.Add(new TableCell(new Paragraph(new Run(item.Balance.ToString("#,##0;(#,##0);-    ")))) { TextAlignment = TextAlignment.Right });

                if (rowNum % 2 == 0) row.Background = Brushes.LightBlue;

                rowGroup.Rows.Add(row);
                table.RowGroups.Add(rowGroup);
                rowNum++;
            }

            document.Blocks.Add(table);
        }

        public static UIElement Header(Size pageSize)
        {
            switch (reportType)
            {
                case ViewType.Plot:
                    Title = MainVM.SelectedPlot.Name;
                    Description = MainVM.SelectedPlot.Description;
                    break;
                case ViewType.Space:
                    Title = $"{MainVM.SelectedSpace.Name} of {MainVM.SelectedPlot.Name}";
                    Description = MainVM.SelectedSpace.Description;
                    break;
                case ViewType.Tenant:
                    Title = MainVM.SelectedTenant.Name;
                    Description = MainVM.SelectedTenant.Address;
                    break;
            }
            Period = $"for the period from {staticDates.From.ToString("dd MMM yyyy")} to {staticDates.To.ToString("dd MMM yyyy")}";
            var header = new Grid()
            {
                Width = pageSize.Width - 2.0 * FlowPaginator.Margin,
                Margin = new Thickness(FlowPaginator.Margin, FlowPaginator.Margin, 0, 0)
            };

            var rh = new ReportHeader();
            rh.UpdateLayout();

            header.Children.Add(rh);
            header.Measure(pageSize);
            header.Arrange(new Rect(header.DesiredSize));
            return header;
        }

        void printInvoice(object o)
        {
            var dialog = new PrintDialog();
            if (dialog.ShowDialog() == true)
            {
                var pageSize = new Size(dialog.PrintableAreaWidth, dialog.PrintableAreaHeight);
                switch (SelectedTab.Type)
                {
                    case ViewType.Plot:
                        IDocumentPaginatorSource source = PlotWiseInvoice(pageSize);
                        dialog.PrintDocument(source.DocumentPaginator, string.Empty);
                        break;
                    case ViewType.Tenant:
                        dialog.PrintVisual(TenantWiseInvoice(pageSize), string.Empty);
                        break;
                }
            }

        }

        bool isPrintInvoiceValid(object o)
        {
            return !MainVM.TenantBusy && !MainVM.PlotBusy &&
                reserved != null &&
                reserved.Where(x => x.Date == Dates.From)
                        .Select(x => x.ControlId)
                        .Contains(MainVM.ControlIdOfReceivable);

        }

        UIElement TenantWiseInvoice(Size pageSize)
        {
            var data = invoiceData(reserved.Where(x => x.Date <= Dates.To));
            var invoice = new Invoice()
            {
                Title = MainVM.SelectedTenant.Name,
                Address = MainVM.SelectedTenant.Address,
                ContactNo = MainVM.SelectedTenant.ContactNo,
                Reportables = data,
                Period = data.Last().Narration
            };
            var grid = new Grid()
            {
                Width = pageSize.Width,
                Height = pageSize.Height,
                Children =
                {
                    new InvoiceControl()
                    {
                        Margin = new Thickness(96),
                        TenantInvoice = invoice
                    }
                }
            };

            grid.Measure(pageSize);
            grid.Arrange(new Rect(grid.DesiredSize));
            return grid;
        }

        List<Reportable> invoiceData(IEnumerable<Reportable> list)
        {
            var previousData = list.Where(x => x.Date < Dates.From).ToList();
            var dataOnCutOffDate = list.Where(x => x.Date == Dates.From).ToList();
            var balance = -1 * dataOnCutOffDate.Sum(x => x.Receipt);
            foreach (var item in previousData)
            {
                balance = balance - item.Receipt + item.Receivable;
            }
            if(previousData.Count > 0)
            {
                var securityDeposits = previousData.Where(x => x.HeadName == "Security Deposit").ToList();
                if(securityDeposits.Count> 0)
                {
                    var receipt = securityDeposits.Sum(x => x.Receipt);
                    var payment = securityDeposits.Sum(x => x.Receivable);
                    balance = (balance - receipt + payment);
                }
            }
            var reportables = new List<Reportable>();
            if(balance != 0)
            {
                reportables.Add(new Reportable()
                {
                    Receivable = balance,
                    HeadName = "balance",
                    Date = Dates.From
                });
            }
            reportables.InsertRange(reportables.Count, dataOnCutOffDate.Where(x => x.ControlId == MainVM.ControlIdOfReceivable));
            return reportables;
        }

        FixedDocument PlotWiseInvoice(Size pageSize)
        {
            var document = new FixedDocument();
            var idList = Reportables.GroupBy(x => x.TenantId, x => x, (key, group) => new { Id = key, List = group.ToList() });

            foreach (var key in idList)
            {
                if(key.Id != 0)
                {
                    var tenant = MainVM.Tenants.First(x => x.Id == key.Id);
                    var data = invoiceData(reserved.Where(x => x.TenantId == key.Id && x.Date <= Dates.To));
                    var invoice = new Invoice()
                    {
                        Title = tenant.Name,
                        Address = tenant.Address,
                        ContactNo = tenant.ContactNo,
                        Reportables = data,
                        Period = data.Last().Narration
                    };
                    var grid = new Grid()
                    {
                        Width = pageSize.Width - 2 * 96,
                        Height = pageSize.Height - 2 * 96,
                        Children =
                        {
                            new InvoiceControl()
                            {
                                FontFamily = SystemFonts.MenuFontFamily,
                                TenantInvoice = invoice
                            }
                        }
                    };
                    grid.Measure(pageSize);
                    grid.Arrange(new Rect(grid.DesiredSize));
                    var page = new FixedPage()
                    {
                        Height = pageSize.Height,
                        Width = pageSize.Width,
                        Margin = new Thickness(96),
                        Children = { grid }
                    };
                    document.Pages.Add(new PageContent() { Child = page });
                }
            }
            return document;
        }

        bool isPrintOrExportValid(object o)
        {
            return !MainVM.TenantBusy && !MainVM.PlotBusy &&
                Reportables != null &&
                Reportables.Count > 0;
        }

        void initializeTabs()
        {
            Tabs = new List<Tab>()
            {
                new Tab("Plot", ViewType.Plot, new PlotLedger() { DataContext = this }, Constants.PlotIcon),
                new Tab("Space", ViewType.Space, new SpaceLedger() { DataContext = this }, Constants.SpaceIcon),
                new Tab("Tenant", ViewType.Tenant, new TenantLedger() { DataContext = this }, Constants.TenantIcon),
            };
        }

        void read(Icon icon)
        {
            if (MainVM.SelectedIcon.Name == Constants.Ledger)
            {
                switch (SelectedTab.Type)
                {
                    case ViewType.Plot:
                        if (MainVM.SelectedPlot != null)
                            readPlotData(MainVM.SelectedPlot.Id);
                        break;
                    case ViewType.Space:
                        if (MainVM.SelectedSpace != null)
                            readSpaceData(MainVM.SelectedSpace.Id);
                        break;
                    case ViewType.Tenant:
                        if (MainVM.SelectedTenant != null)
                            readTenantData(MainVM.SelectedTenant.Id);
                        break;
                }
            }
        }

        bool isBusy()
        {
            return SelectedTab.Type switch
            {
                ViewType.Plot => MainVM.PlotBusy,
                ViewType.Space => MainVM.SpaceBusy,
                ViewType.Tenant => MainVM.TenantBusy
            };
        }

        void generate(object o)
        {
            MainVM.DoAsynchronously(SelectedTab.Type, () =>
            {
                if (Dates.From < Dates.To)
                {
                    var lastEntry = reserved.LastOrDefault(x => x.Date < Dates.From);
                    var newList = new List<Reportable>();
                    if (lastEntry != null)
                    {
                        newList.Add(new Reportable()
                        {
                            Date = Dates.From,
                            Balance = lastEntry.Balance,
                            Narration = "balance b/d"
                        });
                    }
                    var entries = reserved.Where(x => x.Date >= Dates.From && x.Date <= Dates.To).ToList();
                    var receivable = entries.Sum(x => x.Receivable);
                    var receipt = entries.Sum(x => x.Receipt);
                    newList.AddRange(entries);

                    Reportables = newList;
                    TotalReceivable = receivable;
                    TotalReceipt = receipt;
                }
            });
        }

        bool isGenerationValid(object o)
        {
            return !isBusy() && 
                Reportables != null &&
                Reportables.Count > 0 &&
                Dates.From < Dates.To &&
                Dates.To > Reportables.First().Date;
        }

        void readPlotData(int plotId)
        {
            if (MainVM.SelectedIcon.Name == Constants.Ledger && SelectedTab.Type == ViewType.Plot)
                MainVM.DoAsynchronously(ViewType.Plot, () => setReportables("PlotId", plotId));
        }

        void readSpaceData(int spaceId)
        {
            if (MainVM.SelectedIcon.Name == Constants.Ledger && SelectedTab.Type == ViewType.Space)
                MainVM.DoAsynchronously(ViewType.Space, () => setReportables("SpaceId", spaceId));
        }

        void readTenantData(int tenantId)
        {
            if (MainVM.SelectedIcon.Name == Constants.Ledger && SelectedTab.Type == ViewType.Tenant)
                MainVM.DoAsynchronously(ViewType.Tenant, () => setReportables("TenantId", tenantId));
        }

        void setReportables(string where, int id)
        {
            lock (_lock)
            {
                var entries = new List<Reportable>();
                int balance, receivable, receipt;
                balance = receivable = receipt = 0;

                using var cmd = SQLHelper.connection.CreateCommand();
                cmd.CommandText = $@"SELECT tn.Date, p.Name, s.Name, t.Name, h.Name, tn.Narration, tn.ControlId, tn.TenantId, tn.Amount FROM Transactions tn
                                 LEFT JOIN Plots p ON p.Id = tn.PlotId
                                 LEFT JOIN Spaces s ON s.Id = tn.SpaceId
                                 LEFT JOIN Tenants t ON t.Id = tn.TenantId
                                 LEFT JOIN Heads h ON h.Id = tn.HeadId
                                 WHERE tn.{where} = {id} ORDER by tn.Date";

                SQLHelper.connection.Open();
                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    var entry = new Reportable()
                    {
                        Date = reader.GetDateTime(0),
                        PlotName = reader.GetString(1),
                        SpaceName = reader.GetString(2),
                        TenantName = reader.GetString(3),
                        HeadName = reader.GetString(4),
                        Narration = reader.IsDBNull(5) ? string.Empty : reader.GetString(5),
                        ControlId = reader.GetInt32(6),
                        TenantId = reader.GetInt32(7)
                    };
                    var amount = reader.GetInt32(8);

                    if (entry.ControlId == MainVM.ControlIdOfReceivable || entry.ControlId == controlIdOfPayment)
                    {
                        receivable += amount;
                        balance -= amount;
                        entry.Receivable = amount;
                    }
                    else
                    {
                        receipt += amount;
                        balance += amount;
                        entry.Receipt = amount;
                    }
                    entry.Balance = balance;
                    entries.Add(entry);
                }
                SQLHelper.connection.Close();

                reserved = entries;
                Reportables = entries;
                TotalReceipt = receipt;
                TotalReceivable = receivable;

                if (entries.Count > 0)
                {
                    Dates.Start = Reportables.First().Date;
                    Dates.End = Reportables.Last().Date;
                    Dates.From = Reportables.First().Date;
                    Dates.To = Reportables.Last().Date;
                    Heading = $"available from {Dates.From.ToString("dd MMMM, yyyy")} to {Dates.To.ToString("dd MMMM, yyyy")}";
                }
                else
                {
                    Dates.Start = Dates.End = Dates.From = Dates.To = DateTime.Today;
                    Heading = string.Empty;
                }
            }
            
        }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        public static event PropertyChangedEventHandler StaticPropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        static void OnStaticPropertyChanged([CallerMemberName] string name = "") => StaticPropertyChanged?.Invoke(null, new PropertyChangedEventArgs(name));
        #endregion
    }

}
