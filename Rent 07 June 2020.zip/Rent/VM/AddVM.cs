﻿using Microsoft.Data.Sqlite;
using Rent.Common;
using Rent.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace Rent.VM
{
    public class AddVM : INotifyPropertyChanged
    {
        Plot newPlot;
        Space newSpace, selectedVacantSpace;
        Tenant newTeanant, selectedAvailableTenant;
        Lease newLease;
        Head newHead;
        Receivable newReceivable;
        OCollection<Space> vacantSpaces;
        OCollection<Tenant> availableTenants;

        public Plot NewPlot { get => newPlot; set { newPlot = value; OnPropertyChanged(); } }
        public Space NewSpace { get => newSpace; set { newSpace = value; OnPropertyChanged(); } }
        public Space SelectedVacantSpace
        {
            get => selectedVacantSpace;
            set
            {
                selectedVacantSpace = value;
                OnPropertyChanged();
                if (value != null)
                {
                    NewLease.PlotId = value.PlotId;
                    NewLease.SpaceId = value.Id;
                }
            }
        }
        public Tenant NewTeanant { get => newTeanant; set { newTeanant = value; OnPropertyChanged(); } }
        public Tenant SelectedAvailableTenant
        {
            get => selectedAvailableTenant;
            set
            {
                selectedAvailableTenant = value;
                OnPropertyChanged();
                if (value != null) NewLease.TenantId = value.Id;
            }
        }
        public Lease NewLease { get => newLease; set { newLease = value; OnPropertyChanged(); } }
        public Head NewHead { get => newHead; set { newHead = value; OnPropertyChanged(); } }
        public Receivable NewReceivable { get => newReceivable; set { newReceivable = value; OnPropertyChanged(); } }

        public OCollection<Space> VacantSpaces { get => vacantSpaces; set { vacantSpaces = value; OnPropertyChanged(); } }
        public OCollection<Tenant> AvailableTenants { get => availableTenants; set { availableTenants = value; OnPropertyChanged(); } }

        public Command AddPlot { get; set; }
        public Command AddSpace { get; set; }
        public Command AddTenant { get; set; }
        public Command AddLease { get; set; }
        public Command AddHead { get; set; }
        public Command AddReceivable { get; set; }
        public Command RemoveReceivable { get; set; }

        public static event Action<Space> OnSpaceAdded;
        public static event Action<Lease> OnLeaseAdded;

        public AddVM()
        {
            initializeProperties();
            initializeCommands();
            MainVM.DataLoaded += initializeVacantSpaces;
            MainVM.OnSelectedPlotChanged += setVacantSpaces;
            MainVM.OnSelectedControlHeadChanged += setControlId;
            MainVM.OnSelectedReceivableHeadChanged += headId => NewReceivable.HeadId = headId;

            EditVM.OnSpaceVacated += reorderVacanSpaces;
            EditVM.OnTenantLeft += removeFromAvailableTenants;
            EditVM.OnTenantReturn += addtoAvailableTenants;
            EditVM.OnVacantSpaceEdited += space =>
            {
                var old = VacantSpaces.First(x => x.Id == space.Id);
                VacantSpaces[VacantSpaces.IndexOf(old)] = space;
                SelectedVacantSpace = space;
            };
            EditVM.OnAvailableTenantEdited += tenant =>
            {
                var old = AvailableTenants.First(x => x.Id == tenant.Id);
                AvailableTenants[AvailableTenants.IndexOf(old)] = tenant;
                SelectedAvailableTenant = tenant;
            };
        }

        void addtoAvailableTenants(Tenant tenant)
        {
            AvailableTenants.Add(tenant);
            SelectedAvailableTenant = tenant;
        }

        void removeFromAvailableTenants(Tenant tenant)
        {
            AvailableTenants.Remove(tenant);
            SelectedAvailableTenant = AvailableTenants.FirstOrDefault();
        }

        void reorderVacanSpaces(Space space)
        {
            VacantSpaces.Add(space);
            App.Current.Dispatcher.Invoke(() => VacantSpaces = new OCollection<Space>(VacantSpaces.OrderBy(x => x.Id)));
            SelectedVacantSpace = space;
        }

        void initializeVacantSpaces()
        {
            if (MainVM.Plots.Count > 0)
                setVacantSpaces(MainVM.SelectedPlot.Id);
        }

        void initializeCommands()
        {
            AddPlot = new Command(addPlot, (o) => NewPlot.IsInsertValid());
            AddSpace = new Command(addSpace, (o) => NewSpace.IsInsertValid());
            AddTenant = new Command(addTenant, (o) => NewTeanant.IsValid());
            AddLease = new Command(addLease, (o) => NewLease.IsValid());
            AddHead = new Command(addHead, (o) => NewHead.IsInsertValid());
            AddReceivable = new Command(addReceivable, (o) => NewReceivable.IsValid());
            RemoveReceivable = new Command(removeReceivable, (o) => true);
        }

        void initializeProperties()
        {
            NewPlot = new Plot() { Id = getNewId(MainVM.Plots) };
            NewSpace = new Space()
            {
                Id = getNewId(MainVM.Spaces),
                PlotId = MainVM.SelectedPlot == null ? 0 : MainVM.SelectedPlot.Id,
                IsVacant = true
            };
            NewTeanant = new Tenant() { Id = getNewId(MainVM.Tenants) };
            NewLease = new Lease()
            {
                Id = ++MainVM.MaxLeaseId,
                PlotId = SelectedVacantSpace == null ? 0 : SelectedVacantSpace.PlotId,
                SpaceId = SelectedVacantSpace == null ? 0 : SelectedVacantSpace.Id,
                TenantId = SelectedAvailableTenant == null ? 0 : SelectedAvailableTenant.Id,
                Date = DateTime.Now
            };
            NewHead = new Head()
            {
                Id = getNewId(MainVM.Heads),
                ControlId = MainVM.SelectedControlHead.Id
            };
            NewReceivable = new Receivable()
            {
                HeadId = MainVM.SelectedReceivableHead == null ? 0 : MainVM.SelectedReceivableHead.Id,
                LeaseId = NewLease.Id
            };
            AvailableTenants = new OCollection<Tenant>(MainVM.Tenants.Where(x => !x.HasLeft));
            SelectedAvailableTenant = AvailableTenants.FirstOrDefault();
        }

        int getNewId<T>(OCollection<T> collection) =>
            collection.Count > 0 ?
                (int)collection.First().GetType().GetProperty("Id").GetValue(collection.Last()) + 1
                : 1;

        void setVacantSpaces(int plotId)
        {
            App.Current.Dispatcher.Invoke(() => VacantSpaces = new OCollection<Space>(MainVM.Spaces.Where(x => x.IsVacant && x.PlotId == plotId)));
            SelectedVacantSpace = VacantSpaces.FirstOrDefault();
            NewSpace.PlotId = NewLease.PlotId = plotId;
        }

        void setControlId(int controlId)
        {
            NewHead.ControlId = controlId;
        }

        void addPlot(object o)
        {
            MainVM.DoAsynchronously(ViewType.Plot, () =>
                {
                    using var cmd = SQLHelper.connection.CreateCommand();
                    cmd.CommandText = "INSERT INTO Plots (Name, Description) VALUES(@Name, @Description)";
                    cmd.Parameters.AddWithValue("@Name", NewPlot.Name);
                    cmd.Parameters.AddWithValue("@Description", NewPlot.Description);
                    SQLHelper.NonQuery(cmd);

                    MainVM.Plots.Add(NewPlot);
                    MainVM.SelectedPlot = NewPlot;

                    int newId = NewPlot.Id + 1;
                    NewPlot = new Plot() { Id = newId };

                });
        }

        void addSpace(object o)
        {
            MainVM.DoAsynchronously(ViewType.Space, () =>
            {
                using var cmd = SQLHelper.connection.CreateCommand();
                cmd.CommandText = "INSERT INTO Spaces (PlotId, Name, Description, IsVacant) VALUES(@PlotId, @Name, @Description, 1)";
                cmd.Parameters.AddWithValue("@PlotId", NewSpace.PlotId);
                cmd.Parameters.AddWithValue("@Name", NewSpace.Name);
                cmd.Parameters.AddWithValue("@Description", NewSpace.Description);
                SQLHelper.NonQuery(cmd);

                MainVM.Spaces.Add(NewSpace);
                VacantSpaces.Add(NewSpace);
                SelectedVacantSpace = NewSpace;
                OnSpaceAdded?.Invoke(NewSpace);
                MainVM.SelectedSpace = NewSpace;

                int newId = NewSpace.Id + 1;
                NewSpace = new Space() { Id = newId, PlotId = MainVM.SelectedPlot.Id, IsVacant = true };

            });
        }

        void addTenant(object o)
        {
            MainVM.DoAsynchronously(ViewType.Tenant, () =>
            {
                var mother = string.IsNullOrWhiteSpace(NewTeanant.Mother) ? (object)DBNull.Value : NewTeanant.Mother;
                var husband = string.IsNullOrWhiteSpace(NewTeanant.Husband) ? (object)DBNull.Value : NewTeanant.Husband;
                var nid = string.IsNullOrWhiteSpace(NewTeanant.NID) ? (object)DBNull.Value : NewTeanant.NID;

                using var cmd = SQLHelper.connection.CreateCommand();
                cmd.CommandText = @"INSERT INTO Tenants (Name, Father, Mother, Husband, Address, NID, ContactNo, HasLeft) 
                                VALUES(@Name, @Father, @Mother, @Husband, @Address, @NID, @ContactNo, 0)";
                cmd.Parameters.AddWithValue("@Name", NewTeanant.Name);
                cmd.Parameters.AddWithValue("@Father", NewTeanant.Father);
                cmd.Parameters.AddWithValue("@Mother", mother);
                cmd.Parameters.AddWithValue("@Husband", husband);
                cmd.Parameters.AddWithValue("@Address", NewTeanant.Address);
                cmd.Parameters.AddWithValue("@NID", nid);
                cmd.Parameters.AddWithValue("@ContactNo", NewTeanant.ContactNo);
                SQLHelper.NonQuery(cmd);

                MainVM.Tenants.Add(NewTeanant);
                AvailableTenants.Add(NewTeanant);
                MainVM.SelectedTenant = NewTeanant;
                SelectedAvailableTenant = NewTeanant;

                int newId = NewTeanant.Id + 1;
                NewTeanant = new Tenant() { Id = newId };
            });
        }

        void addHead(object o)
        {
            MainVM.DoAsynchronously(ViewType.Head, () =>
            {
                using var cmd = SQLHelper.connection.CreateCommand();
                cmd.CommandText = "INSERT INTO Heads (ControlId, Name, Description) VALUES(@ControlId, @Name, @Description)";
                cmd.Parameters.AddWithValue("@ControlId", NewHead.ControlId);
                cmd.Parameters.AddWithValue("@Name", NewHead.Name);
                cmd.Parameters.AddWithValue("@Description", NewHead.Description);
                SQLHelper.NonQuery(cmd);

                MainVM.Heads.Add(NewHead);
                if (NewHead.ControlId == MainVM.ControlHeads.First(x => x.Name == "Receivable").Id)
                {
                    MainVM.ReceivableHeads.Add(NewHead);
                    MainVM.SelectedReceivableHead = NewHead;
                }
                MainVM.FilteredHeads.Add(NewHead);
                MainVM.SelectedHead = NewHead;

                int newId = NewHead.Id + 1;
                NewHead = new Head() { Id = newId, ControlId = MainVM.SelectedControlHead.Id };

                MainVM.Message = MainVM.SelectedHead.Name + " added";
                MainVM.PopUp();
            });
        }

        void addLease(object o)
        {
            MainVM.DoAsynchronously(ViewType.Lease, () =>
            {
                var commands = new List<SqliteCommand>();
                var cmd = new SqliteCommand(@"INSERT INTO Leases(PlotId, SpaceId, TenantId, Date, Business, IsExpired)
                                         VALUES(@PlotId, @SpaceId, @TenantId, @Date, @Business, 0);
                                        UPDATE Spaces SET IsVacant = 0 WHERE Id = @Id;");
                cmd.Parameters.AddWithValue("@PlotId", NewLease.PlotId);
                cmd.Parameters.AddWithValue("@SpaceId", NewLease.SpaceId);
                cmd.Parameters.AddWithValue("@TenantId", NewLease.TenantId);
                cmd.Parameters.AddWithValue("@Date", NewLease.Date.ToString("yyyy-MM-dd"));
                cmd.Parameters.AddWithValue("@Business", NewLease.Business);
                cmd.Parameters.AddWithValue("@Id", NewLease.SpaceId);
                commands.Add(cmd);

                foreach (var item in NewLease.FixedReceivables)
                    commands.Add(new SqliteCommand($"INSERT INTO Receivables VALUES({NewLease.Id}, {item.HeadId}, {item.Amount})"));

                SQLHelper.Transaction(commands);

                MainVM.Leases.Add(NewLease);
                MainVM.SelectedLease = NewLease;

                var space = MainVM.Spaces.First(x => x.Id == NewLease.SpaceId);
                space.IsVacant = false;
                VacantSpaces.Remove(space);

                OnLeaseAdded?.Invoke(NewLease);

                var plotName = MainVM.Plots.First(x => x.Id == NewLease.PlotId).Name;
                var spaceName = MainVM.Spaces.First(x => x.Id == NewLease.SpaceId).Name;
                var tenantName = MainVM.Tenants.First(x => x.Id == NewLease.TenantId).Name;

                NewLease = new Lease()
                {
                    Id = ++MainVM.MaxLeaseId,
                    TenantId = SelectedAvailableTenant == null ? 0 : SelectedAvailableTenant.Id,
                    Date = DateTime.Now
                };
                NewReceivable.LeaseId = NewLease.Id;

                SelectedVacantSpace = VacantSpaces.FirstOrDefault();
                MainVM.SelectedSpace = SelectedVacantSpace;

                foreach (var command in commands) command.Dispose();

                MainVM.Message = $"{spaceName} of {plotName}\r\nhas been let out to {tenantName}";
                MainVM.PopUp();
            });
        }

        void addReceivable(object o)
        {
            NewLease.FixedReceivables.Add(NewReceivable);
            NewReceivable = new Receivable()
            {
                HeadId = MainVM.SelectedReceivableHead.Id,
                LeaseId = NewLease.Id
            };
        }

        void removeReceivable(object o)
        {
            NewLease.FixedReceivables.Remove(o as Receivable);
        }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

}
