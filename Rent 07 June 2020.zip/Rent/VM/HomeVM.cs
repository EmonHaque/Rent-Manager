﻿using Rent.Common;
using Rent.Model;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace Rent.VM
{
    public class HomeVM : INotifyPropertyChanged
    {

        OCollection<PlotSummary> summaryPlot;
        public OCollection<PlotSummary> SummaryPlot { get => summaryPlot; set { summaryPlot = value; OnPropertyChanged(); } }

        List<HeadSummary> summaryHead;
        public List<HeadSummary> SummaryHead { get => summaryHead; set { summaryHead = value; OnPropertyChanged(); } }

        List<TenantSummary> summaryTenant;
        public List<TenantSummary> SummaryTenant { get => summaryTenant; set { summaryTenant = value; OnPropertyChanged(); } }

        public HomeVM()
        {
            MainVM.OnSelectedIconChanged += UpdateSummary;
        }

        void UpdateSummary(Icon icon)
        {
            if (icon.Name == Constants.Home)
            {
                SummaryPlot = new OCollection<PlotSummary>();
                foreach (var plot in MainVM.Plots)
                {
                    var list = MainVM.Leases.Where(x => x.PlotId == plot.Id).ToList();
                    var receivables = list.Sum(x => x.FixedReceivables.Sum(x => x.Amount));
                    SummaryPlot.Add(new PlotSummary()
                    {
                        Name = plot.Name,
                        Spaces = MainVM.Spaces.Where(x => x.PlotId == plot.Id).ToList().Count,
                        Leases = list.Count,
                        ListLeases = list,
                        Receivables = receivables
                    });
                }

                SummaryHead = MainVM.Heads.GroupBy(x => x.ControlId, x => x, (key, list) => new HeadSummary()
                {
                    ControlName = MainVM.ControlHeads.First(x => x.Id == key).Name,
                    Heads = new List<string>(list.Select(x => x.Name))
                }).ToList();

                getTenantSummary();
            }
        }

        void getTenantSummary()
        {
            var cmd = SQLHelper.connection.CreateCommand();
            cmd.CommandText = @"SELECT p.Name, s.Name, t.Name, SUM(tn.Amount), tn.ControlId, tn.HeadId, tn.TenantId FROM Transactions tn
                                LEFT JOIN Plots p ON p.Id = tn.PlotId
                                LEFT JOIN Spaces s ON s.Id = tn.SpaceId
                                LEFT JOIN Tenants t ON t.Id = tn.TenantId
                                WHERE tn.TenantId IN (SELECT Id FROM Tenants WHERE HasLeft = 0)
                                GROUP BY p.Name, s.Name, t.Name, tn.HeadId
                                ORDER BY p.Name, s.Name";
            SQLHelper.connection.Open();
            var reader = cmd.ExecuteReader();
            var primary = new List<PrimarySummary>();
            while (reader.Read())
            {
                primary.Add(new PrimarySummary()
                {
                    Plot = reader.GetString(0),
                    Space = reader.GetString(1),
                    TenantName = reader.GetString(2),
                    Amount = reader.GetInt32(3),
                    ControlId = reader.GetInt32(4),
                    HeadId = reader.GetInt32(5),
                    TenantId = reader.GetInt32(6)
                });
            }
            SQLHelper.connection.Close();

            var plots = primary.GroupBy(x => x.Plot, x => x, (plot, plotData) => new
            {
                Name = plot,
                Info = plotData.GroupBy(x => x.Space, x => x, (space, spaceData) => new
                {
                    Name = space,
                    Data = spaceData
                })
            });

            var controlOfPayment = MainVM.ControlHeads.First(x => x.Name == "Payment").Id;
            var SDRId = MainVM.Heads.First(x => x.ControlId != controlOfPayment && x.Name == "Security Money").Id;
            var SDPId = MainVM.Heads.First(x => x.ControlId == controlOfPayment && x.Name == "Security Money").Id;
            var tenantSummary = new List<TenantSummary>();
            foreach (var plot in plots)
            {
                var secondary = new List<SecondarySummary>();
                foreach (var space in plot.Info)
                {
                    var tenant = space.Data.First();
                    var tenantName = tenant.TenantName;

                    var spaces = MainVM.Leases.Where(x => x.TenantId == tenant.TenantId)
                                              .Select(x => x.SpaceId)
                                              .Join(MainVM.Spaces, x => x, y => y.Id, (x, y) => y.Name)
                                              .ToList();

                    var receivables = space.Data.Where(x => x.ControlId == MainVM.ControlIdOfReceivable).ToList();
                    var remainings = space.Data.Except(receivables).ToList();
                    var receipts = remainings.Where(x => x.ControlId != controlOfPayment && x.HeadId != SDRId).ToList();
                    remainings = remainings.Except(receipts).ToList();
                    var adjustments = remainings.Where(x => x.ControlId == controlOfPayment && x.HeadId != SDPId).ToList();
                    remainings = remainings.Except(adjustments).ToList();
                    var SDRs = remainings.Where(x => x.ControlId != controlOfPayment).ToList();
                    var SDPs = remainings.Except(SDRs).ToList();

                    var ss = new SecondarySummary()
                    {
                        Space = space.Name,
                        Tenant = tenantName,
                        Receivables = receivables.Sum(x => x.Amount),
                        Receipts = receipts.Sum(x => x.Amount),
                        Adjustments = adjustments.Sum(x => x.Amount),
                        SecurityDeposit = SDRs.Sum(x => x.Amount) - SDPs.Sum(x => x.Amount),
                        IsExpired = !spaces.Contains(space.Name)
                    };
                    ss.Dues = ss.Receivables - ss.Receipts + ss.Adjustments;
                    secondary.Add(ss);
                }
                tenantSummary.Add(new TenantSummary()
                {
                    Plot = plot.Name,
                    Summary = secondary
                });
            }
            SummaryTenant = tenantSummary;
        }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

}
