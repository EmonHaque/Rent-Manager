﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Rent.Model
{

    public class ControlHead : INotifyPropertyChanged
	{

		int id;
		public int Id { get => id; set { id = value; OnPropertyChanged(); } }

		string name;
		public string Name { get => name; set { name = value; OnPropertyChanged(); } }

		#region Notify Property Changed Members
		public event PropertyChangedEventHandler PropertyChanged;
		void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
		#endregion
	}

}
