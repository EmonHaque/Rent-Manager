﻿using System.Collections.Generic;

namespace Rent.Model
{
    public class HeadSummary
    {
        public string ControlName { get; set; }
        public List<string> Heads { get; set; }
    }
}
