﻿using System.Windows;
using System.Windows.Controls;

namespace Rent.CustomControls
{
    public class ReportHeader : ContentControl
    {
        static ReportHeader()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(ReportHeader), new FrameworkPropertyMetadata(typeof(ReportHeader)));
        }
    }
}
