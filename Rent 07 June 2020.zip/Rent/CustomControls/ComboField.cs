﻿using System.Collections;
using System.Windows;
using System.Windows.Controls;

namespace Rent.CustomControls
{
    public class ComboField : Control
    {
        static ComboField()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(ComboField), new FrameworkPropertyMetadata(typeof(ComboField)));
        }

        public string Label
        {
            get { return (string)GetValue(LabelProperty); }
            set { SetValue(LabelProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Label.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty LabelProperty =
            DependencyProperty.Register("Label", typeof(string), typeof(ComboField), new PropertyMetadata(null));


        public DataTemplate UserTemplate
        {
            get { return (DataTemplate)GetValue(UserTemplateProperty); }
            set { SetValue(UserTemplateProperty, value); }
        }

        // Using a DependencyProperty as the backing store for UserTemplate.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty UserTemplateProperty =
            DependencyProperty.Register("UserTemplate", typeof(DataTemplate), typeof(ComboField), new PropertyMetadata(null));


        public string Display
        {
            get { return (string)GetValue(DisplayProperty); }
            set { SetValue(DisplayProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Display.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty DisplayProperty =
            DependencyProperty.Register("Display", typeof(string), typeof(ComboField), new PropertyMetadata(null));


        public object Selected
        {
            get { return (object)GetValue(SelectedProperty); }
            set { SetValue(SelectedProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Selected.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SelectedProperty =
            DependencyProperty.Register("Selected", typeof(object), typeof(ComboField), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));


        public IEnumerable Source
        {
            get { return (IEnumerable)GetValue(SourceProperty); }
            set { SetValue(SourceProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Source.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SourceProperty =
            DependencyProperty.Register("Source", typeof(IEnumerable), typeof(ComboField), new PropertyMetadata(null));

    }
}
