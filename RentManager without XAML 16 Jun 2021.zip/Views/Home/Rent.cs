﻿using RentManager.Abstracts;
using RentManager.CustomControls;
using RentManager.Helpers;
using RentManager.Models;
using RentManager.ViewModels.Home;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace RentManager.Views.Home
{
    class Rent : CardView
    {
        public override string Header => "Rent, Deposit & Dues";
        CommandButton refresh;
        PieChart pie;
        TriState state;
        RentVM viewModel;

        public Rent() {
            viewModel = new RentVM();
            DataContext = viewModel;
            initializeUI();
            bind();
        }
        void initializeUI() {
            refresh = new CommandButton() {
                Command = viewModel.Refresh,
                Icon = Icons.Refresh,
                ToolTip = "Reload",
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Top,
                Margin = new Thickness(0, -28, 0, 0)
            };
            state = new TriState() {
                HorizontalAlignment = HorizontalAlignment.Right,
                CheckedIcon = Icons.Rent,
                UncheckedIcon = Icons.Deposit,
                UndefinedIcon = Icons.Due
            };
            pie = new PieChart() { SelectedValuePath = nameof(PlotSummary.Id) };
            Grid.SetRow(pie, 1);
            var grid = new Grid() {
                RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition()
                },
                Children = { refresh, state, pie }
            };
            setContent(grid);
        }
        void bind() {
            pie.SetBinding(PieChart.ItemsSourceProperty, new Binding(nameof(viewModel.Summary)));
            pie.SetBinding(PieChart.SelectedValueProperty, new Binding(nameof(viewModel.Selected)));
            state.SetBinding(TriState.StateProperty, new Binding(nameof(viewModel.State)));
            state.SetBinding(TriState.TextProperty, new Binding(nameof(viewModel.StateText)));
        }
    }
}
