﻿using RentManager.Abstracts;
using RentManager.CustomControls;
using RentManager.Helpers;
using RentManager.ViewModels.Home;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace RentManager.Views.Home
{
    class PlotRent : CardView
    {
        public override string Header => "Charge & Collections";

        MultiLineChart chart;
        CommandButton refresh;
        BiState state;
        PlotRentVM viewModel;
        public PlotRent() {
            viewModel = new PlotRentVM();
            DataContext = viewModel;
            initializeUI();
            bind();
        }
        void initializeUI() {
            chart = new MultiLineChart();
            refresh = new CommandButton() {
                Command = viewModel.Refresh,
                Icon = Icons.Refresh,
                ToolTip = "Reload",
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Top,
                Margin = new Thickness(0, -28, 0, 0)
            };
            state = new BiState() {
                IsTrue = true,
                Text = "All",
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Top,
                Margin = new Thickness(0, -27, 26, 0)
            };
            var grid = new Grid() {
                Children = { chart, state, refresh }
            };
            setContent(grid);
        }
        void bind() {
            chart.SetBinding(MultiLineChart.ItemsSourceProperty, new Binding(nameof(viewModel.Data)));
            state.SetBinding(BiState.IsTrueProperty, new Binding(nameof(viewModel.State)));
        }
    }
}
