﻿using RentManager.Abstracts;
using RentManager.CustomControls;
using RentManager.DataTemplates;
using RentManager.Enums;
using RentManager.Helpers;
using RentManager.Models;
using RentManager.ViewModel.Edit;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;

namespace RentManager.Views.Edit
{
    class EditHead : CardView
    {
        public override string Icon => Icons.Head;
        public override string Header => "Head";

        SelectItem nonEditableControlHeads;
        ListBox headList;
        ComboSelect controlHeads;
        ComboText name, description;
        ComboButton buttons;
        EditText search;
        CountBlock counter;
        EditHeadVM viewModel;

        public EditHead() : base() {
            viewModel = new EditHeadVM();
            DataContext = viewModel;
            initializeUI();
            bind();            
        }
        
        void initializeUI() {
            nonEditableControlHeads = new SelectItem() {
                Hint = "Control",
                IsRequired = true,
                Icon = Icons.ControlHead,
                SelectedValuePath = nameof(ControlHead.Id),
                DisplayPath = nameof(ControlHead.Name),
                FilterParameter = SelectQuery.NonEditable,
                FilterCommand = viewModel.FilterCommand
            };
            search = new EditText() {
                Icon = Icons.SearchHead,
                Hint = "Head",
                IsTrimBottomRequested = true
            };
            counter = new CountBlock() { VerticalAlignment = VerticalAlignment.Center };
            Grid.SetColumn(counter, 1);
            var searchGrid = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){Width = GridLength.Auto}
                },
                Children = { search, counter }
            };
            Grid.SetRow(searchGrid, 1);
            headList = new ListBox() {
                BorderBrush = Brushes.LightGray,
                BorderThickness = new Thickness(0, 0, 1, 0),
                ItemTemplate = new HiTemplate(nameof(Head.Name), nameof(viewModel.QueryHead), viewModel),
                ItemContainerStyle = App.editableItemContainerStyle
            };
            Grid.SetRow(headList, 2);

            controlHeads = new ComboSelect() {
                Hint = "Control",
                Icon = Icons.ControlHead,
                IsRequired = true,
                SelectedValuePath = nameof(ControlHead.Id),
                DisplayPath = nameof(ControlHead.Name),
                ItemsSource = nameof(viewModel.ControlHeads),
                Error = nameof(viewModel.ErrorControlId),
                Query = nameof(viewModel.ControlQuery),
                FilterParameter = SelectQuery.ControlHead,
                FilterCommand = viewModel.FilterCommand,
                SelectedValue = $"{nameof(viewModel.Edited)}.{nameof(Head.ControlId)}",
                NonEditable = new Binding($"{nameof(viewModel.Selected)}.{nameof(Head.ControlId)}") { Converter = App.convert.controlId2ControlName }
            };
            name = new ComboText() {
                Hint = "Name",
                Icon = Icons.Head,
                IsRequired = true,
                Editable = $"{nameof(viewModel.Edited)}.{nameof(Head.Name)}",
                NonEditable = $"{nameof(viewModel.Selected)}.{nameof(Head.Name)}",
                Error = nameof(viewModel.ErrorName)
            };
            description = new ComboText() {
                Hint = "Description",
                Icon = Icons.Description,
                IsRequired = true,
                IsMultiline = true,
                Editable = $"{nameof(viewModel.Edited)}.{nameof(Head.Description)}",
                NonEditable = $"{nameof(viewModel.Selected)}.{nameof(Head.Description)}",
                Error = nameof(viewModel.ErrorDescription)
            };
            buttons = new ComboButton() {
                EditCommand = viewModel.SetIsOnEdit,
                CancelCommand = viewModel.ResetIsOnEdit,
                SaveCommand = viewModel.Save,
                IsValid = nameof(viewModel.IsValid)
            };
            Grid.SetRow(name, 1);
            Grid.SetRow(description, 2);
            Grid.SetRow(buttons, 3);

            var editableGrid = new Grid() {
                Margin = new Thickness(10, 10, 0, 0),
                RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(),
                    new RowDefinition(){ Height = GridLength.Auto },
                },
                Children = { controlHeads, name, description, buttons }
            };
            Grid.SetRow(editableGrid, 2);
            Grid.SetColumn(editableGrid, 1);

            var grid = new Grid() {
                RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(),
                },
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(),
                },
                Children = { nonEditableControlHeads, searchGrid, headList, editableGrid }
            };
            setContent(grid);
        }

        void bind() {
            nonEditableControlHeads.SetBinding(SelectItem.SelectedvalueProperty, new Binding(nameof(viewModel.SelectedControl)));
            nonEditableControlHeads.SetBinding(SelectItem.ItemsSourceProperty, new Binding(nameof(viewModel.NonEditableControlHeads)));
            nonEditableControlHeads.SetBinding(SelectItem.QueryProperty, new Binding(nameof(viewModel.NonEditableControlQuery)) { Mode = BindingMode.OneWayToSource });
  
            headList.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(viewModel.Editables)));
            headList.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(viewModel.Selected)));

            var binding = new Binding(nameof(viewModel.IsOnEdit));
            controlHeads.SetBinding(ComboSelect.IsOnEditProperty, binding);
            name.SetBinding(ComboText.IsOnEditProperty, binding);
            description.SetBinding(ComboText.IsOnEditProperty, binding);
            buttons.SetBinding(ComboButton.IsOnEditProperty, binding);

            search.SetBinding(EditText.TextProperty, new Binding(nameof(viewModel.QueryHead)) { Mode = BindingMode.OneWayToSource });
            counter.SetBinding(CountBlock.CountProperty, new Binding("Items.Count") { Source = headList });
        }
    }
}
