﻿using System;
using System.Threading;
using System.Windows;
using System.Windows.Threading;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace RentManager.CustomControls
{
    class BusyWindow : Window
    {
        Path arc;
        PointAnimationUsingPath pointAnim;
        BooleanAnimationUsingKeyFrames isLargeAnim;
        TextBlock text;
        public string InfoText { get; set; }
        static BusyWindow window;

        BusyWindow(double left, double top, double width, double height, WindowState state) {
            Left = left;
            Top = top;
            Width = width;
            Height = height;
            WindowState = state;
            WindowStyle = WindowStyle.None;
            ResizeMode = ResizeMode.NoResize;
            AllowsTransparency = true;
            ShowInTaskbar = false;
            Topmost = true;
            Background = new SolidColorBrush(Color.FromArgb(100, 0, 0, 100));
            initializeContent();
            initializeAnimations();
            Loaded += animateArc;
            Unloaded += onUnloaded;
        }
        public static void Activate(string message) {
            double left = App.Current.MainWindow.Left;
            double top = App.Current.MainWindow.Top;
            double width = App.Current.MainWindow.Width;
            double height = App.Current.MainWindow.Height;
            var state = App.Current.MainWindow.WindowState;

            var thread = new Thread(() => {
                window = new BusyWindow(left, top, width, height, state) { InfoText = message };
                window.Show();
                Dispatcher.Run();
            });
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
        }
        public static void Terminate() {
            window.Dispatcher.Invoke(window.Close);
            window.Dispatcher.InvokeShutdown();
        }
        void onUnloaded(object sender, RoutedEventArgs e) {
            Loaded -= animateArc;
            Unloaded -= onUnloaded;
        }
        void initializeAnimations() {
            pointAnim = new PointAnimationUsingPath() {
                PathGeometry = PathGeometry.CreateFromGeometry(arc.Data),
                Duration = TimeSpan.FromSeconds(2),
                AccelerationRatio = 0.5,
                DecelerationRatio = 0.5,
                RepeatBehavior = RepeatBehavior.Forever
            };
            isLargeAnim = new BooleanAnimationUsingKeyFrames() {
                KeyFrames = {
                    new DiscreteBooleanKeyFrame(false, TimeSpan.FromSeconds(0)),
                    new DiscreteBooleanKeyFrame(true, TimeSpan.FromSeconds(1)),
                    new DiscreteBooleanKeyFrame(false, TimeSpan.FromSeconds(2))
                },
                RepeatBehavior = RepeatBehavior.Forever
            };
        }
        void animateArc(object sender, RoutedEventArgs e) {
            text.Text = InfoText;
            var segment = (ArcSegment)((PathGeometry)arc.Data).Figures[0].Segments[0];
            segment.BeginAnimation(ArcSegment.PointProperty, pointAnim);
            segment.BeginAnimation(ArcSegment.IsLargeArcProperty, isLargeAnim);
        }
        void initializeContent() {
            var ellipse = new Path() {
                Fill = Brushes.White,
                Data = new EllipseGeometry() {
                    Center = new Point(Width / 2, Height / 2),
                    RadiusX = 150, 
                    RadiusY = 150 
                }
            };
            arc = new Path() {
                Stroke = Brushes.Coral,
                StrokeThickness = 5,
                Data = new PathGeometry() {
                    Figures = {
                        new PathFigure() {
                            StartPoint = new Point(Width / 2 + 149, Height / 2),
                            Segments = {
                                new ArcSegment() {
                                    IsLargeArc = true,
                                    Point = new Point(Width / 2 + 149, Height / 2 - 0.1),
                                    Size = new Size(148,148),
                                    SweepDirection = SweepDirection.Clockwise
                                }
                            }
                        }
                    }
                }
            };
            text = new TextBlock() {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                FontSize = 36,
                Foreground = Brushes.Coral
            };
            Content = new Grid() { Children = { ellipse, text, arc } };
        }
    }
}
