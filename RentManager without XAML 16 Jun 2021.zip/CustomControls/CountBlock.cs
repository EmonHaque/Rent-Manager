﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;

namespace RentManager.CustomControls
{
    class CountBlock : FrameworkElement
    {
        TextBlock text;
        Border border;
        public CountBlock() {
            text = new TextBlock() {
                Foreground = Brushes.White,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };
            border = new Border() {
                CornerRadius = new CornerRadius(10),
                Background = Brushes.CornflowerBlue,
                Padding = new Thickness(5,2,5,2),
                Child = text
            };
            AddVisualChild(border);
            Loaded += onLoaded;
            Unloaded += onUnloaded;
        }

        void onUnloaded(object sender, RoutedEventArgs e) {
            Loaded -= onLoaded;
            Unloaded -= onUnloaded;
        }

        void onLoaded(object sender, RoutedEventArgs e) {
            text.SetBinding(TextBlock.TextProperty, new Binding(nameof(Count)) { Source = this });
        }
        protected override Size MeasureOverride(Size availableSize) {
            border.Measure(availableSize);
            return border.DesiredSize;
        }
        protected override Size ArrangeOverride(Size finalSize) {
            border.Arrange(new Rect(border.DesiredSize));
            return finalSize;
        }
        protected override Visual GetVisualChild(int index) => border;
        protected override int VisualChildrenCount => 1;

        public string Count {
            get { return (string)GetValue(CountProperty); }
            set { SetValue(CountProperty, value); }
        }
        public static readonly DependencyProperty CountProperty =
            DependencyProperty.Register("Count", typeof(string), typeof(CountBlock), new PropertyMetadata(null));
    }
}
