﻿using RentManager.DataTemplates;
using RentManager.Helpers;
using RentManager.Models;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;

namespace RentManager.CustomControls
{
    class LedgerPage
    {
        double margin, remainingHeight;
        StackPanel header;
        Grid content;
        Border footer, columnNames, pageTotal;
        TextBlock title, subTitle, period, totalReceivable, totalReceipt, footNoteBlock;
        ItemsControl entries;
        ContentControl heightControl;
        Run currentPage, totalPage;

        public FixedPage Page { get; set; }
        public Size PageSize { get; set; }
        public int PageNo { get; set; }
        public string Title { get; set; }
        public string SubTitle { get; set; }
        public string Period { get; set; }
        public int TotalReceivable { get; set; }
        public int TotalReceipt { get; set; }
        public ReportEntry LastEntry { get; set; }
        string footNote;
        public string FootNote {
            get { return footNote; }
            set { footNote = value; footNoteBlock.Text = value; measure(); }
        }
        bool isComplete;
        public bool IsComplete {
            get { return isComplete; }
            set { 
                isComplete = value;
                entries.UpdateLayout();
                addPageTotals(); 
            }
        }
        int numberOfPage;
        public int NumberOfPage {
            get { return numberOfPage; }
            set { numberOfPage = value; totalPage.Text = value.ToString(); }
        }

        public LedgerPage(Size pageSize) {
            margin = 96d * 0.7;
            initializeHeader();
            initializeContent();
            initializeFooter();
            PageSize = pageSize;
            PageNo = 1;
            Page = new FixedPage() {
                Width = PageSize.Width,
                Height = PageSize.Height,
                Margin = new Thickness(margin),
                Children = { header, content, footer }
            };
        }
        public LedgerPage(LedgerPage previousPage) : this(previousPage.PageSize) {
            Title = previousPage.Title;
            SubTitle = previousPage.SubTitle;
            Period = previousPage.Period;
            PageNo = previousPage.PageNo + 1;
            FootNote = previousPage.FootNote;
            AddEntry(new ReportEntry() {
                Date = previousPage.LastEntry.Date,
                Particulars = "balance b/d",
                Narration = string.Empty,
                Receivable = previousPage.TotalReceivable,
                Receipt = previousPage.TotalReceipt,
                Balance = previousPage.LastEntry.Balance
            });
        }
            
        void initializeHeader() {
            title = new TextBlock() { FontSize = 16, TextAlignment = TextAlignment.Center };
            subTitle = new TextBlock() { FontSize = 14, TextAlignment = TextAlignment.Center };
            period = new TextBlock() { FontSize = 12, TextAlignment = TextAlignment.Center };

            var colDate = new TextBlock() { Text = "Date", HorizontalAlignment = HorizontalAlignment.Left };
            var colParticulars = new TextBlock() { Text = "Particulars", HorizontalAlignment = HorizontalAlignment.Left };
            var colReceivable = new TextBlock() { Text = "Receivable", HorizontalAlignment = HorizontalAlignment.Right };
            var colReceipt = new TextBlock() { Text = "Receipt", HorizontalAlignment = HorizontalAlignment.Right };
            var colBalance = new TextBlock() { Text = "Balance", HorizontalAlignment = HorizontalAlignment.Right };
            Grid.SetColumn(colParticulars, 1);
            Grid.SetColumn(colReceivable, 2);
            Grid.SetColumn(colReceipt, 3);
            Grid.SetColumn(colBalance, 4);
            var columnGrid = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) }
                },
                Children = { colDate, colParticulars, colReceivable, colReceipt, colBalance }
            };
            columnNames = new Border() {
                BorderThickness = new Thickness(0, .5, 0, .5),
                BorderBrush = Brushes.Black,
                Child = columnGrid
            };
            header = new StackPanel() {
                Resources = {
                    {
                        typeof(TextBlock),
                        new Style() {
                            Setters = {
                                new Setter(TextBlock.FontWeightProperty, FontWeights.Bold)
                            }
                        }
                    }
                },
                Children = { title, subTitle, period, columnNames }
            };
        }
        void initializeContent() {
            entries = new ItemsControl() { ItemTemplate = new LedgerTemplate(null, null, 70) };
            var totalText = new TextBlock() { Text = "Total", FontWeight = FontWeights.Bold };
            totalReceivable = new TextBlock() {
                FontWeight = FontWeights.Bold,
                HorizontalAlignment = HorizontalAlignment.Right
            };
            totalReceipt = new TextBlock() {
                FontWeight = FontWeights.Bold,
                HorizontalAlignment = HorizontalAlignment.Right
            };
            Grid.SetColumn(totalReceivable, 1);
            Grid.SetColumn(totalReceipt, 2);
            var totalGrid = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) }
                },
                Children = { totalText, totalReceivable, totalReceipt }
            };
            pageTotal = new Border() {
                BorderThickness = new Thickness(0, .5, 0, 0),
                BorderBrush = Brushes.Black,
                Child = totalGrid
            };
            Grid.SetRow(pageTotal, 1);
            content = new Grid() {
                RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto }
                },
                Children = { entries, pageTotal }
            };
        }       
        void initializeFooter() {
            footNoteBlock = new TextBlock();
            currentPage = new Run();
            totalPage = new Run();
            var pageNo = new TextBlock() {
                Inlines = { 
                    currentPage,
                    new Run(){Text = "/" },
                    totalPage
                }
            };
            Grid.SetColumn(pageNo, 1);
            var grid = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto }
                },
                Children = { footNoteBlock, pageNo }
            };
            footer = new Border() {
                BorderThickness = new Thickness(0, .5, 0, 0),
                BorderBrush = Brushes.Black,
                Child = grid
            };
        }
        void measure() {
            var availableSize = new Size(PageSize.Width - 2 * margin, PageSize.Height - 2 * margin);
            heightControl = new ContentControl() {
                Width = availableSize.Width,
                ContentTemplate = new LedgerTemplate(null, null, 70)
            };
            title.Text = Title;
            subTitle.Text = SubTitle;
            period.Text = Period;
            currentPage.Text = "Page: " + PageNo;

            double y = 0;
            foreach (FrameworkElement item in Page.Children) {
                item.Width = availableSize.Width;
                item.Measure(availableSize);
                FixedPage.SetTop(item, y);
                y += item.DesiredSize.Height;
            }
            var contentHeight = availableSize.Height - header.DesiredSize.Height - footer.DesiredSize.Height;
            content.Height = contentHeight;
            remainingHeight = contentHeight - pageTotal.DesiredSize.Height;
            FixedPage.SetTop(footer, header.DesiredSize.Height + contentHeight);
        }
        //double x = 0;
        public bool AddEntry(ReportEntry entry) {
            heightControl.Content = entry;
            heightControl.Measure(PageSize);
            heightControl.UpdateLayout();
            remainingHeight -= heightControl.DesiredSize.Height;
            if (remainingHeight < 0) return false;

            entries.Items.Add(entry);
            TotalReceivable += entry.Receivable;
            TotalReceipt += entry.Receipt;

            //entries.Measure(PageSize);
            //entries.UpdateLayout();
            //x += heightControl.DesiredSize.Height;
            //Debug.WriteLine($"Entries height {entries.DesiredSize.Height} Height {x}");

            return true;
        }
        void addPageTotals() {
            totalReceivable.Text = TotalReceivable.ToString(Constants.NumberFormat);
            totalReceipt.Text = TotalReceipt.ToString(Constants.NumberFormat);
        }
    }
}
