﻿using RentManager.Helpers;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;

namespace RentManager.CustomControls
{
    class ComboButton : FrameworkElement
    {
        Grid container;
        CommandButton edit, cancel, save;
        public Action EditCommand { get; set; }
        public Action SaveCommand { get; set; }
        public Action CancelCommand { get; set; }
        public string IsValid { get; set; }
        public ComboButton() {
            edit = new CommandButton() {
                Icon = Icons.Edit,
                HorizontalAlignment = HorizontalAlignment.Right
            };
            save = new CommandButton() {
                Icon = Icons.Save,
                HorizontalAlignment = HorizontalAlignment.Left,
                Visibility = Visibility.Hidden
            };
            cancel = new CommandButton() {
                Icon = Icons.Cancel,
                HorizontalAlignment = HorizontalAlignment.Right,
                Visibility = Visibility.Hidden
            };
            container = new Grid() { Children = { edit, cancel, save } };
            AddVisualChild(container);
            Loaded += onLoaded;
            Unloaded += onUnloaded;
        }

        void onUnloaded(object sender, RoutedEventArgs e) {
            Loaded -= onLoaded;
            Unloaded -= onUnloaded;
        }
        void onLoaded(object sender, RoutedEventArgs e) {
            edit.Command = EditCommand;
            save.Command = SaveCommand;
            cancel.Command = CancelCommand;
            if(IsValid != null)
                save.SetBinding(IsEnabledProperty, new Binding(IsValid));
        }
        protected override Size MeasureOverride(Size availableSize) {
            foreach (CommandButton button in container.Children) {
                button.Width = 24;
                button.Height = 24;
            }
            container.Width = availableSize.Width;
            container.Measure(availableSize);
            return container.DesiredSize; 
        }
        protected override Size ArrangeOverride(Size finalSize) {
            container.Arrange(new Rect(container.DesiredSize));
            return finalSize;
        }
        protected override Visual GetVisualChild(int index) => container;
        protected override int VisualChildrenCount => 1;

        public bool IsOnEdit {
            get { return (bool)GetValue(IsOnEditProperty); }
            set { SetValue(IsOnEditProperty, value); }
        }
        public static readonly DependencyProperty IsOnEditProperty =
            DependencyProperty.Register("IsOnEdit", typeof(bool), typeof(ComboButton), new PropertyMetadata() {
                DefaultValue = false,
                PropertyChangedCallback = (s, e) => {
                    var o = (ComboButton)s;
                    if ((bool)e.NewValue) {
                        o.cancel.Visibility = Visibility.Visible;
                        o.save.Visibility = Visibility.Visible;
                        o.edit.Visibility = Visibility.Hidden;
                    }
                    else {
                        o.cancel.Visibility = Visibility.Hidden;
                        o.save.Visibility = Visibility.Hidden;
                        o.edit.Visibility = Visibility.Visible;
                    }
                }
            });
    }
}
