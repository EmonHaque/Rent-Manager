﻿using RentManager.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using System.Windows.Shapes;

namespace RentManager.CustomControls
{
    class MultiBarchart : Panel
    {
        public IEnumerable ItemSource {
            get { return (IEnumerable)GetValue(ItemSourceProperty); }
            set { SetValue(ItemSourceProperty, value); }
        }
        public static readonly DependencyProperty ItemSourceProperty =
            DependencyProperty.Register("ItemSource", typeof(IEnumerable), typeof(MultiBarchart), new FrameworkPropertyMetadata() {
                DefaultValue = null,
                PropertyChangedCallback = onSourceChanged,
                AffectsArrange = true
            });

        static void onSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
            var o = d as MultiBarchart;
            o.Children.Clear();
            if (e.NewValue != null) {
                var list = ((IEnumerable<RentPayment>)e.NewValue).ToList();
                o.hasData = list.Count > 0;
                if (o.hasData) o.generateChart(list);
                else o.Children.Add(o.noInfoBlock);
            }
            else {
                o.hasData = false;
                o.Children.Add(o.noInfoBlock);
            }
        }

        double minValue, maxValue, horizontalOffset;
        Size labelDesired, tickDesired;
        bool hasData;
        TextBlock noInfoBlock, infoBlock;

        public MultiBarchart() {
            ClipToBounds = true;
            LayoutTransform = new ScaleTransform() { ScaleY = -1 };
            noInfoBlock = new TextBlock() {
                TextAlignment = TextAlignment.Center,
                FontSize = 18,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Gray,
                Inlines = {
                    new Run(){ Text = "No data"},
                    new LineBreak(),
                    new Run(){ Text = "available" }
                },
                LayoutTransform = new ScaleTransform() { ScaleY = - 1 }
            };
            infoBlock = new TextBlock() {
                Foreground = Brushes.Gray,
                Tag = "Info",
                FontSize = 14,
                IsHitTestVisible = false,
                FontStyle = FontStyles.Italic,
                TextAlignment = TextAlignment.Right,
                LayoutTransform = new ScaleTransform() { ScaleY = -1 }
            };
        }
        void addLabel(string date) {
            var label = new TextBlock() {
                Tag = "Label",
                Text = date,
                IsHitTestVisible = false,
                TextAlignment = TextAlignment.Right,
                Padding = new Thickness(0, 0, 5, 0),
                RenderTransform = new TransformGroup() {
                    Children = {
                            new ScaleTransform() { ScaleY = -1 },
                            new RotateTransform() { Angle = 90 }
                        }
                }
            };
            label.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
            if (labelDesired.Width < label.DesiredSize.Width)
                labelDesired = label.DesiredSize;
            Children.Add(label);
            label.Loaded += animateLabels;
        }
        void addLine() {
            var line = new Line() {
                StrokeThickness = 1,
                Stroke = Brushes.LightBlue,
                IsHitTestVisible = false
            };
            Children.Add(line);
            SetZIndex(line, 1);
            line.Loaded += animateLines;
        }
        void addTick(double value) {
            var tick = new TextBlock() {
                Text = value.ToString("N0"),
                HorizontalAlignment = HorizontalAlignment.Right,
                RenderTransform = new TransformGroup() {
                    Children = {
                            new ScaleTransform() { ScaleY = - 1 },
                            new TranslateTransform()
                        }
                },
                IsHitTestVisible = false
            };
            if (value < 0) tick.Foreground = Brushes.Coral;
            Children.Add(tick);
            tick.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
            tickDesired.Width = tick.DesiredSize.Width > tickDesired.Width ? tick.DesiredSize.Width : tickDesired.Width;
            tickDesired.Height = tick.DesiredSize.Height > tickDesired.Height ? tick.DesiredSize.Height : tickDesired.Height;
            tick.Loaded += animateTicks;
        }    
        void generateChart(List<RentPayment> list) {
            labelDesired = tickDesired = new Size(0, 0);
            maxValue = minValue = 0;
            int cash, kind;
            cash = kind = 0;
            List<DateTime> days = new();
            foreach (var item in list) {
                cash += item.Cash;
                kind += item.Kind;
                if (!days.Contains(item.Date)) {
                    days.Add(item.Date);
                    var payments = list.Where(x => x.Date == item.Date).ToList();
                    var maxVal = payments.Sum(x => x.Cash) + payments.Sum(x => x.Kind);
                    maxVal = payments.First().Due > maxVal ? payments.First().Due : maxVal;
                    var minVal = payments.First().Due < 0 ? payments.First().Due : 0;
                    var bar = new MultiBar(payments);
                    Children.Add(bar);
                    SetZIndex(bar, 2);
                    addLabel(item.Date.ToString("dd MMM yyyy"));
                    if (maxVal > maxValue) maxValue = maxVal;
                    if (minVal < minValue) minValue = minVal;
                }
            }

            string text = "";
            if (cash != 0) text += "Cash: " + cash.ToString("N0");
            if (kind != 0) text += ", Kind: " + kind.ToString("N0");
            if (cash != 0 && kind != 0) text += ", Total: " + (cash + kind).ToString("N0");
            text += " paid in " + days.Count + " payment";
            infoBlock.Text = text;
            infoBlock.Loaded += animateInfoBlock;
            Children.Add(infoBlock);

            var min = minValue < 0 ? minValue : 0;
            double step = 0d;
            var current = min;
            step = min < 0 ? (maxValue + Math.Abs(min)) / 9 : maxValue / 9;
            for (int i = 0; i < 10; i++) {
                addLine();
                addTick(current);
                current += step;
            }
        }

        void animateLabels(object sender, RoutedEventArgs e) {
            var label = (TextBlock)sender;
            label.Loaded -= animateLabels;
            var anim = new DoubleAnimationUsingKeyFrames() {
                AccelerationRatio = 0.9,
                DecelerationRatio = 0.1,
                KeyFrames = {
                    new LinearDoubleKeyFrame(0, TimeSpan.FromSeconds(0)),
                    new LinearDoubleKeyFrame(45, TimeSpan.FromSeconds(0.5)),
                    new LinearDoubleKeyFrame(90, TimeSpan.FromSeconds(1))
                }
            };
            var transform = (label.RenderTransform as TransformGroup).Children[1];
            transform.BeginAnimation(RotateTransform.AngleProperty, anim);
        }
        void animateTicks(object sender, RoutedEventArgs e) {
            var tick = (TextBlock)sender;
            tick.Loaded -= animateTicks;
            var anim = new DoubleAnimationUsingKeyFrames() {
                KeyFrames = {
                    new LinearDoubleKeyFrame(-30 - horizontalOffset, TimeSpan.FromSeconds(0)),
                    new LinearDoubleKeyFrame(-30 - horizontalOffset, TimeSpan.FromSeconds(0.5)),
                    new LinearDoubleKeyFrame(0, TimeSpan.FromSeconds(1)),
                }
            };
            var transform = (tick.RenderTransform as TransformGroup).Children[1];
            transform.BeginAnimation(TranslateTransform.XProperty, anim);
        }
        void animateLines(object sender, RoutedEventArgs e) {
            var line = (Line)sender;
            line.Loaded -= animateLines;
            var anim = new DoubleAnimationUsingKeyFrames() {
                KeyFrames = {
                    new LinearDoubleKeyFrame(ActualHeight - line.Y1+15, TimeSpan.FromSeconds(0)),
                    new LinearDoubleKeyFrame(ActualHeight - line.Y1+15, TimeSpan.FromSeconds(0.5)),
                    new LinearDoubleKeyFrame(0, TimeSpan.FromSeconds(1)),
                }
            };
            line.RenderTransform = new TranslateTransform(0, 0);
            line.RenderTransform.BeginAnimation(TranslateTransform.YProperty, anim);
        }
        void animateInfoBlock(object sender, RoutedEventArgs e) {
            infoBlock.Loaded -= animateInfoBlock;
            infoBlock.RenderTransform = new ScaleTransform(0, 1);
            var anim = new DoubleAnimation() {
                BeginTime = TimeSpan.FromSeconds(1),
                Duration = TimeSpan.FromSeconds(0.5),
                To = 1,
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseIn }
            };
            infoBlock.RenderTransform.BeginAnimation(ScaleTransform.ScaleXProperty, anim);
        }

        protected override Size ArrangeOverride(Size finalSize) {
            if (finalSize.Width == 0 || finalSize.Height == 0) return finalSize;
            if (!hasData) {
                noInfoBlock.Measure(finalSize);
                var center = new Point(finalSize.Width / 2, finalSize.Height / 2);
                var point = new Point(center.X - noInfoBlock.DesiredSize.Width / 2, center.Y - noInfoBlock.DesiredSize.Height / 2);
                noInfoBlock.Arrange(new Rect(point, noInfoBlock.DesiredSize));
                return finalSize;
            }
            double margin = 10;
            infoBlock.Width = finalSize.Width - margin;
            infoBlock.Measure(finalSize);
            infoBlock.Arrange(new Rect(new Point(0, finalSize.Height - infoBlock.DesiredSize.Height), infoBlock.DesiredSize));

            double barsLeftMargin = 5;
            var labelHeight = labelDesired.Width;
            var bars = Children.OfType<MultiBar>().Count();
            var tickSpace = horizontalOffset = tickDesired.Width;
            var barWidth = (finalSize.Width - tickSpace - margin) / bars;
            var remainingHeight = finalSize.Height - labelHeight - infoBlock.DesiredSize.Height;
            var lineSpace = remainingHeight / 10;
            var availableHeight = remainingHeight / 10 * 9;
            var barSpace = tickSpace;
            var labelSpace = tickSpace + barsLeftMargin + barWidth / 2 - labelDesired.Height / 2;
            var y = labelHeight;
            var tickY = labelHeight;
            var upperBound = maxValue;
            var lowerBound = minValue < 0 ? Math.Abs(minValue) : 0;

            var posHeight = availableHeight / (lowerBound + upperBound) * upperBound;
            var negHeight = availableHeight - posHeight;

            if (barWidth < 1 || availableHeight < 5) return finalSize;
            foreach (UIElement item in Children) {
                if (item is MultiBar) {
                    var rect = (MultiBar)item;
                    rect.SetParameters(lowerBound, upperBound, posHeight, negHeight);
                    rect.Measure(new Size(barWidth, availableHeight));
                    rect.Arrange(new Rect(new Point(barSpace, labelHeight), rect.DesiredSize));
                    barSpace += barWidth;
                }
                else if (item is Line) {
                    var line = (Line)item;
                    line.X2 = finalSize.Width - margin;
                    line.Y1 = line.Y2 = y;
                    item.Measure(finalSize);
                    item.Arrange(new Rect(item.DesiredSize));
                    y += lineSpace;
                }
                else if (item is TextBlock) {
                    var block = (TextBlock)item;
                    if (block.Tag != null) {
                        if (string.Equals(block.Tag.ToString(), "Label")) {
                            block.Width = labelDesired.Width;
                            block.Measure(finalSize);
                            block.Arrange(new Rect(new Point(labelSpace, 0), block.DesiredSize));
                            labelSpace += barWidth;
                        }
                    }
                    else {
                        block.Measure(finalSize);
                        block.Arrange(new Rect(new Point(0, tickY + block.DesiredSize.Height), block.DesiredSize));
                        tickY += lineSpace;
                    }
                }
            }
            return finalSize;
        }
    }
}
