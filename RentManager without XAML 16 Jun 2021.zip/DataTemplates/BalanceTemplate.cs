﻿using RentManager.CustomControls;
using RentManager.Helpers;
using RentManager.Models;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;

namespace RentManager.DataTemplates
{
    class BalanceTemplate : DataTemplate
    {
        public BalanceTemplate(string queryProperty, object viewModel) {
            var grid = new FrameworkElementFactory(typeof(Grid));
            var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var col4 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var col5 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var tenantPanel = new FrameworkElementFactory(typeof(StackPanel)) { Name = "tenant" };
            var singleSpace = new FrameworkElementFactory(typeof(TextBlock));
            var multiSpacePanel = new FrameworkElementFactory(typeof(StackPanel)) { Name = "multiSpacePanel"};
            var from = new FrameworkElementFactory(typeof(TextBlock));
            var cash = new FrameworkElementFactory(typeof(TextBlock));
            var kind = new FrameworkElementFactory(typeof(TextBlock));
            var total = new FrameworkElementFactory(typeof(TextBlock));
            var tenantName = new FrameworkElementFactory(typeof(HiBlock));

            var spaceName = new FrameworkElementFactory(typeof(TextBlock));
            var expired = new FrameworkElementFactory(typeof(TextBlock)) { Name = "expired" };
            var hyphen = new FrameworkElementFactory(typeof(Run));
            var expiryDate = new FrameworkElementFactory(typeof(Run));

            expired.SetValue(TextBlock.VisibilityProperty, Visibility.Hidden);
            multiSpacePanel.SetValue(StackPanel.OrientationProperty, Orientation.Horizontal);
            expired.AppendChild(hyphen);
            expired.AppendChild(expiryDate);
            multiSpacePanel.AppendChild(spaceName);
            multiSpacePanel.AppendChild(expired);

            Resources.Add(typeof(TextBlock), new Style() {
                Setters = {
                    new Setter(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right)
                }
            });
            col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(150));
            col3.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
            col4.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
            col5.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
            tenantName.SetValue(HiBlock.FontWeightProperty, FontWeights.Bold);
            singleSpace.SetValue(TextBlock.FontStyleProperty, FontStyles.Italic);
            tenantPanel.SetValue(StackPanel.VisibilityProperty, Visibility.Hidden);
            tenantPanel.SetValue(StackPanel.HorizontalAlignmentProperty, HorizontalAlignment.Left);
            tenantPanel.SetValue(StackPanel.OrientationProperty, Orientation.Horizontal);
            singleSpace.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Left);
            singleSpace.SetValue(TextBlock.MarginProperty, new Thickness(5,0,0,0));
            from.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Center);

            from.SetValue(Grid.ColumnProperty, 1);
            cash.SetValue(Grid.ColumnProperty, 2);
            kind.SetValue(Grid.ColumnProperty, 3);
            total.SetValue(Grid.ColumnProperty, 4);
            hyphen.SetValue(Run.TextProperty, " - expired on ");

            tenantName.SetBinding(HiBlock.TextProperty, new Binding(nameof(Balance.Tenant)));
            tenantName.SetBinding(HiBlock.QueryProperty, new Binding(queryProperty) { Source = viewModel, IsAsync = true });
            from.SetBinding(TextBlock.TextProperty, new Binding(nameof(Balance.DateStart)) { StringFormat = "dd MMMM yyyy" });
            singleSpace.SetBinding(TextBlock.TextProperty, new Binding(nameof(Balance.Space)));
            spaceName.SetBinding(TextBlock.TextProperty, new Binding(nameof(Balance.Space)));
            expiryDate.SetBinding(Run.TextProperty, new Binding(nameof(Balance.DateEnd)) { StringFormat = "dd MMMM yyyy"});

            cash.SetBinding(TextBlock.TextProperty, new Binding(nameof(Balance.Security)) { StringFormat = Constants.NumberFormat });
            kind.SetBinding(TextBlock.TextProperty, new Binding(nameof(Balance.Rent)) { StringFormat = Constants.NumberFormat });
            total.SetBinding(TextBlock.TextProperty, new Binding(nameof(Balance.Due)) { StringFormat = Constants.NumberFormat });

            tenantPanel.AppendChild(tenantName);
            tenantPanel.AppendChild(singleSpace);

            grid.AppendChild(col1);
            grid.AppendChild(col2);
            grid.AppendChild(col3);
            grid.AppendChild(col4);
            grid.AppendChild(col5);
            grid.AppendChild(tenantPanel);
            grid.AppendChild(multiSpacePanel);
            grid.AppendChild(from);
            grid.AppendChild(cash);
            grid.AppendChild(kind);
            grid.AppendChild(total);

            Triggers.Add(new MultiDataTrigger() {
                Conditions = {
                    new Condition(new Binding("DataContext.IsBottomLevel"){
                        RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(ItemsPresenter), 1)
                    }, true),
                    new Condition(new Binding("DataContext.ItemCount"){
                        RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(ItemsPresenter), 1)
                    }, 1),
                },
                Setters = {
                    new Setter(TextBlock.VisibilityProperty, Visibility.Hidden, "multiSpacePanel"),
                    new Setter(TextBlock.VisibilityProperty, Visibility.Visible, "tenant")
                }
            });
            Triggers.Add(new DataTrigger() {
                Binding = new Binding(nameof(Balance.IsExpired)),
                Value = true,
                Setters = {
                    new Setter(TextBlock.VisibilityProperty, Visibility.Visible, "expired"),
                    new Setter(TextElement.FontStyleProperty, FontStyles.Italic, "multiSpacePanel")
                }
            });

            VisualTree = grid;
        }
    }
}
