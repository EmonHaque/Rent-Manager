﻿using RentManager.Abstracts;

namespace RentManager.Models
{
    public class Plot : Notifiable
    {
        public int? Id { get; set; }
        string name;
        public string Name {
            get { return name; }
            set {
                if (name != value) {
                    name = value;
                    OnPropertyChanged(nameof(Name));
                }
             }
        }
        string description;
        public string Description {
            get { return description; }
            set { 
                if (description != value) {
                    description = value; 
                    OnPropertyChanged(nameof(Description));
                }
            }
        }
    }
}
