﻿using RentManager.Abstracts;

namespace RentManager.Models
{
    public class Space : Notifiable
    {
        public int? Id { get; set; }
        int? plotId;
        public int? PlotId {
            get { return plotId; }
            set {
                if (plotId != value) {
                    plotId = value;
                    OnPropertyChanged(nameof(PlotId));
                }
            }
        }
        string name;
        public string Name {
            get { return name; }
            set {
                if (name != value) {
                    name = value;
                    OnPropertyChanged(nameof(Name));
                }
            }
        }
        string description;
        public string Description {
            get { return description; }
            set {
                if (description != value) {
                    description = value;
                    OnPropertyChanged(nameof(Description));
                }
            }
        }
        bool isVacant;
        public bool IsVacant {
            get { return isVacant; }
            set {
                if (isVacant != value) {
                    isVacant = value;
                    OnPropertyChanged(nameof(IsVacant));
                }
            }
        }
        string plotName;
        public string PlotName {
            get { return plotName; }
            set {
                if (plotName != value) {
                    plotName = value;
                    OnPropertyChanged(nameof(PlotName));
                }
            }
        }
    }
}
