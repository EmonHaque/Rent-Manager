﻿using RentManager.CustomControls;
using RentManager.Enums;
using RentManager.Helpers;
using RentManager.Models;
using RentManager.ViewModels;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows.Data;

namespace RentManager.ViewModel.Edit
{
    public class EditTransactionVM : EditBase<Transaction>
    {
        ObservableCollection<Transaction> transactions;
        ObservableCollection<Lease> plots, spaces;
        CollectionViewSource tenants, controlHeads, heads, editables;
        bool isEqual;
        DateTime? transactionDate;
        public DateTime? TransactionDate {
            get { return transactionDate; }
            set {
                if (transactionDate != value) {
                    transactionDate = value;
                    if (value == null) {
                        IsRefreshValid = false;
                        transactions.Clear();
                    }
                    else {
                        IsRefreshValid = true;
                        getTransactions();
                    }
                    OnPropertyChanged(nameof(IsRefreshValid));
                }
            }
        }
        string amount;
        public string Amount {
            get { return amount; }
            set {
                if (amount != value) {
                    amount = value;
                    OnPropertyChanged(nameof(Amount));
                    validateAmount();
                }
            }
        }
        string filterName;
        public string FilterName {
            get { return filterName; }
            set {
                if (filterName != value) {
                    filterName = value?.Trim().ToLower();
                    Editables.Refresh();
                }
            }
        }
        public string TenantQuery { get; set; }
        public string PlotQuery { get; set; }
        public string SpaceQuery { get; set; }
        public string ControlQuery { get; set; }
        public string HeadQuery { get; set; }
        public string ErrorTenantId { get; set; }
        public string ErrorPlotId { get; set; }
        public string ErrorSpaceId { get; set; }
        public string ErrorControlId { get; set; }
        public string ErrorHeadId { get; set; }
        public string ErrorDate { get; set; }
        public string ErrorAmount { get; set; }
        public string ErrorNarration { get; set; }
        public bool IsValid { get; set; }
        public bool IsRefreshValid { get; set; }
        public ICollectionView Plots { get; set; }
        public ICollectionView Spaces { get; set; }
        public ICollectionView Tenants { get; set; }
        public ICollectionView ControlHeads { get; set; }
        public ICollectionView Heads { get; set; }
        public Action Delete { get; set; }
        public Action Refresh { get; set; }
        public Action<SelectQuery, string> FilterCommand { get; set; }
        
        public EditTransactionVM() : base() {
            transactions = new ObservableCollection<Transaction>();
            plots = new ObservableCollection<Lease>();
            spaces = new ObservableCollection<Lease>();
            tenants = new CollectionViewSource() { Source = AppData.tenants };
            heads = new CollectionViewSource() { Source = AppData.heads };
            controlHeads = new CollectionViewSource() { Source = AppData.controlHeads };
            editables = new CollectionViewSource() {
                Source = transactions,
                IsLiveFilteringRequested = true,
                IsLiveGroupingRequested = true,
                LiveFilteringProperties = { nameof(Transaction.Date) },
                LiveGroupingProperties = { nameof(Transaction.PlotId) }
            };
            ControlHeads = controlHeads.View;
            Tenants = tenants.View;
            Heads = heads.View;
            Editables = editables.View;

            Plots = CollectionViewSource.GetDefaultView(plots);
            Spaces = CollectionViewSource.GetDefaultView(spaces);
            Editables.GroupDescriptions.Add(new PropertyGroupDescription(nameof(Transaction.PlotId)));
            Editables.Filter = filterTransactions;

            Tenants.Filter = filterTenants;
            ControlHeads.Filter = filterControlHeads;
            Plots.Filter = filterPlots;
            Spaces.Filter = filterSpaces;
            Heads.Filter = filterHeads;
            TransactionDate = DateTime.Today;
            Refresh = getTransactions;
            Delete = delete;
            FilterCommand = filterCommand;
            EditPlotVM.NameChanged += onPlotNameChanged;
            EditTenantVM.NameChanged += onTenantNameChanged;
        }
        void filterCommand(SelectQuery parameter, string query) {
            switch (parameter) {
                case SelectQuery.Plot: PlotQuery = query; Plots.Refresh(); break;
                case SelectQuery.Space: SpaceQuery = query; Spaces.Refresh(); break;
                case SelectQuery.Tenant: TenantQuery = query; Tenants.Refresh(); break;
                case SelectQuery.ControlHead: ControlQuery = query; ControlHeads.Refresh(); break;
                case SelectQuery.Head: HeadQuery = query; Heads.Refresh(); break;
            }
        }
        void onPlotNameChanged(Plot p) {
            if (transactions == null || transactions.Count == 0) return;
            foreach (var item in transactions) {
                if (item.PlotId == p.Id) {
                    //item.PlotId = p.Id;
                    //item.OnPropertyChanged(string.Empty);
                    item.OnPropertyChanged(nameof(Transaction.PlotId));
                }
            }
        }
        void onTenantNameChanged(Tenant t) {
            if (transactions == null || transactions.Count == 0) return;
            foreach (var item in transactions) {
                if(item.TenantId == t.Id) {
                    item.TenantName = t.Name;
                    item.OnPropertyChanged(nameof(Transaction.TenantName));
                }
            }
        }

        void getTransactions() {
            transactions.Clear();
            lock (SQLHelper.key) {
                using var cmd = SQLHelper.connection.CreateCommand();
                cmd.CommandText = $"SELECT * FROM Transactions WHERE Date = '{TransactionDate.Value.ToString("yyyy-MM-dd")}'";
                SQLHelper.connection.Open();
                var reader = cmd.ExecuteReader();
                while (reader.Read()) {
                    transactions.Add(new Transaction() {
                        Id = reader.GetInt32(0),
                        Date = reader.GetDateTime(1),
                        PlotId = reader.GetInt32(2),
                        SpaceId = reader.GetInt32(3),
                        TenantId = reader.GetInt32(4),
                        ControlId = reader.GetInt32(5),
                        HeadId = reader.GetInt32(6),
                        Amount = reader.GetInt32(7),
                        IsCash = reader.GetBoolean(8),
                        Narration = reader.IsDBNull(9) ? null : reader.GetString(9)
                    });
                }
                SQLHelper.connection.Close();
            }
            foreach (var transaction in transactions)
                transaction.TenantName = AppData.tenants.First(x => x.Id == transaction.TenantId).Name;
        }
        void setPlotsAndSpaces() {
            plots.Clear();
            spaces.Clear();
            for (int i = 0; i < AppData.leases.Count; i++) {
                if (AppData.leases[i].TenantId == Edited.TenantId) {
                    var lease = AppData.leases[i];
                    bool containedInPlots = false;
                    for (int j = 0; j < plots.Count; j++) {
                        if (plots[j].PlotId == lease.PlotId) {
                            containedInPlots = true;
                            break;
                        }
                    }
                    if (!containedInPlots) plots.Add(lease);
                    spaces.Add(lease);
                }
            }
        }
        void delete() {
            var message = AppData.controlHeads.First(x => x.Id == Selected.ControlId).Name + " : " +
                          AppData.heads.First(x => x.Id == Selected.HeadId).Name + " amounting " + Selected.Amount.ToString("N0") +
                          "\r\nfrom " + AppData.tenants.First(x => x.Id == Selected.TenantId).Name +
                          "\r\non " + Selected.Date.Value.ToString("dd MMMM, yyyy") + " will be deleted permanently";
            var confirm = new ConfirmationDialog() {
                Title = "Transaction",
                Message = message
            };
            if (confirm.ShowDialog().Value) {
                lock (SQLHelper.key) {
                    using var cmd = SQLHelper.connection.CreateCommand();
                    cmd.CommandText = @$"DELETE FROM Transactions WHERE Id = {Selected.Id}";
                    SQLHelper.NonQuery(cmd);
                }
                transactions.Remove(Selected);
            }
        }

        #region validation rules
        void validateTenantId() {
            setPlotsAndSpaces();
            ErrorTenantId = string.Empty;
            if (Edited.TenantId == null)
                ErrorTenantId = " is required";
            OnPropertyChanged(nameof(ErrorTenantId));
        }
        void validatePlotId() {
            ErrorPlotId = string.Empty;
            if (Edited.PlotId == null)
                ErrorPlotId = " is required";
            OnPropertyChanged(nameof(ErrorPlotId));
            Spaces.Refresh();
            Edited.SpaceId = (Spaces.CurrentItem as Lease)?.SpaceId;
        }
        void validateSpaceId() {
            ErrorSpaceId = string.Empty;
            if (Edited.SpaceId == null)
                ErrorSpaceId = " is required";
            OnPropertyChanged(nameof(ErrorSpaceId));
        }
        void validateControlId() {
            ErrorControlId = string.Empty;
            if (Edited.ControlId == null)
                ErrorControlId = " is required";
            OnPropertyChanged(nameof(ErrorControlId));
            Heads.Refresh();
            Edited.IsCash = Edited.ControlId != AppData.controlIdOfReceivable;
            Edited.HeadId = (Heads.CurrentItem as Head)?.Id;
        }
        void validateHeadId() {
            ErrorHeadId = string.Empty;
            if (Edited.HeadId == null)
                ErrorHeadId = " is required";
            OnPropertyChanged(nameof(ErrorHeadId));
        }
        void validateDate() {
            ErrorDate = string.Empty;
            if (Edited.Date == null)
                ErrorDate = " is required";
            OnPropertyChanged(nameof(ErrorDate));
        }
        void validateAmount() {
            ErrorAmount = string.Empty;
            if (string.IsNullOrWhiteSpace(Amount))
                ErrorAmount = "Amount in required";
            else {
                int x;
                if (int.TryParse(Amount, out x)) {
                    if (x > 0) {
                        Edited.Amount = x;
                        ErrorAmount = string.Empty;
                    }
                    else ErrorAmount = "Positive integers only";
                }
                else ErrorAmount = "Integer only";
            }
            OnPropertyChanged(nameof(ErrorAmount));
            checkValidity();
        }
        void validateNarration() {
            ErrorNarration = string.Empty;
            if (string.IsNullOrWhiteSpace(Edited.Narration))
                ErrorNarration = "Narration is required";
            OnPropertyChanged(nameof(ErrorNarration));
        }
        bool isBothEqual() {
            return
                Selected.TenantId == Edited.TenantId &&
                Selected.PlotId == Edited.PlotId &&
                Selected.SpaceId == Edited.SpaceId &&
                Selected.ControlId == Edited.ControlId &&
                Selected.HeadId == Edited.HeadId &&
                Nullable.Compare(Selected.Date, Edited.Date) == 0 &&
                Selected.Amount == Edited.Amount &&
                Selected.IsCash == Edited.IsCash &&
                string.Equals(Selected.Narration, Edited.Narration, StringComparison.OrdinalIgnoreCase);
        }
        void checkValidity() {
            isEqual = isBothEqual();
            IsValid =
                !isEqual &&
                ErrorTenantId == string.Empty &&
                ErrorPlotId == string.Empty &&
                ErrorSpaceId == string.Empty &&
                ErrorControlId == string.Empty &&
                ErrorHeadId == string.Empty &&
                ErrorDate == string.Empty &&
                ErrorAmount == string.Empty &&
                ErrorNarration == string.Empty;
            OnPropertyChanged(nameof(IsValid));
        }
        #endregion

        #region filters
        bool filterTenants(object o) {
            if (string.IsNullOrWhiteSpace(TenantQuery)) return true;
            return ((Tenant)o).Name.ToLower().Contains(TenantQuery);
        }
        bool filterPlots(object o) {
            if (string.IsNullOrWhiteSpace(PlotQuery)) return true;
            return ((Lease)o).PlotName.ToLower().Contains(PlotQuery);
        }
        bool filterSpaces(object o) {
            var lease = (Lease)o;
            var result = lease.PlotId == Edited.PlotId;
            if (string.IsNullOrWhiteSpace(SpaceQuery)) return result;
            return result && lease.SpaceName.ToLower().Contains(SpaceQuery);
        }
        bool filterControlHeads(object o) {
            if (string.IsNullOrWhiteSpace(ControlQuery)) return true;
            return ((ControlHead)o).Name.ToLower().Contains(ControlQuery);
        }
        bool filterHeads(object o) {
            if (Edited == null) return false;
            var head = (Head)o;
            var result = head.ControlId == Edited.ControlId;
            if (string.IsNullOrWhiteSpace(HeadQuery)) return result;
            return result && head.Name.ToLower().Contains(HeadQuery);
        }
        bool filterTransactions(object o) {
            var transaction = (Transaction)o;
            var result = transaction.Date == TransactionDate;
            if (string.IsNullOrWhiteSpace(FilterName)) return result;
            return result && transaction.TenantName.ToLower().Contains(FilterName);
        }
        #endregion

        #region base implementation
        protected override void setStatesOnClone() {
            setPlotsAndSpaces();
            Edited.PlotId = Selected.PlotId;
            Spaces.Refresh();
            Edited.SpaceId = Selected.SpaceId;
            Amount = Edited.Amount.ToString();
        }
        protected override Transaction clone() {
            return new Transaction() {
                Id = Selected.Id,
                PlotId = Selected.PlotId,
                SpaceId = Selected.SpaceId,
                TenantId = Selected.TenantId,
                ControlId = Selected.ControlId,
                HeadId = Selected.HeadId,
                Narration = Selected.Narration,
                IsCash = Selected.IsCash,
                Date = Selected.Date,
                Amount = Selected.Amount
            };
        }
        protected override void validate(object sender, PropertyChangedEventArgs e) {
            switch (e.PropertyName) {
                case nameof(Transaction.TenantId): validateTenantId(); break;
                case nameof(Transaction.PlotId): validatePlotId(); break;
                case nameof(Transaction.SpaceId): validateSpaceId(); break;
                case nameof(Transaction.ControlId): validateControlId(); break;
                case nameof(Transaction.HeadId): validateHeadId(); break;
                case nameof(Transaction.Date): validateDate(); break;
                case nameof(Transaction.Amount): validateAmount(); break;
                case nameof(Transaction.Narration): validateNarration(); break;
            }
            checkValidity();
        }
        protected override void setValidationProperties() {
            isEqual = true;
            IsValid = false;
            ErrorTenantId =
            ErrorPlotId =
            ErrorSpaceId =
            ErrorControlId =
            ErrorHeadId =
            ErrorDate =
            ErrorAmount =
            ErrorNarration = string.Empty;
            OnPropertyChanged(nameof(ErrorTenantId));
            OnPropertyChanged(nameof(ErrorPlotId));
            OnPropertyChanged(nameof(ErrorSpaceId));
            OnPropertyChanged(nameof(ErrorControlId));
            OnPropertyChanged(nameof(ErrorHeadId));
            OnPropertyChanged(nameof(ErrorDate));
            OnPropertyChanged(nameof(ErrorAmount));
            OnPropertyChanged(nameof(ErrorNarration));
            OnPropertyChanged(nameof(IsValid));
        }
        protected override void save() {
            var narration = Edited.Narration == null ? (object)DBNull.Value : Edited.Narration;
            lock (SQLHelper.key) {
                using var cmd = SQLHelper.connection.CreateCommand();
                cmd.CommandText = @$"UPDATE Transactions SET Date = '{Edited.Date.Value.ToString("yyyy-MM-dd")}', PlotId = {Edited.PlotId}, SpaceId ={Edited.SpaceId},
                                     TenantId ={Edited.TenantId}, ControlId = {Edited.ControlId}, HeadId = {Edited.HeadId}, IsCash = {Edited.IsCash}, 
                                        Narration = @Narration, Amount = {Edited.Amount} WHERE Id = {Edited.Id}";
                cmd.Parameters.AddWithValue("@Narration", narration);
                SQLHelper.NonQuery(cmd);
            }
        }
        protected override void update() {
            if(Selected.TenantId != Edited.TenantId) {
                Selected.TenantId = Edited.TenantId;
                Selected.TenantName = AppData.tenants.First(x => x.Id == Selected.TenantId).Name;
            }
            Selected.PlotId = Edited.PlotId;
            Selected.SpaceId = Edited.SpaceId;
            Selected.ControlId = Edited.ControlId;
            Selected.HeadId = Edited.HeadId;
            Selected.Date = Edited.Date;
            Selected.Amount = Edited.Amount;
            Selected.IsCash = Edited.IsCash;
            Selected.Narration = Edited.Narration;
        }
        #endregion
    }
}
