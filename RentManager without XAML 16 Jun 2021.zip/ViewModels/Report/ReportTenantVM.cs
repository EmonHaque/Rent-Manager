﻿using RentManager.Models;
using System.ComponentModel;
using System.Linq;
using System.Windows.Data;

namespace RentManager.ViewModels.Report
{
    public class ReportTenantVM : ReportBase
    {
        protected override string particulars => "p.Name ||' -> '|| s.Name ";
        protected override string where => "TenantId";
        public override ICollectionView selectionView => tenants.View;
        

        CollectionViewSource tenants;
        public ReportTenantVM() : base() {
            tenants = new CollectionViewSource() { Source = AppData.tenants, };
            selectionView.Filter = filterTenants;
        }
        bool filterTenants(object o) {
            if (string.IsNullOrWhiteSpace(Query)) return true;
            return ((Tenant)o).Name.ToLower().Contains(Query);
        }
        protected override void setTitleAndSubTitle(){
            var tenant = AppData.tenants.First(x => x.Id == base.Id);
            base.Title = tenant.Name;
            base.SubTitle = tenant.Address;
        }
    }
}
