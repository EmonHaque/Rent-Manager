﻿using RentManager.Abstracts;
using RentManager.Models;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Linq;

namespace RentManager.ViewModels.Home
{
    class CountsVM : Notifiable
    {
        bool? state;
        public bool? State {
            get { return state; }
            set {
                if (state != value) {
                    state = value;
                    switch (SelectionState) {
                        case null: getTenantSummary(); break;
                        case true: getSpaceSummary(); break;
                        default: getLeaseSummary(); break;
                    }
                }
            }
        }
        bool? selectionState;
        public bool? SelectionState {
            get { return selectionState; }
            set {
                if (selectionState != value) {
                    selectionState = value;
                    switch (value) {
                        case null: getTenantSummary(); break;
                        case true: getSpaceSummary(); break;
                        default: getLeaseSummary(); break;
                    }
                }
            }
        }
        int? selected;
        public int? Selected {
            get { return selected; }
            set {
                if (selected != value) {
                    selected = value;
                    //TODO
                }
            }
        }

        public string StateText { get; set; }
        public string SelectionStateText { get; set; }
        public List<PlotSummary> Summary { get; set; }
        public Action Refresh { get; set; }
        //public static event Action<int?, List<PlotSummary>> SelectionChanged;

        public CountsVM() {
            State = true;
            SelectionState = true;
            Refresh = refresh;
        }
        void refresh() {
            switch (SelectionState) {
                case null: getTenantSummary(); break;
                case true: getSpaceSummary(); break;
                default: getLeaseSummary(); break;
            }
        }
        void getSpaceSummary() {
            SelectionStateText = "Space";
            Summary = new List<PlotSummary>();
            if (State == null) {
                StateText = "All";
                foreach (var plot in AppData.plots) {
                    int total = 0;
                    for (int i = 0; i < AppData.spaces.Count; i++) {
                        if (plot.Id == AppData.spaces[i].PlotId) total++;
                    }
                    Summary.Add(new PlotSummary() {
                        Id = plot.Id,
                        Name = plot.Name,
                        Total = total
                    });
                }
            }
            else if (State.Value) {
                StateText = "Occupied";
                foreach (var plot in AppData.plots) {
                    int total = 0;
                    for (int i = 0; i < AppData.spaces.Count; i++) {
                        if (plot.Id == AppData.spaces[i].PlotId && !AppData.spaces[i].IsVacant) total++;
                    }
                    Summary.Add(new PlotSummary() {
                        Id = plot.Id,
                        Name = plot.Name,
                        Total = total
                    });
                }
            }
            else {
                StateText = "Vacant";
                foreach (var plot in AppData.plots) {
                    int total = 0;
                    for (int i = 0; i < AppData.spaces.Count; i++) {
                        if (plot.Id == AppData.spaces[i].PlotId && AppData.spaces[i].IsVacant) total++;
                    }
                    Summary.Add(new PlotSummary() {
                        Id = plot.Id,
                        Name = plot.Name,
                        Total = total
                    });
                }
            }
            OnPropertyChanged(nameof(Summary));
            OnPropertyChanged(nameof(StateText));
            OnPropertyChanged(nameof(SelectionStateText));
        }
        void getLeaseSummary() {
            SelectionStateText = "Lease";
            Summary = new List<PlotSummary>();
            if (State == null) {
                StateText = "All";
                foreach (var plot in AppData.plots) {
                    Summary.Add(new PlotSummary() {
                        Id = plot.Id,
                        Name = plot.Name,
                        Total = AppData.leases.Count(x => x.PlotId == plot.Id)
                    });
                }
            }
            else if (State.Value) {
                StateText = "Active";
                foreach (var plot in AppData.plots) {
                    Summary.Add(new PlotSummary() {
                        Id = plot.Id,
                        Name = plot.Name,
                        Total = AppData.leases.Count(x => x.PlotId == plot.Id && !x.IsExpired)
                    });
                }
            }
            else {
                StateText = "Expired";
                foreach (var plot in AppData.plots) {
                    Summary.Add(new PlotSummary() {
                        Id = plot.Id,
                        Name = plot.Name,
                        Total = AppData.leases.Count(x => x.PlotId == plot.Id && x.IsExpired)
                    });
                }
            }
            OnPropertyChanged(nameof(Summary));
            OnPropertyChanged(nameof(StateText));
            OnPropertyChanged(nameof(SelectionStateText));
        }
        void getTenantSummary() {
            SelectionStateText = "Tenant";
            Summary = new List<PlotSummary>();
            if(State == null) {
                StateText = "All";
                foreach (var plot in AppData.plots) {
                    Summary.Add(new PlotSummary() {
                        Id = plot.Id,
                        Name = plot.Name,
                        Total = AppData.leases.Where(x => x.PlotId == plot.Id).Select(x => x.TenantId).Distinct().Count()
                    });
                }
            }
            else if (State.Value) {
                StateText = "Existing";
                foreach (var plot in AppData.plots) {
                    var left = AppData.tenants.Where(x => !x.HasLeft).Select(x => x.Id);
                    var list = AppData.leases.Where(x => x.PlotId == plot.Id).Select(x => x.TenantId).Distinct();
                    Summary.Add(new PlotSummary() {
                        Id = plot.Id,
                        Name = plot.Name,
                        Total = left.Intersect(list).Count()
                    });
                }
            }
            else {
                StateText = "Left";
                foreach (var plot in AppData.plots) {
                    var existing = AppData.tenants.Where(x => x.HasLeft).Select(x => x.Id);
                    var list = AppData.leases.Where(x => x.PlotId == plot.Id).Select(x => x.TenantId).Distinct();
                    Summary.Add(new PlotSummary() {
                        Id = plot.Id,
                        Name = plot.Name,
                        Total = existing.Intersect(list).Count()
                    });
                }
            }
            OnPropertyChanged(nameof(Summary));
            OnPropertyChanged(nameof(StateText));
            OnPropertyChanged(nameof(SelectionStateText));
        }
    }
}
