﻿enum DepositDueRentState
{
    Rent,
    Deposit,
    Due
}
