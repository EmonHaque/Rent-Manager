﻿enum CalendarState
{
    Day,
    Month,
    Year
}
