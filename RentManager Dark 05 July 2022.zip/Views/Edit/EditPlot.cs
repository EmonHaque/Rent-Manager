﻿class EditPlot : CardView
{
    public override string Icon => Icons.Plot;
    public override string Header => "Plot";

    ComboText name, description;
    ComboButton buttons;
    ListBox plotList;
    EditText search;
    CountBlock counter;
    EditPlotVM viewModel;

    public EditPlot() : base() {
        viewModel = new EditPlotVM();
        DataContext = viewModel;
        initializeUI();
        bind();
    }

    void initializeUI() {
        name = new ComboText() {
            Hint = "Name",
            Icon = Icons.Plot,
            IsRequired = true,
            Editable = $"{nameof(viewModel.Edited)}.{nameof(Plot.Name)}",
            NonEditable = $"{nameof(viewModel.Selected)}.{nameof(Plot.Name)}",
            Error = nameof(viewModel.ErrorName)
        };
        description = new ComboText() {
            Hint = "Description",
            Icon = Icons.Description,
            IsRequired = true,
            IsMultiline = true,
            Editable = $"{nameof(viewModel.Edited)}.{nameof(Plot.Description)}",
            NonEditable = $"{nameof(viewModel.Selected)}.{nameof(Plot.Description)}",
            Error = nameof(viewModel.ErrorDescription)
        };
        buttons = new ComboButton() {
            EditCommand = viewModel.SetIsOnEdit,
            CancelCommand = viewModel.ResetIsOnEdit,
            SaveCommand = viewModel.Save,
            IsValid = nameof(viewModel.IsValid)
        };
        Grid.SetRow(description, 1);
        Grid.SetRow(buttons, 2);
        var editableGrid = new Grid() {
            Margin = new Thickness(10, 10, 0, 0),
            RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(),
                    new RowDefinition(){ Height = GridLength.Auto },
                },
            Children = { name, description, buttons }
        };
        Grid.SetRow(editableGrid, 1);
        Grid.SetColumn(editableGrid, 1);


        search = new EditText() {
            Icon = Icons.SearchPlot,
            Hint = "Plot",
            IsTrimBottomRequested = true
        };
        counter = new CountBlock() { VerticalAlignment = VerticalAlignment.Center };
        Grid.SetColumn(counter, 1);
        var searchGrid = new Grid() {
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){Width = GridLength.Auto}
                },
            Children = { search, counter }
        };

        plotList = new ListBox() {
            BorderBrush = Brushes.LightGray,
            BorderThickness = new Thickness(0, 0, 1, 0),
            ItemTemplate = new HiTemplate(nameof(Plot.Name), nameof(viewModel.FilterName), viewModel)
        };
        Grid.SetRow(plotList, 1);
        var grid = new Grid() {
            RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition()
                },
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition()
                },
            Children = { searchGrid, plotList, editableGrid }
        };
        setContent(grid);
    }
    void bind() {
        plotList.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(viewModel.Editables)));
        plotList.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(viewModel.Selected)));

        var binding = new Binding(nameof(viewModel.IsOnEdit));
        name.SetBinding(ComboText.IsOnEditProperty, binding);
        description.SetBinding(ComboText.IsOnEditProperty, binding);
        buttons.SetBinding(ComboButton.IsOnEditProperty, binding);

        search.SetBinding(EditText.TextProperty, new Binding(nameof(viewModel.FilterName)) { Mode = BindingMode.OneWayToSource });
        counter.SetBinding(CountBlock.CountProperty, new Binding("Items.Count") { Source = plotList });
    }
}

