﻿class ReportCurrentMonth : CardView
{
    public static double Top { get; set; }
    public static double Left { get; set; }
    public new static double Width { get; set; }
    public new static double Height { get; set; }

    ListBox list;
    MultiState state;
    CommandButton refresh;
    Border header, footer;
    TextBlock totalDue, totalLastDue, totalPaid, totalEntry;
    Run entryCount;
    ReportCurrentMonthVM vm;
    public ReportCurrentMonth() {
        vm = new ReportCurrentMonthVM();
        DataContext = vm;
        Header = vm.Month;
        initializeUI();
        bind();
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }
    void onLoaded(object sender, RoutedEventArgs e) {
        App.Current.MainWindow.LocationChanged += onRelocate;
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
        App.Current.MainWindow.LocationChanged -= onRelocate;
    }
    void initializeHeader() {
        var particulars = new TextBlock() { Text = "Particulars", VerticalAlignment = VerticalAlignment.Center };
        var date = new TextBlock() { Text = "Paid on", HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
        var due = new TextBlock() { Text = "Due", HorizontalAlignment = HorizontalAlignment.Right };
        var lastDue = new TextBlock() { Text = "Charge", HorizontalAlignment = HorizontalAlignment.Right };
        var payment = new TextBlock() { Text = "Receipt", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center };

        Grid.SetColumn(date, 1);
        Grid.SetColumn(due, 2);
        Grid.SetColumn(lastDue, 3);
        Grid.SetColumn(payment, 4);

        var grid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(80) },
                new ColumnDefinition(){ Width = new GridLength(70) },
                new ColumnDefinition(){ Width = new GridLength(70) },
                new ColumnDefinition(){ Width = new GridLength(70) }
            },
            Children = { particulars, date, due, lastDue, payment }
        };

        header = new Border() {
            Padding = new Thickness(4, 2, 5, 2),
            Margin = new Thickness(0, 0, Constants.ScrollBarThickness, 0),
            BorderThickness = new Thickness(0, 0, 0, 1),
            BorderBrush = Brushes.LightGray,
            Child = grid
        };
        header.Resources.Add(typeof(TextBlock), new Style() {
            Setters = {
                    new Setter(TextBlock.FontWeightProperty, FontWeights.Bold)
                }
        });
    }
    void initializeFooter() {
        entryCount = new Run();
        totalEntry = new TextBlock() { Inlines = { "Total of ", entryCount } };
        totalDue = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        totalLastDue = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        totalPaid = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };

        Grid.SetColumn(totalDue, 1);
        Grid.SetColumn(totalLastDue, 2);
        Grid.SetColumn(totalPaid, 3);

        var grid = new Grid() {
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) }
                },
            Children = { totalEntry, totalDue, totalLastDue, totalPaid }
        };
        footer = new Border() {
            Margin = new Thickness(0, 0, Constants.ScrollBarThickness, 0),
            Padding = new Thickness(4, 2, 5, 2),
            BorderThickness = new Thickness(0, 1, 0, 1),
            BorderBrush = Brushes.LightGray,
            Child = grid
        };
        footer.Resources.Add(typeof(TextBlock), new Style() {
            Setters = {
                    new Setter(TextBlock.FontWeightProperty, FontWeights.Bold)
                }
        });
    }

    void initializeUI() {
        state = new MultiState() {
            Texts = new string[] { "All", "Paid", "Due" },
            Icons = new string[] { Icons.All, Icons.Checked, Icons.CloseCircle }
        };
        refresh = new CommandButton() {
            Icon = Icons.Refresh,
            Command = () => { vm.Refresh(); Header = vm.Month; },
            Margin = new Thickness(5, 0, 0, 0),
            ToolTip = "Refresh"
        };
        addAction(new UIElement[] { state, refresh });
        list = new ListBox() {
            Margin = new Thickness(0, 5, 0, 0),
            ItemTemplate = new CurrentMonthTemplate(),
            GroupStyle = {
                new GroupStyle() {
                    ContainerStyle = new Style(typeof(GroupItem)) {
                        Setters = {
                            new Setter(GroupItem.TemplateProperty, new GroupedCurrentMonthTemplate())
                        }
                    }
                }
            },
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate(false)),
                        }
                    }
                }
            }
        };
        initializeHeader();
        initializeFooter();
        Grid.SetRow(list, 1);
        Grid.SetRow(footer, 2);
        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(),
                new RowDefinition(){Height = GridLength.Auto}
            },
            Children = { header, list, footer }
        };
        setContent(grid);
    }

    void bind() {
        list.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Payments)));
        state.SetBinding(MultiState.StateProperty, new Binding(nameof(vm.State)));
        entryCount.SetBinding(Run.TextProperty, new Binding(nameof(vm.TotalEntry)) { StringFormat = "N0" });
        totalDue.SetBinding(TextBlock.TextProperty, new Binding(nameof(vm.TotalDue)) { StringFormat = Constants.NumberFormat });
        totalLastDue.SetBinding(TextBlock.TextProperty, new Binding(nameof(vm.TotalLastDue)) { StringFormat = Constants.NumberFormat });
        totalPaid.SetBinding(TextBlock.TextProperty, new Binding(nameof(vm.TotalPaid)) { StringFormat = Constants.NumberFormat });
    }

    void onRelocate(object? sender, EventArgs e) => updatePosition();
    protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo) {
        base.OnRenderSizeChanged(sizeInfo);
        updatePosition();
    }
    void updatePosition() {
        var dpi = VisualTreeHelper.GetDpi(this);
        var topLeft = base.card.TransformToAncestor(this).Transform(new Point(0, 0));
        var position = PointToScreen(topLeft);

        position.X /= dpi.DpiScaleX;
        position.Y /= dpi.DpiScaleY;

        Top = position.Y;
        Left = position.X;
        Width = base.card.ActualWidth;
        Height = base.card.ActualHeight;
    }
}
