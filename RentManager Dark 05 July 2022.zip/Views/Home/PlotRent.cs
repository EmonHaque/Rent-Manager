﻿class PlotRent : CardView
{
    public override string Header => "Charge & Collections";

    MultiLineChart chart;
    ActionButton refresh;
    BiState state;
    PlotRentVM viewModel;
    public PlotRent() {
        viewModel = new PlotRentVM();
        DataContext = viewModel;
        initializeUI();
        bind();
    }
    void refreshCommand() {
        if (BusyWindow.IsOpened) return;
        var position = PointToScreen(new Point(0, 0));
        var dpi = VisualTreeHelper.GetDpi(this);
        position.X /= dpi.DpiScaleX;
        position.Y /= dpi.DpiScaleY;
        position.X += Constants.CardMargin.Left;
        position.Y += Constants.CardMargin.Top;
        var width = ActualWidth - Constants.CardMargin.Left - Constants.CardMargin.Right;
        var height = ActualHeight - Constants.CardMargin.Top - Constants.CardMargin.Bottom;

        BusyWindow.Activate(position.X, position.Y, width, height, "Reloading ...");
        viewModel.Refresh.Invoke();
        BusyWindow.Terminate();
    }

    void initializeUI() {
        state = new BiState() {
            IsTrue = true,
            Text = "All",
            Margin = new Thickness(0, 0, 5, 0)
        };
        refresh = new ActionButton() {
            Command = refreshCommand,
            Icon = Icons.Refresh,
            ToolTip = "Reload"
        };
        addAction(new UIElement[] { state, refresh });
        chart = new MultiLineChart();
        setContent(chart);
    }
    void bind() {
        chart.SetBinding(MultiLineChart.ItemsSourceProperty, new Binding(nameof(viewModel.Data)));
        state.SetBinding(BiState.IsTrueProperty, new Binding(nameof(viewModel.State)));
    }
}
