﻿class BusyWindow : Window
{
    Path arc;
    PointAnimationUsingPath pointAnim;
    BooleanAnimationUsingKeyFrames isLargeAnim;
    TextBlock text;
    static BusyWindow window;
    static bool isMaximized;
    public static bool IsOpened;
    BusyWindow(double width, double height, string message) {
        Width = width;
        Height = height;
        WindowStyle = WindowStyle.None;
        ResizeMode = ResizeMode.NoResize;
        AllowsTransparency = true;
        ShowInTaskbar = false;
        Background = new SolidColorBrush(Color.FromArgb(127, 0, 0, 0));
        WindowChrome.SetWindowChrome(this, new WindowChrome() {
            GlassFrameThickness = new Thickness(0),
            CornerRadius = new CornerRadius(7),
            ResizeBorderThickness = new Thickness(0)
        });

        initializeContent(message);
        initializeAnimations();
        Loaded += onLoaded;
    }
    BusyWindow(double left, double top, double width, double height, string message) : this(width, height, message) {
        Left = left;
        Top = top;
    }

    void onLoaded(object sender, RoutedEventArgs e) {
        var segment = (ArcSegment)((PathGeometry)arc.Data).Figures[0].Segments[0];
        segment.BeginAnimation(ArcSegment.PointProperty, pointAnim);
        segment.BeginAnimation(ArcSegment.IsLargeArcProperty, isLargeAnim);
    }
    void initializeAnimations() {
        pointAnim = new PointAnimationUsingPath() {
            PathGeometry = PathGeometry.CreateFromGeometry(arc.Data),
            Duration = TimeSpan.FromSeconds(2),
            AccelerationRatio = 0.5,
            DecelerationRatio = 0.5,
            RepeatBehavior = RepeatBehavior.Forever
        };
        isLargeAnim = new BooleanAnimationUsingKeyFrames() {
            KeyFrames = {
                    new DiscreteBooleanKeyFrame(false, TimeSpan.FromSeconds(0)),
                    new DiscreteBooleanKeyFrame(true, TimeSpan.FromSeconds(1)),
                    new DiscreteBooleanKeyFrame(false, TimeSpan.FromSeconds(2))
                },
            RepeatBehavior = RepeatBehavior.Forever
        };
    }
    void initializeContent(string message) {
        var center = new Point(Width / 2, Height / 2);
        if (isMaximized) {
            var dpi = VisualTreeHelper.GetDpi(this);
            center.X /= dpi.DpiScaleX;
            center.Y /= dpi.DpiScaleY;
        }
        var start = new Point(center.X + 149, center.Y);
        var end = new Point(center.X + 149, center.Y - 0.1);

        var ellipse = new Path() {
            Fill = new SolidColorBrush(Color.FromRgb(50, 50, 50)),
            Data = new EllipseGeometry() {
                Center = center,
                RadiusX = 150,
                RadiusY = 150
            }
        };
        arc = new Path() {
            Stroke = Brushes.Coral,
            StrokeThickness = 5,
            Data = new PathGeometry() {
                Figures = {
                        new PathFigure() {
                            StartPoint = start,
                            Segments = {
                                new ArcSegment() {
                                    IsLargeArc = true,
                                    Point = end,
                                    Size = new Size(148,148),
                                    SweepDirection = SweepDirection.Clockwise
                                }
                            }
                        }
                    }
            }
        };
        text = new TextBlock() {
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center,
            FontSize = 36,
            Foreground = Brushes.Coral,
            Text = message
        };
        Content = new Grid() { Children = { ellipse, text, arc } };
    }

    public static void Activate(double left, double top, double width, double height, string message) {
        App.Current.MainWindow.IsEnabled = false;
        isMaximized = false;
        var thread = new Thread(() => {
            window = new BusyWindow(left, top, width, height, message);
            window.Show();
            Dispatcher.Run();
        });
        thread.SetApartmentState(ApartmentState.STA);
        thread.Start();
        IsOpened = true;
        Thread.Sleep(1000);
    }
    public static void Activate(string message) {
        double left, top, width, height;
        if (App.Current.MainWindow.WindowState == WindowState.Maximized) {
            var screen = System.Windows.Forms.Screen.FromHandle(new System.Windows.Interop.WindowInteropHelper(App.Current.MainWindow).Handle);
            left = screen.WorkingArea.Left;
            top = screen.WorkingArea.Top;
            width = screen.WorkingArea.Width;
            height = screen.Bounds.Height;
            isMaximized = true;
        }
        else {
            left = App.Current.MainWindow.Left;
            top = App.Current.MainWindow.Top;
            width = App.Current.MainWindow.Width;
            height = App.Current.MainWindow.Height;
            isMaximized = false;
        }

        App.Current.MainWindow.IsEnabled = false;
        var thread = new Thread(() => {
            window = new BusyWindow(width, height, message) {
                Left = left,
                Top = top
            };
            window.Show();
            Dispatcher.Run();
        });
        thread.SetApartmentState(ApartmentState.STA);
        thread.Start();
        IsOpened = true;
        Thread.Sleep(1000);
    }
    public static void Terminate() {
        while (window == null) { }
        App.Current.Dispatcher.Invoke(() => {
            App.Current.MainWindow.IsEnabled = true;
        });
        window.Dispatcher.Invoke(window.Close);
    }
    protected override void OnClosed(EventArgs e) {
        Loaded -= onLoaded;
        IsOpened = false;
        window.Dispatcher.InvokeShutdown();
        window = null;
    }
}
