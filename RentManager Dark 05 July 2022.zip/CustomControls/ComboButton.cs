﻿class ComboButton : Grid
{
    CommandButton edit, cancel, save;
    public Action EditCommand { get; set; }
    public Action SaveCommand { get; set; }
    public Action CancelCommand { get; set; }
    public string IsValid { get; set; }
    public ComboButton() {
        Margin = new Thickness(5);
        edit = new CommandButton() {
            Icon = Icons.Edit,
            HorizontalAlignment = HorizontalAlignment.Right,
            Width = 16,
            Height = 16
        };
        save = new CommandButton() {
            Icon = Icons.Save,
            HorizontalAlignment = HorizontalAlignment.Left,
            Visibility = Visibility.Hidden,
            Width = 16,
            Height = 16
        };
        cancel = new CommandButton() {
            Icon = Icons.Cancel,
            HorizontalAlignment = HorizontalAlignment.Right,
            Visibility = Visibility.Hidden,
            Width = 16,
            Height = 16
        };
        Children.Add(edit);
        Children.Add(cancel);
        Children.Add(save);
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }

    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
    }
    void onLoaded(object sender, RoutedEventArgs e) {
        edit.Command = EditCommand;
        save.Command = SaveCommand;
        cancel.Command = CancelCommand;
        if (IsValid != null)
            save.SetBinding(IsEnabledProperty, new Binding(IsValid));
    }

    public bool IsOnEdit {
        get { return (bool)GetValue(IsOnEditProperty); }
        set { SetValue(IsOnEditProperty, value); }
    }
    public static readonly DependencyProperty IsOnEditProperty =
        DependencyProperty.Register("IsOnEdit", typeof(bool), typeof(ComboButton), new PropertyMetadata() {
            DefaultValue = false,
            PropertyChangedCallback = (s, e) => {
                var o = (ComboButton)s;
                if ((bool)e.NewValue) {
                    o.cancel.Visibility = Visibility.Visible;
                    o.save.Visibility = Visibility.Visible;
                    o.edit.Visibility = Visibility.Hidden;
                }
                else {
                    o.cancel.Visibility = Visibility.Hidden;
                    o.save.Visibility = Visibility.Hidden;
                    o.edit.Visibility = Visibility.Visible;
                }
            }
        });
}
