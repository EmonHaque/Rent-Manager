﻿class GroupedLeaseTemplate : ControlTemplate
{
    public GroupedLeaseTemplate(string queryProperty, object viewModel) {
        TargetType = typeof(GroupItem);
        var grid = new FrameworkElementFactory(typeof(Grid));
        var row1 = new FrameworkElementFactory(typeof(RowDefinition));
        var row2 = new FrameworkElementFactory(typeof(RowDefinition));
        var headerPanel = new FrameworkElementFactory(typeof(StackPanel));
        var plotName = new FrameworkElementFactory(typeof(HiBlock));
        var count = new FrameworkElementFactory(typeof(CountBlock));
        var items = new FrameworkElementFactory(typeof(ItemsPresenter));

        row1.SetValue(RowDefinition.HeightProperty, new GridLength(1, GridUnitType.Auto));
        headerPanel.SetValue(StackPanel.OrientationProperty, Orientation.Horizontal);
        items.SetValue(Grid.RowProperty, 1);
        items.SetValue(ItemsPresenter.MarginProperty, new Thickness(10, 0, 0, 0));
        plotName.SetBinding(HiBlock.TextProperty, new Binding("Name") { Mode = BindingMode.OneWay });
        plotName.SetBinding(HiBlock.QueryProperty, new Binding(queryProperty) { Source = viewModel, IsAsync = true });
        plotName.SetValue(HiBlock.FontWeightProperty, FontWeights.Bold);
        plotName.SetValue(HiBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
        count.SetValue(CountBlock.MarginProperty, new Thickness(5, 0, 0, 0));
        count.SetBinding(CountBlock.CountProperty, new Binding("Items.Count") { Mode = BindingMode.OneWay });

        headerPanel.AppendChild(plotName);
        headerPanel.AppendChild(count);
        grid.AppendChild(row1);
        grid.AppendChild(row2);
        grid.AppendChild(headerPanel);
        grid.AppendChild(items);
        VisualTree = grid;
    }
}
