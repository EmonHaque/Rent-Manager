﻿class GroupedSpaceTemplate : ControlTemplate
{
    public GroupedSpaceTemplate(string queryProperty, object viewModel) {
        TargetType = typeof(GroupItem);
        var grid = new FrameworkElementFactory(typeof(Grid));
        var row1 = new FrameworkElementFactory(typeof(RowDefinition));
        var row2 = new FrameworkElementFactory(typeof(RowDefinition));
        var headerBorder = new FrameworkElementFactory(typeof(Border));
        var header = new FrameworkElementFactory(typeof(HiBlock));
        var items = new FrameworkElementFactory(typeof(ItemsPresenter));

        row1.SetValue(RowDefinition.HeightProperty, GridLength.Auto);
        headerBorder.SetValue(Border.BorderThicknessProperty, new Thickness(0, 0, 0, 1));
        headerBorder.SetValue(Border.BorderBrushProperty, Brushes.LightBlue);
        header.SetValue(HiBlock.FontWeightProperty, FontWeights.Bold);
        header.SetValue(HiBlock.MarginProperty, new Thickness(5, 0, 0, 0));
        items.SetValue(Grid.RowProperty, 1);
        items.SetValue(ItemsPresenter.MarginProperty, new Thickness(10, 0, 0, 0));
        header.SetBinding(HiBlock.TextProperty, new Binding(nameof(GroupItem.Name)));
        header.SetBinding(HiBlock.QueryProperty, new Binding(queryProperty) { Source = viewModel, IsAsync = true });
        headerBorder.AppendChild(header);
        grid.AppendChild(row1);
        grid.AppendChild(row2);
        grid.AppendChild(headerBorder);
        grid.AppendChild(items);
        VisualTree = grid;
    }
}
