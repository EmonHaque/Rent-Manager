﻿class GroupedCurrentMonthTemplate : ControlTemplate
{
    public GroupedCurrentMonthTemplate() {
        TargetType = typeof(GroupItem);
        var grid = new FrameworkElementFactory(typeof(Grid));
        var row1 = new FrameworkElementFactory(typeof(RowDefinition));
        var row2 = new FrameworkElementFactory(typeof(RowDefinition));
        var row3 = new FrameworkElementFactory(typeof(RowDefinition));
        var headerStack = new FrameworkElementFactory(typeof(StackPanel));
        var plotName = new FrameworkElementFactory(typeof(TextBlock));
        var tenantCount = new FrameworkElementFactory(typeof(CountBlock));
        var items = new FrameworkElementFactory(typeof(ItemsPresenter));
        var footer = new FrameworkElementFactory(typeof(ContentControl));

        row1.SetValue(RowDefinition.HeightProperty, GridLength.Auto);
        row3.SetValue(RowDefinition.HeightProperty, GridLength.Auto);
        items.SetValue(Grid.RowProperty, 1);
        footer.SetValue(Grid.RowProperty, 2);
        items.SetValue(ItemsPresenter.MarginProperty, new Thickness(10, 0, 5, 0));
        footer.SetValue(ContentControl.MarginProperty, new Thickness(0, 0, 5, 0));
        footer.SetValue(ContentControl.ContentTemplateProperty, new CurrentMonthSummaryTemplate());
        plotName.SetValue(TextBlock.FontWeightProperty, FontWeights.Bold);
        plotName.SetValue(TextBlock.FontSizeProperty, 13d);
        plotName.SetValue(TextBlock.ForegroundProperty, Brushes.Gray);
        plotName.SetValue(TextBlock.MarginProperty, new Thickness(0, 0, 5, 0));
        plotName.SetBinding(TextBlock.TextProperty, new Binding(nameof(GroupItem.Name)) { Mode = BindingMode.OneWay });
        tenantCount.SetBinding(CountBlock.CountProperty, new Binding(nameof(CollectionViewGroup.ItemCount)) { Mode = BindingMode.OneWay });
        footer.SetBinding(ContentControl.ContentProperty, new Binding() { Converter = Converters.currentMonth2Summary });

        headerStack.SetValue(StackPanel.OrientationProperty, Orientation.Horizontal);
        headerStack.AppendChild(plotName);
        headerStack.AppendChild(tenantCount);

        grid.AppendChild(row1);
        grid.AppendChild(row2);
        grid.AppendChild(row3);
        grid.AppendChild(headerStack);
        grid.AppendChild(items);
        grid.AppendChild(footer);

        VisualTree = grid;
    }
}
