﻿class TenantTemplate : DataTemplate
{
    public TenantTemplate(string queryProperty, object viewModel, bool hasTrigger = false) {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var name = new FrameworkElementFactory(typeof(HiBlock));
        var phone = new FrameworkElementFactory(typeof(TextBlock));
        col2.SetValue(ColumnDefinition.WidthProperty, GridLength.Auto);
        phone.SetValue(Grid.ColumnProperty, 1);
        name.SetBinding(HiBlock.TextProperty, new Binding(nameof(Tenant.Name)) { Mode = BindingMode.TwoWay });
        name.SetBinding(HiBlock.QueryProperty, new Binding(queryProperty) { Source = viewModel, IsAsync = true });
        phone.SetBinding(TextBlock.TextProperty, new Binding(nameof(Tenant.ContactNo)));
        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(name);
        grid.AppendChild(phone);
        if (hasTrigger) {
            if (viewModel is not EditLeaseVM) {
                Triggers.Add(new DataTrigger() {
                    Binding = new Binding(nameof(Tenant.HasLeft)),
                    Value = true,
                    Setters = {
                            new Setter(TextElement.ForegroundProperty, Brushes.Gray),
                            new Setter(TextElement.FontStyleProperty, FontStyles.Italic),
                        }
                });
            }
            else {
                Triggers.Add(new MultiDataTrigger() {
                    Conditions = {
                            new Condition(new Binding("FilterState"){ Source = viewModel }, null),
                            new Condition(new Binding(nameof(Tenant.HasLeft)), true),
                        },
                    Setters = {
                            new Setter(TextElement.ForegroundProperty, Brushes.Gray),
                            new Setter(TextElement.FontStyleProperty, FontStyles.Italic),
                        }
                });
            }
        }
        VisualTree = grid;
    }
}
