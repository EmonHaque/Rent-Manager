﻿class HomeDueTemplate : DataTemplate
{
    public HomeDueTemplate(HomePlotDueTip tip) {
        var grid = new FrameworkElementFactory(typeof(Grid)) { Name = "grid" };
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var tenant = new FrameworkElementFactory(typeof(HiBlock));
        var amount = new FrameworkElementFactory(typeof(TextBlock));
        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
        amount.SetValue(Grid.ColumnProperty, 1);
        amount.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
        amount.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        tenant.SetValue(HiBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
        tenant.SetBinding(HiBlock.TextProperty, new Binding(nameof(PlotWiseDue.Tenant)));
        tenant.SetBinding(HiBlock.QueryProperty, new Binding(nameof(tip.Query)) { Source = tip });
        amount.SetBinding(TextBlock.TextProperty, new Binding(nameof(PlotWiseDue.Due)) { StringFormat = Constants.NumberFormat });
        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(tenant);
        grid.AppendChild(amount);

        VisualTree = grid;
        Triggers.Add(new Trigger() {
            Property = ItemsControl.AlternationIndexProperty,
            Value = 1,
            Setters = {
                    new Setter(Grid.BackgroundProperty, Constants.BackgroundDark, "grid")
                }
        });
    }
}
