﻿using RentManager.Abstracts;
using System;
using System.Collections.ObjectModel;

namespace RentManager.Models
{
    public class Lease : Notifiable
	{
        public int Id { get; set; }
        int? plotId;
        public int? PlotId {
            get { return plotId; }
            set {
                if (plotId != value) {
                    plotId = value;
                    OnPropertyChanged(nameof(PlotId));
                }
            }
        }
        int? spaceId;
        public int? SpaceId {
            get { return spaceId; }
            set {
                if (spaceId != value) {
                    spaceId = value;
                    OnPropertyChanged(nameof(SpaceId));
                }
            }
        }
        int? tenantId;
        public int? TenantId {
            get { return tenantId; }
            set {
                if (tenantId != value) {
                    tenantId = value;
                    OnPropertyChanged(nameof(TenantId));
                }
            }
        }
        DateTime? dateStart;
        public DateTime? DateStart {
            get { return dateStart; }
            set {
                if (dateStart != value) {
                    dateStart = value;
                    OnPropertyChanged(nameof(DateStart));
                }
            }
        }
        DateTime? dateEnd;
        public DateTime? DateEnd {
            get { return dateEnd; }
            set {
                if (dateEnd != value) {
                    dateEnd = value;
                    OnPropertyChanged(nameof(DateEnd));
                }
            }
        }

        string business;
        public string Business {
            get { return business; }
            set {
                if (business != value) {
                    business = value;
                    OnPropertyChanged(nameof(Business));
                }
            }
        }
        private bool isExpired;

        public bool IsExpired {
            get { return isExpired; }
            set {
                if (isExpired != value) {
                    isExpired = value;
                    OnPropertyChanged(nameof(IsExpired));
                }
            }
        }
        ObservableCollection<Receivable> fixedReceivables;
        public ObservableCollection<Receivable> FixedReceivables {
            get { return fixedReceivables; }
            set {
                if (fixedReceivables != value) {
                    fixedReceivables = value;
                    OnPropertyChanged(nameof(FixedReceivables));
                }
            }
        }
        string plotName;
        public string PlotName {
            get { return plotName; }
            set {
                if (plotName != value) {
                    plotName = value;
                    OnPropertyChanged(nameof(PlotName));
                }
            }
        }
        string spaceName;
        public string SpaceName {
            get { return spaceName; }
            set {
                if (spaceName != value) {
                    spaceName = value;
                    OnPropertyChanged(nameof(SpaceName));
                }
            }
        }
        string tenantName;
        public string TenantName {
            get { return tenantName; }
            set {
                if (tenantName != value) {
                    tenantName = value;
                    OnPropertyChanged(nameof(TenantName));
                }
            }
        }

        public Lease() {
            App.Current.Dispatcher.Invoke(() => FixedReceivables = new ObservableCollection<Receivable>());
        }
    }
}
