﻿using RentManager.Abstracts;

namespace RentManager.Models
{
    public class Tenant : Notifiable
    {
        public int? Id { get; set; }
        string name;
        public string Name {
            get { return name; }
            set {
                if (name != value) {
                    name = value;
                    OnPropertyChanged(nameof(Name));
                }
            }
        }
        string father;
        public string Father {
            get { return father; }
            set {
                if (father != value) {
                    father = value;
                    OnPropertyChanged(nameof(Father));
                }
            }
        }
        string mother;
        public string Mother {
            get { return mother; }
            set {
                if (mother != value) {
                    mother = value;
                    OnPropertyChanged(nameof(Mother));
                }
            }
        }
        string husband;
        public string Husband {
            get { return husband; }
            set {
                if (husband != value) {
                    husband = value;
                    OnPropertyChanged(nameof(Husband));
                }
            }
        }
        string address;
        public string Address {
            get { return address; }
            set {
                if (address != value) {
                    address = value;
                    OnPropertyChanged(nameof(Address));
                }
            }
        }
        string nid;
        public string NID {
            get { return nid; }
            set {
                if (nid != value) {
                    nid = value;
                    OnPropertyChanged(nameof(NID));
                }
            }
        }
        string contactNo;
        public string ContactNo {
            get { return contactNo; }
            set {
                if (contactNo != value) {
                    contactNo = value;
                    OnPropertyChanged(nameof(ContactNo));
                }
            }
        }
        bool hasLeft;
        public bool HasLeft {
            get { return hasLeft; }
            set {
                if (hasLeft != value) {
                    hasLeft = value;
                    OnPropertyChanged(nameof(HasLeft));
                }
            }
        }
    }
}
