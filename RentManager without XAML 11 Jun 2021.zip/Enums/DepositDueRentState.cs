﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentManager.Enums
{
    enum DepositDueRentState
    {
        Rent,
        Deposit,
        Due
    }
}
