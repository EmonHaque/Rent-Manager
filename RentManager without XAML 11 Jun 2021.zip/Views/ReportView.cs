﻿using RentManager.Abstracts;
using RentManager.CustomControls;
using RentManager.Helpers;
using RentManager.Views.Report;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace RentManager.Views
{
    class ReportView : ViewContainer
    {
        override public string Icon => Icons.Ledger;
        public ReportView() {
            Children.Add(new ReportPlot());
            Children.Add(new ReportSpace());
            Children.Add(new ReportTenant());
            Children.Add(new ReportBalance());
            Children.Add(new ReportRPs());
        }
    }
}
