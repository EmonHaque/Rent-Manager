﻿using RentManager.Abstracts;
using RentManager.Helpers;
using RentManager.Views.Transact;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace RentManager.Views
{
    class TransactionView : View
    {
        public override string Icon => Icons.Transact;
        public override FrameworkElement container => grid;
        Grid grid;
        public TransactionView() : base() {
            var rent = new BulkRentTransaction();
            var regular = new RegularTransaction();
            Grid.SetColumn(regular, 1);
            grid = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(){Width = new GridLength(3, GridUnitType.Star)},
                    new ColumnDefinition(){Width = new GridLength(4, GridUnitType.Star)},
                },
                Children = {rent, regular }
            };
            AddVisualChild(grid);
        }
    }
}
