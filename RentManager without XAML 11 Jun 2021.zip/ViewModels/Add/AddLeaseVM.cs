﻿using Microsoft.Data.Sqlite;
using RentManager.Helpers;
using RentManager.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows.Data;
using System.Windows.Input;

namespace RentManager.ViewModels.Add
{
    public class AddLeaseVM : AddBase<Lease>
    {
        public string ErrorPlotId { get; set; }
        public string ErrorSpaceId { get; set; }
        public string ErrorTenantId { get; set; }
        public string ErrorBusiness { get; set; }
        public string ErrorDate { get; set; }
        public string ErrorAmount { get; set; }
        public string ErrorHeadId { get; set; }
        public string ErrorCharge { get; set; }
        public bool IsValid { get; set; }
        public bool IsReceivableValid { get; set; }

        public Receivable NewReceivable { get; set; }
        public ICollectionView Plots { get; set; }
        public ICollectionView VacantSpaces { get; set; }
        public ICollectionView AvailableTenants { get; set; }
        public ICollectionView ReceivableHeads { get; set; }
        public Action AddReceivable { get; set; }
        public Action<Receivable> RemoveReceivable { get; set; }
        public static event Action<Lease> LeaseAdded;

        string plotQuery;
        public string PlotQuery {
            get { return plotQuery; }
            set {
                if (plotQuery != value) {
                    plotQuery = value?.Trim().ToLower();
                    Plots.Refresh();
                }
            }
        }
        string spaceQuery;
        public string SpaceQuery {
            get { return spaceQuery; }
            set {
                if (spaceQuery != value) {
                    spaceQuery = value?.Trim().ToLower();
                    VacantSpaces.Refresh();
                }
            }
        }
        string tenantQuery;
        public string TenantQuery {
            get { return tenantQuery; }
            set {
                if (tenantQuery != value) {
                    tenantQuery = value?.Trim().ToLower();
                    AvailableTenants.Refresh();
                }
            }
        }
        string headQuery;
        public string HeadQuery {
            get { return headQuery; }
            set {
                if (headQuery != value) {
                    headQuery = value?.Trim().ToLower();
                    ReceivableHeads.Refresh();
                }
            }
        }
        string amount;
        public string Amount {
            get { return amount; }
            set {if (amount != value) {
                    amount = value;
                    OnPropertyChanged(nameof(Amount));
                    validateAmount();
                }
            }
        }

        public AddLeaseVM() : base() {
            initializeCollections();
            TObject.PropertyChanged += validate;
            TObject.Id = ++AppData.maxLeaseId;
            NewReceivable = new Receivable() { LeaseId = TObject.Id };
            initializeFilters();
            AddReceivable = addReceivable;
            RemoveReceivable = removeReceivable;
            NewReceivable.PropertyChanged += validateReceivable;
            initializeValidationProperties();
        }

        void initializeValidationProperties() {
            IsValid = IsReceivableValid = false;
            ErrorPlotId = ErrorSpaceId = ErrorTenantId = ErrorHeadId = ErrorCharge = ErrorDate = " is required";
            ErrorBusiness = "Business is required";
            ErrorAmount = "Amount is required";
        }

        #region validation rules
        void validate(object sender, PropertyChangedEventArgs e) {
            switch (e.PropertyName) {
                case nameof(Lease.PlotId): validatePlotId(); break;
                case nameof(Lease.SpaceId): validateSpaceId(); break;
                case nameof(Lease.TenantId): validateTenantId(); break;
                case nameof(Lease.Business): validateBusiness(); break;
                case nameof(Lease.DateStart): validateDate(); break;
            }
            checkValidity();
        }
        void validateReceivable(object sender, PropertyChangedEventArgs e) {
            switch (e.PropertyName) {
                case nameof(Receivable.Amount):
                case nameof(Receivable.HeadId): validateHead(); break;
            }
            IsReceivableValid =
                ErrorHeadId == string.Empty &&
                ErrorAmount == string.Empty
                ? true : false;
            OnPropertyChanged(nameof(IsReceivableValid));
        }
        void validatePlotId() {
            ErrorPlotId = string.Empty;
            if (TObject.PlotId == null) 
                ErrorPlotId = " is required";
            OnPropertyChanged(nameof(ErrorPlotId));

            VacantSpaces.Refresh();
            TObject.SpaceId = (VacantSpaces.CurrentItem as Space)?.Id;
        }
        void validateSpaceId() {
            ErrorSpaceId = string.Empty;
            if (TObject.SpaceId == null) 
                ErrorSpaceId = " is required";
            OnPropertyChanged(nameof(ErrorSpaceId));
        }
        void validateTenantId() {
            ErrorTenantId = string.Empty;
            if (TObject.TenantId == null) 
                ErrorTenantId = " is required";
            OnPropertyChanged(nameof(ErrorTenantId));
        }
        void validateBusiness() {
            ErrorBusiness = string.Empty;
            if (string.IsNullOrWhiteSpace(TObject.Business)) 
                ErrorBusiness = "Business is required";
            OnPropertyChanged(nameof(ErrorBusiness));
        }
        void validateDate() {
            ErrorDate = string.Empty;
            if (TObject.DateStart == null)
                ErrorDate = " is required";
            OnPropertyChanged(nameof(ErrorDate));
        }
        void validateHead() {
            ErrorHeadId = string.Empty;
            if (NewReceivable.HeadId == null)
                ErrorHeadId = " is required";
            OnPropertyChanged(nameof(ErrorHeadId));
        }
        void validateAmount() {
            ErrorAmount = string.Empty;
            if (string.IsNullOrWhiteSpace(Amount))
                ErrorAmount = "Amount in required";
            else {
                int x;
                if(int.TryParse(Amount, out x)) {
                    if(x > 0) {
                        NewReceivable.Amount = x;
                        ErrorAmount = string.Empty;
                    }
                    else ErrorAmount = "Positive integers only";
                }
                else ErrorAmount = "Integer only";
            }
            OnPropertyChanged(nameof(ErrorAmount));

            IsReceivableValid =
                ErrorHeadId == string.Empty &&
                ErrorAmount == string.Empty
                ? true : false;
            OnPropertyChanged(nameof(IsReceivableValid));
        }
        void checkValidity() {
            IsValid =
                ErrorPlotId == string.Empty &&
                ErrorSpaceId == string.Empty &&
                ErrorTenantId == string.Empty &&
                ErrorDate == string.Empty &&
                ErrorBusiness == string.Empty &&
                ErrorCharge == string.Empty;
            OnPropertyChanged(nameof(IsValid));
        }
        #endregion

        #region For Constructor
        void initializeCollections() {
            Plots = new CollectionViewSource() { Source = AppData.plots }.View;
            VacantSpaces = new CollectionViewSource() {
                Source = AppData.spaces,
                IsLiveFilteringRequested = true,
                LiveFilteringProperties = { nameof(Space.IsVacant), nameof(Space.PlotId) }
            }.View;

            AvailableTenants = new CollectionViewSource() {
                Source = AppData.tenants,
                IsLiveFilteringRequested = true,
                LiveFilteringProperties = { nameof(Tenant.HasLeft) }
            }.View;
            ReceivableHeads = new CollectionViewSource() { Source = AppData.heads }.View;
        }

        void initializeFilters() {
            Plots.Filter = filterPlots;
            VacantSpaces.Filter = filterSpaces;
            AvailableTenants.Filter = filterTenant;
            ReceivableHeads.Filter = filterReceivableHeads;
        }
        #endregion

        #region Commands
        void addReceivable() {
            NewReceivable.PropertyChanged -= validateReceivable;
            TObject.FixedReceivables.Add(NewReceivable);
            var head = ReceivableHeads.CurrentItem as Head;
            NewReceivable = new Receivable() {
                HeadId = head == null ? 0 : head.Id,
                LeaseId = TObject.Id
            };
            NewReceivable.PropertyChanged += validateReceivable;
            OnPropertyChanged(nameof(NewReceivable));

            Amount = null;
            if (ErrorCharge != string.Empty) {
                ErrorCharge = string.Empty;
                OnPropertyChanged(nameof(ErrorCharge));
                checkValidity();
            }
            ReceivableHeads.Refresh();
            if(ReceivableHeads.CurrentItem != null) {
                NewReceivable.HeadId = ((Head)ReceivableHeads.CurrentItem).Id;
            }
        }
        void removeReceivable(Receivable receivable) {
            TObject.FixedReceivables.Remove(receivable);
            ReceivableHeads.Refresh();
            if (ReceivableHeads.CurrentItem == null)
                ReceivableHeads.MoveCurrentToFirst();
            if (TObject.FixedReceivables.Count == 0) {
                ErrorCharge = " is required";
                OnPropertyChanged(nameof(ErrorCharge));
                checkValidity();
            }
        }
        #endregion

        #region Filters
        bool filterPlots(object o) {
            if (string.IsNullOrWhiteSpace(PlotQuery)) return true;
            return ((Plot)o).Name.ToLower().Contains(PlotQuery);
        }
        bool filterSpaces(object o) {
            if (TObject.PlotId == null) return false;
            var space = o as Space;
            var result = space.IsVacant && space.PlotId == TObject.PlotId;
            if (string.IsNullOrWhiteSpace(SpaceQuery)) return result;
            return space.Name.ToLower().Contains(SpaceQuery) && result;
        }
        bool filterTenant(object o) {
            var tenant = o as Tenant;
            if (string.IsNullOrWhiteSpace(TenantQuery)) return !tenant.HasLeft;
            return tenant.Name.ToLower().Contains(TenantQuery) && !tenant.HasLeft;
        }
        bool filterReceivableHeads(object o) {
            var head = o as Head;
            var result = head.ControlId == AppData.controlIdOfReceivable
                && TObject.FixedReceivables.FirstOrDefault(x => x.HeadId == head.Id) == null;
            if(string.IsNullOrWhiteSpace(HeadQuery)) return result;
            return head.Name.ToLower().Contains(HeadQuery) && result;
        }
        #endregion

        #region base implementation
        protected override ObservableCollection<Lease> collection => AppData.leases;
        protected override void insertInDatabase() {
            var commands = new List<SqliteCommand>();
            var cmd = new SqliteCommand(@"INSERT INTO Leases(PlotId, SpaceId, TenantId, DateStart, Business, IsExpired)
                                         VALUES(@PlotId, @SpaceId, @TenantId, @Date, @Business, 0);
                                        UPDATE Spaces SET IsVacant = 0 WHERE Id = @Id;");
            cmd.Parameters.AddWithValue("@PlotId", TObject.PlotId);
            cmd.Parameters.AddWithValue("@SpaceId", TObject.SpaceId);
            cmd.Parameters.AddWithValue("@TenantId", TObject.TenantId);
            cmd.Parameters.AddWithValue("@Date", TObject.DateStart.Value.ToString("yyyy-MM-dd"));
            cmd.Parameters.AddWithValue("@Business", TObject.Business);
            cmd.Parameters.AddWithValue("@Id", TObject.SpaceId);
            commands.Add(cmd);

            foreach (var item in TObject.FixedReceivables)
                commands.Add(new SqliteCommand($"INSERT INTO Receivables VALUES({TObject.Id}, {item.HeadId}, {item.Amount})"));

            SQLHelper.Transaction(commands);
            foreach (var command in commands) command.Dispose();
        }
        protected override void renewTObject() {
            TObject.PropertyChanged -= validate;
            TObject.PlotName = AppData.plots.First(x => x.Id == TObject.PlotId).Name;
            TObject.SpaceName = AppData.spaces.First(x => x.Id == TObject.SpaceId).Name;
            TObject.TenantName = AppData.tenants.First(x => x.Id == TObject.TenantId).Name;
            LeaseAdded?.Invoke(TObject);
            var spaceId = TObject.SpaceId;

            initializeValidationProperties();
            TObject = new Lease() {
                Id = ++AppData.maxLeaseId,
                PlotId = TObject.PlotId,
                TenantId = TObject.TenantId,
                DateStart = null
            };
            OnPropertyChanged(string.Empty);
            TObject.PropertyChanged += validate;

            AppData.spaces.First(x => x.Id == spaceId).IsVacant = false;
            TObject.OnPropertyChanged(nameof(Lease.PlotId));
            TObject.OnPropertyChanged(nameof(Lease.TenantId));
            TObject.OnPropertyChanged(nameof(Lease.DateStart));

            NewReceivable.LeaseId = TObject.Id;
            ReceivableHeads.Refresh();
            ReceivableHeads.MoveCurrentToFirst();
            NewReceivable.HeadId = ReceivableHeads.CurrentItem == null? null : ((Head)ReceivableHeads.CurrentItem).Id;
        }
        #endregion
    }
}
