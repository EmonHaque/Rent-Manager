﻿using RentManager.Helpers;
using RentManager.Models;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Data;

namespace RentManager.ViewModels.Add
{
    public class AddHeadVM : AddBase<Head>
    {
        public string ErrorName { get; set; }
        public string ErrorDescription { get; set; }
        public bool IsValid { get; set; }
        public ICollectionView ControlHeads { get; set; }
        string query;
        public string Query {
            get { return query; }
            set { 
                if (query != value) {
                    query = value;
                    ControlHeads.Refresh();
                } 
            }
        }


        public AddHeadVM() : base() {
            ControlHeads = new CollectionViewSource() { Source = AppData.controlHeads }.View;
            ControlHeads.Filter = filter;
            TObject.Id = AppData.GetId(AppData.heads);
            TObject.PropertyChanged += validate;
            initializeValidationProperties();
        }

        bool filter(object o) {
            if (string.IsNullOrWhiteSpace(Query)) return true;
            return ((ControlHead)o).Name.ToLower().Contains(Query.Trim().ToLower());
        }

        void initializeValidationProperties() {
            IsValid = false;
            ErrorName = "Name is required";
            ErrorDescription = "Description is required";
        }

        #region validation rules
        void validate(object sender, PropertyChangedEventArgs e) {
            switch (e.PropertyName) {
                case nameof(Head.Name): validateName(); break;
                case nameof(Head.Description): validateDescription(); break;
            }
            IsValid =
                ErrorName == string.Empty &&
                ErrorDescription == string.Empty
                ? true : false;
            OnPropertyChanged(nameof(IsValid));
        }
        void validateName() {
            ErrorName = string.Empty;
            if (string.IsNullOrWhiteSpace(TObject.Name)) ErrorDescription = "Name is required";
            else {
                int? selectedControlId = TObject.ControlId;
                if (selectedControlId != null) {
                    for (int i = 0; i < AppData.heads.Count; i++) {
                        if (AppData.heads[i].ControlId == selectedControlId) {
                            if (string.Equals(AppData.heads[i].Name, TObject.Name.Trim(), StringComparison.OrdinalIgnoreCase)) {
                                ErrorName = "Name exists";
                                break;
                            }
                        }
                    }
                }
            }
            OnPropertyChanged(nameof(ErrorName));
        }
        void validateDescription() {
            ErrorDescription = string.Empty;
            if (string.IsNullOrWhiteSpace(TObject.Description)) ErrorDescription = "Description is required";
            OnPropertyChanged(nameof(ErrorDescription));
        }
        #endregion

        #region base Implementation
        protected override ObservableCollection<Head> collection => AppData.heads;
        protected override void insertInDatabase()
        {
            using var cmd = SQLHelper.connection.CreateCommand();
            cmd.CommandText = "INSERT INTO Heads (ControlId, Name, Description) VALUES(@ControlId, @Name, @Description)";
            cmd.Parameters.AddWithValue("@ControlId", TObject.ControlId);
            cmd.Parameters.AddWithValue("@Name", TObject.Name);
            cmd.Parameters.AddWithValue("@Description", TObject.Description);
            SQLHelper.NonQuery(cmd);
        }
        protected override void renewTObject()
        {
            TObject.PropertyChanged -= validate;
            initializeValidationProperties();
            TObject = new Head(){
                Id = TObject.Id + 1,
                ControlId = TObject.ControlId
            };
            OnPropertyChanged(string.Empty);
            TObject.PropertyChanged += validate;
            TObject.OnPropertyChanged(nameof(Head.ControlId));
        }
        #endregion
    }
}
