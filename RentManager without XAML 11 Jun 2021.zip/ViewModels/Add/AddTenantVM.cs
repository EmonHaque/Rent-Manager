﻿using RentManager.Helpers;
using RentManager.Models;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace RentManager.ViewModels.Add
{
    public class AddTenantVM : AddBase<Tenant>
    {
        public string ErrorName { get; set; }
        public string ErrorFather { get; set; }
        public string ErrorAddress { get; set; }
        public string ErrorContactNo { get; set; }
        public bool IsValid { get; set; }
        public AddTenantVM() : base() {
            TObject.Id = AppData.GetId(AppData.tenants);
            TObject.PropertyChanged += validate;
            initializeValidationProperties();
        }

        void initializeValidationProperties() {
            IsValid = false;
            ErrorName = "Name is required";
            ErrorFather = "Father is required";
            ErrorAddress = "Addres is required";
            ErrorContactNo = "Contact No. is required";
        }

        #region validation rules
        void validate(object sender, PropertyChangedEventArgs e) {
            switch (e.PropertyName) {
                case nameof(Tenant.Name): validateName(); break;
                case nameof(Tenant.Father): validateFather(); break;
                case nameof(Tenant.Address): validateAddress(); break;
                case nameof(Tenant.ContactNo): validateContactNo(); break;
            }
            IsValid =
                ErrorName == string.Empty &&
                ErrorFather == string.Empty &&
                ErrorAddress == string.Empty &&
                ErrorContactNo == string.Empty
                ? true : false;
            OnPropertyChanged(nameof(IsValid));

        }
        void validateName() {
            ErrorName = string.Empty;
            if (string.IsNullOrWhiteSpace(TObject.Name)) ErrorName = "Name is required";
            else {
                for (int i = 0; i < AppData.tenants.Count; i++) {
                    if (string.Equals(AppData.tenants[i].Name, TObject.Name.Trim(), StringComparison.OrdinalIgnoreCase)) {
                        ErrorName = "Name exits";
                        break;
                    }
                }
            }
            OnPropertyChanged(nameof(ErrorName));
        }
        void validateFather() {
            ErrorFather = string.Empty;
            if (string.IsNullOrWhiteSpace(TObject.Father)) ErrorFather = "Father is required";
            OnPropertyChanged(nameof(ErrorFather));
        }
        void validateAddress() {
            ErrorAddress = string.Empty;
            if (string.IsNullOrWhiteSpace(TObject.Address)) ErrorAddress = "Address is required";
            OnPropertyChanged(nameof(ErrorAddress));
        }
        void validateContactNo() {
            ErrorContactNo = string.Empty;
            if (string.IsNullOrWhiteSpace(TObject.ContactNo)) ErrorContactNo = "Contact No. is required";
            OnPropertyChanged(nameof(ErrorContactNo));
        }
        #endregion

        #region base implementation
        protected override ObservableCollection<Tenant> collection => AppData.tenants;      
        protected override void insertInDatabase()
        {
            var mother = string.IsNullOrWhiteSpace(TObject.Mother) ? (object)DBNull.Value : TObject.Mother;
            var husband = string.IsNullOrWhiteSpace(TObject.Husband) ? (object)DBNull.Value : TObject.Husband;
            var nid = string.IsNullOrWhiteSpace(TObject.NID) ? (object)DBNull.Value : TObject.NID;

            using var cmd = SQLHelper.connection.CreateCommand();
            cmd.CommandText = @"INSERT INTO Tenants (Name, Father, Mother, Husband, Address, NID, ContactNo, HasLeft) 
                                VALUES(@Name, @Father, @Mother, @Husband, @Address, @NID, @ContactNo, 0)";
            cmd.Parameters.AddWithValue("@Name", TObject.Name);
            cmd.Parameters.AddWithValue("@Father", TObject.Father);
            cmd.Parameters.AddWithValue("@Mother", mother);
            cmd.Parameters.AddWithValue("@Husband", husband);
            cmd.Parameters.AddWithValue("@Address", TObject.Address);
            cmd.Parameters.AddWithValue("@NID", nid);
            cmd.Parameters.AddWithValue("@ContactNo", TObject.ContactNo);
            SQLHelper.NonQuery(cmd);
        }
        protected override void renewTObject() {
            TObject.PropertyChanged -= validate;
            initializeValidationProperties();
            TObject = new Tenant() { Id = TObject.Id + 1 };
            OnPropertyChanged(string.Empty);
            TObject.PropertyChanged += validate;
        }
        #endregion
    }
}
