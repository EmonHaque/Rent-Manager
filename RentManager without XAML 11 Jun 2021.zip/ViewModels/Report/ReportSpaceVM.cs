﻿using RentManager.Models;
using System.ComponentModel;
using System.Linq;
using System.Windows.Data;

namespace RentManager.ViewModels.Report
{
    public class ReportSpaceVM : ReportBase
    {
        protected override string particulars => "t.Name";
        protected override string where => "SpaceId";
        public override ICollectionView selectionView => spaces.View;

        CollectionViewSource spaces;
        public ReportSpaceVM() : base() {
            spaces = new CollectionViewSource() { 
                Source = AppData.spaces,
                IsLiveGroupingRequested = true,
                LiveGroupingProperties = { nameof(Space.PlotName) }
            };
            spaces.View.GroupDescriptions.Add(new PropertyGroupDescription(nameof(Space.PlotName)));
            selectionView.Filter = filterSpaces;
        }
        bool filterSpaces(object o) {
            if (string.IsNullOrWhiteSpace(Query)) return true;
            var query = Query.Trim().ToLower();
            var space = (Space)o;
            return 
                space.PlotName.ToLower().Contains(query) || 
                space.Name.ToLower().Contains(query);
        }
        protected override void setTitleAndSubTitle(){
            var space = AppData.spaces.First(x => x.Id == base.Id);
            base.Title = space.Name + " of " + space.PlotName;
            base.SubTitle = space.Description;
        }
    }
}
