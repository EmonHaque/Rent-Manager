﻿using System.Windows.Controls;

namespace Rent.View.Edit
{
    /// <summary>
    /// Interaction logic for HeadView.xaml
    /// </summary>
    public partial class HeadView : UserControl
    {
        public HeadView()
        {
            InitializeComponent();
        }
    }
}
