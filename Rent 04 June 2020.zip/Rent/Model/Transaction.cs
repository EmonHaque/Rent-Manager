﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Rent.Model
{

    public class Transaction : INotifyPropertyChanged
	{

		DateTime date;
		public DateTime Date { get => date; set { date = value; OnPropertyChanged(); } }

		int plotId;
		public int PlotId { get => plotId; set { plotId = value; OnPropertyChanged(); } }

		int spaceId;
		public int SpaceId { get => spaceId; set { spaceId = value; OnPropertyChanged(); } }

		int tenantId;
		public int TenantId { get => tenantId; set { tenantId = value; OnPropertyChanged(); } }

		int controlId;
		public int ControlId { get => controlId; set { controlId = value; OnPropertyChanged(); } }

		int headId;
		public int HeadId { get => headId; set { headId = value; OnPropertyChanged(); } }

		int amount;
		public int Amount { get => amount; set { amount = value; OnPropertyChanged(); } }

		string narration;
		public string Narration { get => narration; set { narration = value; OnPropertyChanged(); } }

		public Transaction()
		{
			Date = DateTime.Now;
		}

		public bool IsValid()
		{
			return PlotId > 0 &&
				SpaceId > 0 &&
				TenantId > 0 &&
				HeadId > 0 &&
				Amount > 0;
		}

		#region Notify Property Changed Members
		public event PropertyChangedEventHandler PropertyChanged;
		void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
		#endregion
	}

}
