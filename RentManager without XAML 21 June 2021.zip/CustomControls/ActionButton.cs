﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace RentManager.CustomControls
{
    class ActionButton : Border
    {
        string icon;
        public string Icon {
            get { return icon; }
            set { icon = value; ((Path)Child).Data = Geometry.Parse(value); }
        }
        public Action Command { get; set; }
        protected SolidColorBrush brush;
        protected ColorAnimation anim;
        protected Color normalColor, highlightColor, downColor;       
        public ActionButton() {
            normalColor = Colors.Black;
            highlightColor = Colors.Coral;
            downColor = Colors.Red;
            brush = new SolidColorBrush(normalColor);

            FocusVisualStyle = null;
            Background = Brushes.Transparent;
            Width = Height = 18;
            VerticalAlignment = VerticalAlignment.Center;
            Child = new Path() {
                Fill = brush,
                Stretch = Stretch.Uniform
            };
            anim = new ColorAnimation() {
                Duration = TimeSpan.FromSeconds(0.5),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
        }
        protected void animateBrush(Color color) {
            anim.To = color;
            brush.BeginAnimation(SolidColorBrush.ColorProperty, anim);
        }
        protected override void OnMouseEnter(MouseEventArgs e) => animateBrush(highlightColor);
        protected override void OnMouseLeave(MouseEventArgs e) => animateBrush(normalColor);
        protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e) => Command.Invoke();
        protected override void OnMouseDown(MouseButtonEventArgs e) => animateBrush(downColor);
    }
}
