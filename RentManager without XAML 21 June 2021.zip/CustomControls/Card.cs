﻿using RentManager.Helpers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Effects;

namespace RentManager.CustomControls
{
    class Card : Border
    {
        Grid container;
        TextBlock headerBlock;
        Separator divider;
        UIElement content;
        public UIElement Content {
            get { return content; }
            set {
                content = value;
                Grid.SetRow(value, 2);
                container.Children.Add(value);
            }
        }
        string header;
        public string Header {
            get { return header; }
            set {
                header = value;
                headerBlock.Text = value;
                headerBlock.Visibility = Visibility.Visible;
                divider.Visibility = Visibility.Visible;
            }
        }

        public Card() {
            headerBlock = new TextBlock() {
                FontSize = 24,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.LightGray,
                Visibility = Visibility.Collapsed
            };
            divider = new Separator() {
                Margin = new Thickness(0, 0, 0, 5),
                Background = Brushes.LightGray,
                Visibility = Visibility.Collapsed
            };
            Grid.SetRow(divider, 1);
            container = new Grid() {
                RowDefinitions = {
                    new RowDefinition(){Height = GridLength.Auto},
                    new RowDefinition(){Height = GridLength.Auto},
                    new RowDefinition()
                },
                Children = { headerBlock, divider }
            };
            Margin = Constants.CardMargin;
            Padding = new Thickness(5);
            CornerRadius = new CornerRadius(5);
            Background = Brushes.White;
            Effect = new DropShadowEffect() { BlurRadius = 10, ShadowDepth = 0 };
            Child = container;
        }
        protected override Size MeasureOverride(Size availableSize) => availableSize;
    }
}
