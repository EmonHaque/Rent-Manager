﻿using System;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Shell;
using System.Windows.Threading;

namespace RentManager.CustomControls
{
    class BusyWindow : Window
    {
        Path arc;
        PointAnimationUsingPath pointAnim;
        BooleanAnimationUsingKeyFrames isLargeAnim;
        TextBlock text;
        static BusyWindow window;
        public static bool IsOpened;
        BusyWindow(double width, double height, string message) {
            Width = width;
            Height = height;
            WindowStyle = WindowStyle.None;
            ResizeMode = ResizeMode.NoResize;
            AllowsTransparency = true;
            ShowInTaskbar = false;
            Background = new SolidColorBrush(Color.FromArgb(100, 0, 0, 100));
            WindowChrome.SetWindowChrome(this, new WindowChrome() {
                GlassFrameThickness = new Thickness(0),
                CornerRadius = new CornerRadius(7),
                ResizeBorderThickness = new Thickness(0)
            });
            
            initializeContent(message);
            initializeAnimations();
            Loaded += onLoaded;           
        }
        BusyWindow(double left, double top, double width, double height, string message) : this(width, height, message) {
            Left = left;
            Top = top;
        }
        
        void onLoaded(object sender, RoutedEventArgs e) {
            var segment = (ArcSegment)((PathGeometry)arc.Data).Figures[0].Segments[0];
            segment.BeginAnimation(ArcSegment.PointProperty, pointAnim);
            segment.BeginAnimation(ArcSegment.IsLargeArcProperty, isLargeAnim);
        }
        void initializeAnimations() {
            pointAnim = new PointAnimationUsingPath() {
                PathGeometry = PathGeometry.CreateFromGeometry(arc.Data),
                Duration = TimeSpan.FromSeconds(2),
                AccelerationRatio = 0.5,
                DecelerationRatio = 0.5,
                RepeatBehavior = RepeatBehavior.Forever
            };
            isLargeAnim = new BooleanAnimationUsingKeyFrames() {
                KeyFrames = {
                    new DiscreteBooleanKeyFrame(false, TimeSpan.FromSeconds(0)),
                    new DiscreteBooleanKeyFrame(true, TimeSpan.FromSeconds(1)),
                    new DiscreteBooleanKeyFrame(false, TimeSpan.FromSeconds(2))
                },
                RepeatBehavior = RepeatBehavior.Forever
            };
        }
        void initializeContent(string message) {
            var ellipse = new Path() {
                Fill = Brushes.WhiteSmoke,
                Data = new EllipseGeometry() {
                    Center = new Point(Width / 2, Height / 2),
                    RadiusX = 150,
                    RadiusY = 150
                }
            };
            arc = new Path() {
                Stroke = Brushes.Coral,
                StrokeThickness = 5,
                Data = new PathGeometry() {
                    Figures = {
                        new PathFigure() {
                            StartPoint = new Point(Width / 2 + 149, Height / 2),
                            Segments = {
                                new ArcSegment() {
                                    IsLargeArc = true,
                                    Point = new Point(Width / 2 + 149, Height / 2 - 0.1),
                                    Size = new Size(148,148),
                                    SweepDirection = SweepDirection.Clockwise
                                }
                            }
                        }
                    }
                }
            };
            text = new TextBlock() {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                FontSize = 36,
                Foreground = Brushes.Coral,
                Text = message
            };
            Content = new Grid() { Children = { ellipse, text, arc } };
        }

        public static void Activate(double left, double top, double width, double height, string message) {
            App.Current.MainWindow.IsEnabled = false;
            var thread = new Thread(() => {
                window = new BusyWindow(left, top, width, height, message);
                window.Show();
                Dispatcher.Run();
            });
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
            IsOpened = true;
            Thread.Sleep(1000);
        }
        public static void Activate(string message) {
            double left = App.Current.MainWindow.Left;
            double top = App.Current.MainWindow.Top;
            double width = App.Current.MainWindow.Width;
            double height = App.Current.MainWindow.Height;
            var state = App.Current.MainWindow.WindowState;
            App.Current.MainWindow.IsEnabled = false;
            var thread = new Thread(() => {
                window = new BusyWindow(width, height, message) {
                    Left = left,
                    Top = top,
                    WindowState = state
                };
                window.Show();
                Dispatcher.Run();
            });
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
            IsOpened = true;
            Thread.Sleep(1000);
        }
        public static void Terminate() {
            while (window == null) { }
            App.Current.Dispatcher.Invoke(() => App.Current.MainWindow.IsEnabled = true);
            window.Dispatcher.Invoke(window.Close);
        }
        
        protected override void OnClosed(EventArgs e) {
            Loaded -= onLoaded;
            IsOpened = false;
            window.Dispatcher.InvokeShutdown();
            window = null;
        }
    }
}
