﻿using RentManager.Abstracts;
using RentManager.CustomControls;
using RentManager.Helpers;
using RentManager.Models;
using RentManager.ViewModels.Home;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace RentManager.Views.Home
{
    class Rent : CardView
    {
        public override string Header => "Rent, Deposit & Dues";
        CommandButton refresh;
        PieChart pie;
        TriState state;
        RentVM viewModel;

        public Rent() {
            viewModel = new RentVM();
            DataContext = viewModel;
            initializeUI();
            bind();
        }
        void refreshCommand() {
            if (BusyWindow.IsOpened) return;
            var position = PointToScreen(new Point(0, 0));
            position.X += Constants.CardMargin.Left;
            position.Y += Constants.CardMargin.Top;
            var width = ActualWidth - Constants.CardMargin.Left - Constants.CardMargin.Right;
            var height = ActualHeight - Constants.CardMargin.Top - Constants.CardMargin.Bottom;

            BusyWindow.Activate(position.X, position.Y, width, height, "Reloading ...");
            viewModel.Refresh.Invoke();
            BusyWindow.Terminate();
        }

        void initializeUI() {
            refresh = new CommandButton() {
                Command = refreshCommand,
                Icon = Icons.Refresh,
                ToolTip = "Reload",
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Top,
                Margin = new Thickness(0, -28, 0, 0)
            };
            state = new TriState() {
                HorizontalAlignment = HorizontalAlignment.Right,
                CheckedIcon = Icons.Rent,
                UncheckedIcon = Icons.Deposit,
                UndefinedIcon = Icons.Due
            };
            pie = new PieChart() { SelectedValuePath = nameof(PlotSummary.Id) };
            Grid.SetRow(pie, 1);
            var grid = new Grid() {
                RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition()
                },
                Children = { refresh, state, pie }
            };
            setContent(grid);
        }
        void bind() {
            pie.SetBinding(PieChart.ItemsSourceProperty, new Binding(nameof(viewModel.Summary)));
            pie.SetBinding(PieChart.SelectedValueProperty, new Binding(nameof(viewModel.Selected)));
            state.SetBinding(TriState.StateProperty, new Binding(nameof(viewModel.State)));
            state.SetBinding(TriState.TextProperty, new Binding(nameof(viewModel.StateText)));
        }
    }
}
