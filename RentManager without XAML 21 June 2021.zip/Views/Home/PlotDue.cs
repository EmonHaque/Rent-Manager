﻿using RentManager.Abstracts;
using RentManager.CustomControls;
using RentManager.Helpers;
using RentManager.ViewModels.Home;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;

namespace RentManager.Views.Home
{
    class PlotDue : CardView
    {
        public override string Header => "Due & Tenants";

        BarChart chart;
        CommandButton refresh;
        BiState state;
        TextBlock info;
        PlotDueVM viewModel;
        public PlotDue() {
            viewModel = new PlotDueVM();
            DataContext = viewModel;
            initializeUI();
            bind();
        }
        void refreshCommand() {
            if (BusyWindow.IsOpened) return;
            var position = PointToScreen(new Point(0, 0));
            position.X += Constants.CardMargin.Left;
            position.Y += Constants.CardMargin.Top;
            var width = ActualWidth - Constants.CardMargin.Left - Constants.CardMargin.Right;
            var height = ActualHeight - Constants.CardMargin.Top - Constants.CardMargin.Bottom;

            BusyWindow.Activate(position.X, position.Y, width, height, "Reloading ...");
            viewModel.Refresh.Invoke();
            BusyWindow.Terminate();
        }
        void initializeUI() {
            chart = new BarChart();
            refresh = new CommandButton() {
                Command = refreshCommand,
                Icon = Icons.Refresh,
                ToolTip = "Reload",
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Top,
                Margin = new Thickness(0, -28, 0, 0)
            };
            state = new BiState() {
                IsTrue = true,
                Text = "All",
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Top,
                Margin = new Thickness(0, -27, 26, 0)
            };
            info = new TextBlock() {
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(0,0,10,0),
                Foreground = Brushes.Gray,
                FontWeight = FontWeights.Bold,
                FontSize = 14,
            };
            Grid.SetRow(chart, 1);
            var grid = new Grid() {
                RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition()
                },
                Children = { chart, state, refresh, info }
            };
            setContent(grid);
        }
        void bind() {
            chart.SetBinding(BarChart.ItemSourceProperty, new Binding(nameof(viewModel.Data)));
            state.SetBinding(BiState.IsTrueProperty, new Binding(nameof(viewModel.State)));
            info.SetBinding(TextBlock.TextProperty, new Binding(nameof(viewModel.Name)));
        }
    }
}
