﻿CREATE TABLE "Plots" (
	"Id"	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"Name"	TEXT NOT NULL,
	"Description"	TEXT NOT NULL
);
CREATE TABLE "Spaces" (
	"Id"	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"PlotId"	INTEGER NOT NULL,
	"Name"	TEXT NOT NULL,
	"Description"	TEXT NOT NULL,
	"IsVacant"	INTEGER NOT NULL,
	FOREIGN KEY("PlotId") REFERENCES "Plots"("Id")
);
CREATE TABLE "Tenants" (
	"Id"	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"Name"	TEXT NOT NULL,
	"Father"	TEXT NOT NULL,
	"Mother"	TEXT,
	"Husband"	TEXT,
	"Address"	TEXT NOT NULL,
	"NID"	TEXT,
	"ContactNo"	TEXT NOT NULL,
	"HasLeft"	INTEGER NOT NULL
);
CREATE TABLE "Leases" (
	"Id"	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"PlotId"	INTEGER NOT NULL,
	"SpaceId"	INTEGER NOT NULL,
	"TenantId"	INTEGER NOT NULL,
	"DateStart"	TEXT NOT NULL,
	"DateEnd"	TEXT,
	"Business"	TEXT NOT NULL,
	"IsExpired"	INTEGER NOT NULL,
	FOREIGN KEY("PlotId") REFERENCES "Plots"("Id"),
	FOREIGN KEY("SpaceId") REFERENCES "Spaces"("Id"),
	FOREIGN KEY("TenantId") REFERENCES "Tenants"("Id")
);
CREATE TABLE "ControlHeads" (
	"Id"	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"Name"	TEXT NOT NULL
);
CREATE TABLE "Heads" (
	"Id"	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"ControlId"	INTEGER NOT NULL,
	"Name"	TEXT NOT NULL,
	"Description"	INTEGER NOT NULL,
	FOREIGN KEY("ControlId") REFERENCES "ControlHeads"("Id")
);
CREATE TABLE "Receivables" (
	"LeaseId"	INTEGER NOT NULL,
	"HeadId"	INTEGER NOT NULL,
	"Amount"	INTEGER NOT NULL,
	FOREIGN KEY("LeaseId") REFERENCES "Leases"("Id"),
	FOREIGN KEY("HeadId") REFERENCES "Heads"("Id")
);
CREATE TABLE "Transactions" (
	"Id"	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"Date"	TEXT NOT NULL,
	"PlotId"	INTEGER NOT NULL,
	"SpaceId"	INTEGER NOT NULL,
	"TenantId"	INTEGER NOT NULL,
	"ControlId"	INTEGER NOT NULL,
	"HeadId"	INTEGER NOT NULL,
	"Amount"	INTEGER NOT NULL,
	"IsCash"	INTEGER NOT NULL,
	"Narration"	TEXT,
	FOREIGN KEY("PlotId") REFERENCES "Plots"("Id"),
	FOREIGN KEY("SpaceId") REFERENCES "Spaces"("Id"),
	FOREIGN KEY("TenantId") REFERENCES "Tenants"("Id"),
	FOREIGN KEY("ControlId") REFERENCES "ControlHeads"("Id"),
	FOREIGN KEY("HeadId") REFERENCES "Heads"("Id")
);
INSERT INTO "ControlHeads" (Name) VALUES
('Receivable'),
('Receipt'),
('Payment');

INSERT INTO "Heads" (Id, ControlId, Name, Description) VALUES 
 (1,1,'Rent','Fixed monthly charge'),
 (2,1,'Water','Fixed monthly charge'),
 (3,1,'Gas','Fixed monthly charge'),
 (4,2,'Security Money','Receipt'),
 (5,2,'Against Monthly Receivable','Receipt'),
 (6,3,'Security Money','Payment'),
 (7,1,'Electricity','Monthly Electricity Consumption bill.'),
 (8,1,'Restoration','For any change/damage'),
 (9,1,'Service Charge','For Darwan'),
 (10,1,'Common Electric','Common Electric'),
 (11,1,'Welfare Society','For garbage'),
 (12,1,'Garage','Car Parking');
