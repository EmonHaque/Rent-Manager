﻿ abstract class AddBase<T> : Notifiable where T : Notifiable, new()
    {
        public T TObject { get; set; }
        public Action Add { get; set; }
        public AddBase() {
            TObject = new T();
            Add = addTObject;
        }
        protected abstract ObservableCollection<T> collection { get; }
        protected abstract void insertInDatabase();
        protected abstract void renewTObject();
        void addTObject() {
            lock (SQL.key) { insertInDatabase(); }
            collection.Add(TObject);
            renewTObject();
        }
    }
