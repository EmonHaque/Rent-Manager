﻿class LeaseTip : ToolTip
{
    public LeaseTip() {
        BorderBrush = null;
        Effect = null;
        Background = null;
        HasDropShadow = false;
        ShowsToolTipOnKeyboardFocus = false;
        var header = new TextBlock() {
            Text = "Receivable(s)",
            FontSize = 16
        };
        var divider = new Separator() { Background = Brushes.LightGray };
        var receivables = new ItemsControl() {
            Margin = new Thickness(2, 0, 2, 0),
            ItemTemplate = new ReceivableTemplate()
        };
        receivables.SetBinding(ItemsControl.ItemsSourceProperty, new Binding(nameof(Lease.FixedReceivables)));
        Grid.SetRow(divider, 1);
        Grid.SetRow(receivables, 2);
        Content = new Border() {
            MinWidth = 175,
            Background = Constants.Background,
            BorderBrush = Brushes.White,
            BorderThickness = new Thickness(1),
            //Effect = new DropShadowEffect() { BlurRadius = 50, ShadowDepth = 10, Color = Colors.White },
            Padding = new Thickness(5),
            CornerRadius = new CornerRadius(5),
            Child = new Grid() {
                RowDefinitions = {
                        new RowDefinition(){ Height = GridLength.Auto },
                        new RowDefinition(){ Height = GridLength.Auto },
                        new RowDefinition()
                    },
                Children = { header, divider, receivables }
            }
        };
    }
}
