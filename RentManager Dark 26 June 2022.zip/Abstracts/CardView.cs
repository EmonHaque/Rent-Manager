﻿abstract class CardView : View
{
    string header;
    public virtual string Header {
        get { return header; }
        set { header = value; card.Header = value; }
    }
    public override FrameworkElement container => card;
    protected Card card;
    public CardView() {
        card = new Card() { Header = Header };
        AddVisualChild(card);
        KeyboardNavigation.SetTabNavigation(this, KeyboardNavigationMode.Cycle);
        FocusManager.SetIsFocusScope(this, true);
    }
    protected void setContent(FrameworkElement element) => card.Content = element;
    protected void addAction(UIElement action) => card.AddActions(action);
    protected void addAction(UIElement[] actions) => card.AddActions(actions);
}
