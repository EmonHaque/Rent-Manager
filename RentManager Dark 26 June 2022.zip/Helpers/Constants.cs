﻿class Constants
{
    public const string DBName = "data.db";
    public const string ConnectionString = "data source = " + DBName;
    public const double ScrollBarThickness = 12;
    public const string NumberFormat = "#,##0;(#,##0);-    ";
    public static Thickness CardMargin = new Thickness(7);
    public static Brush Background = new SolidColorBrush(Color.FromRgb(50, 50, 50));
    public static Brush BackgroundDark = new SolidColorBrush(Color.FromRgb(60, 60, 60));
}
