if you have an existing database created by earlier version of Rent Manager, you've to update the Transactions table of data.db.
in previous version IsCash was 1 for cash and 0 for noncash/kind transactions.
in this version cash is 0, noncash/kind is 1 and mobile is 2.

do something like this:

UPDATE Transactions SET IsCash = 3 WHERE IsCash = 0;
UPDATE Transactions SET IsCash = 0 WHERE IsCash = 1;
UPDATE Transactions SET IsCash = 1 WHERE IsCash = 3;
