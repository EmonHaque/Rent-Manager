﻿using Microsoft.Data.Sqlite;
using RentManager.Abstracts;
using RentManager.CustomControls;
using RentManager.Helpers;
using RentManager.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Windows.Data;

namespace RentManager.ViewModels.Transact
{
    class BulkRentTransactionVM : Notifiable
    {
        List<Lease> activeLeases;
        string narration, chargeDate;
        public string ErrorMonth { get; set; }
        public bool IsValid { get; set; }       
        public ICollectionView Leases { get; set; }       
        public Action PassEntries { get; set; }
        DateTime? month;
        public DateTime? Month {
            get { return month; }
            set {
                if (month != value) {
                    month = value;
                    validate();
                }
            }
        }
        List<Lease> excluededLeases;
        public List<Lease> ExcludedLeases {
            get { return excluededLeases; }
            set { 
                if (excluededLeases != value) {
                    excluededLeases = value;
                    validate();
                }
            }
        }
        string filterName;
        public string FilterName {
            get { return filterName; }
            set {
                if (filterName != value) {
                    filterName = value?.Trim().ToLower();
                    Leases.Refresh();
                }
            }
        }
        public BulkRentTransactionVM() {
            Leases = new CollectionViewSource() {
                Source = AppData.leases,
                IsLiveFilteringRequested = true,
                LiveFilteringProperties = { nameof(Lease.IsExpired) },
                IsLiveSortingRequested = true,
                LiveSortingProperties = { nameof(Lease.SpaceName) },
                IsLiveGroupingRequested = true,
                LiveGroupingProperties = { nameof(Lease.PlotName) }
            }.View;
            activeLeases = new List<Lease>();
            ExcludedLeases = new List<Lease>();

            Leases.GroupDescriptions.Add(new PropertyGroupDescription(nameof(Lease.PlotName)));
            Leases.SortDescriptions.Add(new SortDescription(nameof(Lease.SpaceName), ListSortDirection.Ascending));
            Leases.Filter = filter;
            PassEntries = passEntries;
            ErrorMonth = " is required";
        }

        void validate() {
            ErrorMonth = Month == null ? " is required" : string.Empty;
            OnPropertyChanged(nameof(ErrorMonth));
            //activeLeases computation could be moved to the filter function
            activeLeases = AppData.leases.Where(x => !x.IsExpired).ToList();
            IsValid =
                !Leases.IsEmpty &&
                Month != null &&
                ExcludedLeases.Count < activeLeases.Count;
            OnPropertyChanged(nameof(IsValid));
        }
        
        bool filter(object o) {
            var lease = (Lease)o;
            if (string.IsNullOrWhiteSpace(FilterName)) return !lease.IsExpired;
            return 
                !lease.IsExpired &&
                (ExcludedLeases.Contains(lease) ||
                lease.TenantName.ToLower().Contains(FilterName) || 
                lease.PlotName.ToLower().Contains(FilterName) ||
                lease.SpaceName.ToLower().Contains(FilterName));
        }

        void passEntries() {           
            if(ExcludedLeases.Count > 0) 
                activeLeases = activeLeases.Except(ExcludedLeases).ToList();

            narration = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(month.Value.Month) + ", " + Month.Value.Year;
            var log = new ConfirmationDialog() {
                Title = "Rent",
                Message = $"Rent for {activeLeases.Count} spaces for the month of {narration} will be charged"
            };
            if (log.ShowDialog().Value) {
                chargeDate = new DateTime(Month.Value.Year, month.Value.Month, DateTime.DaysInMonth(Month.Value.Year, month.Value.Month)).ToString("yyyy-MM-dd");
                var commands = new List<SqliteCommand>();
                foreach (var lease in activeLeases) {
                    foreach (var receivable in lease.FixedReceivables)
                        commands.Add(monthlyCommand(lease, receivable));
                }
                SQLHelper.Transaction(commands);
                foreach (var command in commands) command.Dispose();

                Month = null;
                OnPropertyChanged(nameof(Month));
            }
        }

        SqliteCommand monthlyCommand(Lease lease, Receivable receivable) {
            return  new SqliteCommand(@$"INSERT INTO Transactions (Date, PlotId, SpaceId, TenantId, ControlId, HeadId, Amount, IsCash, Narration) 
                                        VALUES('{chargeDate}', {lease.PlotId}, {lease.SpaceId}, {lease.TenantId}, 
                                        {AppData.controlIdOfReceivable}, {receivable.HeadId}, {receivable.Amount}, 0, '{narration}')");
        }
    }
}
