﻿using RentManager.ControlTemplates;
using RentManager.DataTemplates;
using RentManager.Helpers;
using RentManager.Models;
using System.Collections;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;

namespace RentManager.CustomControls
{
    class Ledger : Grid
    {
        TextBlock totalReceivable, totalReceipt;
        Border header, footer;
        ListBox entries;
        Thickness padding;
        double fixedColumnWidth = 80;
        public string Source { get; set; }
        object viewModel;
        string query;
        public Ledger(object viewModel, string query) {
            RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
            RowDefinitions.Add(new RowDefinition());
            RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });

            this.viewModel = viewModel;
            this.query = query;
            padding = new Thickness(5, 0, 5, 0);
            initializeHeader();
            initializeEntries();
            initializeFooter();

            SetRow(entries, 1);
            SetRow(footer, 2);
            
            Children.Add(header);
            Children.Add(entries);
            Children.Add(footer);
            Loaded += onLoaded;
            Unloaded += onUnloaded;
        }

        void onUnloaded(object sender, RoutedEventArgs e) {
            Loaded -= onLoaded;
            Unloaded -= onUnloaded;
        }
        void onLoaded(object sender, RoutedEventArgs e) {
            totalReceivable.SetBinding(TextBlock.TextProperty, new Binding($"{nameof(Summary)}.{nameof(ReportSummary.TotalReceivable)}") { StringFormat = Constants.NumberFormat });
            totalReceipt.SetBinding(TextBlock.TextProperty, new Binding($"{nameof(Summary)}.{nameof(ReportSummary.TotalReceipt)}") { StringFormat = Constants.NumberFormat });
        }

        void initializeHeader() {
            var date = new TextBlock() { Text = "Date" };
            var particulars = new TextBlock() { Text = "Particulars" };
            var charges = new TextBlock() {
                Inlines = {
                    new Run(){Text = "Receivable/"},
                    new LineBreak(),
                    new Run(){Text = "Payment"}
                },
                HorizontalAlignment = HorizontalAlignment.Right,
                TextAlignment = TextAlignment.Right
            };
            var receipt = new TextBlock() { Text = "Receipt", HorizontalAlignment = HorizontalAlignment.Right };
            var balance = new TextBlock() {
                Text = "Balance",
                HorizontalAlignment = HorizontalAlignment.Right
            };
            SetColumn(particulars, 1);
            SetColumn(charges, 2);
            SetColumn(receipt, 3);
            SetColumn(balance, 4);

            var grid = new Grid() {
                Resources = {
                    {
                        typeof(TextBlock),
                        new Style() {
                            Setters = {
                                new Setter(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center),
                                new Setter(TextBlock.FontWeightProperty, FontWeights.Bold)
                            }
                        }
                    }
                },
                ColumnDefinitions = {
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) },
                     new ColumnDefinition(),
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) },
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) },
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) }
                },
                Children = { date, particulars, charges, receipt, balance }
            };
            header = new Border() {
                Padding = padding,
                Margin = new Thickness(0, 0, Constants.ScrollBarThickness, 0),
                BorderThickness = new Thickness(0, 1, 0, 1),
                BorderBrush = Brushes.SkyBlue,
                Child = grid
            };
        }
        void initializeEntries() {
            entries = new ListBox() {
                ItemTemplate = new LedgerTemplate(query, viewModel),
                Resources = {{
                        typeof(ScrollViewer),
                        new Style() {
                            Setters = {
                                new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                                new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate())
                            }
                        }
                    }
                }
            };
        }
        void initializeFooter() {
            var totalText = new TextBlock() { Text = "Total" };
            totalReceivable = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
            totalReceipt = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
            SetColumn(totalReceivable, 2);
            SetColumn(totalReceipt, 3);
            var grid = new Grid() {
                Resources = {
                    {
                        typeof(TextBlock),
                        new Style(){
                        Setters = {
                                new Setter(TextBlock.FontWeightProperty, FontWeights.Bold)}
                        }
                    }
                },
                ColumnDefinitions = {
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) },
                     new ColumnDefinition(),
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) },
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) },
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) }
                },
                Children = { totalText, totalReceivable, totalReceipt }
            };

            footer = new Border() {
                Padding = padding,
                Margin = new Thickness(0, 0, Constants.ScrollBarThickness, 0),
                BorderThickness = new Thickness(0, 1, 0, 1),
                BorderBrush = Brushes.SkyBlue,
                Child = grid
            };
        }

        #region DependencyProperties
        public IEnumerable ItemsSource {
            get { return (IEnumerable)GetValue(ItemsSourceProperty); }
            set { SetValue(ItemsSourceProperty, value); }
        }
        public ReportSummary Summary {
            get { return (ReportSummary)GetValue(SummaryProperty); }
            set { SetValue(SummaryProperty, value); }
        }

        public static readonly DependencyProperty SummaryProperty =
            DependencyProperty.Register("Summary", typeof(ReportSummary), typeof(Ledger), new PropertyMetadata(null));

        public static readonly DependencyProperty ItemsSourceProperty =
            DependencyProperty.Register("ItemsSource", typeof(IEnumerable), typeof(Ledger), new PropertyMetadata(null, onSourceChanged));

        static void onSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
            var o = d as Ledger;
            o.entries.ItemsSource = (IEnumerable)e.NewValue;
        }
        #endregion
    }
}
