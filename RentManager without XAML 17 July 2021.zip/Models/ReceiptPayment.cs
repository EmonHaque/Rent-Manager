﻿namespace RentManager.Models
{
    class ReceiptPayment
    {
        public string Control { get; set; }
        public string Head { get; set; }
        public string Plot { get; set; }
        public string Tenant { get; set; }
        public string Space { get; set; }
        public int Cash { get; set; }
        public int Kind { get; set; }
        public int Total { get; set; }
    }
}
