﻿using RentManager.Abstracts;
using RentManager.Helpers;
using RentManager.Views.Report;

namespace RentManager.Views
{
    class ReportView : ViewContainer
    {
        override public string Icon => Icons.Ledger;
        public ReportView() {
            Children.Add(new ReportPlot());
            Children.Add(new ReportSpace());
            Children.Add(new ReportTenant());
            Children.Add(new ReportBalance());
            Children.Add(new ReportRPs());
        }
    }
}
