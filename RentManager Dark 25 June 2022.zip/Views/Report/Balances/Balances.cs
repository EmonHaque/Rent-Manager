﻿class Balances : View
{
    public override string Icon => Icons.Balance;
    public override FrameworkElement container => grid;
    Grid grid;
    public Balances() {
        var balance = new ReportBalance();
        var current = new ReportCurrentMonth();
        Grid.SetColumn(current, 1);
        grid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(){Width = new GridLength(1.5, GridUnitType.Star)},
                new ColumnDefinition()
            },
            Children = { balance, current }
        };
        AddVisualChild(grid);
    }
}
