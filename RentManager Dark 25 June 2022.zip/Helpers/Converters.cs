﻿class Converters
{
    public static PlotIdToNameConverter plotId2plotName;
    public static SpaceIdToNameConverter spaceId2spaceName;
    public static TenantIdToNameConverter tenantId2TenantName;
    public static ControlId2NameConverter controlId2ControlName;
    public static HeadIdToNameConverter headId2headName;
    public static BoolToVisibilityConverter bool2visibility;
    public static BoolToInvisibilityConverter bool2invisibility;
    public static LeaseExpiryDateVisibilityConverter leaseExpiryDate;
    public static RPSummaryConverter rpGroup2Summary;
    public static BalanceSummaryConverter balanceGroup2Summary;
    public static CurrentMonthSummaryConverter currentMonth2Summary;
    public static SpaceIdToTenantNameConverter spaceId2TenantName;
    public static BooleanToPathDataConverter bool2PathIconConverter;
    public static BooleanToPathFillConverter bool2PathFillConverter;
    public Converters() {
        plotId2plotName = new PlotIdToNameConverter();
        spaceId2spaceName = new SpaceIdToNameConverter();
        tenantId2TenantName = new TenantIdToNameConverter();
        controlId2ControlName = new ControlId2NameConverter();
        headId2headName = new HeadIdToNameConverter();
        bool2visibility = new BoolToVisibilityConverter();
        bool2invisibility = new BoolToInvisibilityConverter();
        leaseExpiryDate = new LeaseExpiryDateVisibilityConverter();
        rpGroup2Summary = new RPSummaryConverter();
        balanceGroup2Summary = new BalanceSummaryConverter();
        currentMonth2Summary = new CurrentMonthSummaryConverter();
        spaceId2TenantName = new SpaceIdToTenantNameConverter();
        bool2PathIconConverter = new BooleanToPathDataConverter();
        bool2PathFillConverter = new BooleanToPathFillConverter();
    }
}
class BooleanToPathDataConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
        var v = (byte)value;
        switch (v) {
            case 0: return Icons.Cash;
            case 1: return Icons.Noncash;
            case 2: return Icons.Phone;
        }
        return null;
    }
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => throw new NotImplementedException();
}
class BooleanToPathFillConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
        var v = (byte)value;
        switch (v) {
            case 0: return Brushes.LightGreen;
            case 1: return Brushes.Coral;
            case 2: return Brushes.CornflowerBlue;
        }
        return null;
    }
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => throw new NotImplementedException();
}
class PlotIdToNameConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
        return value == null ? "" : AppData.plots.First(x => x.Id == (int)value).Name;
    }
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => throw new NotImplementedException();
}
class SpaceIdToNameConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) => AppData.spaces.First(x => x.Id == (int)value).Name;
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => throw new NotImplementedException();
}
class TenantIdToNameConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) => AppData.tenants.First(x => x.Id == (int)value).Name;
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => throw new NotImplementedException();
}
class ControlId2NameConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) => AppData.controlHeads.First(x => x.Id == (int)value).Name;
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => throw new NotImplementedException();
}
class HeadIdToNameConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) => AppData.heads.First(x => x.Id == (int)value).Name;
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => throw new NotImplementedException();
}
class BoolToInvisibilityConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) => (bool)value ? Visibility.Hidden : Visibility.Visible;
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => throw new NotImplementedException();
}
class BoolToVisibilityConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) => (bool)value ? Visibility.Visible : Visibility.Hidden;
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => throw new NotImplementedException();
}
class LeaseExpiryDateVisibilityConverter : IMultiValueConverter
{
    public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture) {
        if (parameter == null) {
            if ((bool)values[0]) {
                if ((bool)values[1]) return Visibility.Hidden;
                if ((bool)values[2]) return Visibility.Visible;
                return Visibility.Hidden;
            }
            return Visibility.Hidden;
        }
        else {
            if ((bool)values[0]) {
                if ((bool)values[2]) return Visibility.Visible;
                return Visibility.Hidden;
            }
            else {
                if (values[1] != DependencyProperty.UnsetValue)
                    if ((bool)values[1]) return Visibility.Visible;
            }
            return Visibility.Hidden;
        }
    }
    public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture) => throw new NotImplementedException();
}
class RPSummaryConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
        var group = (CollectionViewGroup)value;
        int sumCash, sumMobile, sumKind, sumTotal;
        sumCash = sumMobile = sumKind = sumTotal = 0;
        string text = "";

        if (group.IsBottomLevel) {
            var items = group.Items.OfType<ReceiptPayment>();
            text = "Total " + group.Name;
            sumCash = items.Sum(x => x.Cash);
            sumMobile = items.Sum(x => x.Mobile);
            sumKind = items.Sum(x => x.Kind);
            sumTotal = items.Sum(x => x.Total);
        }
        else {
            foreach (CollectionViewGroup subGroup in group.Items) {
                var sum = (Tuple<string, int, int, int, int>)Convert(subGroup, null, null, null);
                text = "Total " + group.Name;
                sumCash += sum.Item2;
                sumMobile += sum.Item3;
                sumKind += sum.Item4;
                sumTotal += sum.Item5;
            }
        }
        return new Tuple<string, int, int, int, int>(text, sumCash, sumMobile, sumKind, sumTotal);
    }
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => throw new NotImplementedException();
}
class BalanceSummaryConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
        var group = (CollectionViewGroup)value;
        int sumCash, sumKind, sumTotal;
        sumCash = sumKind = sumTotal = 0;
        string text = "";

        if (group.IsBottomLevel) {
            var items = group.Items.OfType<Balance>();
            text = "Total " + group.Name;
            sumCash = items.Sum(x => x.Security);
            sumKind = items.Sum(x => x.Rent);
            sumTotal = items.Sum(x => x.Due);
        }
        else {
            foreach (CollectionViewGroup subGroup in group.Items) {
                var sum = (Tuple<string, int, int, int>)Convert(subGroup, null, null, null);
                text = "Total " + group.Name;
                sumCash += sum.Item2;
                sumKind += sum.Item3;
                sumTotal += sum.Item4;
            }
        }
        return new Tuple<string, int, int, int>(text, sumCash, sumKind, sumTotal);
    }
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => throw new NotImplementedException();
}
class CurrentMonthSummaryConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
        var group = (CollectionViewGroup)value;
        int sumDue, sumPayment;
        sumDue = sumPayment = 0;

        if (group.IsBottomLevel) {
            var items = group.Items.OfType<CurrentPayment>();
            sumDue = items.Sum(x => x.Due);
            sumPayment = items.Sum(x => x.Payment);
        }
        else {
            foreach (CollectionViewGroup subGroup in group.Items) {
                var sum = (Tuple<int, int>)Convert(subGroup, null, null, null);
                sumDue += sum.Item1;
                sumPayment += sum.Item2;
            }
        }
        return new Tuple<int, int>(sumDue, sumPayment);
    }
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => throw new NotImplementedException();
}
class SpaceIdToTenantNameConverter : IMultiValueConverter
{
    public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture) {
        bool isVacant = (bool)values[0];
        int spaceId = (int)values[1];
        if (isVacant) {
            var date = AppData.leases.Where(x => x.SpaceId == spaceId).Max(x => x.DateEnd);
            return date == null ? "since beginning" : "since " + date.Value.ToString("dd MMMM yyyy");
        }
        var tenantId = AppData.leases.FirstOrDefault(x => x.SpaceId == spaceId && !x.IsExpired).TenantId;
        return AppData.tenants.First(x => x.Id == tenantId).Name;
    }

    public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture) {
        throw new NotImplementedException();
    }
}
