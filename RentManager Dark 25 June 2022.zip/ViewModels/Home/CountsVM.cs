﻿class CountsVM : Notifiable
{
    byte state;
    public byte State {
        get { return state; }
        set {
            if (state != value) {
                state = value;
                switch (SelectionState) {
                    case 0: getSpaceSummary(); break;
                    case 1: getLeaseSummary(); break;
                    case 2: getTenantSummary(); break;
                }
            }
        }
    }
    byte selectionState;
    public byte SelectionState {
        get { return selectionState; }
        set {
            if (selectionState != value) {
                selectionState = value;
                switch (value) {
                    case 0: 
                        getSpaceSummary();
                        StateTexts = new string[] { "Occupied", "Vacant", "All" };
                        break;
                    case 1: 
                        getLeaseSummary();
                        StateTexts = new string[] { "Active", "Expired", "All" };
                        break;
                    case 2: 
                        getTenantSummary();
                        StateTexts = new string[] { "Existing", "Left", "All" };
                        break;
                }
                OnPropertyChanged(nameof(StateTexts));
            }
        }
    }
    int? selected;
    public int? Selected {
        get { return selected; }
        set {
            if (selected != value) {
                selected = value;
            }
        }
    }
    public string[] StateTexts { get; set; }
    public List<PlotSummary> Summary { get; set; }
    public Action Refresh { get; set; }

    public CountsVM() {
        StateTexts = new string[] { "Occupied", "Vacant", "All" };
        getSpaceSummary();
        Refresh = refresh;
    }
    void refresh() {
        switch (SelectionState) {
            case 0: getSpaceSummary(); break;
            case 1: getLeaseSummary(); break;
            case 2: getTenantSummary(); break;
        }
    }
    void getSpaceSummary() {
        Summary = new List<PlotSummary>();
        if (State == 2) {
            foreach (var plot in AppData.plots) {
                int total = 0;
                for (int i = 0; i < AppData.spaces.Count; i++) {
                    if (plot.Id == AppData.spaces[i].PlotId) total++;
                }
                Summary.Add(new PlotSummary() {
                    Id = plot.Id,
                    Name = plot.Name,
                    Total = total
                });
            }
        }
        else if (State == 1) {
            foreach (var plot in AppData.plots) {
                int total = 0;
                for (int i = 0; i < AppData.spaces.Count; i++) {
                    if (plot.Id == AppData.spaces[i].PlotId && AppData.spaces[i].IsVacant) total++;
                }
                Summary.Add(new PlotSummary() {
                    Id = plot.Id,
                    Name = plot.Name,
                    Total = total
                });
            }
        }
        else {
            foreach (var plot in AppData.plots) {
                int total = 0;
                for (int i = 0; i < AppData.spaces.Count; i++) {
                    if (plot.Id == AppData.spaces[i].PlotId && !AppData.spaces[i].IsVacant) total++;
                }
                Summary.Add(new PlotSummary() {
                    Id = plot.Id,
                    Name = plot.Name,
                    Total = total
                });
            }
        }
        OnPropertyChanged(nameof(Summary));
        
    }
    void getLeaseSummary() {
        Summary = new List<PlotSummary>();
        if (State == 2) {
            foreach (var plot in AppData.plots) {
                Summary.Add(new PlotSummary() {
                    Id = plot.Id,
                    Name = plot.Name,
                    Total = AppData.leases.Count(x => x.PlotId == plot.Id)
                });
            }
        }
        else if (State == 1) {
            foreach (var plot in AppData.plots) {
                Summary.Add(new PlotSummary() {
                    Id = plot.Id,
                    Name = plot.Name,
                    Total = AppData.leases.Count(x => x.PlotId == plot.Id && x.IsExpired)
                });
            }
        }
        else {
            foreach (var plot in AppData.plots) {
                Summary.Add(new PlotSummary() {
                    Id = plot.Id,
                    Name = plot.Name,
                    Total = AppData.leases.Count(x => x.PlotId == plot.Id && !x.IsExpired)
                });
            }
        }
        OnPropertyChanged(nameof(Summary));
    }
    void getTenantSummary() {
        Summary = new List<PlotSummary>();
        if (State == 2) {
            foreach (var plot in AppData.plots) {
                Summary.Add(new PlotSummary() {
                    Id = plot.Id,
                    Name = plot.Name,
                    Total = AppData.leases.Where(x => x.PlotId == plot.Id).Select(x => x.TenantId).Distinct().Count()
                });
            }
        }
        else if (State == 1) {
            foreach (var plot in AppData.plots) {
                var left = AppData.tenants.Where(x => x.HasLeft).Select(x => x.Id);
                var list = AppData.leases.Where(x => x.PlotId == plot.Id).Select(x => x.TenantId).Distinct();
                Summary.Add(new PlotSummary() {
                    Id = plot.Id,
                    Name = plot.Name,
                    Total = left.Intersect(list).Count()
                });
            }
        }
        else {
            foreach (var plot in AppData.plots) {
                var existing = AppData.tenants.Where(x => !x.HasLeft).Select(x => x.Id);
                var list = AppData.leases.Where(x => x.PlotId == plot.Id).Select(x => x.TenantId).Distinct();
                Summary.Add(new PlotSummary() {
                    Id = plot.Id,
                    Name = plot.Name,
                    Total = existing.Intersect(list).Count()
                });
            }
        }
        OnPropertyChanged(nameof(Summary));
    }
}
