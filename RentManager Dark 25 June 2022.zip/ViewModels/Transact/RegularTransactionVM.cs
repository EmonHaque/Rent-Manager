﻿class RegularTransactionVM : TransactionBaseVM
{
    ObservableCollection<Lease> plots, spaces;
    public RegularTransactionVM() : base() {
        AddLeaseVM.LeaseAdded += onLeaseAdded;
    }
    void onLeaseAdded(Lease o) {
        if (o.TenantId != Entry.TenantId) return;
        resetPlotandSpaces();
    }
    protected override void validateTenantId() {
        base.validateTenantId();
        resetPlotandSpaces();
    }
    protected override void validatePlotId() {
        base.validatePlotId();
        Entry.SpaceId = (Spaces.CurrentItem as Lease)?.SpaceId;
    }
    protected override void initializePlotAndSpace() {
        plots = new ObservableCollection<Lease>();
        spaces = new ObservableCollection<Lease>();
        Plots = CollectionViewSource.GetDefaultView(plots);
        Spaces = CollectionViewSource.GetDefaultView(spaces);
    }
    protected override bool filterPlots(object o) {
        if (Entry.TenantId == null) return false;
        if (string.IsNullOrWhiteSpace(PlotQuery)) return true;
        return ((Lease)o).PlotName.ToLower().Contains(PlotQuery);
    }
    protected override bool filterSpaces(object o) {
        if (Entry.TenantId == null) return false;
        var lease = (Lease)o;
        var result = lease.PlotId == Entry.PlotId;
        if (string.IsNullOrWhiteSpace(SpaceQuery)) return result;
        return result && lease.SpaceName.ToLower().Contains(SpaceQuery);
    }
    void resetPlotandSpaces() {
        if (Entry.TenantId == null) {
            Plots.Refresh();
            return;
        }
        plots.Clear();
        spaces.Clear();
        for (int i = 0; i < AppData.leases.Count; i++) {
            if (AppData.leases[i].TenantId == Entry.TenantId) {
                var lease = AppData.leases[i];
                bool containedInPlots = false;
                for (int j = 0; j < plots.Count; j++) {
                    if (plots[j].PlotId == lease.PlotId) {
                        containedInPlots = true;
                        break;
                    }
                }
                if (!containedInPlots) plots.Add(lease);
                spaces.Add(lease);
            }
        }
    }
}
