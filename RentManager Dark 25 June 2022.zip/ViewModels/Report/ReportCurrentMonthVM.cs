﻿class ReportCurrentMonthVM : Notifiable
{
	DateTime cutOffBegin, cutOffEnd;
    ObservableCollection<CurrentPayment> payments;
    byte state;
    public byte State {
        get { return state; }
        set { state = value; Payments.Refresh(); }
    }
    public string Month { get; set; }
    public int TotalDue { get; set; }
    public int TotalPaid { get; set; }
    public int TotalEntry { get; set; }
    public ICollectionView Payments { get; set; }
    public Action Refresh { get; set; }
    public ReportCurrentMonthVM() {
        payments = new ObservableCollection<CurrentPayment>();
		Payments = CollectionViewSource.GetDefaultView(payments);
		Payments.GroupDescriptions.Add(new PropertyGroupDescription(nameof(CurrentPayment.Plot)));
		Payments.Filter = filter;
		Payments.CollectionChanged += onCollectionChanged;
		cutOffEnd = DateTime.Today.AddMonths(-1);
		var lastDay = DateTime.DaysInMonth(cutOffEnd.Year, cutOffEnd.Month);
		cutOffEnd = new DateTime(cutOffEnd.Year, cutOffEnd.Month, lastDay);
		cutOffBegin = new DateTime(cutOffEnd.Year, cutOffEnd.Month, 1);
		getData();
		Refresh = refresh;
		Month = DateTime.Today.ToString("MMMM, yyyy");
    }

    bool filter(object o) {
        switch (state) {
			case 0: return true;
			case 1: return ((CurrentPayment)o).Payment != 0;
			default: return ((CurrentPayment)o).Payment == 0;
		}
    }
	void onCollectionChanged(object? sender, NotifyCollectionChangedEventArgs e) {
		TotalEntry = 0;
		TotalDue = 0;
		TotalPaid = 0;
		foreach (CurrentPayment item in Payments) {
			TotalEntry++;
			TotalDue += item.Due;
			TotalPaid += item.Payment;
		}
		OnPropertyChanged(nameof(TotalEntry));
		OnPropertyChanged(nameof(TotalDue));
		OnPropertyChanged(nameof(TotalPaid));
	}

	void refresh() {
		BusyWindow.Activate(ReportCurrentMonth.Left, ReportCurrentMonth.Top, ReportCurrentMonth.Width, ReportCurrentMonth.Height, "Reloading ...");
		cutOffEnd = DateTime.Today.AddMonths(-1);
		var lastDay = DateTime.DaysInMonth(cutOffEnd.Year, cutOffEnd.Month);
		cutOffEnd = new DateTime(cutOffEnd.Year, cutOffEnd.Month, lastDay);
		cutOffBegin = new DateTime(cutOffEnd.Year, cutOffEnd.Month, 1);
		getData();
		Month = DateTime.Today.ToString("MMMM, yyyy");
		BusyWindow.Terminate();
	}
    void getData() {
		payments.Clear();
        lock (SQL.key) {
            SQL.command.CommandText = $@"WITH t1 AS(
											SELECT DISTINCT TenantId, SpaceId FROM Transactions
											WHERE Date BETWEEN '{cutOffBegin.ToString("yyyy-MM-dd")}' AND '{cutOffEnd.ToString("yyyy-MM-dd")}' AND ControlId = 1											
										), 
										t2 AS(
											SELECT Date, Transactions.PlotId, Transactions.TenantId, SUM(Amount) Amount FROM Transactions
											LEFT JOIN t1 ON t1.SpaceId = Transactions.SpaceId AND t1.TenantId = Transactions.TenantId
											WHERE ControlId = 2 AND HeadId = 5
											AND Date > '{cutOffEnd.ToString("yyyy-MM-dd")}'
											GROUP BY Transactions.PlotId, Transactions.TenantId
										),
										t3 AS(
											SELECT PlotId, SpaceId, TenantId,
											SUM(CASE WHEN ControlId = 1 THEN Amount ELSE 0 END) -
											SUM(CASE WHEN ControlId = 2 AND HeadId = 5 THEN Amount ELSE 0 END) Amount
											FROM Transactions
											WHERE Date <= '{cutOffEnd.ToString("yyyy-MM-dd")}' AND TenantId IN(SELECT TenantId FROM t1)
											GROUP BY PlotId, TenantId
										)
										SELECT t2.Date, Plots.Name, Tenants.Name, t3.Amount Due, t2.Amount Paid FROM t3
										LEFT JOIN t2 ON t2.PlotId = t3.PlotId AND t2.TenantId = t3.TenantId
										LEFT JOIN Plots ON Plots.Id = t3.PlotId
										LEFT JOIN Tenants ON Tenants.Id = t3.TenantId
										WHERE Due <> 0 OR Paid <> 0";

			var reader = SQL.command.ExecuteReader();
            while (reader.Read()) {
				var e = new CurrentPayment() {
					Date = reader.IsDBNull(0) ? null : reader.GetDateTime(0),
					Plot = reader.GetString(1),
					Tenant = reader.GetString(2),
					Due = reader.GetInt32(3),
					Payment = reader.IsDBNull(4) ? 0 : reader.GetInt32(4)
				};
				payments.Add(e);
            }
			reader.Close();
			reader.DisposeAsync();
		}
	}
}
