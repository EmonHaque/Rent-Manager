﻿class EditSpaceVM : EditBase<Space>
{
    CollectionViewSource plots, nonEditablePlots;
    bool isEqual;
    int? selectedPlot;
    public int? SelectedPlot {
        get { return selectedPlot; }
        set {
            if (selectedPlot != value) {
                selectedPlot = value;
                if (IsOnEdit) base.resetIsOnEdit();
                Editables.Refresh();
            }
        }
    }
    DateTime? vaccatedOn;
    public DateTime? VaccatedOn {
        get { return vaccatedOn; }
        set {
            if (vaccatedOn != value) {
                vaccatedOn = value;
                validateVaccatedDate();
            }
        }
    }
    string spaceQuery;
    public string SpaceQuery {
        get { return spaceQuery; }
        set {
            if (spaceQuery != value) {
                spaceQuery = value?.Trim().ToLower();
                Editables.Refresh();
            }
        }
    }
    byte filterState;
    public byte FilterState {
        get { return filterState; }
        set {
            if (filterState != value) {
                filterState = value;
                Editables.Refresh();
            }
        }
    }
    public string NonEditablePlotQuery { get; set; }
    public string PlotQuery { get; set; }
    public string ErrorPlotId { get; set; }
    public string ErrorName { get; set; }
    public string ErrorDescription { get; set; }
    public string ErrorVacantDate { get; set; }
    public bool IsValid { get; set; }
    public ICollectionView NonEditablePlots { get; set; }
    public ICollectionView Plots { get; set; }
    public Action<SelectQuery, string> FilterCommand { get; set; }

    public EditSpaceVM() {
        Editables = new CollectionViewSource() {
            Source = AppData.spaces,
            IsLiveSortingRequested = true,
            IsLiveFilteringRequested = true,
            LiveSortingProperties = { nameof(Space.Name) },
            LiveFilteringProperties = { nameof(Space.PlotId), nameof(Space.IsVacant) }
        }.View;
        nonEditablePlots = new CollectionViewSource() { Source = AppData.plots };
        plots = new CollectionViewSource() { Source = AppData.plots };
        NonEditablePlots = nonEditablePlots.View;
        Plots = plots.View;
        if (NonEditablePlots.MoveCurrentToFirst()) {
            SelectedPlot = ((Plot)NonEditablePlots.CurrentItem).Id;
        }

        NonEditablePlots.Filter = filterPlots;
        Plots.Filter = filterEditablePlots;
        Editables.SortDescriptions.Add(new SortDescription(nameof(Space.Name), ListSortDirection.Ascending));
        Editables.Filter = filterSpace;
        FilterState = 0;
        FilterCommand = filterCommand;
    }
    void filterCommand(SelectQuery parameter, string query) {
        switch (parameter) {
            case SelectQuery.Plot: PlotQuery = query; Plots.Refresh(); break;
            case SelectQuery.NonEditable: NonEditablePlotQuery = query; NonEditablePlots.Refresh(); break;
        }
    }
    bool filterSpace(object o) {
        if (AppData.spaces.Count > 0) {
            if (SelectedPlot == null) return false;
            var space = (Space)o;
            if (space.PlotId == SelectedPlot) {
                switch (FilterState) {
                    case 0:
                        return string.IsNullOrWhiteSpace(SpaceQuery) ? true && space.IsVacant : space.Name.ToLower().Contains(SpaceQuery) && space.IsVacant;
                    case 1:
                        return string.IsNullOrWhiteSpace(SpaceQuery) ? true && !space.IsVacant : space.Name.ToLower().Contains(SpaceQuery) && !space.IsVacant;
                    default:
                        return string.IsNullOrWhiteSpace(SpaceQuery) ? true : space.Name.ToLower().Contains(SpaceQuery);
                }
            }
            return false;
        }
        return false;
    }
    bool filterEditablePlots(object o) {
        if (string.IsNullOrWhiteSpace(PlotQuery)) return true;
        return ((Plot)o).Name.ToLower().Contains(PlotQuery);
    }

    bool filterPlots(object o) {
        if (NonEditablePlotQuery == null) return true;
        return ((Plot)o).Name.ToLower().Contains(NonEditablePlotQuery);
    }

    #region validation rules
    void validatePlotId() {
        ErrorPlotId = string.Empty;
        if (Edited.PlotId == null)
            ErrorPlotId = " is required";
        else {
            if ((Edited.PlotId != Selected.PlotId) &&
                 Edited.IsVacant != Selected.IsVacant) {
                ErrorPlotId = " can't be vacant";
            }
            else validateName();
        }
        OnPropertyChanged(nameof(ErrorPlotId));
    }
    void validateName() {
        ErrorName = string.Empty;
        if (string.IsNullOrWhiteSpace(Edited.Name))
            ErrorName = "Name is required";
        else {
            var trimmedName = Edited.Name.Trim();
            if (Selected.PlotId != Edited.PlotId) {
                for (int i = 0; i < AppData.spaces.Count; i++) {
                    if (AppData.spaces[i].PlotId == Edited.PlotId)
                        if (string.Equals(trimmedName, AppData.spaces[i].Name, StringComparison.OrdinalIgnoreCase))
                            ErrorName = "Name exists";
                }
            }
            else {
                if (!string.Equals(trimmedName, Selected.Name, StringComparison.OrdinalIgnoreCase)) {
                    for (int i = 0; i < AppData.spaces.Count; i++) {
                        if (AppData.spaces[i].PlotId == Edited.PlotId)
                            if (string.Equals(trimmedName, AppData.spaces[i].Name, StringComparison.OrdinalIgnoreCase))
                                ErrorName = "Name exists";
                    }
                }
            }
        }
        OnPropertyChanged(nameof(ErrorName));
    }
    void validateDescription() {
        ErrorDescription = string.Empty;
        if (string.IsNullOrWhiteSpace(Edited.Description))
            ErrorDescription = "Description is required";
        OnPropertyChanged(nameof(ErrorDescription));
    }
    void validateVaccatedDate() {
        ErrorVacantDate = string.Empty;
        if (Edited.IsVacant) {
            if (VaccatedOn == null)
                ErrorVacantDate = " is required";
            else {
                var lease = AppData.leases.First(x => x.SpaceId == Edited.Id && !x.IsExpired);
                if (Nullable.Compare(VaccatedOn, lease.DateStart) <= 0) {
                    ErrorVacantDate = " must be later than Lease start date";
                }
            }
        }
        OnPropertyChanged(nameof(ErrorVacantDate));
        checkValidity();
    }
    void checkValidity() {
        IsValid =
            !isEqual &&
            ErrorPlotId == string.Empty &&
            ErrorName == string.Empty &&
            ErrorDescription == string.Empty &&
            ErrorVacantDate == string.Empty;
        OnPropertyChanged(nameof(IsValid));
    }
    #endregion

    #region base implementation
    protected override void save() {
        string tenantName, spaceName;
        tenantName = spaceName = string.Empty;

        var commands = new List<KeyValuePair<string, List<SqliteParameter>>>();
        if (Edited.IsVacant && !Selected.IsVacant) {
            var lease = AppData.leases.First(x => !x.IsExpired && x.SpaceId == Edited.Id);
            tenantName = AppData.tenants.First(x => x.Id == lease.TenantId).Name;
            spaceName = AppData.spaces.First(x => x.Id == lease.SpaceId).Name;
            var leaseCommand = $"UPDATE Leases SET DateEnd = '{VaccatedOn.Value.ToString("yyyy-MM-dd")}', IsExpired = 1 WHERE Id = {lease.Id}";
            commands.Add(new KeyValuePair<string, List<SqliteParameter>>(leaseCommand, null));

            lease.DateEnd = VaccatedOn.Value;
            lease.IsExpired = true;
            lease.OnPropertyChanged(nameof(Lease.DateEnd));
            lease.OnPropertyChanged(nameof(Lease.IsExpired));

            AppData.spaces.First(x => x.Id == Edited.Id).IsVacant = true;
        }

        var cmd = "UPDATE Spaces SET PlotId = @PlotId, Name = @Name, Description = @Description, IsVacant = @IsVacant WHERE Id = @Id";
        var paras = new List<SqliteParameter>() {
            new SqliteParameter("@PlotId", Edited.PlotId),
            new SqliteParameter("@Name", Edited.Name),
            new SqliteParameter("@Description", Edited.Description),
            new SqliteParameter("@IsVacant", Edited.IsVacant),
            new SqliteParameter("@Id", Edited.Id)
        };
        commands.Add(new KeyValuePair<string, List<SqliteParameter>>(cmd, paras));

        lock (SQL.key) SQL.Transaction(commands);
        
        if (!string.IsNullOrEmpty(tenantName)) {
            var msg = $"{spaceName} was let out to {tenantName}\r\nNow is vacant and available to let out";
            InfoWindow.Activate("Space", msg);
        }
    }
    protected override Space clone() {
        return new Space() {
            Id = Selected.Id,
            PlotId = Selected.PlotId,
            Name = Selected.Name,
            Description = Selected.Description,
            IsVacant = Selected.IsVacant
        };
    }
    protected override void validate(object sender, PropertyChangedEventArgs e) {
        switch (e.PropertyName) {
            case nameof(Space.PlotId): validatePlotId(); break;
            case nameof(Space.Name): validateName(); break;
            case nameof(Space.Description): validateDescription(); break;
            case nameof(Space.IsVacant): validateVaccatedDate(); break;
        }
        isEqual =
            Edited.PlotId == Selected.PlotId &&
            Edited.IsVacant == Selected.IsVacant &&
            string.Equals(Edited.Name, Selected.Name, StringComparison.OrdinalIgnoreCase) &&
            string.Equals(Edited.Description, Selected.Description, StringComparison.OrdinalIgnoreCase);
        checkValidity();
    }
    protected override void setValidationProperties() {
        isEqual = true;
        IsValid = false;
        ErrorPlotId = string.Empty;
        ErrorName = string.Empty;
        ErrorDescription = string.Empty;
        ErrorVacantDate = string.Empty;
        OnPropertyChanged(nameof(IsValid));
        OnPropertyChanged(nameof(ErrorPlotId));
        OnPropertyChanged(nameof(ErrorName));
        OnPropertyChanged(nameof(ErrorDescription));
        OnPropertyChanged(nameof(ErrorVacantDate));
    }
    protected override void update() {
        if (!string.Equals(Selected.Name, Edited.Name)) {
            foreach (var lease in AppData.leases) {
                if (lease.SpaceId == Selected.Id)
                    lease.SpaceName = Edited.Name;
            }
        }
        Selected.PlotId = Edited.PlotId;
        Selected.Name = Edited.Name;
        Selected.Description = Edited.Description;
        Selected.IsVacant = Edited.IsVacant;
    }
    #endregion
}
