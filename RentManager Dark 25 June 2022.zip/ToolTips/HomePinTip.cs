﻿class HomePinTip : PopupDraggable
{
    ICollectionView view;
    EditText search;
    string query;
    public string Query {
        get { return query; }
        set {
            if (query != value) {
                query = value;
                view.Refresh();
            }
        }
    }
    public HomePinTip(List<PlotwiseRent> values) {
        view = new CollectionViewSource() { Source = values }.View;
        view.Filter = filter;
        var boldStyle = new Style(typeof(TextBlock)) {
            Setters = {
                    new Setter(TextBlock.FontWeightProperty, FontWeights.Bold),
                    new Setter(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right),
                    new Setter(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center),
                    new Setter(TextBlock.ForegroundProperty, Brushes.Gray),
                    new Setter(Grid.RowProperty, 1)
                }
        };
        search = new EditText() {
            Hint = "Tenant",
            Icon = Icons.SearchTenant,
            IsTrimBottomRequested = true,
            Margin = new Thickness(10, 10, -17, 0)
        };
        search.SetBinding(EditText.TextProperty, new Binding(nameof(Query)) {
            Mode = BindingMode.OneWayToSource,
            UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged,
            Source = this
        });
        var monthYear = values.First().Month.Split('-');
        var month = new DateTime(Convert.ToInt32(monthYear[1].Trim()), Convert.ToInt32(monthYear[0].Trim()), 1);
        var header = new TextBlock() {
            FontSize = 16,
            FontWeight = FontWeights.Bold,
            Foreground = Brushes.Gray,
            Text = month.ToString("MMMM yyyy"),
            VerticalAlignment = VerticalAlignment.Center
        };
        var margin = new Thickness(5, 0, Constants.ScrollBarThickness + 5, 0);
        var dueBlock = new TextBlock() { Text = "Due", Style = boldStyle };
        var cashBlock = new TextBlock() { Text = "Cash", Style = boldStyle };
        var mobileBlock = new TextBlock() { Text = "Mobile", Style = boldStyle };
        var kindBlock = new TextBlock() { Text = "Kind", Style = boldStyle };
        var totalBlock = new TextBlock() { Text = "Total", Style = boldStyle };
        Grid.SetRowSpan(header, 2);
        Grid.SetColumn(search, 1);
        Grid.SetColumnSpan(search, 5);
        Grid.SetColumn(dueBlock, 1);
        Grid.SetColumn(cashBlock, 2);
        Grid.SetColumn(mobileBlock, 3);
        Grid.SetColumn(kindBlock, 4);
        Grid.SetColumn(totalBlock, 5);
        var headerGrid = new Grid() {
            Margin = margin,
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition() { Width = new GridLength(70) },
                    new ColumnDefinition() { Width = new GridLength(70) },
                    new ColumnDefinition() { Width = new GridLength(70) },
                    new ColumnDefinition() { Width = new GridLength(70) },
                    new ColumnDefinition() { Width = new GridLength(70) }
                },
            RowDefinitions = {
                    new RowDefinition() { Height = GridLength.Auto },
                    new RowDefinition() { Height = GridLength.Auto }
                },
            Children = { search, header, dueBlock, cashBlock, mobileBlock, kindBlock, totalBlock }
        };

        PlotwiseRent total = new();
        int count = 0;
        foreach (var item in values) {
            total.Cash += item.Cash;
            total.Mobile += item.Mobile;
            total.Kind += item.Kind;
            total.Rent += item.Rent;
            count++;
        }
        total.Total = total.Cash + total.Mobile + total.Kind;
        total.Tenant = "Total of " + count;

        var topDivider = new Separator() { Background = Brushes.LightGray };
        var bottomDivider = new Separator() { Background = Brushes.LightGray };
        PlotwiseRentTemplate itemTemplate = new(this);

        var receipts = new ItemsControl() {
            Margin = new Thickness(5, 0, 5, 0),
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            ItemTemplate = itemTemplate,
            ItemsSource = view,
            AlternationCount = 2
        };
        var scrollViewer = new ScrollViewer() {
            OverridesDefaultStyle = true,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            Template = new LedgerScrollTemplate(),
            Content = receipts
        };
        var footer = new ContentControl() {
            Content = total,
            ContentTemplate = itemTemplate,
            Margin = margin,
            Resources = { { typeof(TextBlock), boldStyle } }
        };
        Grid.SetRow(topDivider, 1);
        Grid.SetRow(scrollViewer, 2);
        Grid.SetRow(bottomDivider, 3);
        Grid.SetRow(footer, 4);
        Child = new Border() {
            MinWidth = 250,
            MaxHeight = 500,
            Background = Constants.Background,
            BorderBrush = Brushes.White,
            BorderThickness = new Thickness(1),
            //Effect = new DropShadowEffect() { BlurRadius = 50, ShadowDepth = 10 },
            Margin = new Thickness(2),
            Padding = new Thickness(5),
            CornerRadius = new CornerRadius(5),
            Child = new Grid() {
                RowDefinitions = {
                        new RowDefinition(){ Height = GridLength.Auto },
                        new RowDefinition(){ Height = GridLength.Auto },
                        new RowDefinition(),
                        new RowDefinition(){ Height = GridLength.Auto },
                        new RowDefinition(){ Height = GridLength.Auto },
                    },
                Children = { headerGrid, topDivider, scrollViewer, bottomDivider, footer }
            }
        };
    }

    bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return true;
        return ((PlotwiseRent)o).Tenant.ToLower().Contains(Query.Trim().ToLower());
    }
}
