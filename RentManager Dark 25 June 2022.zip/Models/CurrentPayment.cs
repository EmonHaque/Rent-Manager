﻿class CurrentPayment
{
    public string Plot { get; set; }
    public string Tenant { get; set; }
    public int Due { get; set; }
    public int Payment { get; set; }
    public DateTime? Date { get; set; }
}
