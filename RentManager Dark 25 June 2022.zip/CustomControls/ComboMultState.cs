﻿class ComboMultiState : Grid
{
    MultiState editableState, nonEditableState;
    public string Text { get; set; }
    public string Editable { get; set; }
    public string NonEditable { get; set; }
    public ComboMultiState() {
        editableState = new MultiState() {
            Icons = new string[] { Icons.Cash, Icons.Noncash, Icons.Phone },
            Texts = new string[] {"Cash", "Noncash", "Mobile"},
            Visibility = Visibility.Hidden
        };
        nonEditableState = new MultiState() {
            Icons = new string[] { Icons.Cash, Icons.Noncash, Icons.Phone },
            Texts = new string[] { "Cash", "Noncash", "Mobile" },
            IsEnabled = false
        };

        Children.Add(editableState);
        Children.Add(nonEditableState);
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
    }
    void onLoaded(object sender, RoutedEventArgs e) {
        editableState.SetBinding(MultiState.StateProperty, new Binding(Editable));
        nonEditableState.SetBinding(MultiState.StateProperty, new Binding(NonEditable));
    }

    public bool IsOnEdit {
        get { return (bool)GetValue(IsOnEditProperty); }
        set { SetValue(IsOnEditProperty, value); }
    }
    public static readonly DependencyProperty IsOnEditProperty =
        DependencyProperty.Register("IsOnEdit", typeof(bool), typeof(ComboMultiState), new PropertyMetadata() {
            DefaultValue = false,
            PropertyChangedCallback = (s, e) => {
                var o = (ComboMultiState)s;
                if ((bool)e.NewValue) {
                    o.editableState.Visibility = Visibility.Visible;
                    o.nonEditableState.Visibility = Visibility.Hidden;
                }
                else {
                    o.editableState.Visibility = Visibility.Hidden;
                    o.nonEditableState.Visibility = Visibility.Visible;
                }
            }
        });
}
