﻿using RentManager.DataTemplates;
using RentManager.Helpers;
using RentManager.Models;
using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using System.Windows.Shapes;

namespace RentManager.CustomControls
{
    public class SelectItem : FrameworkElement
    {
        Border border, selecteditem, rightIconBorder, popContent;
        TextBox inputBox;
        TextBlock hintBlock;
        Grid container;
        Path leftIcon, rightIcon;
        MultiCommandButton close;
        Popup pop;
        ListBox list;
        ICollectionView view;
        ContentControl selectedContent;
        TranslateTransform translateHint;
        ScaleTransform scaleHint;
        DoubleAnimation translateHintAnim, scaleHintAnim, rightIconAnim;
        ColorAnimation brushAnim;
        SolidColorBrush brush;
        Run errorText;
        bool isHintMoved, isRemovedByUser;

        public string Hint { get; set; }
        public string Icon { get; set; }
        public string SelectedValuePath { get; set; }
        public string DisplayPath { get; set; }
        public DataTemplate ItemTemplate { get; set; }
        public ControlTemplate GroupTemplate { get; set; }
        public bool IsRequired { get; set; }
        bool enabled;
        public bool Enabled {
            get { return enabled; }
            set {
                enabled = value;
                if (!enabled) {
                    moveHintDown();
                    IsEnabled = false;
                }
                else {
                    moveHintUp();
                    IsEnabled = true;
                }
                animateOnEnableChanged();
            }
        }

        public SelectItem() {
            brush = new SolidColorBrush(Colors.SkyBlue);
            Margin = new Thickness(5);
            errorText = new Run() {
                Foreground = Brushes.Coral,
                FontStyle = FontStyles.Italic
            };
            initializeControls();
            initializeSelectedItemControls();
            container = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition() {Width = GridLength.Auto},
                    new ColumnDefinition(),
                    new ColumnDefinition() {Width = GridLength.Auto}
                },
                Children = { leftIcon, inputBox, hintBlock, selecteditem, rightIconBorder }
            };
            border = new Border() {
                Margin = new Thickness(0, 5, 0, 5),
                BorderBrush = brush,
                BorderThickness = new Thickness(0, 0, 0, 1),
                Child = container
            };
            AddVisualChild(border);

            initializePopup();
            initializeAnimations();
            Loaded += onLoaded;
            Unloaded += onUnloaded;
        }

        void onUnloaded(object sender, RoutedEventArgs e) {
            Loaded -= onLoaded;
            Unloaded -= onUnloaded;
            rightIconBorder.MouseUp -= showPopup;
            inputBox.KeyUp -= focusList;
            selectedContent.MouseLeftButtonUp -= showPopup;
            pop.Opened -= animateRightIcon;
            pop.Closed -= animateRightIcon;
            list.KeyUp -= onEnterOnList;
            list.MouseLeftButtonUp -= onClickOnList;
            view.CollectionChanged -= onCollectionViewChanged;
        }
        void onLoaded(object sender, RoutedEventArgs e) {
            var transform = (RotateTransform)rightIcon.RenderTransform;
            transform.CenterX = rightIcon.ActualWidth / 2;
            transform.CenterY = rightIcon.ActualHeight / 2;

            if (Hint != null) hintBlock.Inlines.Add(Hint);
            if (Error != null) hintBlock.Inlines.Add(errorText);
            if (Icon != null) {
                leftIcon.Data = Geometry.Parse(Icon);
                leftIcon.Visibility = Visibility.Visible;
            }
            if (DisplayPath != null) {
                var be = BindingOperations.GetBindingExpression(this, TextProperty);
                ItemTemplate = new HiTemplate(DisplayPath, be.ParentBinding.Path.Path, DataContext);
            }
            list.ItemTemplate =
            selectedContent.ContentTemplate = ItemTemplate;
            selectedContent.SetBinding(ContentControl.ContentProperty, new Binding() {
                Path = new PropertyPath(nameof(list.SelectedItem)),
                Source = list
            });

            if (GroupTemplate != null) {
                list.GroupStyle.Add(new GroupStyle() {
                    ContainerStyle = new Style(typeof(GroupItem)) {
                        Setters = {
                            new Setter(GroupItem.TemplateProperty, GroupTemplate)
                        }
                    }
                });
            }
        }
        void setSelectedValue() {
            list.SelectedValuePath = SelectedValuePath;
            if (list.Items.Count > 0) {
                Enabled = true;
                view.MoveCurrentToFirst();
                Selectedvalue = (int?)list.SelectedValue;
            }
            else Enabled = false;
        }
        void animateOnEnableChanged() {
            brushAnim.To = Enabled ? Colors.SkyBlue : Colors.LightGray;
            brush.BeginAnimation(SolidColorBrush.ColorProperty, brushAnim);
        }
        void initializeControls() {
            translateHint = new TranslateTransform();
            scaleHint = new ScaleTransform();

            hintBlock = new TextBlock {
                Padding = new Thickness(5, 0, 5, 0),
                Foreground = Brushes.Gray,
                Background = Brushes.White,
                HorizontalAlignment = HorizontalAlignment.Left,
                VerticalAlignment = VerticalAlignment.Center,
                RenderTransform = new TransformGroup {
                    Children = { scaleHint, translateHint }
                }
            };
            inputBox = new TextBox() {
                Margin = new Thickness(5),
                BorderThickness = new Thickness(0)
            };
            leftIcon = new Path {
                Fill = brush,
                Width = 18,
                Height = 18,
                Stretch = Stretch.Uniform,
                HorizontalAlignment = HorizontalAlignment.Right,
                Visibility = Visibility.Collapsed
            };
            rightIcon = new Path() {
                Fill = brush,
                Data = Geometry.Parse(Icons.ScrollDown),
                Width = 18,
                Height = 18,
                Stretch = Stretch.Uniform,
                VerticalAlignment = VerticalAlignment.Center,
                RenderTransform = new RotateTransform(0)
            };
            rightIconBorder = new Border() {
                Background = Brushes.Transparent,
                Child = rightIcon
            };
            Grid.SetColumn(rightIconBorder, 2);
            Grid.SetColumn(hintBlock, 1);
            Grid.SetColumn(inputBox, 1);

            rightIconBorder.MouseUp += showPopup;
            inputBox.KeyUp += focusList;
        }
        void initializeSelectedItemControls() {
            selectedContent = new ContentControl() {
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 5, 0),
                FocusVisualStyle = null
            };
            close = new MultiCommandButton() {
                Width = 16,
                Height = 16,
                Icon = Icons.CloseCircle,
                BeforeCommand = () => isRemovedByUser = true,
                Command = removeSelected
            };
            Grid.SetColumn(close, 1);
            selecteditem = new Border() {
                Background = Brushes.WhiteSmoke,
                Margin = new Thickness(5, 0, 5, 0),
                CornerRadius = new CornerRadius(5),
                Padding = new Thickness(5, 0, 5, 0),
                Visibility = Visibility.Hidden,
                Child = new Grid() {
                    ColumnDefinitions = {
                        new ColumnDefinition(),
                        new ColumnDefinition(){Width = GridLength.Auto}
                    },
                    Children = { selectedContent, close }
                }
            };
            Grid.SetColumn(selecteditem, 1);
            selectedContent.MouseLeftButtonUp += showPopup;
        }
        void initializePopup() {
            list = new ListBox() {
                IsSynchronizedWithCurrentItem = true,
                BorderThickness = new Thickness(0),
                HorizontalContentAlignment = HorizontalAlignment.Stretch,
                ItemContainerStyle = new Style() {
                    TargetType = typeof(ListBoxItem),
                    Setters = {
                        new Setter() {
                            Property = FocusVisualStyleProperty,
                            Value = null
                        }
                    }
                }
            };
            popContent = new Border() {
                Background = Brushes.White,
                Effect = new DropShadowEffect() { BlurRadius = 5, ShadowDepth = 0 },
                Padding = new Thickness(5),
                Margin = new Thickness(2),
                CornerRadius = new CornerRadius(5),
                Child = list
            };
            pop = new Popup() {
                AllowsTransparency = true,
                Child = popContent,
                MaxHeight = 150,
                StaysOpen = false,
                Placement = PlacementMode.Bottom,
                VerticalOffset = 2,
                PlacementTarget = border
            };
            pop.Opened += animateRightIcon;
            pop.Closed += animateRightIcon;
            list.KeyUp += onEnterOnList;
            list.MouseLeftButtonUp += onClickOnList;
        }
        void showPopup(object sender, MouseButtonEventArgs e) => pop.IsOpen = !pop.IsOpen;
        void onClickOnList(object sender, MouseButtonEventArgs e) => focusSelectedContent();
        void onEnterOnList(object sender, KeyEventArgs e) {
            if (e.Key != Key.Enter) return;
            focusSelectedContent();
        }
        void setSelected() {
            if (isRemovedByUser) isRemovedByUser = false;
            inputBox.IsEnabled = false;
            inputBox.Text = Text = string.Empty;
            if(selecteditem.Visibility == Visibility.Hidden)
                selecteditem.Visibility = Visibility.Visible;
            pop.IsOpen = false;
            if (IsRequired && string.IsNullOrWhiteSpace(Error)) hintBlock.Inlines.Remove(errorText);
            if (FocusManager.GetFocusedElement(this) != null)
                Keyboard.Focus(close);
        }
        void removeSelected() => Selectedvalue = null;
        void removeSelectedContent() {
            selecteditem.Visibility = Visibility.Hidden;
            if (isRemovedByUser) {
                inputBox.Text = string.Empty;
                inputBox.IsEnabled = true;
            }
            if (IsRequired) hintBlock.Inlines.Add(errorText);
            if (Enabled) inputBox.Focus();
            pop.IsOpen = false;
        }
        void onCollectionViewChanged(object sender, NotifyCollectionChangedEventArgs e) {
            switch (e.Action) {
                case NotifyCollectionChangedAction.Add:
                    if (!Enabled) Enabled = true;
                    if (list.SelectedItem != e.NewItems[0]) {
                        list.SelectedItem = e.NewItems[0];
                        Selectedvalue = (int?)list.SelectedValue;
                    }
                    if (!isHintMoved) moveHintUp();
                    break;
                case NotifyCollectionChangedAction.Remove:
                case NotifyCollectionChangedAction.Reset:
                    if (e.NewItems == null && !list.Items.IsEmpty) {
                        if (!inputBox.IsEnabled) {
                            if (!isRemovedByUser) {
                                if (list.SelectedValue == null) {
                                    list.Items.MoveCurrentToFirst();
                                    Selectedvalue = (int?)list.SelectedValue;
                                }
                            }
                        }
                        else pop.IsOpen = true;
                        if (!Enabled) Enabled = true;
                    }
                    else {
                        if (!pop.IsOpen) {
                            if (!isRemovedByUser) Enabled = false;
                            removeSelected();
                        }
                    }
                    break;
            }
        }
        void focusList(object sender, KeyEventArgs e) {
            if (e.Key == Key.Down) {
                if (pop.IsOpen) {
                    if (list.HasItems) {
                        list.SelectedIndex = 0;
                        Keyboard.Focus((ListBoxItem)list.ItemContainerGenerator.ContainerFromIndex(0));
                    }
                }
            }
            else Text = inputBox.Text;
        }
        void focusSelectedContent() {
            if (view.CurrentItem != null) {
                Selectedvalue = (int?)list.SelectedValue;
                Keyboard.Focus(close);
            }
        }
        void initializeAnimations() {
            var duration = TimeSpan.FromMilliseconds(250);
            var ease = new CubicEase { EasingMode = EasingMode.EaseInOut };
            scaleHintAnim = new DoubleAnimation {
                Duration = duration,
                EasingFunction = ease
            };
            translateHintAnim = new DoubleAnimation {
                Duration = duration,
                EasingFunction = ease
            };
            brushAnim = new ColorAnimation {
                Duration = duration,
                EasingFunction = ease
            };
            rightIconAnim = new DoubleAnimation() {
                Duration = duration,
                EasingFunction = ease
            };
        }
        void animateHint() {
            translateHint.BeginAnimation(TranslateTransform.YProperty, translateHintAnim);
            scaleHint.BeginAnimation(ScaleTransform.ScaleYProperty, scaleHintAnim);
            scaleHint.BeginAnimation(ScaleTransform.ScaleXProperty, scaleHintAnim);
        }
        void moveHintUp() {
            isHintMoved = true;
            scaleHintAnim.To = 0.9;
            translateHintAnim.To = -20;
            animateHint();
        }
        void moveHintDown() {
            isHintMoved = false;
            scaleHintAnim.To = 1;
            translateHintAnim.To = 0;
            animateHint();
        }
        void animateRightIcon(object sender, EventArgs e) {
            rightIconAnim.To = pop.IsOpen ? 180 : 0;
            rightIcon.RenderTransform.BeginAnimation(RotateTransform.AngleProperty, rightIconAnim);
        }

        protected override void OnMouseEnter(MouseEventArgs e) {
            if (string.IsNullOrWhiteSpace(inputBox.Text)) {
                if (inputBox.IsEnabled) {
                    inputBox.Focus();
                    brushAnim.To = Colors.CornflowerBlue;
                    brush.BeginAnimation(SolidColorBrush.ColorProperty, brushAnim);
                }
            }
        }
        protected override void OnGotKeyboardFocus(KeyboardFocusChangedEventArgs e) {
            if (Selectedvalue == null && !isHintMoved) moveHintUp();
            brushAnim.To = Colors.CornflowerBlue;
            brush.BeginAnimation(SolidColorBrush.ColorProperty, brushAnim);
            Keyboard.Focus(close);
        }
        protected override void OnPreviewLostKeyboardFocus(KeyboardFocusChangedEventArgs e) {
            if (Selectedvalue == null && inputBox.Text.Length == 0 && !pop.IsOpen && isHintMoved) {
                moveHintDown();
            }
            if (!pop.IsOpen) {
                brushAnim.To = Colors.SkyBlue;
                brush.BeginAnimation(SolidColorBrush.ColorProperty, brushAnim);
            }
        }
        protected override Size MeasureOverride(Size availableSize) {
            border.Width = availableSize.Width;
            pop.Width = availableSize.Width;
            border.Measure(availableSize);
            return border.DesiredSize;
        }
        protected override Size ArrangeOverride(Size finalSize) {
            border.Arrange(new Rect(border.DesiredSize));
            return finalSize;
        }
        protected override Visual GetVisualChild(int index) => border;
        protected override int VisualChildrenCount => 1;

        #region DependencyProperty
        public IEnumerable ItemsSource {
            get { return (IEnumerable)GetValue(ItemsSourceProperty); }
            set { SetValue(ItemsSourceProperty, value); }
        }
        public int? Selectedvalue {
            get { return (int?)GetValue(SelectedvalueProperty); }
            set { SetValue(SelectedvalueProperty, value); }
        }
        public string Error {
            get { return (string)GetValue(ErrorProperty); }
            set { SetValue(ErrorProperty, value); }
        }
        public string Text {
            get { return (string)GetValue(TextProperty); }
            set { SetValue(TextProperty, value); }
        }

        public static readonly DependencyProperty TextProperty =
            DependencyProperty.Register("Text", typeof(string), typeof(SelectItem), new PropertyMetadata(null));

        public static readonly DependencyProperty ErrorProperty =
            DependencyProperty.Register("Error", typeof(string), typeof(SelectItem), new PropertyMetadata(null, onErrorChanged));

        public static readonly DependencyProperty ItemsSourceProperty =
            DependencyProperty.Register("ItemsSource", typeof(IEnumerable), typeof(SelectItem), new PropertyMetadata(null, onSourceChanged));

        public static readonly DependencyProperty SelectedvalueProperty =
            DependencyProperty.Register("Selectedvalue", typeof(int?), typeof(SelectItem), new FrameworkPropertyMetadata() {
                DefaultValue = null,
                BindsTwoWayByDefault = true,
                DefaultUpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged,
                PropertyChangedCallback = onSelectedValueChanged
            });

        static void onSelectedValueChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
            var o = d as SelectItem;
            o.list.SelectedValue = e.NewValue;
            if (e.NewValue == null) {
                o.Text = null;
                o.removeSelectedContent();
            }
            else {
                o.setSelected();
            }
        }
        static void onErrorChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
            var o = d as SelectItem;
            if (e.NewValue != null) {
                o.errorText.Text = e.NewValue.ToString();
                if (o.IsRequired) o.hintBlock.Inlines.Add(o.errorText);
            }
        }
        static void onSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
            var o = d as SelectItem;
            if (e.OldValue != null) {
                o.view.CollectionChanged -= o.onCollectionViewChanged;
            }
            o.view = e.NewValue as ICollectionView;
            o.list.ItemsSource = o.view;

            o.view.CollectionChanged += o.onCollectionViewChanged;
            o.setSelectedValue();

        }
        #endregion
    }
}
