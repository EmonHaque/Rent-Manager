﻿using RentManager.ControlTemplates;
using RentManager.DataTemplates;
using RentManager.Helpers;
using RentManager.Models;
using System.Collections;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;

namespace RentManager.CustomControls
{
    class Ledger : FrameworkElement
    {
        Grid container;
        TextBlock title, totalReceivable, totalReceipt;
        Border header, footer;
        ListBox entries;
        Thickness padding;
        double fixedColumnWidth = 80;
        public string Source { get; set; }
        public Ledger() {
            padding = new Thickness(5, 0, 5, 0);
            initializeHeader();
            initializeEntries();
            initializeFooter();
            title = new TextBlock() { FontSize = 18, HorizontalAlignment = HorizontalAlignment.Center };
            Grid.SetRow(header, 1);
            Grid.SetRow(entries, 2);
            Grid.SetRow(footer, 3);
            container = new Grid() {
                RowDefinitions = {
                    new RowDefinition(){Height = GridLength.Auto},
                    new RowDefinition(){Height = GridLength.Auto},
                    new RowDefinition(),
                    new RowDefinition(){Height = GridLength.Auto}
                },
                Children = { title, header, entries, footer }
            };
            AddVisualChild(container);
            Loaded += onLoaded;
            Unloaded += onUnloaded;
        }

        void onUnloaded(object sender, RoutedEventArgs e) {
            Loaded -= onLoaded;
            Unloaded -= onUnloaded;
        }
        void onLoaded(object sender, RoutedEventArgs e) {
            title.SetBinding(TextBlock.TextProperty, new Binding($"{nameof(Summary)}.{nameof(ReportSummary.Heading)}"));
            totalReceivable.SetBinding(TextBlock.TextProperty, new Binding($"{nameof(Summary)}.{nameof(ReportSummary.TotalReceivable)}") { StringFormat = "#,##0;(#,##0);-    " });
            totalReceipt.SetBinding(TextBlock.TextProperty, new Binding($"{nameof(Summary)}.{nameof(ReportSummary.TotalReceipt)}") { StringFormat = "#,##0;(#,##0);-    " });
        }
        void initializeHeader() {
            var date = new TextBlock() { Text = "Date" };
            var particulars = new TextBlock() { Text = "Particulars" };
            var charges = new TextBlock() {
                Inlines = {
                    new Run(){Text = "Receivable/"},
                    new LineBreak(),
                    new Run(){Text = "Payment"}
                },
                HorizontalAlignment = HorizontalAlignment.Right,
                TextAlignment = TextAlignment.Right
            };
            var receipt = new TextBlock() { Text = "Receipt", HorizontalAlignment = HorizontalAlignment.Right };
            var balance = new TextBlock() {
                Text = "Balance",
                HorizontalAlignment = HorizontalAlignment.Right
            };
            Grid.SetColumn(particulars, 1);
            Grid.SetColumn(charges, 2);
            Grid.SetColumn(receipt, 3);
            Grid.SetColumn(balance, 4);

            var grid = new Grid() {
                Resources = {
                    {
                        typeof(TextBlock),
                        new Style() {
                            Setters = {
                                new Setter(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center),
                                new Setter(TextBlock.FontWeightProperty, FontWeights.Bold)
                            }
                        }
                    }
                },
                ColumnDefinitions = {
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) },
                     new ColumnDefinition(),
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) },
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) },
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) }
                },
                Children = { date, particulars, charges, receipt, balance }
            };
            header = new Border() {
                Padding = padding,
                Margin = new Thickness(0,0,Constants.ScrollBarThickness,0),
                BorderThickness = new Thickness(0, 1, 0, 1),
                BorderBrush = Brushes.SkyBlue,
                Child = grid
            };
        }
        void initializeEntries() {
            entries = new ListBox() {
                BorderThickness = new Thickness(0),
                HorizontalContentAlignment = HorizontalAlignment.Stretch,
                ItemTemplate = new LedgerTemplate(),
                Resources = {{
                        typeof(ScrollViewer),
                        new Style() {
                            Setters = {
                                new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                                new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate())
                            }
                        }
                    }
                }
            };
        }
        void initializeFooter() {
            var totalText = new TextBlock() { Text = "Total" };
            totalReceivable = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
            totalReceipt = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
            Grid.SetColumn(totalReceivable, 1);
            Grid.SetColumn(totalReceipt, 2);
            var grid = new Grid() {
                Resources = {
                    { 
                        typeof(TextBlock), 
                        new Style(){
                        Setters = { 
                                new Setter(TextBlock.FontWeightProperty, FontWeights.Bold)} 
                        } 
                    }
                },
                ColumnDefinitions = {
                     new ColumnDefinition(),
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) },
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) },
                     new ColumnDefinition(){ Width = new GridLength(fixedColumnWidth) }
                },
                Children = { totalText, totalReceivable, totalReceipt }
            };

            footer = new Border() {
                Padding = padding,
                Margin = new Thickness(0, 0, Constants.ScrollBarThickness, 0),
                BorderThickness = new Thickness(0, 1, 0, 1),
                BorderBrush = Brushes.SkyBlue,
                Child = grid
            };
        }
        
        protected override Size MeasureOverride(Size availableSize) {
            container.Width = availableSize.Width;
            container.Height = availableSize.Height;
            container.Measure(availableSize);
            return container.DesiredSize;
        }
        protected override Size ArrangeOverride(Size finalSize) {
            container.Arrange(new Rect(container.DesiredSize));
            return finalSize;
        }
        protected override Visual GetVisualChild(int index) => container;
        protected override int VisualChildrenCount => 1;

        #region DependencyProperties
        public IEnumerable ItemsSource {
            get { return (IEnumerable)GetValue(ItemsSourceProperty); }
            set { SetValue(ItemsSourceProperty, value); }
        }
        public ReportSummary Summary {
            get { return (ReportSummary)GetValue(SummaryProperty); }
            set { SetValue(SummaryProperty, value); }
        }

        public static readonly DependencyProperty SummaryProperty =
            DependencyProperty.Register("Summary", typeof(ReportSummary), typeof(Ledger), new PropertyMetadata(null));

        public static readonly DependencyProperty ItemsSourceProperty =
            DependencyProperty.Register("ItemsSource", typeof(IEnumerable), typeof(Ledger), new PropertyMetadata(null, onSourceChanged));

        static void onSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
            var o = d as Ledger;
            o.entries.ItemsSource = (IEnumerable)e.NewValue;
        }
        #endregion
    }
}
