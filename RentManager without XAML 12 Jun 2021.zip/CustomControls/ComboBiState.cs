﻿using System.Windows;
using System.Windows.Data;
using System.Windows.Media;

namespace RentManager.CustomControls
{
    class ComboBiState : FrameworkElement
    {
        VisualCollection children;
        BiState editableState, nonEditableState;
        public string Text { get; set; }
        public string Editable { get; set; }
        public string NonEditable { get; set; }
        public ComboBiState() {
            editableState = new BiState() { Visibility = Visibility.Hidden };
            nonEditableState = new BiState() { IsEnabled = false };
            children = new VisualCollection(this) { editableState, nonEditableState };
            Loaded += onLoaded;
            Unloaded += onUnloaded;
        }

        void onUnloaded(object sender, RoutedEventArgs e) {
            Loaded -= onLoaded;
            Unloaded -= onUnloaded;
        }
        void onLoaded(object sender, RoutedEventArgs e) {
            editableState.Text = nonEditableState.Text = Text;
            editableState.SetBinding(BiState.IsTrueProperty, new Binding(Editable));
            nonEditableState.SetBinding(BiState.IsTrueProperty, new Binding(NonEditable));
        }
        protected override Size MeasureOverride(Size availableSize) {
            foreach (BiState state in children) 
                state.Measure(availableSize);
            return editableState.DesiredSize;
        }
        protected override Size ArrangeOverride(Size finalSize) {
            foreach (BiState state in children) 
                state.Arrange(new Rect(state.DesiredSize));
            return finalSize;
        }
        protected override Visual GetVisualChild(int index) => children[index];
        protected override int VisualChildrenCount => children.Count;

        public bool IsOnEdit {
            get { return (bool)GetValue(IsOnEditProperty); }
            set { SetValue(IsOnEditProperty, value); }
        }
        public static readonly DependencyProperty IsOnEditProperty =
            DependencyProperty.Register("IsOnEdit", typeof(bool), typeof(ComboBiState), new PropertyMetadata() {
                DefaultValue = false,
                PropertyChangedCallback = (s, e) => {
                    var o = (ComboBiState)s;
                    if ((bool)e.NewValue) {
                        o.editableState.Visibility = Visibility.Visible;
                        o.nonEditableState.Visibility = Visibility.Hidden;
                    }
                    else {
                        o.editableState.Visibility = Visibility.Hidden;
                        o.nonEditableState.Visibility = Visibility.Visible;
                    }
                }
            });
    }
}
