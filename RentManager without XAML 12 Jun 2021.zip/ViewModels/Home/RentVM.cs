﻿using RentManager.Abstracts;
using RentManager.Enums;
using RentManager.Helpers;
using RentManager.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace RentManager.ViewModels.Home
{
    class RentVM : Notifiable
    {
        List<DepositDueRent> list;
        bool? state;
        public bool? State {
            get { return state; }
            set {
                if (state != value) {
                    state = value;
                    getData();
                    if(Selected != null)
                        SelectionChanged?.Invoke(Selected, list);
                }
            }
        }
        int? selected;
        public int? Selected {
            get { return selected; }
            set {
                if (selected != value) {
                    selected = value;
                    SelectionChanged?.Invoke(value, list);
                }
            }
        }
        public string StateText { get; set; }
        public Action Refresh { get; set; }
        public List<PlotSummary> Summary { get; set; }
        public static event Action<int?, List<DepositDueRent>> SelectionChanged;
        public RentVM() {
            State = true;
            Refresh = getData;
            if (Summary.Count > 0) {
                Selected = Summary.First().Id;
            }
         }
        void getData() {
            Summary = new List<PlotSummary>();
            list = new List<DepositDueRent>();
            if (State == null) {
                StateText = "Due";
                lock (SQLHelper.key) {
                    SQLHelper.connection.Open();
                    var cmd = SQLHelper.connection.CreateCommand();
                    cmd.CommandText = @"SELECT PlotId, SpaceId, TenantId,
                                            SUM(CASE WHEN ControlId = 1 THEN 1 ELSE -1 END * Amount) Amount
                                        FROM Transactions 
                                        LEFT JOIN Tenants t ON t.Id = TenantId
                                        WHERE ControlId IN(1, 2) AND HeadId <> 4 AND t.HasLeft = 0
                                        GROUP BY PlotId, SpaceId, TenantId";
                    var reader = cmd.ExecuteReader();
                    while (reader.Read()) {
                        list.Add(new DepositDueRent() {
                            State = DepositDueRentState.Due,
                            PlotId = reader.GetInt32(0),
                            SpaceId = reader.GetInt32(1),
                            TenantId = reader.GetInt32(2),
                            Amount = reader.GetInt32(3)
                        });
                    }
                    cmd.Dispose();
                    SQLHelper.connection.Close();
                }
                foreach (var plot in AppData.plots) {
                    Summary.Add(new PlotSummary() {
                        Id = plot.Id,
                        Name = plot.Name,
                        Total = list.Where(x => x.PlotId == plot.Id).Sum(x => x.Amount)
                    });
                }
            }
            else if (State.Value) {
                StateText = "Rent";
                foreach (var plot in AppData.plots) {
                    foreach (var item in AppData.leases) {
                        if (item.PlotId == plot.Id && !item.IsExpired) {
                            list.Add(new DepositDueRent() {
                                State = DepositDueRentState.Rent,
                                PlotId = item.PlotId,
                                SpaceId = item.SpaceId,
                                TenantId = item.TenantId,
                                Amount = item.FixedReceivables.Sum(x => x.Amount)
                            });
                        }
                    }
                    Summary.Add(new PlotSummary() {
                        Id = plot.Id,
                        Name = plot.Name,
                        Total = AppData.leases.Where(x => x.PlotId == plot.Id && !x.IsExpired).Select(x => x.FixedReceivables.Select(y => y.Amount).Sum()).Sum()
                    });
                }
            }
            else {
                StateText = "Desposit";
                lock (SQLHelper.key) {
                    SQLHelper.connection.Open();
                    var cmd = SQLHelper.connection.CreateCommand();
                    cmd.CommandText = @"SELECT PlotId, SpaceId, TenantId,
                                            SUM(CASE WHEN ControlId = 2 THEN 1 ELSE -1 END * Amount) Amount
                                        FROM Transactions 
                                        LEFT JOIN Tenants t ON t.Id = TenantId
                                        WHERE HeadId IN(4,6) AND t.HasLeft = 0
                                        GROUP BY PlotId, SpaceId, TenantId";
                    var reader = cmd.ExecuteReader();
                    while (reader.Read()) {
                        list.Add(new DepositDueRent() {
                            State = DepositDueRentState.Deposit,
                            PlotId = reader.GetInt32(0),
                            SpaceId = reader.GetInt32(1),
                            TenantId = reader.GetInt32(2),
                            Amount = reader.GetInt32(3)
                        });
                    }
                    cmd.Dispose();
                    SQLHelper.connection.Close();
                }
                foreach (var plot in AppData.plots) {
                    Summary.Add(new PlotSummary() {
                        Id = plot.Id,
                        Name = plot.Name,
                        Total = list.Where(x => x.PlotId == plot.Id).Sum(x => x.Amount)
                    });
                }
            }

            OnPropertyChanged(nameof(Summary));
            OnPropertyChanged(nameof(StateText));
        }
    }
}
