﻿using RentManager.CustomControls;
using RentManager.Models;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;

namespace RentManager.DataTemplates
{
    class LedgerTemplate : DataTemplate
    {
        public LedgerTemplate(double fixedColumnsWidth = 80) {
            var grid = new FrameworkElementFactory(typeof(Grid));
            var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var col4 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var col5 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var date = new FrameworkElementFactory(typeof(TextBlock));
            var particulars = new FrameworkElementFactory(typeof(TextBlock));
            var receivable = new FrameworkElementFactory(typeof(TextBlock));
            var receipt = new FrameworkElementFactory(typeof(TextBlock));
            var balance = new FrameworkElementFactory(typeof(TextBlock));
            var part1 = new FrameworkElementFactory(typeof(Run));
            var part2 = new FrameworkElementFactory(typeof(Run));

            col1.SetValue(ColumnDefinition.WidthProperty, new GridLength(fixedColumnsWidth));
            col3.SetValue(ColumnDefinition.WidthProperty, new GridLength(fixedColumnsWidth));
            col4.SetValue(ColumnDefinition.WidthProperty, new GridLength(fixedColumnsWidth));
            col5.SetValue(ColumnDefinition.WidthProperty, new GridLength(fixedColumnsWidth));

            receivable.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
            receipt.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
            balance.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
            receivable.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
            receipt.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
            balance.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
            particulars.SetValue(TextBlock.TextWrappingProperty, TextWrapping.Wrap);

            particulars.SetValue(Grid.ColumnProperty, 1);
            receivable.SetValue(Grid.ColumnProperty, 2);
            receipt.SetValue(Grid.ColumnProperty, 3);
            balance.SetValue(Grid.ColumnProperty, 4);

            part2.SetValue(Run.FontStyleProperty, FontStyles.Italic);
            part2.SetValue(Run.ForegroundProperty, Brushes.Gray);

            date.SetBinding(TextBlock.TextProperty, new Binding(nameof(ReportEntry.Date)) { StringFormat = "dd MMM yyy" });
            part1.SetBinding(Run.TextProperty, new Binding(nameof(ReportEntry.Particulars)));
            part2.SetBinding(Run.TextProperty, new Binding(nameof(ReportEntry.Narration)));
            
            receivable.SetBinding(TextBlock.TextProperty, new Binding(nameof(ReportEntry.Receivable)) { StringFormat = "#,##0;(#,##0);-    " });
            receipt.SetBinding(TextBlock.TextProperty, new Binding(nameof(ReportEntry.Receipt)) { StringFormat = "#,##0;(#,##0);-    " });
            balance.SetBinding(TextBlock.TextProperty, new Binding(nameof(ReportEntry.Balance)) { StringFormat = "#,##0;(#,##0);-    " });

            particulars.AppendChild(part1);
            particulars.AppendChild(part2);
           

            grid.AppendChild(col1);
            grid.AppendChild(col2);
            grid.AppendChild(col3);
            grid.AppendChild(col4);
            grid.AppendChild(col5);
            grid.AppendChild(date);
            grid.AppendChild(particulars);
            grid.AppendChild(receivable);
            grid.AppendChild(receipt);
            grid.AppendChild(balance);

            VisualTree = grid;
        }
    }
}
