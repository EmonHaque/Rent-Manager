﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentManager.Helpers
{
    class Constants
    {
        public const string DBName = "data.db";
        public const string ConnectionString = "data source = " + DBName;
        public const double ScrollBarThickness = 12;
        public const string NumberFormat = "#,##0;(#,##0);-    ";
    }
}
