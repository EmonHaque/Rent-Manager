﻿using RentManager.DataTemplates;
using RentManager.Models;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Media.Effects;

namespace RentManager.ToolTips
{
    class LeaseTip : ToolTip
    {
        public LeaseTip() {
            BorderBrush = null;
            Effect = null;
            Background = null;
            HasDropShadow = false;
            var header = new TextBlock() {
                Text = "Receivable(s)",
                FontSize = 16,
                Foreground = Brushes.Gray
            };
            var divider = new Separator() { Background = Brushes.LightGray };
            var receivables = new ItemsControl() {
                Margin = new Thickness(2,0,2,0),
                ItemTemplate = new ReceivableTemplate()
            };
            receivables.SetBinding(ItemsControl.ItemsSourceProperty, new Binding(nameof(Lease.FixedReceivables)));
            Grid.SetRow(divider, 1);
            Grid.SetRow(receivables, 2);            
            Content = new Border() {
                MinWidth = 175,
                Background = Brushes.White,
                Effect = new DropShadowEffect() { BlurRadius = 5, ShadowDepth = 0 },
                Padding = new Thickness(5),
                CornerRadius = new CornerRadius(5),
                Child = new Grid() {
                    RowDefinitions = {
                        new RowDefinition(){ Height = GridLength.Auto },
                        new RowDefinition(){ Height = GridLength.Auto },
                        new RowDefinition()
                    },
                    Children = { header, divider, receivables }
                }
            };
        }
    }
}
