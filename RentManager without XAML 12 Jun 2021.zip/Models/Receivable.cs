﻿using RentManager.Abstracts;

namespace RentManager.Models
{
    public class Receivable : Notifiable
	{
		public int LeaseId { get; set; }
        int amount;
        public int Amount {
            get { return amount; }
            set {if (amount != value) {
                    amount = value; 
                    OnPropertyChanged(nameof(Amount));
                }
            }
        }
        int? headId;
        public int? HeadId {
            get { return headId; }
            set {
                if (headId != value) {
                    headId = value;
                    OnPropertyChanged(nameof(HeadId));
                }
            }
        }
        public Receivable() { }
        public Receivable(Receivable r) {
            LeaseId = r.LeaseId;
            HeadId = r.HeadId;
            Amount = r.Amount;
        }
    }
}
