﻿using RentManager.CustomControls;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;

namespace RentManager.Abstracts
{
    abstract class CardView : View
    {
        public abstract string Header { get; }
        public override FrameworkElement container => card;
        Card card;
        public CardView() {
            card = new Card() { Header = Header };
            AddVisualChild(card);
            KeyboardNavigation.SetTabNavigation(this, KeyboardNavigationMode.Cycle);
            FocusManager.SetIsFocusScope(this, true);
        }
        protected void setContent(FrameworkElement element) => card.Content = element;
    }
}
