﻿using RentManager.CustomControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace RentManager.Abstracts
{
    abstract class ViewContainer : Panel
    {
        double navWidth = 32;
        int selectedIndex, newIndex;
        bool isAnimating;
        List<View> containers;
        List<TransitButton> buttons;
        Border border;
        DoubleAnimation getIn, getOut;

        public virtual string Icon { get; }

        public ViewContainer() {
            ClipToBounds = true;
            containers = new List<View>();
            buttons = new List<TransitButton>();
            border = new Border() {
                HorizontalAlignment = HorizontalAlignment.Right,
                Width = navWidth,
                CornerRadius = new CornerRadius(0, 0, 10, 0)
            };
            SetZIndex(border, 1);
            Children.Add(border);

            var duration = TimeSpan.FromSeconds(1);
            var ease = new CubicEase() { EasingMode = EasingMode.EaseInOut };
            getIn = new DoubleAnimation() {
                To = 0,
                Duration = duration,
                EasingFunction = ease
            };
            getOut = new DoubleAnimation() {
                Duration = duration,
                EasingFunction = ease
            };
            getOut.Completed += reset;
        }

        void reset(object sender, EventArgs e) {
            containers[selectedIndex].Visibility = Visibility.Hidden;
            selectedIndex = newIndex;
            isAnimating = buttons[selectedIndex].isActing = false;
        }

        void go(int o) {
            var index = o;
            if (!isAnimating && index != selectedIndex) {
                isAnimating = true;
                buttons[index].isActing = true;
                buttons[index].IsSelected = true;
                buttons[selectedIndex].IsSelected = false;

                newIndex = index;

                containers[selectedIndex].RenderTransform.BeginAnimation(TranslateTransform.YProperty, getOut);
                containers[newIndex].RenderTransform.BeginAnimation(TranslateTransform.YProperty, getIn);
                containers[newIndex].Visibility = Visibility.Visible;
            }
        }

        protected override Size ArrangeOverride(Size finalSize) {
            if (finalSize.Width < navWidth) return finalSize;
            getIn.From = finalSize.Height;
            getOut.To = -finalSize.Height;
            var y = 10d;
            foreach (TransitButton item in buttons) {
                item.Width = item.Height = navWidth;
                item.Measure(finalSize);
                item.Arrange(new Rect(new Point(finalSize.Width - navWidth, y), item.DesiredSize));
                y += navWidth;
            }
            foreach (View item in containers) {
                item.Width = finalSize.Width - navWidth;
                item.Height = finalSize.Height;
                item.Measure(finalSize);
                item.Arrange(new Rect(new Point(0, 0), item.DesiredSize));
                if (!containers.ElementAt(selectedIndex).Equals(item))
                    item.Visibility = Visibility.Hidden;
            }
            border.Height = finalSize.Height;
            border.Measure(finalSize);
            border.Arrange(new Rect(new Point(finalSize.Width - navWidth, 0), border.DesiredSize));
            return finalSize;
        }

        protected override void OnVisualChildrenChanged(DependencyObject visualAdded, DependencyObject visualRemoved) {
            if (visualAdded is View) {
                var container = visualAdded as View;
                container.RenderTransform = new TranslateTransform(0, 0);
                containers.Add(container);
                SetZIndex(container, 0);

                var button = new TransitButton(32);
                button.Icon = container.Icon;
                buttons.Add(button);
                button.Command = go;
                button.index = buttons.IndexOf(button);
                if (button.index == 0) button.IsSelected = true;
                Children.Add(button);
                SetZIndex(button, 2);
            }
        }
    }
}
