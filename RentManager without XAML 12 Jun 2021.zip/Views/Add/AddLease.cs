﻿using RentManager.Abstracts;
using RentManager.CustomControls;
using RentManager.DataTemplates;
using RentManager.Helpers;
using RentManager.Models;
using RentManager.ViewModels;
using RentManager.ViewModels.Add;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;

namespace RentManager.Views.Add
{
    class AddLease : CardView
    {
        public override string Header => "Lease";
        SelectItem plot, space, tenant, head;
        EditText business, amount;
        DayPicker dateFrom;
        CommandButton addLease, addReceivable;
        Separator divider;
        TextBlock charge;
        Run chargeError;
        Grid chargesGrid;
        ItemsControl receivables;
        AddLeaseVM viewModel;

        public AddLease() : base() {
            viewModel = new AddLeaseVM();
            DataContext = viewModel;
            initializeUI();
            bind();
        }
        void initializeUI() {
            plot = new SelectItem() {
                Hint = "Plot",
                IsRequired = true,
                Icon = Icons.Plot,
                SelectedValuePath = nameof(Plot.Id),
                DisplayPath = nameof(Plot.Name)
            };
            space = new SelectItem() {
                Hint = "Space",
                IsRequired = true,
                Icon = Icons.Space,
                SelectedValuePath = nameof(Space.Id),
                DisplayPath = nameof(Space.Name)
            };
            Grid.SetRow(space, 1);
            tenant = new SelectItem() {
                Hint = "Tenant",
                IsRequired = true,
                Icon = Icons.Tenant,
                SelectedValuePath = nameof(Tenant.Id),
                ItemTemplate = new TenantTemplate(nameof(viewModel.TenantQuery), viewModel)
            };
            Grid.SetRow(tenant, 2);
            business = new EditText() {
                IsRequired = true,
                IsMultiline = true,
                Hint = "Business",
                Icon = Icons.Business
            };
            Grid.SetRow(business, 3);
            dateFrom = new DayPicker() {
                Hint = "Date",
                DateFormat = "dd/MM/yyyy",
                IsRequired = true,
                Margin = new Thickness(0,15,0,0)
            };
            Grid.SetRow(dateFrom, 4);
            charge = new TextBlock() { Margin = new Thickness(7, 7, 0, 0) };
            charge.Inlines.Add(new Run() {
                Text = "Fixed charges",
                FontSize = 16,
                Foreground = Brushes.Gray
            });
            chargeError = new Run() {
                Foreground = Brushes.Coral,
                FontStyle = FontStyles.Italic
            };
            charge.Inlines.Add(chargeError);
            Grid.SetRow(charge, 5);
            divider = new Separator() {
                Background = Brushes.LightGray,
                Margin = new Thickness(0, 5, 0, 10)
            };
            Grid.SetRow(divider, 6);
            initializeChargesGrid();
            Grid.SetRow(chargesGrid, 7);
            addLease = new CommandButton() {
                Width = 24,
                Height = 24,
                Icon = Icons.Add,
                Command = viewModel.Add,
                HorizontalAlignment = HorizontalAlignment.Right
            };
            Grid.SetRow(addLease, 8);
            var grid = new Grid() {
                RowDefinitions = {
                    new RowDefinition(){Height = GridLength.Auto},
                    new RowDefinition(){Height = GridLength.Auto},
                    new RowDefinition(){Height = GridLength.Auto},
                    new RowDefinition(){Height = GridLength.Auto},
                    new RowDefinition(){Height = GridLength.Auto},
                    new RowDefinition(){Height = GridLength.Auto},
                    new RowDefinition(){Height = GridLength.Auto},
                    new RowDefinition(),
                    new RowDefinition(){Height = GridLength.Auto},
                },
                Children = { plot, space, tenant, business, dateFrom, charge, divider, chargesGrid, addLease }
            };
            setContent(grid);
        }

        void initializeChargesGrid() {
            head = new SelectItem() {
                Hint = "Head",
                IsRequired = true,
                Icon = Icons.Head,
                SelectedValuePath = nameof(Head.Id),
                //SearchPath = nameof(Head.Name),
                DisplayPath = nameof(Head.Name)
            };
            Grid.SetColumnSpan(head, 2);
            amount = new EditText() {
                Hint = "Amount",
                IsRequired = true,
                Icon = Icons.Amount,
            };
            Grid.SetRow(amount, 1);
            addReceivable = new CommandButton() {
                Width = 20,
                Height = 20,
                Icon = Icons.Plus,
                Command = viewModel.AddReceivable,
                Margin = new Thickness(10,0,5,0),
                VerticalAlignment = VerticalAlignment.Center
            };
            Grid.SetRow(addReceivable, 1);
            Grid.SetColumn(addReceivable, 1);
            receivables = new ItemsControl() {
                Margin = new Thickness(7),
                ItemTemplate = new ReceivableTemplate(new Binding(nameof(viewModel.RemoveReceivable)) { Source = viewModel }) //receivableTemplate()
            };
            Grid.SetRow(receivables, 2);
            Grid.SetColumnSpan(receivables, 2);
            chargesGrid = new Grid() {
                RowDefinitions = {
                    new RowDefinition(){Height = GridLength.Auto},
                    new RowDefinition(){Height = GridLength.Auto},
                    new RowDefinition()
                },
                ColumnDefinitions = {
                    new ColumnDefinition(){ Width = new GridLength(2, GridUnitType.Star)},
                    new ColumnDefinition(){Width = GridLength.Auto}
                },
                Children = { head, amount, addReceivable, receivables }
            };
            FocusManager.SetIsFocusScope(chargesGrid, true);
            KeyboardNavigation.SetTabNavigation(chargesGrid, KeyboardNavigationMode.Cycle);
        }

        void bind() {
            plot.SetBinding(SelectItem.SelectedvalueProperty, new Binding($"{nameof(viewModel.TObject)}.{nameof(Lease.PlotId)}"));
            plot.SetBinding(SelectItem.ErrorProperty, new Binding(nameof(viewModel.ErrorPlotId)));
            plot.SetBinding(SelectItem.ItemsSourceProperty, new Binding(nameof(viewModel.Plots)));
            plot.SetBinding(SelectItem.TextProperty, new Binding(nameof(viewModel.PlotQuery)) { Mode = BindingMode.OneWayToSource });           
            
            space.SetBinding(SelectItem.SelectedvalueProperty, new Binding($"{nameof(viewModel.TObject)}.{nameof(Lease.SpaceId)}"));
            space.SetBinding(SelectItem.ErrorProperty, new Binding(nameof(viewModel.ErrorSpaceId)));
            space.SetBinding(SelectItem.ItemsSourceProperty, new Binding(nameof(viewModel.VacantSpaces)));
            space.SetBinding(SelectItem.TextProperty, new Binding(nameof(viewModel.SpaceQuery)) { Mode = BindingMode.OneWayToSource });

            tenant.SetBinding(SelectItem.SelectedvalueProperty, new Binding($"{nameof(viewModel.TObject)}.{nameof(Lease.TenantId)}"));
            tenant.SetBinding(SelectItem.ErrorProperty, new Binding(nameof(viewModel.ErrorTenantId)));
            tenant.SetBinding(SelectItem.ItemsSourceProperty, new Binding(nameof(viewModel.AvailableTenants)));
            tenant.SetBinding(SelectItem.TextProperty, new Binding(nameof(viewModel.TenantQuery)) { Mode = BindingMode.OneWayToSource });

            business.SetBinding(EditText.TextProperty, new Binding($"{nameof(viewModel.TObject)}.{nameof(Lease.Business)}"));
            business.SetBinding(EditText.ErrorProperty, new Binding(nameof(viewModel.ErrorBusiness)));

            dateFrom.SetBinding(DayPicker.SelectedDateProperty, new Binding($"{nameof(viewModel.TObject)}.{nameof(Lease.DateStart)}"));
            dateFrom.SetBinding(DayPicker.ErrorProperty, new Binding(nameof(viewModel.ErrorDate)));

            chargeError.SetBinding(Run.TextProperty, new Binding(nameof(viewModel.ErrorCharge)));
               
            head.SetBinding(SelectItem.SelectedvalueProperty, new Binding($"{nameof(viewModel.NewReceivable)}.{nameof(Receivable.HeadId)}"));
            head.SetBinding(SelectItem.ErrorProperty, new Binding(nameof(viewModel.ErrorHeadId)));
            head.SetBinding(SelectItem.ItemsSourceProperty, new Binding(nameof(viewModel.ReceivableHeads)));
            head.SetBinding(SelectItem.TextProperty, new Binding(nameof(viewModel.HeadQuery)) { Mode = BindingMode.OneWayToSource });

            amount.SetBinding(EditText.TextProperty, new Binding(nameof(viewModel.Amount)));
            amount.SetBinding(EditText.ErrorProperty, new Binding(nameof(viewModel.ErrorAmount)));

            addReceivable.SetBinding(IsEnabledProperty, new Binding(nameof(viewModel.IsReceivableValid)));
            addLease.SetBinding(IsEnabledProperty, new Binding(nameof(viewModel.IsValid)));

            receivables.SetBinding(ItemsControl.ItemsSourceProperty, new Binding($"{nameof(viewModel.TObject)}.{nameof(Lease.FixedReceivables)}"));
        }
    }
}
