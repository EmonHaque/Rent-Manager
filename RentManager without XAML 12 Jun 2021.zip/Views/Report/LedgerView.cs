﻿using RentManager.Abstracts;
using RentManager.CustomControls;
using RentManager.Helpers;
using RentManager.Models;
using RentManager.ViewModels.Report;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace RentManager.Views.Report
{
    abstract class LedgerView : CardView
    {
        SelectItem items;
        DayPicker startDate, endDate;
        CommandButton refresh, exportCSV, print;
        Ledger report;
        protected virtual string display { get; }
        protected virtual DataTemplate template { get; }
        protected virtual ControlTemplate groupTemplate { get; }
        protected abstract ReportBase viewModel { get; }
        public LedgerView() : base() {
            DataContext = viewModel;
            initializeUI();
            if (display == null) items.ItemTemplate = template;
            else items.DisplayPath = display;
            if (groupTemplate != null) items.GroupTemplate = groupTemplate;
            bind();
            Resources.Add(typeof(CommandButton), new Style() {
                Setters = {
                    new Setter(CommandButton.WidthProperty, 18d),
                    new Setter(CommandButton.HeightProperty, 18d),
                    new Setter(CommandButton.VerticalAlignmentProperty, VerticalAlignment.Center)
                }
            });
        }

        void initializeUI() {
            items = new SelectItem() {
                Hint = Header,
                Icon = Icon,
                IsRequired = true,
                SelectedValuePath = "Id"
            };
            startDate = new DayPicker() {
                Hint = "From",
                DateFormat = "dd/MM/yyyy",
                IsRequired = true,
                VerticalAlignment = VerticalAlignment.Center
            };
            endDate = new DayPicker() {
                Hint = "To",
                DateFormat = "dd/MM/yyyy",
                IsRequired = true,
                VerticalAlignment = VerticalAlignment.Center
            };
            refresh = new CommandButton() {
                Icon = Icons.Refresh,
                Command = viewModel.RefreshReport
            };
            exportCSV = new CommandButton() {
                Icon = Icons.CSV,
                Command = viewModel.ExportCSV,
                HorizontalAlignment = HorizontalAlignment.Right
            };
            print = new CommandButton() {
                Icon = Icons.Print,
                Command = viewModel.PrintReport
            };
            report = new Ledger() { Margin = new Thickness(0,-20,0,0) };
            Grid.SetColumn(startDate, 1);
            Grid.SetColumn(endDate, 2);
            Grid.SetColumn(refresh, 3);
            Grid.SetRow(exportCSV, 1);
            Grid.SetRow(print, 1);
            Grid.SetColumn(exportCSV, 2);
            Grid.SetColumn(print, 3);
            Grid.SetRow(report, 2);
            Grid.SetColumnSpan(report, 4);
            var grid = new Grid() {
                RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(),
                },
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto }
                },
                Children = { items, startDate, endDate, refresh, exportCSV, print, report }
            };
            setContent(grid);
        }
        void bind() {
            items.SetBinding(SelectItem.SelectedvalueProperty, new Binding(nameof(viewModel.Id)));
            items.SetBinding(SelectItem.ItemsSourceProperty, new Binding(nameof(viewModel.selectionView)));
            items.SetBinding(SelectItem.TextProperty, new Binding(nameof(viewModel.Query)) { Mode = BindingMode.OneWayToSource });
           
            report.SetBinding(Ledger.ItemsSourceProperty, new Binding(nameof(viewModel.Reportables)));
            report.SetBinding(Ledger.SummaryProperty, new Binding(nameof(viewModel.Summary)));

            startDate.SetBinding(DayPicker.StartDateProperty, new Binding($"{nameof(viewModel.Dates)}.{nameof(ReportDates.Start)}"));
            startDate.SetBinding(DayPicker.EndDateProperty, new Binding($"{nameof(viewModel.Dates)}.{nameof(ReportDates.End)}"));
            startDate.SetBinding(DayPicker.SelectedDateProperty, new Binding($"{nameof(viewModel.Dates)}.{nameof(ReportDates.From)}"));

            endDate.SetBinding(DayPicker.StartDateProperty, new Binding($"{nameof(viewModel.Dates)}.{nameof(ReportDates.Start)}"));
            endDate.SetBinding(DayPicker.EndDateProperty, new Binding($"{nameof(viewModel.Dates)}.{nameof(ReportDates.End)}"));
            endDate.SetBinding(DayPicker.SelectedDateProperty, new Binding($"{nameof(viewModel.Dates)}.{nameof(ReportDates.To)}"));

            var binding = new Binding(nameof(viewModel.IsPrintOrExportValid));
            print.SetBinding(CommandButton.IsEnabledProperty, binding);
            exportCSV.SetBinding(CommandButton.IsEnabledProperty, binding);
            refresh.SetBinding(CommandButton.IsEnabledProperty, new Binding(nameof(viewModel.IsRefreshValid)));
        }
    }
}
