﻿using RentManager.Abstracts;
using RentManager.CustomControls;
using RentManager.Helpers;
using System.Windows;
using RentManager.ViewModel.Edit;
using System.Windows.Controls;
using RentManager.Models;
using System.Windows.Data;
using RentManager.DataTemplates;
using RentManager.ControlTemplates;
using System.Diagnostics;
using System.Windows.Media;
using System.Windows.Documents;
using System;
using System.ComponentModel;
using RentManager.Enums;

namespace RentManager.Views.Edit
{
    class EditTransaction : CardView
    {
        public override string Icon => Icons.Transact;
        public override string Header => "Transaction";

        DayPicker queryDate;
        ListBox transactions;
        ComboSelect tenant, plot, space, controlHead, head;
        ComboDate date;
        ComboText amount, narration;
        ComboBiState isCash;
        ComboButton buttons;
        CommandButton refresh, delete;
        Grid editableGrid;
        EditText search;
        CountBlock counter;
        EditTransactionVM viewModel;
        public EditTransaction() : base() {
            viewModel = new EditTransactionVM();
            DataContext = viewModel;
            initializeUI();
            bind();
        }

        void initializeUI() {
            queryDate = new DayPicker() {
                Hint = "Date",
                DateFormat = "dd/MM/yyyy",
                IsRequired = true
            };
            refresh = new CommandButton() {
                Icon = Icons.Refresh,
                Command = viewModel.Refresh,
                Width = 18,
                Height = 18,
                VerticalAlignment = VerticalAlignment.Center,
                ToolTip = "Refresh"
            };
            Grid.SetColumn(refresh, 1);
            var queryGrid = new Grid() {
                Margin = new Thickness(0,5,0,0),
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto }
                },
                Children = { queryDate , refresh }
            };
            transactions = new ListBox() {
                BorderThickness = new Thickness(0, 0, 1, 0),
                HorizontalContentAlignment = HorizontalAlignment.Stretch,
                ItemTemplate = new TransactionTemplate(),
                GroupStyle = {
                    new GroupStyle() {
                        HidesIfEmpty = true,
                        ContainerStyle = new Style(typeof(GroupItem)){
                            Setters = {
                                new Setter(GroupItem.TemplateProperty, new GroupedTransactionTemplate())
                            }
                        }
                    }
                }
            };
            transactions.Resources.Add(typeof(ScrollViewer), new Style() {
                Setters = {
                    new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled)
                }
            });
            search = new EditText() {
                Icon = Icons.SearchTenant,
                Hint = "Tenant",
                IsTrimBottomRequested = true,
                Margin = new Thickness(0, 10, 0, 0)
            };
            counter = new CountBlock() { VerticalAlignment = VerticalAlignment.Center };
            Grid.SetColumn(counter, 1);
            var searchGrid = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){Width = GridLength.Auto}
                },
                Children = { search, counter }
            };
            initializeEditables();
            Grid.SetRow(searchGrid, 1);
            Grid.SetRow(transactions, 2);
            Grid.SetColumn(editableGrid, 1);
            Grid.SetRow(editableGrid, 2);
            var grid = new Grid() {
                RowDefinitions = {
                    new RowDefinition(){ Height = new GridLength(1, GridUnitType.Auto) },
                    new RowDefinition(){ Height = new GridLength(1, GridUnitType.Auto) },
                    new RowDefinition()
                },
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition()
                },
                Children = { queryGrid, searchGrid, transactions, editableGrid }
            };
            setContent(grid);
        }

        void initializeEditables() {
            delete = new CommandButton() {
                Width = 18,
                Height = 18,
                Icon = Icons.Delete,
                Command = viewModel.Delete,
                ToolTip = "Delete",
                HorizontalAlignment = HorizontalAlignment.Right
            };
            tenant = new ComboSelect() {
                Hint = "Tenant",
                Icon = Icons.Tenant,
                IsRequired = true,
                SelectedValuePath = nameof(Tenant.Id),
                ItemsSource = nameof(viewModel.Tenants),
                ItemTemplate = new TenantTemplate(nameof(viewModel.TenantQuery), viewModel),
                Error = nameof(viewModel.ErrorTenantId),
                Query = nameof(viewModel.TenantQuery),
                FilterParameter = SelectQuery.Tenant,
                FilterCommand = viewModel.FilterCommand,
                SelectedValue = $"{nameof(viewModel.Edited)}.{nameof(Transaction.TenantId)}",
                NonEditable = new Binding($"{nameof(viewModel.Selected)}.{nameof(Transaction.TenantName)}")
            };
            plot = new ComboSelect() {
                Hint = "Plot",
                Icon = Icons.Plot,
                IsRequired = true,
                DisplayPath = nameof(Lease.PlotName),
                SelectedValuePath = nameof(Lease.PlotId),
                ItemsSource = nameof(viewModel.Plots),
                Error = nameof(viewModel.ErrorPlotId),
                Query = nameof(viewModel.PlotQuery),
                FilterParameter = SelectQuery.Plot,
                FilterCommand = viewModel.FilterCommand,
                SelectedValue = $"{nameof(viewModel.Edited)}.{nameof(Lease.PlotId)}",
                NonEditable = new Binding($"{nameof(viewModel.Selected)}.{nameof(Lease.PlotId)}") { Converter = App.convert.plotId2plotName }
            };
            space = new ComboSelect() {
                Hint = "Space",
                Icon = Icons.Space,
                IsRequired = true,
                SelectedValuePath = nameof(Lease.SpaceId),
                ItemTemplate = new TransactionSpaceTemplate(nameof(viewModel.SpaceQuery), viewModel),
                ItemsSource = nameof(viewModel.Spaces),
                Error = nameof(viewModel.ErrorSpaceId),
                Query = nameof(viewModel.SpaceQuery),
                FilterParameter = SelectQuery.Space,
                FilterCommand = viewModel.FilterCommand,
                SelectedValue = $"{nameof(viewModel.Edited)}.{nameof(Lease.SpaceId)}",
                NonEditable = new Binding($"{nameof(viewModel.Selected)}.{nameof(Lease.SpaceId)}") { Converter = App.convert.spaceId2spaceName }
            };
            controlHead = new ComboSelect() {
                Hint = "Control",
                Icon = Icons.ControlHead,
                IsRequired = true,
                SelectedValuePath = nameof(ControlHead.Id),
                DisplayPath = nameof(ControlHead.Name),
                ItemsSource = nameof(viewModel.ControlHeads),
                Error = nameof(viewModel.ErrorControlId),
                Query = nameof(viewModel.ControlQuery),
                FilterParameter = SelectQuery.ControlHead,
                FilterCommand = viewModel.FilterCommand,
                SelectedValue = $"{nameof(viewModel.Edited)}.{nameof(Transaction.ControlId)}",
                NonEditable = new Binding($"{nameof(viewModel.Selected)}.{nameof(Transaction.ControlId)}") { Converter = App.convert.controlId2ControlName }
            };
            head = new ComboSelect() {
                Hint = "Head",
                Icon = Icons.Head,
                IsRequired = true,
                SelectedValuePath = nameof(Head.Id),
                DisplayPath = nameof(Head.Name),
                ItemsSource = nameof(viewModel.Heads),
                Error = nameof(viewModel.ErrorHeadId),
                Query = nameof(viewModel.HeadQuery),
                FilterParameter = SelectQuery.Head,
                FilterCommand = viewModel.FilterCommand,
                SelectedValue = $"{nameof(viewModel.Edited)}.{nameof(Transaction.HeadId)}",
                NonEditable = new Binding($"{nameof(viewModel.Selected)}.{nameof(Transaction.HeadId)}") { Converter = App.convert.headId2headName }
            };
            date = new ComboDate() {
                Hint = "Date",
                IsRequired = true,
                Editable = $"{nameof(viewModel.Edited)}.{nameof(Transaction.Date)}",
                NonEditable = $"{nameof(viewModel.Selected)}.{nameof(Transaction.Date)}",
                Error = nameof(viewModel.ErrorDate)
            };
            amount = new ComboText() {
                Hint = "Amount",
                Icon = Icons.Amount,
                IsRequired = true,
                Editable = nameof(viewModel.Amount),
                NonEditable = $"{nameof(viewModel.Selected)}.{nameof(Transaction.Amount)}",
                Error = nameof(viewModel.ErrorAmount)
            };
            isCash = new ComboBiState() {
                Text = "Is cash?",
                Editable = $"{nameof(viewModel.Edited)}.{nameof(Transaction.IsCash)}",
                NonEditable = $"{nameof(viewModel.Selected)}.{nameof(Transaction.IsCash)}",
                Margin = new Thickness(5, 0, 0, 0),
                VerticalAlignment = VerticalAlignment.Center
            };
            Grid.SetColumn(isCash, 1);
            var amountGrid = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = new GridLength(1, GridUnitType.Auto) }
                },
                Children = { amount, isCash }
            };
            narration = new ComboText() {
                Hint = "Narration",
                Icon = Icons.Description,
                IsRequired = true,
                IsMultiline = true,
                Editable = $"{nameof(viewModel.Edited)}.{nameof(Transaction.Narration)}",
                NonEditable = $"{nameof(viewModel.Selected)}.{nameof(Transaction.Narration)}",
                Error = nameof(viewModel.ErrorNarration)
            };
            buttons = new ComboButton() {
                EditCommand = viewModel.SetIsOnEdit,
                CancelCommand = viewModel.ResetIsOnEdit,
                SaveCommand = viewModel.Save,
                IsValid = nameof(viewModel.IsValid)
            };
            Grid.SetColumn(delete, 1);
            Grid.SetRow(tenant, 1);
            Grid.SetColumnSpan(tenant, 2);
            Grid.SetRow(plot, 2);
            Grid.SetRow(space, 2);
            Grid.SetColumn(space, 1);
            Grid.SetRow(controlHead, 3);
            Grid.SetRow(head, 3);
            Grid.SetColumn(head, 1);
            Grid.SetRow(date, 4);
            Grid.SetRow(amountGrid, 4);
            Grid.SetColumn(amountGrid, 1);
            Grid.SetRow(narration, 5);
            Grid.SetColumnSpan(narration, 2);
            Grid.SetRow(buttons, 6);
            Grid.SetColumnSpan(buttons, 2);
            editableGrid = new Grid() {
                Margin = new Thickness(10, 0, 0, 0),
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition()
                },
                RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(),
                    new RowDefinition(){ Height = GridLength.Auto }
                },
                Children = { delete, tenant, plot, space, controlHead, head, date, amountGrid, narration, buttons }
            };
        }

        void bind() {
            queryDate.SetBinding(DayPicker.SelectedDateProperty, new Binding(nameof(viewModel.TransactionDate)));
            transactions.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(viewModel.Editables)));
            transactions.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(viewModel.Selected)));
            refresh.SetBinding(CommandButton.IsEnabledProperty, new Binding(nameof(viewModel.IsRefreshValid)));

            var binding = new Binding(nameof(viewModel.IsOnEdit));
            tenant.SetBinding(ComboSelect.IsOnEditProperty, binding);
            plot.SetBinding(ComboSelect.IsOnEditProperty, binding);
            space.SetBinding(ComboSelect.IsOnEditProperty, binding);
            controlHead.SetBinding(ComboSelect.IsOnEditProperty, binding);
            head.SetBinding(ComboSelect.IsOnEditProperty, binding);
            amount.SetBinding(ComboText.IsOnEditProperty, binding);
            date.SetBinding(ComboDate.IsOnEditProperty, binding);
            isCash.SetBinding(ComboBiState.IsOnEditProperty, binding);
            narration.SetBinding(ComboText.IsOnEditProperty, binding);
            buttons.SetBinding(ComboButton.IsOnEditProperty, binding);

            delete.Resources.Add(typeof(CommandButton), new Style() {
                Triggers = {
                    new DataTrigger() {
                        Binding = new Binding(nameof(viewModel.Selected)),
                        Value = null,
                        Setters = { new Setter(IsEnabledProperty, false) }
                    }
                }
            });

            search.SetBinding(EditText.TextProperty, new Binding(nameof(viewModel.FilterName)) { Mode = BindingMode.OneWayToSource });
            counter.SetBinding(CountBlock.CountProperty, new Binding("Items.Count") { Source = transactions });
        }
    }
}
